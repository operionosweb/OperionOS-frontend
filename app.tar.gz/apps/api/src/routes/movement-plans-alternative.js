import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper: Create audit log entry
const createAuditLog = async (movement_plan_id, action, actionBy, details = {}, newState = {}) => {
  await pb.collection('movement_audit_log').create({
    movement_plan_id,
    action,
    action_by: actionBy,
    action_timestamp: new Date().toISOString(),
    details,
    new_state: JSON.stringify(newState),
  });
};

// Helper: Validate compliance for alternative plan
const validateComplianceForAlternative = (crew, complianceRecords, estimatedMovementHours) => {
  const violations = [];

  // Check duty hours
  const currentDutyHours = complianceRecords.reduce((sum, record) => sum + (record.duty_hours || 0), 0);
  const totalDutyHours = currentDutyHours + estimatedMovementHours;

  if (totalDutyHours > 60) {
    violations.push(`Total duty hours (${totalDutyHours}h) exceed weekly limit (60h)`);
  }

  if (estimatedMovementHours > 10) {
    violations.push(`Estimated movement hours (${estimatedMovementHours}h) exceed daily limit (10h)`);
  }

  // Check rest periods
  if (complianceRecords.length > 0) {
    const lastRestRecord = complianceRecords.sort((a, b) => new Date(b.last_rest) - new Date(a.last_rest))[0];
    if (lastRestRecord && lastRestRecord.last_rest) {
      const hoursSinceRest = (new Date() - new Date(lastRestRecord.last_rest)) / (1000 * 60 * 60);
      if (hoursSinceRest < 8) {
        violations.push(`Insufficient rest: ${hoursSinceRest.toFixed(1)}h since last rest`);
      }
    }
  }

  return violations;
};

// Helper: Generate alternative segments
const generateAlternativeSegments = (originalSegments, disruptedProviderName) => {
  return originalSegments.map(segment => {
    if (segment.provider_name === disruptedProviderName) {
      // Replace with alternative provider
      return {
        ...segment,
        provider_name: `alternative_${segment.provider_type}`,
        is_alternative: true,
      };
    }
    return segment;
  });
};

// POST /movement-plans/:id/generate-alternative
router.post('/:id/generate-alternative', async (req, res) => {
  const { id } = req.params;
  const { disruption_reason } = req.body;

  if (!disruption_reason) {
    return res.status(400).json({ error: 'disruption_reason is required' });
  }

  // (a) Fetch original movement plan
  const originalPlan = await pb.collection('movement_plans').getOne(id);

  // (b) Identify disrupted segment
  const executionStatuses = await pb.collection('execution_status').getList(1, 100, {
    filter: `movement_plan_id="${id}" && (status="delayed" || status="cancelled")`,
  });

  if (executionStatuses.items.length === 0) {
    return res.status(400).json({ error: 'No disrupted segments found' });
  }

  const disruptedSegment = executionStatuses.items[0];
  const originalSegments = JSON.parse(originalPlan.movement_segments);
  const disruptedProviderName = disruptedSegment.provider_name;

  // (c) Regenerate movement segments avoiding disrupted provider
  const newSegments = generateAlternativeSegments(originalSegments, disruptedProviderName);

  // (d) Validate compliance of new segments
  const crew = await pb.collection('crew').getOne(originalPlan.crew_id);
  const complianceRecords = await pb.collection('compliance').getList(1, 50, {
    filter: `crew_id="${originalPlan.crew_id}"`,
  });

  const estimatedMovementHours = 4;
  const violations = validateComplianceForAlternative(crew, complianceRecords.items, estimatedMovementHours);

  // (e) Determine compliance status
  let compliance_status = 'compliant';
  if (violations.length > 0) {
    logger.warn(`Alternative plan has compliance violations: ${violations.join('; ')}`);
    compliance_status = 'at_risk';
  }

  // (f) Create new movement plan
  const alternativePlan = await pb.collection('movement_plans').create({
    crew_id: originalPlan.crew_id,
    origin: originalPlan.origin,
    destination: originalPlan.destination,
    start_date: originalPlan.start_date,
    end_date: originalPlan.end_date,
    movement_segments: JSON.stringify(newSegments),
    status: 'draft',
    created_by: 'system',
    compliance_status,
    compliance_violations: JSON.stringify(violations),
    parent_plan_id: id,
    created_at: new Date().toISOString(),
  });

  // (g) Create audit log on original plan
  await createAuditLog(
    id,
    'adjusted',
    'system',
    `Alternative plan generated due to: ${disruption_reason}`,
    {
      alternative_plan_id: alternativePlan.id,
    }
  );

  logger.info(`Alternative plan generated for plan ${id}: ${alternativePlan.id}`);

  // (h) Return response
  res.json({
    original_plan_id: id,
    alternative_plan_id: alternativePlan.id,
    disruption_reason,
    new_plan: {
      id: alternativePlan.id,
      crew_id: alternativePlan.crew_id,
      origin: alternativePlan.origin,
      destination: alternativePlan.destination,
      status: alternativePlan.status,
      compliance_status: alternativePlan.compliance_status,
      movement_segments: newSegments,
    },
  });
});

export default router;