import { Router } from 'express';
import healthCheck from './health-check.js';
import contactRouter from './contact.js';
import movementPlansRouter from './movement-plans.js';
import executionStatusRouter from './execution-status.js';
import providersRouter from './providers.js';
import movementPlansAlternativeRouter from './movement-plans-alternative.js';
import aiRouter from './ai.js';

const router = Router();

export default () => {
  const appRouter = Router();

  // Movement orchestration routes
  appRouter.use('/movement-plans', movementPlansRouter);
  appRouter.use('/execution-status', executionStatusRouter);
  appRouter.use('/providers', providersRouter);
  appRouter.use('/movement-plans', movementPlansAlternativeRouter);

  // AI chat routes
  appRouter.use('/ai', aiRouter);

  // Existing routes
  appRouter.get('/health', healthCheck);
  appRouter.use('/contact', contactRouter);

  return appRouter;
};