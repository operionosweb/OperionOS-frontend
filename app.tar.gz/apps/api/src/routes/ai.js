import express from 'express';
import { generateAIResponse } from '../utils/aiService.js';
import logger from '../utils/logger.js';

const router = express.Router();

// POST /ai/chat
router.post('/chat', async (req, res) => {
  const { message, context } = req.body;

  // Validate message is provided and not empty
  if (!message || typeof message !== 'string' || message.trim().length === 0) {
    return res.status(400).json({ error: 'Message is required and cannot be empty' });
  }

  // Generate AI response
  const response = generateAIResponse(message, context || {});

  logger.info(`AI chat response generated for message: "${message.substring(0, 50)}..."`);

  // Return response
  res.json({ response });
});

export default router;
