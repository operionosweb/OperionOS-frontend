import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper: Create audit log entry
const createAuditLog = async (movement_plan_id, action, actionBy, details = {}, previousState = {}, newState = {}) => {
  await pb.collection('movement_audit_log').create({
    movement_plan_id,
    action,
    action_by: actionBy,
    action_timestamp: new Date().toISOString(),
    details,
    previous_state: JSON.stringify(previousState),
    new_state: JSON.stringify(newState),
  });
};

// GET /execution-status/:plan_id
router.get('/:plan_id', async (req, res) => {
  const { plan_id } = req.params;

  // (a) Fetch all execution status records
  const executionStatuses = await pb.collection('execution_status').getList(1, 100, {
    filter: `movement_plan_id="${plan_id}"`,
  });

  logger.info(`Fetched execution status for movement plan ${plan_id}`);

  // (b-c) Return array with required fields
  res.json(
    executionStatuses.items.map(es => ({
      id: es.id,
      movement_plan_id: es.movement_plan_id,
      segment_id: es.segment_id,
      provider_name: es.provider_name,
      status: es.status,
      confirmation_reference: es.confirmation_reference,
      crew_location: es.crew_location,
      compliance_status: es.compliance_status,
      last_updated: es.last_updated,
    }))
  );
});

// POST /execution-status/update (Webhook Handler)
router.post('/update', async (req, res) => {
  const { movement_plan_id, segment_id, provider_name, status, confirmation_reference, crew_location, provider_data } = req.body;

  if (!movement_plan_id || !segment_id || !status) {
    return res.status(400).json({
      error: 'Missing required fields: movement_plan_id, segment_id, status',
    });
  }

  // (a) Fetch execution status record
  const executionStatuses = await pb.collection('execution_status').getList(1, 100, {
    filter: `movement_plan_id="${movement_plan_id}" && segment_id="${segment_id}"`,
  });

  let executionStatus;
  if (executionStatuses.items.length === 0) {
    // Create new record if not found
    executionStatus = await pb.collection('execution_status').create({
      movement_plan_id,
      segment_id,
      provider_name,
      status,
      confirmation_reference,
      crew_location,
      compliance_status: 'compliant',
      last_updated: new Date().toISOString(),
    });
  } else {
    executionStatus = executionStatuses.items[0];
  }

  // (b) Determine if disruption
  const disruption_flag = status === 'delayed' || status === 'cancelled';

  // (c) Update execution status
  const updateData = {
    status,
    last_updated: new Date().toISOString(),
    updated_by: 'system',
  };

  if (confirmation_reference) {
    updateData.confirmation_reference = confirmation_reference;
  }
  if (crew_location) {
    updateData.crew_location = crew_location;
  }
  if (status === 'in_progress') {
    updateData.actual_start_time = new Date().toISOString();
  }
  if (status === 'completed') {
    updateData.actual_end_time = new Date().toISOString();
  }

  const updatedStatus = await pb.collection('execution_status').update(executionStatus.id, updateData);

  // (d) Create audit log
  await createAuditLog(
    movement_plan_id,
    'status_updated',
    'system',
    `Segment ${segment_id} status updated to ${status}`,
    { status: executionStatus.status },
    { status }
  );

  // (e) Handle disruptions
  if (disruption_flag) {
    logger.warn(`Disruption detected: ${provider_name} segment ${segment_id} status=${status}`);

    // (e-ii) Fetch movement plan
    const plan = await pb.collection('movement_plans').getOne(movement_plan_id);

    // (e-iii) Trigger alternative plan generation
    // Note: This would normally call POST /movement-plans/:id/generate-alternative internally
    // For now, we'll log the intent
    logger.info(`Alternative plan generation triggered for plan ${movement_plan_id} due to ${status}`);
  }

  logger.info(`Execution status updated for plan ${movement_plan_id}, segment ${segment_id}: ${status}`);

  // (f) Return updated execution status
  res.json({
    id: updatedStatus.id,
    movement_plan_id: updatedStatus.movement_plan_id,
    segment_id: updatedStatus.segment_id,
    provider_name: updatedStatus.provider_name,
    status: updatedStatus.status,
    confirmation_reference: updatedStatus.confirmation_reference,
    crew_location: updatedStatus.crew_location,
    compliance_status: updatedStatus.compliance_status,
    last_updated: updatedStatus.last_updated,
  });
});

// GET /execution-status/:plan_id/location
router.get('/:plan_id/location', async (req, res) => {
  const { plan_id } = req.params;

  // (a) Fetch execution status records where status='in_progress'
  const executionStatuses = await pb.collection('execution_status').getList(1, 100, {
    filter: `movement_plan_id="${plan_id}" && status="in_progress"`,
  });

  logger.info(`Fetched location for movement plan ${plan_id}`);

  // (b-c) If found, return crew location
  if (executionStatuses.items.length > 0) {
    const record = executionStatuses.items[0];
    return res.json({
      crew_location: record.crew_location,
      current_segment: record.segment_id,
      estimated_arrival: record.estimated_arrival || 'TBD',
      status: 'in_progress',
    });
  }

  // (c) If not found, return not in progress
  res.json({
    status: 'not_in_progress',
    message: 'No active movement',
  });
});

export default router;