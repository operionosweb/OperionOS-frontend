import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper: Create audit log entry
const createAuditLog = async (movement_plan_id, action, actionBy, details = {}, previousState = {}, newState = {}) => {
  await pb.collection('movement_audit_log').create({
    movement_plan_id,
    action,
    action_by: actionBy,
    action_timestamp: new Date().toISOString(),
    details,
    previous_state: JSON.stringify(previousState),
    new_state: JSON.stringify(newState),
  });
};

// Helper: Validate certifications
const validateCertifications = (crew, destination, requiredCerts = []) => {
  const crewCerts = crew.certifications || [];
  const violations = [];

  // Check destination-specific certifications
  const destinationCerts = requiredCerts.filter(cert => cert.destination === destination);
  for (const cert of destinationCerts) {
    if (!crewCerts.includes(cert.certification)) {
      violations.push(`Missing certification: ${cert.certification} for destination ${destination}`);
    }
  }

  return violations;
};

// Helper: Calculate duty hours
const calculateDutyHours = (complianceRecords, estimatedMovementHours) => {
  const currentDutyHours = complianceRecords.reduce((sum, record) => sum + (record.duty_hours || 0), 0);
  const totalDutyHours = currentDutyHours + estimatedMovementHours;
  return { currentDutyHours, totalDutyHours, estimatedMovementHours };
};

// Helper: Validate duty hours
const validateDutyHours = (dutyHoursData) => {
  const violations = [];
  const { totalDutyHours, estimatedMovementHours } = dutyHoursData;

  // Check weekly limit (60 hours/week)
  if (totalDutyHours > 60) {
    violations.push(`Total duty hours (${totalDutyHours}h) exceed weekly limit (60h)`);
  }

  // Check daily limit (10 hours/day)
  if (estimatedMovementHours > 10) {
    violations.push(`Estimated movement hours (${estimatedMovementHours}h) exceed daily limit (10h)`);
  }

  return violations;
};

// Helper: Validate rest periods
const validateRestPeriods = (complianceRecords) => {
  const violations = [];

  if (complianceRecords.length === 0) {
    return violations;
  }

  const lastRestRecord = complianceRecords.sort((a, b) => new Date(b.last_rest) - new Date(a.last_rest))[0];
  if (lastRestRecord && lastRestRecord.last_rest) {
    const hoursSinceRest = (new Date() - new Date(lastRestRecord.last_rest)) / (1000 * 60 * 60);
    if (hoursSinceRest < 8) {
      violations.push(`Insufficient rest: ${hoursSinceRest.toFixed(1)}h since last rest (minimum 8h required)`);
    }
  }

  return violations;
};

// Helper: Determine compliance status
const determineComplianceStatus = (allViolations) => {
  if (allViolations.length === 0) {
    return 'compliant';
  }
  // Check if any violation is critical (duty hours or rest)
  const criticalViolations = allViolations.filter(v => v.includes('exceed') || v.includes('Insufficient'));
  return criticalViolations.length > 0 ? 'violated' : 'at_risk';
};

// Helper: Generate movement segments
const generateMovementSegments = (origin, destination, startDate, endDate) => {
  const segments = [];
  const start = new Date(startDate);
  const end = new Date(endDate);

  // Segment 1: Flight
  segments.push({
    id: `seg_${Date.now()}_1`,
    segment_type: 'flight',
    provider_type: 'airline',
    provider_name: 'default_airline',
    origin,
    destination,
    scheduled_date: startDate,
    scheduled_time: '09:00',
    estimated_duration: '2h',
    compliance_check: { is_compliant: true, violations: [] },
  });

  // Segment 2: Accommodation (if multi-day)
  const durationDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
  if (durationDays > 1) {
    segments.push({
      id: `seg_${Date.now()}_2`,
      segment_type: 'accommodation',
      provider_type: 'accommodation',
      provider_name: 'default_hotel',
      location: destination,
      scheduled_date: startDate,
      estimated_duration: `${durationDays}d`,
      compliance_check: { is_compliant: true, violations: [] },
    });
  }

  // Segment 3: Ground transport
  segments.push({
    id: `seg_${Date.now()}_3`,
    segment_type: 'ground_transport',
    provider_type: 'ground_transport',
    provider_name: 'default_logistics',
    origin: destination,
    destination: origin,
    scheduled_date: endDate,
    scheduled_time: '10:00',
    estimated_duration: '1h',
    compliance_check: { is_compliant: true, violations: [] },
  });

  return segments;
};

// POST /movement-plans/generate
router.post('/generate', async (req, res) => {
  const { crew_id, origin, destination, start_date, end_date, constraints } = req.body;

  // Validate input
  if (!crew_id || !origin || !destination || !start_date || !end_date) {
    return res.status(400).json({
      error: 'Missing required fields: crew_id, origin, destination, start_date, end_date',
    });
  }

  // (a) Fetch crew
  const crew = await pb.collection('crew').getOne(crew_id);

  // (b) Fetch compliance records
  const complianceRecords = await pb.collection('compliance').getList(1, 50, {
    filter: `crew_id="${crew_id}"`,
  });

  const allViolations = [];

  // (c) Validate certifications
  const certViolations = validateCertifications(crew, destination, constraints?.required_certifications || []);
  allViolations.push(...certViolations);

  // (d) Check duty hours
  const estimatedMovementHours = 4; // Estimate 4 hours for movement
  const dutyHoursData = calculateDutyHours(complianceRecords.items, estimatedMovementHours);
  const dutyViolations = validateDutyHours(dutyHoursData);
  allViolations.push(...dutyViolations);

  // (e) Check rest periods
  const restViolations = validateRestPeriods(complianceRecords.items);
  allViolations.push(...restViolations);

  // Throw error if critical violations
  if (allViolations.some(v => v.includes('exceed') || v.includes('Insufficient'))) {
    throw new Error(`Compliance validation failed: ${allViolations.join('; ')}`);
  }

  // (f) Generate movement segments
  const movement_segments = generateMovementSegments(origin, destination, start_date, end_date);

  // (g) Determine compliance status
  const compliance_status = determineComplianceStatus(allViolations);

  // (h) Create movement plan
  const plan = await pb.collection('movement_plans').create({
    crew_id,
    origin,
    destination,
    start_date,
    end_date,
    movement_segments: JSON.stringify(movement_segments),
    status: 'draft',
    created_by: 'system', // In real scenario, use @request.auth.id
    compliance_status,
    compliance_violations: JSON.stringify(allViolations),
    created_at: new Date().toISOString(),
  });

  // (i) Create audit log
  await createAuditLog(
    plan.id,
    'created',
    'system',
    'Movement plan generated',
    {},
    plan
  );

  logger.info(`Movement plan generated for crew ${crew_id}: ${plan.id}`);

  // (j) Return plan with compliance details
  res.json({
    plan: {
      id: plan.id,
      crew_id: plan.crew_id,
      origin: plan.origin,
      destination: plan.destination,
      start_date: plan.start_date,
      end_date: plan.end_date,
      status: plan.status,
      movement_segments: JSON.parse(plan.movement_segments),
      compliance_status: plan.compliance_status,
      compliance_violations: JSON.parse(plan.compliance_violations || '[]'),
      created_at: plan.created_at,
    },
  });
});

// GET /movement-plans/:id
router.get('/:id', async (req, res) => {
  const { id } = req.params;

  // (a) Fetch movement plan
  const plan = await pb.collection('movement_plans').getOne(id);

  // (b) Fetch execution status records
  const executionStatuses = await pb.collection('execution_status').getList(1, 100, {
    filter: `movement_plan_id="${id}"`,
  });

  // (c) Fetch provider confirmations
  const providerConfirmations = await pb.collection('provider_confirmations').getList(1, 100, {
    filter: `movement_plan_id="${id}"`,
  });

  // (d) Fetch audit log entries
  const auditLogs = await pb.collection('movement_audit_log').getList(1, 100, {
    filter: `movement_plan_id="${id}"`,
    sort: '-action_timestamp',
  });

  logger.info(`Fetched movement plan ${id}`);

  // (e) Return combined response
  res.json({
    plan: {
      id: plan.id,
      crew_id: plan.crew_id,
      origin: plan.origin,
      destination: plan.destination,
      start_date: plan.start_date,
      end_date: plan.end_date,
      status: plan.status,
      movement_segments: JSON.parse(plan.movement_segments),
      compliance_status: plan.compliance_status,
      compliance_violations: JSON.parse(plan.compliance_violations || '[]'),
      created_at: plan.created_at,
    },
    execution_status: executionStatuses.items.map(es => ({
      id: es.id,
      segment_id: es.segment_id,
      provider_name: es.provider_name,
      status: es.status,
      confirmation_reference: es.confirmation_reference,
      crew_location: es.crew_location,
      compliance_status: es.compliance_status,
      last_updated: es.last_updated,
    })),
    confirmations: providerConfirmations.items.map(pc => ({
      id: pc.id,
      provider_name: pc.provider_name,
      confirmation_reference: pc.confirmation_reference,
      confirmation_data: JSON.parse(pc.confirmation_data || '{}'),
      confirmation_timestamp: pc.confirmation_timestamp,
      status: pc.status,
    })),
    audit_log: auditLogs.items.map(log => ({
      id: log.id,
      action: log.action,
      action_by: log.action_by,
      action_timestamp: log.action_timestamp,
      details: log.details,
      previous_state: JSON.parse(log.previous_state || '{}'),
      new_state: JSON.parse(log.new_state || '{}'),
    })),
  });
});

// POST /movement-plans/:id/approve
router.post('/:id/approve', async (req, res) => {
  const { id } = req.params;
  const { approver_id } = req.body;

  if (!approver_id) {
    return res.status(400).json({ error: 'approver_id is required' });
  }

  // (a) Fetch movement plan
  const plan = await pb.collection('movement_plans').getOne(id);

  // (b) Validate plan status is 'draft'
  if (plan.status !== 'draft') {
    throw new Error(`Cannot approve plan with status '${plan.status}'. Only 'draft' plans can be approved.`);
  }

  // (c) Re-validate compliance
  const violations = JSON.parse(plan.compliance_violations || '[]');
  if (plan.compliance_status === 'violated') {
    throw new Error(`Cannot approve plan with compliance violations: ${violations.join('; ')}`);
  }

  // (d) Update plan
  const updatedPlan = await pb.collection('movement_plans').update(id, {
    status: 'approved',
    approved_by: approver_id,
    approval_date: new Date().toISOString(),
  });

  // (e) Create audit log
  await createAuditLog(
    id,
    'approved',
    approver_id,
    'Plan approved for execution',
    { status: 'draft' },
    { status: 'approved' }
  );

  logger.info(`Movement plan ${id} approved by ${approver_id}`);

  // (f) Return updated plan
  res.json({
    id: updatedPlan.id,
    crew_id: updatedPlan.crew_id,
    origin: updatedPlan.origin,
    destination: updatedPlan.destination,
    status: updatedPlan.status,
    approved_by: updatedPlan.approved_by,
    approval_date: updatedPlan.approval_date,
    movement_segments: JSON.parse(updatedPlan.movement_segments),
  });
});

// POST /movement-plans/:id/send-to-providers
router.post('/:id/send-to-providers', async (req, res) => {
  const { id } = req.params;

  // (a) Fetch movement plan
  const plan = await pb.collection('movement_plans').getOne(id);

  // (b) Validate plan status is 'approved'
  if (plan.status !== 'approved') {
    throw new Error(`Cannot send plan with status '${plan.status}'. Only 'approved' plans can be sent to providers.`);
  }

  const segments = JSON.parse(plan.movement_segments);
  const crew = await pb.collection('crew').getOne(plan.crew_id);
  const confirmations = [];

  // (c) Process each segment
  for (const segment of segments) {
    // (c-i) Fetch provider integration
    const providers = await pb.collection('provider_integrations').getList(1, 100, {
      filter: `provider_name="${segment.provider_name}"`,
    });

    if (providers.items.length === 0) {
      logger.warn(`No provider integration found for ${segment.provider_name}`);
      continue;
    }

    const provider = providers.items[0];

    // (c-ii) Format segment data based on provider type
    let formattedData = {};
    if (segment.provider_type === 'airline') {
      formattedData = {
        crew_id: plan.crew_id,
        passenger_name: crew.name,
        origin: plan.origin,
        destination: plan.destination,
        departure_date: segment.scheduled_date,
        departure_time: segment.scheduled_time || '09:00',
        special_requirements: crew.certifications || [],
      };
    } else if (segment.provider_type === 'accommodation') {
      formattedData = {
        crew_id: plan.crew_id,
        guest_name: crew.name,
        location: plan.destination,
        check_in_date: segment.scheduled_date,
        check_out_date: plan.end_date,
        room_type: 'standard',
        special_requirements: crew.certifications || [],
      };
    } else if (segment.provider_type === 'ground_transport') {
      formattedData = {
        crew_id: plan.crew_id,
        pickup_location: plan.origin,
        dropoff_location: plan.destination,
        pickup_date: segment.scheduled_date,
        pickup_time: segment.scheduled_time || '10:00',
        special_requirements: crew.certifications || [],
      };
    }

    // (c-iii) Call external provider API
    const response = await fetch(provider.api_endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${provider.api_key}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(formattedData),
    });

    // (c-iv) Check response status
    if (!response.ok) {
      throw new Error(`Provider API error: ${response.status}`);
    }

    // (c-v) Parse response
    const providerResponse = await response.json();

    // (c-vi) Create provider confirmation record
    await pb.collection('provider_confirmations').create({
      movement_plan_id: id,
      provider_name: segment.provider_name,
      confirmation_reference: providerResponse.confirmation_reference,
      confirmation_data: JSON.stringify(providerResponse),
      confirmation_timestamp: new Date().toISOString(),
      status: 'confirmed',
      received_at: new Date().toISOString(),
    });

    // (c-vii) Create execution status record
    await pb.collection('execution_status').create({
      movement_plan_id: id,
      segment_id: segment.id,
      provider_name: segment.provider_name,
      status: 'pending',
      confirmation_reference: providerResponse.confirmation_reference,
      compliance_status: 'compliant',
      last_updated: new Date().toISOString(),
    });

    confirmations.push({
      segment_id: segment.id,
      provider_name: segment.provider_name,
      confirmation_reference: providerResponse.confirmation_reference,
    });

    logger.info(`Segment ${segment.id} sent to ${segment.provider_name}: ${providerResponse.confirmation_reference}`);
  }

  // (d) Update movement plan status
  const updatedPlan = await pb.collection('movement_plans').update(id, {
    status: 'sent_to_providers',
  });

  // (e) Create audit log
  await createAuditLog(
    id,
    'sent_to_providers',
    'system',
    `Plan sent to ${segments.length} providers`,
    { status: 'approved' },
    { status: 'sent_to_providers' }
  );

  logger.info(`Movement plan ${id} sent to ${segments.length} providers`);

  // (f) Return response
  res.json({
    plan: {
      id: updatedPlan.id,
      status: updatedPlan.status,
    },
    confirmations,
  });
});

// GET /movement-plans/:id/audit-log
router.get('/:id/audit-log', async (req, res) => {
  const { id } = req.params;

  // (a) Fetch all audit log records
  const auditLogs = await pb.collection('movement_audit_log').getList(1, 100, {
    filter: `movement_plan_id="${id}"`,
    sort: '-action_timestamp',
  });

  logger.info(`Fetched audit log for movement plan ${id}`);

  // (b-c) Return array sorted by timestamp descending
  res.json(
    auditLogs.items.map(log => ({
      id: log.id,
      movement_plan_id: log.movement_plan_id,
      action: log.action,
      action_by: log.action_by,
      action_timestamp: log.action_timestamp,
      details: log.details,
      previous_state: JSON.parse(log.previous_state || '{}'),
      new_state: JSON.parse(log.new_state || '{}'),
    }))
  );
});

export default router;