import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper: Create audit log entry
const createAuditLog = async (action, actionBy, details = {}, newState = {}) => {
  await pb.collection('movement_audit_log').create({
    action,
    action_by: actionBy,
    action_timestamp: new Date().toISOString(),
    details,
    new_state: JSON.stringify(newState),
  });
};

// GET /providers
router.get('/', async (req, res) => {
  // (a) Fetch all active provider integrations
  const providers = await pb.collection('provider_integrations').getList(1, 100, {
    filter: 'status="active"',
  });

  logger.info(`Fetched ${providers.items.length} active providers`);

  // (b) Return array with required fields
  res.json(
    providers.items.map(p => ({
      id: p.id,
      provider_name: p.provider_name,
      provider_type: p.provider_type,
      integration_type: p.integration_type,
      status: p.status,
      last_sync: p.last_sync,
    }))
  );
});

// POST /providers/:id/sync
router.post('/:id/sync', async (req, res) => {
  const { id } = req.params;

  // (a) Fetch provider integration
  const provider = await pb.collection('provider_integrations').getOne(id);

  // (b) Call provider API
  const response = await fetch(`${provider.api_endpoint}/status`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${provider.api_key}`,
    },
  });

  // (c) Check response status
  if (!response.ok) {
    throw new Error(`Provider sync failed: ${response.status}`);
  }

  // (d) Parse response
  const statusUpdates = await response.json();

  // (e) Process each status update
  const syncResults = [];
  if (Array.isArray(statusUpdates)) {
    for (const update of statusUpdates) {
      // (e-i) Find corresponding execution status record
      const executionStatuses = await pb.collection('execution_status').getList(1, 100, {
        filter: `movement_plan_id="${update.movement_plan_id}" && segment_id="${update.segment_id}"`,
      });

      if (executionStatuses.items.length > 0) {
        // (e-ii) Call POST /execution-status/update internally
        try {
          const updateResponse = await fetch('http://localhost:3001/hcgi/api/execution-status/update', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              movement_plan_id: update.movement_plan_id,
              segment_id: update.segment_id,
              provider_name: update.provider_name,
              status: update.status,
              confirmation_reference: update.confirmation_reference,
              crew_location: update.crew_location,
              provider_data: update.provider_data,
            }),
          });

          if (updateResponse.ok) {
            syncResults.push({
              movement_plan_id: update.movement_plan_id,
              segment_id: update.segment_id,
              status: update.status,
              synced: true,
            });
          }
        } catch (error) {
          logger.error(`Failed to sync update for plan ${update.movement_plan_id}:`, error.message);
          syncResults.push({
            movement_plan_id: update.movement_plan_id,
            segment_id: update.segment_id,
            synced: false,
            error: error.message,
          });
        }
      }
    }
  }

  // (f) Update provider integration last_sync
  await pb.collection('provider_integrations').update(id, {
    last_sync: new Date().toISOString(),
  });

  // (g) Create audit log
  await createAuditLog(
    'provider_sync',
    'system',
    `Synced with provider ${provider.provider_name}`,
    {
      provider_id: id,
      sync_count: syncResults.length,
    }
  );

  logger.info(`Provider ${provider.provider_name} synced: ${syncResults.length} updates`);

  // (h) Return response
  res.json({
    provider_name: provider.provider_name,
    synced_records: syncResults.length,
    timestamp: new Date().toISOString(),
  });
});

export default router;