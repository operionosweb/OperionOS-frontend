import express from 'express';
import nodemailer from 'nodemailer';
import logger from '../utils/logger.js';

const router = express.Router();

// Email validation regex
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Validate email format
const isValidEmail = (email) => emailRegex.test(email);

// Create nodemailer transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT, 10),
  secure: process.env.SMTP_PORT === '465', // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

router.post('/send-email', async (req, res) => {
  const { name, email, subject, message } = req.body;

  // Validate all fields are present
  if (!name || !email || !subject || !message) {
    return res.status(400).json({ error: 'All fields (name, email, subject, message) are required' });
  }

  // Validate email format
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Invalid email format' });
  }

  // Validate name is not empty
  if (typeof name !== 'string' || name.trim().length === 0) {
    return res.status(400).json({ error: 'Name must be a non-empty string' });
  }

  // Validate subject is not empty
  if (typeof subject !== 'string' || subject.trim().length === 0) {
    return res.status(400).json({ error: 'Subject must be a non-empty string' });
  }

  // Validate message is not empty
  if (typeof message !== 'string' || message.trim().length === 0) {
    return res.status(400).json({ error: 'Message must be a non-empty string' });
  }

  // Create HTML email body
  const htmlBody = `
    <html>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px;">
          <h2 style="color: #2c3e50;">New Contact Form Submission</h2>
          <hr style="border: none; border-top: 1px solid #ddd;" />
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Subject:</strong> ${subject}</p>
          <hr style="border: none; border-top: 1px solid #ddd;" />
          <h3 style="color: #2c3e50;">Message:</h3>
          <p>${message.replace(/\n/g, '<br>')}</p>
          <hr style="border: none; border-top: 1px solid #ddd;" />
          <p style="font-size: 12px; color: #7f8c8d;">This email was sent from your contact form.</p>
        </div>
      </body>
    </html>
  `;

  // Send email
  const mailOptions = {
    from: email,
    to: 'crewandtravel@gmail.com',
    subject: subject,
    html: htmlBody,
    replyTo: email,
  };

  await transporter.sendMail(mailOptions);

  logger.info(`Email sent from ${email} with subject: ${subject}`);

  res.json({ success: true, message: 'Email sent successfully' });
});

export default router;