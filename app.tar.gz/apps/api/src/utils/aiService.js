import logger from './logger.js';

/**
 * Generate AI response based on message and context
 * This is a placeholder implementation that generates meaningful responses
 * without calling external AI APIs
 */
const generateAIResponse = (message, context = {}) => {
  if (!message || typeof message !== 'string' || message.trim().length === 0) {
    throw new Error('Message cannot be empty');
  }

  const trimmedMessage = message.trim().toLowerCase();
  const { activeTab, activeCompanyId, currentData } = context;

  // Extract key topics from message
  const topics = extractTopics(trimmedMessage);

  // Generate contextual response
  let response = generateContextualResponse(trimmedMessage, topics, { activeTab, activeCompanyId, currentData });

  logger.info(`AI response generated for message: "${message.substring(0, 50)}..."`);

  return response;
};

/**
 * Extract key topics from the message
 */
const extractTopics = (message) => {
  const topics = [];

  // Movement/logistics related
  if (message.includes('movement') || message.includes('crew') || message.includes('transport')) {
    topics.push('movement');
  }

  // Compliance related
  if (message.includes('compliance') || message.includes('violation') || message.includes('regulation')) {
    topics.push('compliance');
  }

  // Provider related
  if (message.includes('provider') || message.includes('airline') || message.includes('hotel') || message.includes('logistics')) {
    topics.push('provider');
  }

  // Status/tracking related
  if (message.includes('status') || message.includes('track') || message.includes('location') || message.includes('where')) {
    topics.push('status');
  }

  // Help/guidance related
  if (message.includes('help') || message.includes('how') || message.includes('what') || message.includes('guide')) {
    topics.push('help');
  }

  // Planning related
  if (message.includes('plan') || message.includes('schedule') || message.includes('arrange')) {
    topics.push('planning');
  }

  return topics;
};

/**
 * Generate contextual response based on topics and context
 */
const generateContextualResponse = (message, topics, context) => {
  const { activeTab, activeCompanyId, currentData } = context;

  // Movement/crew management responses
  if (topics.includes('movement')) {
    if (message.includes('create') || message.includes('generate')) {
      return 'I can help you create a new movement plan. To get started, I need the crew ID, origin, destination, and travel dates. Would you like me to guide you through the process?';
    }
    if (message.includes('view') || message.includes('show')) {
      return 'You can view all movement plans in the Movement Plans section. Each plan shows the crew, route, status, and compliance information. Would you like to see details for a specific plan?';
    }
    return 'I understand you need help with crew movement planning. I can assist with creating plans, tracking status, managing providers, and ensuring compliance. What would you like to do?';
  }

  // Compliance responses
  if (topics.includes('compliance')) {
    if (message.includes('violation') || message.includes('issue')) {
      return 'Compliance violations are critical. I can help you review violations, understand the requirements, and generate alternative plans to resolve them. Would you like to see the current compliance status?';
    }
    if (message.includes('check') || message.includes('validate')) {
      return 'I can validate compliance for crew movements. This includes checking duty hours, rest periods, certifications, and regulatory requirements. Which crew or plan would you like me to check?';
    }
    return 'I can help you manage compliance requirements. This includes duty hour limits, rest period validation, certification checks, and regulatory compliance. What compliance information do you need?';
  }

  // Provider responses
  if (topics.includes('provider')) {
    if (message.includes('sync') || message.includes('update')) {
      return 'I can sync with your providers to get the latest status updates. This includes flight confirmations, accommodation bookings, and ground transport details. Would you like me to sync now?';
    }
    if (message.includes('list') || message.includes('view')) {
      return 'You have several integrated providers available. I can show you active providers, their integration status, and last sync time. Would you like to see the provider list?';
    }
    return 'I can help you manage provider integrations. This includes syncing status updates, managing confirmations, and handling disruptions. Which provider would you like to work with?';
  }

  // Status/tracking responses
  if (topics.includes('status')) {
    if (message.includes('location') || message.includes('where')) {
      return 'I can track the current location of crew members during active movements. This shows real-time location data, current segment, and estimated arrival time. Which movement would you like to track?';
    }
    if (message.includes('update')) {
      return 'I can update the status of movement segments. This includes marking segments as in-progress, completed, delayed, or cancelled. Which segment needs a status update?';
    }
    return 'I can help you track movement status. This includes viewing execution status, location tracking, and status history. Which movement would you like to check?';
  }

  // Planning responses
  if (topics.includes('planning')) {
    return 'I can help you plan crew movements. This includes generating movement plans, validating compliance, managing providers, and handling disruptions. What would you like to plan?';
  }

  // Help/guidance responses
  if (topics.includes('help')) {
    return 'I\'m here to help with crew movement management. I can assist with: creating movement plans, tracking status, managing providers, validating compliance, and handling disruptions. What would you like help with?';
  }

  // Default response
  return `I understand you're asking about: "${message}". I can help with crew movement planning, compliance management, provider coordination, and status tracking. Could you provide more details about what you need?`;
};

export { generateAIResponse };
