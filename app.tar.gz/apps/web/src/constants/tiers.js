
export const PRODUCT_TIERS = {
  STARTER: 'starter',
  PROFESSIONAL: 'professional',
  ENTERPRISE: 'enterprise'
};

export const TIER_FEATURES = {
  [PRODUCT_TIERS.STARTER]: [
    'core_dashboard',
    'basic_reporting',
    'manual_movements'
  ],
  [PRODUCT_TIERS.PROFESSIONAL]: [
    'core_dashboard',
    'basic_reporting',
    'manual_movements',
    'automated_movements',
    'ai_assistant',
    'advanced_analytics',
    'command_center'
  ],
  [PRODUCT_TIERS.ENTERPRISE]: [
    'core_dashboard',
    'basic_reporting',
    'manual_movements',
    'automated_movements',
    'ai_assistant',
    'advanced_analytics',
    'command_center',
    'investor_mode',
    'multi_company',
    'api_access'
  ]
};
