
export const ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  OPERATOR: 'operator',
  VIEWER: 'viewer'
};

export const ROLE_PERMISSIONS = {
  [ROLES.SUPER_ADMIN]: {
    canViewControlPanel: true,
    canViewCommandCenter: true,
    canViewAnalytics: true,
    canManageUsers: true,
    canManageCompany: true,
    canAccessAI: true,
    canViewAllData: true,
    canExport: true
  },
  [ROLES.ADMIN]: {
    canViewControlPanel: true,
    canViewCommandCenter: true,
    canViewAnalytics: true,
    canManageUsers: true,
    canManageCompany: false,
    canAccessAI: true,
    canViewAllData: true,
    canExport: true
  },
  [ROLES.OPERATOR]: {
    canViewControlPanel: true,
    canViewCommandCenter: false,
    canViewAnalytics: false,
    canManageUsers: false,
    canManageCompany: false,
    canAccessAI: true,
    canViewAllData: false,
    canExport: false
  },
  [ROLES.VIEWER]: {
    canViewControlPanel: true,
    canViewCommandCenter: false,
    canViewAnalytics: false,
    canManageUsers: false,
    canManageCompany: false,
    canAccessAI: false,
    canViewAllData: false,
    canExport: false
  }
};
