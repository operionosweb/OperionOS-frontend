
export const LIFECYCLE_STAGES = {
  NEW_USER: 'new_user',
  ONBOARDING: 'onboarding',
  ACTIVE_USER: 'active_user',
  ADMIN_MODE: 'admin_mode'
};

export const FEATURE_ROLES = {
  investor_mode: ['super_admin'],
  command_center: ['super_admin', 'admin'],
  analytics: ['super_admin', 'admin'],
  operations: ['super_admin', 'admin', 'operator'],
  overview: ['super_admin', 'admin', 'operator', 'viewer'],
  manage_users: ['super_admin', 'admin']
};

export const FEATURE_TIERS = {
  investor_mode: ['enterprise'],
  command_center: ['enterprise', 'professional'],
  analytics: ['enterprise', 'professional'],
  operations: ['enterprise', 'professional', 'starter'],
  overview: ['enterprise', 'professional', 'starter'],
  multi_company: ['enterprise']
};
