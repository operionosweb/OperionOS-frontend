
# Real-Time Event System Documentation

## Overview
The Event System provides a robust, decoupled architecture for real-time data synchronization and cross-component communication within the Operion platform. It consists of an `EventEmitter` (Event Bus), a `DataSyncManager` for polling and change detection, and React Context/Hooks for seamless integration.

## Architecture
1. **EventBus (`lib/eventBus.js`)**: A standard pub/sub implementation supporting multiple listeners, one-time listeners, and payload delivery.
2. **DataSyncManager (`lib/dataSyncManager.js`)**: Polls data sources, performs deep comparisons using `lib/changeDetection.js`, and emits events only when actual changes occur.
3. **EventContext (`contexts/EventContext.jsx`)**: Provides the singleton instances of the EventBus and DataSyncManager to the React tree.
4. **Hooks**: `useRealTimeEvents` and `useDataSync` provide clean APIs for components to interact with the system.

## Event Types & Payloads
Defined in `types/events.js`.

*   `CONTRACT_UPDATED`: Emitted when a contract is modified or added.
    *   Payload: `{ contractId, data, changes, timestamp, source }`
*   `FLEET_UPDATED`: Emitted when fleet/vessel data changes.
*   `USER_UPDATED`: Emitted when user data changes.
*   `ALERT_TRIGGERED`: Emitted when a new system alert is generated.
*   `DATA_SYNC_STARTED` / `DATA_SYNC_COMPLETED`: Emitted during the polling lifecycle.

## Hook Usage Examples

### `useRealTimeEvents`
Subscribe to specific events and automatically unsubscribe on unmount.

