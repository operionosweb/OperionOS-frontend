
# OPERION OS CORE - Integration Checklist & Validation

## 1. System Layer Validation (Production Environment)
- [ ] **Condition:** Log in or impersonate a company ID other than the demo ID.
- [ ] **Test:** Verify `getActiveLayer()` returns `SYSTEM_LAYER`.
- [ ] **Test:** Ensure "Simulation" and "Command Center" tabs are NOT visible.
- [ ] **Test:** Ensure Investor and Fundraising toggle buttons are NOT visible.
- [ ] **Test:** Crew tab displays real users from PocketBase `users` collection.
- [ ] **Test:** Isolation Guard does not throw warnings.

## 2. Demo Layer Validation (Simulation Environment)
- [ ] **Condition:** Impersonate demo company ID (`6c091a44...`).
- [ ] **Test:** Verify `getActiveLayer()` returns `DEMO_LAYER`.
- [ ] **Test:** "Simulation" and "Command Center" tabs appear in the layout navigation.
- [ ] **Test:** Investor and Fundraising toggle buttons appear next to company selector.
- [ ] **Test:** Crew tab displays 35 generated mock crew members.
- [ ] **Test:** Fleet tab displays 18 generated mock aircraft/vessels.

## 3. Data & State Isolation Validation
- [ ] **Test:** Navigate between System Layer and Demo Layer. Verify state resets (e.g., active tabs reset to Overview if returning to System Layer from a Demo-only tab).
- [ ] **Test:** Force a mock data array into a System Layer view via code injection. Verify `DemoIsolationGuard` console warning (`[ISOLATION BREACH]`) triggers and Sonner toast appears.

## 4. Overlay Validation
- **AI Assistant:**
  - [ ] **Test:** Click floating Bot icon in bottom right. Panel slides in smoothly.
  - [ ] **Test:** Assistant greeting dynamically reads the active tab context (e.g., "Context: overview").
  - [ ] **Test:** Typing a message and pressing enter shows a simulated AI typing response.
- **Command Palette:**
  - [ ] **Test:** Press `Ctrl+K` or `Cmd+K`. Palette opens globally regardless of active tab.
  - [ ] **Test:** Fuzzy search works (e.g., typing "maint" filters to maintenance commands).
  - [ ] **Test:** Executing a navigation command correctly updates the `OperionOSContext` active tab.

## 5. Backward Compatibility Validation
- [ ] **Test:** The overarching Layout structure preserves Header visibility and mobile responsiveness.
- [ ] **Test:** The specific components inside the Overview tab (Live Map, ROI charts, Feed) still render correctly without throwing prop errors.
- [ ] **Test:** `useImpersonation` context maintains correct sync with the new `OperionOSContext`.
