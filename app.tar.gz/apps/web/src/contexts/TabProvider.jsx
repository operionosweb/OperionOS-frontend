
import React, { createContext, useContext, useState, useCallback } from 'react';

const TabContext = createContext(null);

export const TabProvider = ({ children }) => {
  const [tabDataCache, setTabDataCache] = useState({});
  const [tabLoading, setTabLoading] = useState({});

  const loadTabData = useCallback(async (tabId, fetcherFn) => {
    if (tabDataCache[tabId]) return; // Use cache if exists
    
    setTabLoading(prev => ({ ...prev, [tabId]: true }));
    try {
      const data = await fetcherFn();
      setTabDataCache(prev => ({ ...prev, [tabId]: data }));
    } catch (e) {
      console.error(`Error loading tab ${tabId}`, e);
    } finally {
      setTabLoading(prev => ({ ...prev, [tabId]: false }));
    }
  }, [tabDataCache]);

  const manualRefresh = useCallback(async (tabId, fetcherFn) => {
    setTabLoading(prev => ({ ...prev, [tabId]: true }));
    try {
      const data = await fetcherFn();
      setTabDataCache(prev => ({ ...prev, [tabId]: data }));
    } catch (e) {
      console.error(`Error refreshing tab ${tabId}`, e);
    } finally {
      setTabLoading(prev => ({ ...prev, [tabId]: false }));
    }
  }, []);

  const clearCache = useCallback(() => {
    setTabDataCache({});
  }, []);

  const refreshTabData = useCallback(async (tabId, fetcherFn) => {
    clearCache();
    await manualRefresh(tabId, fetcherFn);
  }, [clearCache, manualRefresh]);

  return (
    <TabContext.Provider value={{
      tabDataCache,
      tabLoading,
      loadTabData,
      manualRefresh,
      clearCache,
      refreshTabData
    }}>
      {children}
    </TabContext.Provider>
  );
};

export const useTabData = () => {
  const ctx = useContext(TabContext);
  if (!ctx) throw new Error('useTabData must be used within TabProvider');
  return ctx;
};
