
import React, { createContext, useState, useEffect } from 'react';

export const CompanyContext = createContext(null);

export const CompanyProvider = ({ children }) => {
  const [companyId, setCompanyId] = useState(() => {
    return localStorage.getItem('operion_active_company') || 'comp_default';
  });

  const [companyProfile, setCompanyProfile] = useState({
    name: 'Operion Demo Corp',
    industry: 'Maritime',
    crewSize: 150
  });

  useEffect(() => {
    localStorage.setItem('operion_active_company', companyId);
  }, [companyId]);

  const updateCompanyProfile = (updates) => {
    setCompanyProfile(prev => ({ ...prev, ...updates }));
  };

  return (
    <CompanyContext.Provider value={{ 
      companyId, 
      setCompanyId, 
      companyProfile, 
      updateCompanyProfile 
    }}>
      {children}
    </CompanyContext.Provider>
  );
};
