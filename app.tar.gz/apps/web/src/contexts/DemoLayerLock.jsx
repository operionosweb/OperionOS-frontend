
import React, { createContext, useContext, useCallback } from 'react';
import { logViolation } from '@/lib/ViolationLogger.js';
import { VIOLATION_TYPES, SEVERITY } from '@/lib/FoundationLockConfig.js';

const DemoLayerLockContext = createContext(null);

export const DemoLayerLockProvider = ({ children }) => {
  
  const enforceDemoIsolation = useCallback((tableName) => {
    if (!tableName.startsWith('demo_')) {
      logViolation(VIOLATION_TYPES.LAYER, SEVERITY.CRITICAL, `Demo layer attempted access to non-demo table: ${tableName}`);
      return false;
    }
    return true;
  }, []);

  const ensureStaticSandbox = useCallback(() => {
    logViolation(VIOLATION_TYPES.MODE, SEVERITY.INFO, `Demo sandbox static constraint verified.`);
  }, []);

  return (
    <DemoLayerLockContext.Provider value={{ enforceDemoIsolation, ensureStaticSandbox }}>
      {children}
    </DemoLayerLockContext.Provider>
  );
};

export const useDemoLayerLock = () => {
  const context = useContext(DemoLayerLockContext);
  if (!context) throw new Error('useDemoLayerLock must be used within DemoLayerLockProvider');
  return context;
};
