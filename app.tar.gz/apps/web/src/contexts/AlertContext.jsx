
import React, { createContext, useContext, useState, useCallback, useMemo } from 'react';

const AlertContext = createContext(null);

export function AlertProvider({ children }) {
  const [alerts, setAlerts] = useState([]);
  const [dismissedAlerts, setDismissedAlerts] = useState(new Set());

  const addAlert = useCallback((alert) => {
    setAlerts(prev => {
      // Prevent exact duplicates
      if (prev.some(a => a.id === alert.id)) return prev;
      return [alert, ...prev].slice(0, 50); // Keep max 50 in state
    });
  }, []);

  const removeAlert = useCallback((alertId) => {
    setAlerts(prev => prev.filter(a => a.id !== alertId));
  }, []);

  const acknowledgeAlert = useCallback((alertId) => {
    setAlerts(prev => prev.map(a => 
      a.id === alertId ? { ...a, read: true } : a
    ));
  }, []);

  const dismissAlert = useCallback((alertId) => {
    setDismissedAlerts(prev => {
      const next = new Set(prev);
      next.add(alertId);
      return next;
    });
    removeAlert(alertId);
  }, [removeAlert]);

  const activeAlerts = useMemo(() => {
    return alerts.filter(a => !dismissedAlerts.has(a.id));
  }, [alerts, dismissedAlerts]);

  const alertStats = useMemo(() => {
    return activeAlerts.reduce((acc, alert) => {
      if (!alert.read) {
        acc[alert.severity] = (acc[alert.severity] || 0) + 1;
        acc.total += 1;
      }
      return acc;
    }, { critical: 0, warning: 0, info: 0, total: 0 });
  }, [activeAlerts]);

  const value = {
    alerts: activeAlerts,
    alertStats,
    addAlert,
    removeAlert,
    acknowledgeAlert,
    dismissAlert
  };

  return (
    <AlertContext.Provider value={value}>
      {children}
    </AlertContext.Provider>
  );
}

export function useAlert() {
  const context = useContext(AlertContext);
  if (!context) {
    // Return safe defaults if used outside provider
    return {
      alerts: [],
      alertStats: { critical: 0, warning: 0, info: 0, total: 0 },
      addAlert: () => {},
      removeAlert: () => {},
      acknowledgeAlert: () => {},
      dismissAlert: () => {}
    };
  }
  return context;
}
