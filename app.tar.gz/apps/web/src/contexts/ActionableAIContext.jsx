
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useCopilot } from '@/contexts/CopilotContext.jsx';
import { useUserRole } from '@/hooks/useUserRole.js';
import { useAuthGuard } from '@/hooks/useAuthGuard.js';
import { ActionExecutor } from '@/lib/ActionExecutor.js';
import { AuditLogger } from '@/lib/AuditLogger.js';
import { ACTION_STATUS } from '@/lib/ActionableAIEngine.js';
import { toast } from 'sonner';

const ActionableAIContext = createContext(null);

export function ActionableAIProvider({ children }) {
  const { alerts } = useCopilot();
  const { role } = useUserRole();
  const { user } = useAuthGuard();
  
  const [actions, setActions] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [executingActionId, setExecutingActionId] = useState(null);
  const [executionProgress, setExecutionProgress] = useState({ percent: 0, message: '' });

  // Load initial audit logs
  useEffect(() => {
    setAuditLogs(AuditLogger.getLogs());
  }, []);

  // Sync actions from Copilot alerts
  useEffect(() => {
    if (!alerts || alerts.length === 0) return;

    setActions(prevActions => {
      const existingIds = new Set(prevActions.map(a => a.insightId));
      const newActions = alerts
        .filter(alert => alert.recommendedAction && !existingIds.has(alert.id))
        .map(alert => alert.recommendedAction);

      if (newActions.length === 0) return prevActions;
      
      // Keep existing actions that are still relevant or in progress, add new ones
      return [...newActions, ...prevActions].sort((a, b) => b.priority - a.priority);
    });
  }, [alerts]);

  const updateActionStatus = useCallback((actionId, updates) => {
    setActions(prev => prev.map(a => a.id === actionId ? { ...a, ...updates } : a));
  }, []);

  const cancelAction = useCallback((actionId) => {
    updateActionStatus(actionId, { status: ACTION_STATUS.CANCELLED });
    
    const action = actions.find(a => a.id === actionId);
    if (action) {
      const logEntry = AuditLogger.log({
        actionId: action.id,
        actionTitle: action.title,
        category: action.category,
        status: ACTION_STATUS.CANCELLED,
        initiatedBy: user?.id || 'system',
        affectedEntities: action.targetEntities?.length || 0,
        result: { message: 'Action cancelled by user.' }
      });
      if (logEntry) setAuditLogs(prev => [logEntry, ...prev]);
    }
    
    toast.info('Action cancelled');
  }, [actions, updateActionStatus, user]);

  const executeAction = useCallback(async (actionId) => {
    if (role !== 'super_admin') {
      toast.error('Unauthorized: Only Super Admins can execute automated actions.');
      return;
    }

    const action = actions.find(a => a.id === actionId);
    if (!action) return;

    setExecutingActionId(actionId);
    setExecutionProgress({ percent: 0, message: 'Starting execution...' });
    updateActionStatus(actionId, { 
      status: ACTION_STATUS.EXECUTING,
      approvedBy: user?.id || 'admin',
      timestamps: { ...action.timestamps, approved: Date.now() }
    });

    try {
      const resultAction = await ActionExecutor.execute(action, user, (percent, message) => {
        setExecutionProgress({ percent, message });
      });

      updateActionStatus(actionId, resultAction);

      // Log to audit
      const logEntry = AuditLogger.log({
        actionId: resultAction.id,
        actionTitle: resultAction.title,
        category: resultAction.category,
        status: resultAction.status,
        initiatedBy: 'system',
        approvedBy: user?.id || 'admin',
        executedBy: resultAction.executedBy,
        affectedEntities: resultAction.targetEntities?.length || 0,
        result: resultAction.result
      });
      
      if (logEntry) setAuditLogs(prev => [logEntry, ...prev]);

      if (resultAction.status === ACTION_STATUS.COMPLETED) {
        toast.success('Action executed successfully');
      } else {
        toast.error('Action execution failed');
      }

    } catch (error) {
      console.error('Execution error:', error);
      updateActionStatus(actionId, { status: ACTION_STATUS.FAILED });
      toast.error('An unexpected error occurred during execution.');
    } finally {
      setExecutingActionId(null);
      setExecutionProgress({ percent: 0, message: '' });
    }
  }, [actions, role, updateActionStatus, user]);

  const clearAuditLogs = useCallback(() => {
    AuditLogger.clear();
    setAuditLogs([]);
    toast.success('Audit logs cleared');
  }, []);

  const pendingActions = actions.filter(a => a.status === ACTION_STATUS.PENDING);

  return (
    <ActionableAIContext.Provider value={{
      actions,
      pendingActions,
      auditLogs,
      executingActionId,
      executionProgress,
      executeAction,
      cancelAction,
      clearAuditLogs,
      canApprove: role === 'super_admin'
    }}>
      {children}
    </ActionableAIContext.Provider>
  );
}

export function useActionableAI() {
  const context = useContext(ActionableAIContext);
  if (!context) {
    throw new Error('useActionableAI must be used within an ActionableAIProvider');
  }
  return context;
}
