
import React, { createContext, useState, useCallback, useRef } from 'react';
import { FinancialSimulationEngine } from '@/lib/financialSimulationEngine.js';

export const FinancialSimulationContext = createContext(null);

export function FinancialSimulationProvider({ children }) {
  const [simulationCache, setSimulationCache] = useState(new Map());
  const engineRef = useRef(new FinancialSimulationEngine());

  const calculateSimulation = useCallback((contract) => {
    if (!contract || (!contract.id && !contract.contract_id)) return null;
    
    const contractId = contract.contract_id || contract.id;
    
    // Return cached if exists
    if (simulationCache.has(contractId)) {
      return simulationCache.get(contractId);
    }

    const engine = engineRef.current;
    
    const invoiceSchedule = engine.invoiceScheduleGenerator(contract);
    const penalties = engine.penaltyExposureCalculator(contract, invoiceSchedule);
    const scenarios = engine.scenarioAnalyzer(contract, invoiceSchedule, penalties);
    const cashFlowMetrics = engine.calculateCashFlowMetrics(invoiceSchedule);
    const riskScores = engine.calculateFinancialRiskScore(contract, penalties, cashFlowMetrics);

    const result = {
      invoiceSchedule,
      penalties,
      scenarios,
      cashFlowMetrics,
      riskScores,
      lastCalculated: new Date().toISOString()
    };

    setSimulationCache(prev => {
      const next = new Map(prev);
      next.set(contractId, result);
      return next;
    });

    return result;
  }, [simulationCache]);

  return (
    <FinancialSimulationContext.Provider value={{ calculateSimulation, simulationCache }}>
      {children}
    </FinancialSimulationContext.Provider>
  );
}
