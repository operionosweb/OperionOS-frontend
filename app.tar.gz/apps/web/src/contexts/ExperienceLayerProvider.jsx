
import React, { createContext, useContext, useEffect } from 'react';
import { useImpersonation } from '@/contexts/ImpersonationContext.jsx';
import { TabStateProvider } from '@/contexts/TabStateContext.jsx';
import { clearCacheForCompany } from '@/lib/TabDataCache.js';

const ExperienceLayerContext = createContext(null);

export const ExperienceLayerProvider = ({ children }) => {
  const { activeCompanyId } = useImpersonation();
  
  const isDemoActive = activeCompanyId === '6c091a44-952c-4433-944d-c18d02574003';

  useEffect(() => {
    if (activeCompanyId) {
      clearCacheForCompany(activeCompanyId);
    }
  }, [activeCompanyId]);

  return (
    <ExperienceLayerContext.Provider value={{ activeCompanyId, isDemoActive }}>
      <TabStateProvider>
        {children}
      </TabStateProvider>
    </ExperienceLayerContext.Provider>
  );
};

export const useExperienceLayer = () => {
  const ctx = useContext(ExperienceLayerContext);
  if (!ctx) throw new Error('useExperienceLayer must be used within ExperienceLayerProvider');
  return ctx;
};
