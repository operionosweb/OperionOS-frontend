
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useImpersonation } from '@/contexts/ImpersonationContext.jsx';

const OperionOSContext = createContext(null);

export const DEMO_COMPANY_ID = '6c091a44-952c-4433-944d-c18d02574003';

export const OperionOSProvider = ({ children }) => {
  const { activeCompanyId } = useImpersonation();
  
  // OS Level State
  const [activeTab, setActiveTab] = useState('overview');
  
  // Feature Flags & Modes (Only relevant for Demo Layer)
  const [isInvestorMode, setIsInvestorMode] = useState(false);
  const [isFundraisingMode, setIsFundraisingMode] = useState(false);

  // Helper Functions
  const isDemo = () => activeCompanyId === DEMO_COMPANY_ID;
  
  const getActiveLayer = () => isDemo() ? 'DEMO_LAYER' : 'SYSTEM_LAYER';
  
  const getDataSource = () => isDemo() ? 'MOCK_GENERATOR' : 'POCKETBASE_PRODUCTION';
  
  const getFeatureFlags = () => ({
    enableSimulationTab: isDemo(),
    enableInvestorMode: isDemo(),
    enableFundraisingMode: isDemo(),
    enableCommandCenter: isDemo(),
    enableAIInsights: true // Available in both, but data differs
  });

  // State Isolation: Reset modes if we switch out of demo
  useEffect(() => {
    if (!isDemo()) {
      setIsInvestorMode(false);
      setIsFundraisingMode(false);
      if (activeTab === 'simulation' || activeTab === 'command-center') {
        setActiveTab('overview');
      }
    }
  }, [activeCompanyId, activeTab]);

  const value = {
    activeCompanyId,
    activeTab,
    setActiveTab,
    isInvestorMode,
    setIsInvestorMode,
    isFundraisingMode,
    setIsFundraisingMode,
    isDemo,
    getActiveLayer,
    getDataSource,
    getFeatureFlags
  };

  return (
    <OperionOSContext.Provider value={value}>
      {children}
    </OperionOSContext.Provider>
  );
};

export const useOperionOS = () => {
  const context = useContext(OperionOSContext);
  if (!context) {
    throw new Error('useOperionOS must be used within an OperionOSProvider');
  }
  return context;
};
