import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { getInitialData, calculateAircraftStatus, calculateRiskScore, calculateMonthsRemaining } from '@/lib/aviationFleetIntelligenceData.js';
import { toast } from 'sonner';

const AviationFleetContext = createContext();

export const useAviationFleet = () => {
  const context = useContext(AviationFleetContext);
  if (!context) throw new Error('useAviationFleet must be used within an AviationFleetProvider');
  return context;
};

export const AviationFleetProvider = ({ children }) => {
  const [aircraft, setAircraft] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const { aircraft: initialAircraft, contracts: initialContracts } = getInitialData();
    setAircraft(initialAircraft);
    setContracts(initialContracts);
    setIsLoading(false);
  }, []);

  const updateAircraft = (id, updates) => {
    setAircraft(prev => prev.map(a => {
      if (a.aircraftId === id) {
        const updated = { ...a, ...updates };
        if (updates.leaseEndDate) {
          updated.status = calculateAircraftStatus(updates.leaseEndDate);
        }
        if (updates.monthlyCost || updates.maintenanceCost) {
          updated.totalMonthlyCost = (updated.monthlyCost || a.monthlyCost) + (updated.maintenanceCost || a.maintenanceCost || Math.round((updated.monthlyCost || a.monthlyCost)*0.08));
        }
        return updated;
      }
      return a;
    }));
    toast.success(`Aircraft ${id} updated successfully.`);
  };

  const updateContract = (id, updates) => {
    setContracts(prev => prev.map(c => {
      if (c.contractId === id) {
        const updated = { ...c, ...updates };
        if (updates.endDate || updates.penaltyClause) {
          const ac = aircraft.find(a => a.aircraftId === c.aircraftId);
          const monthsRemaining = calculateMonthsRemaining(updated.endDate || c.endDate);
          updated.riskScore = calculateRiskScore(updated.penaltyClause || c.penaltyClause, monthsRemaining, ac?.utilization || 80);
          updated.riskLevel = updated.riskScore > 70 ? 'High' : updated.riskScore > 40 ? 'Medium' : 'Low';
        }
        return updated;
      }
      return c;
    }));
    toast.success(`Contract ${id} updated successfully.`);
  };

  // Derived Insights
  const insights = useMemo(() => {
    if (!aircraft.length || !contracts.length) return {};
    
    const nearingLeaseEnd = aircraft.filter(a => a.alerts.lease_expiring_soon).length;
    const topRiskContracts = [...contracts].sort((a, b) => b.riskScore - a.riskScore).slice(0, 5);
    const avgUtilization = aircraft.reduce((sum, a) => sum + a.utilization, 0) / aircraft.length;
    const avgRiskScore = contracts.reduce((sum, c) => sum + c.riskScore, 0) / contracts.length;
    const underutilizedCount = aircraft.filter(a => a.alerts.underutilized).length;
    
    return {
      nearingLeaseEnd,
      topRiskContracts,
      avgUtilization: avgUtilization.toFixed(1),
      avgRiskScore: avgRiskScore.toFixed(0),
      underutilizedCount
    };
  }, [aircraft, contracts]);

  // Aggregated Alerts
  const allAlerts = useMemo(() => {
    const alerts = [];
    aircraft.forEach(a => {
      if (a.alerts.lease_expiring_soon) alerts.push({ id: `alert-le-${a.aircraftId}`, type: 'lease_expiring_soon', title: `Lease Expiring: ${a.aircraftId}`, relatedId: a.aircraftId, severity: 'high' });
      if (a.alerts.underutilized) alerts.push({ id: `alert-ut-${a.aircraftId}`, type: 'underutilized', title: `Underutilized: ${a.aircraftId} (${a.utilization}%)`, relatedId: a.aircraftId, severity: 'medium' });
      if (a.alerts.high_cost) alerts.push({ id: `alert-hc-${a.aircraftId}`, type: 'high_cost', title: `High Cost: ${a.aircraftId}`, relatedId: a.aircraftId, severity: 'medium' });
    });
    contracts.forEach(c => {
      if (c.alerts.high_risk) alerts.push({ id: `alert-hr-${c.contractId}`, type: 'high_risk', title: `High Risk Contract: ${c.contractId}`, relatedId: c.aircraftId, severity: 'high' });
      if (c.alerts.high_penalty) alerts.push({ id: `alert-hp-${c.contractId}`, type: 'high_penalty', title: `High Penalty: ${c.contractId}`, relatedId: c.aircraftId, severity: 'medium' });
    });
    return alerts;
  }, [aircraft, contracts]);

  const value = {
    aircraft,
    contracts,
    isLoading,
    updateAircraft,
    updateContract,
    insights,
    allAlerts
  };

  return <AviationFleetContext.Provider value={value}>{children}</AviationFleetContext.Provider>;
};