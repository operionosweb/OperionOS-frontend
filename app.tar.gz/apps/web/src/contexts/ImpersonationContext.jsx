
import React, { createContext, useContext, useState } from 'react';

const ImpersonationContext = createContext();

export const ImpersonationProvider = ({ children }) => {
  const [activeCompanyId, setActiveCompanyIdState] = useState(() => localStorage.getItem('impersonate_id') || null);
  const [activeCompanyName, setActiveCompanyName] = useState(() => localStorage.getItem('impersonate_name') || null);

  const setActiveCompany = (id, name) => {
    setActiveCompanyIdState(id);
    setActiveCompanyName(name);
    
    if (id) localStorage.setItem('impersonate_id', id);
    else localStorage.removeItem('impersonate_id');
    
    if (name) localStorage.setItem('impersonate_name', name);
    else localStorage.removeItem('impersonate_name');
  };

  const setActiveCompanyId = (id) => {
    setActiveCompany(id, 'Selected Company'); // Fallback name if only ID is provided
  };

  const exitImpersonation = () => {
    setActiveCompany(null, null);
  };

  return (
    <ImpersonationContext.Provider 
      value={{ 
        activeCompanyId, 
        activeCompanyName, 
        setActiveCompany,
        setActiveCompanyId,
        exitImpersonation 
      }}
    >
      {children}
    </ImpersonationContext.Provider>
  );
};

export const useImpersonation = () => {
  const context = useContext(ImpersonationContext);
  if (context === undefined) {
    throw new Error('useImpersonation must be used within an ImpersonationProvider');
  }
  return context;
};
