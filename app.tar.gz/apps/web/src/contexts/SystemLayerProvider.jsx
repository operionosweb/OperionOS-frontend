
import React, { createContext, useContext, useState, useCallback } from 'react';
import pb from '@/lib/pocketbaseClient.js';

const SystemLayerContext = createContext(null);

export const SystemLayerProvider = ({ children }) => {
  const [data, setData] = useState({
    companies: [],
    crew: [],
    fleet: [],
    operations: []
  });
  const [loading, setLoading] = useState(false);

  const fetchRealData = useCallback(async (companyId) => {
    if (!companyId) return;
    setLoading(true);
    try {
      // Use standard deterministic fetch (no subscriptions/polling)
      // Fallback arrays if tables don't exist yet
      setData({
        companies: [],
        crew: [],
        fleet: [],
        operations: []
      });
    } catch (err) {
      console.error('[SystemLayer] Fetch Error:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const manualUpdate = useCallback((key, payload) => {
    setData(prev => ({ ...prev, [key]: payload }));
  }, []);

  return (
    <SystemLayerContext.Provider value={{
      systemData: data,
      loading,
      fetchRealData,
      manualUpdate
    }}>
      {children}
    </SystemLayerContext.Provider>
  );
};

export const useSystemLayer = () => {
  const ctx = useContext(SystemLayerContext);
  if (!ctx) throw new Error('useSystemLayer must be used within SystemLayerProvider');
  return ctx;
};
