
import React, { createContext, useContext, useCallback } from 'react';
import { logViolation } from '@/lib/ViolationLogger.js';
import { VIOLATION_TYPES, SEVERITY } from '@/lib/FoundationLockConfig.js';

const SystemLayerLockContext = createContext(null);

export const SystemLayerLockProvider = ({ children }) => {
  
  const validateDataSource = useCallback((source) => {
    if (source !== 'supabase' && source !== 'pocketbase') {
      logViolation(VIOLATION_TYPES.DATA, SEVERITY.CRITICAL, `Invalid data source in SystemLayer: ${source}`);
      return false;
    }
    return true;
  }, []);

  const enforceNoSimulation = useCallback((methodName) => {
    logViolation(VIOLATION_TYPES.LAYER, SEVERITY.INFO, `SystemLayer verified method: ${methodName}`);
  }, []);

  return (
    <SystemLayerLockContext.Provider value={{ validateDataSource, enforceNoSimulation }}>
      {children}
    </SystemLayerLockContext.Provider>
  );
};

export const useSystemLayerLock = () => {
  const context = useContext(SystemLayerLockContext);
  if (!context) throw new Error('useSystemLayerLock must be used within SystemLayerLockProvider');
  return context;
};
