import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { 
  generateROIKPIs, 
  generateDisruptionSavings, 
  generateCrewOptimization, 
  generateFlightOperationsSavings, 
  generateAISavingsInsights, 
  generateTimelineData, 
  generateROICalculatorDefaults 
} from '@/lib/aviationROISavingsData.js';
import { toast } from 'sonner';

const AviationROISavingsContext = createContext();

export const useAviationROISavings = () => {
  const context = useContext(AviationROISavingsContext);
  if (!context) throw new Error('useAviationROISavings must be used within AviationROISavingsProvider');
  return context;
};

export const AviationROISavingsProvider = ({ children }) => {
  const [kpis, setKpis] = useState(null);
  const [disruptions, setDisruptions] = useState([]);
  const [crewData, setCrewData] = useState([]);
  const [flightData, setFlightData] = useState([]);
  const [insights, setInsights] = useState([]);
  const [timeline, setTimeline] = useState([]);
  const [calcInputs, setCalcInputs] = useState(null);
  
  const [filters, setFilters] = useState({
    timeRange: '30d',
    airports: [],
    fleet: [],
    routes: [],
    crewType: [],
    category: []
  });

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API load
    const loadData = async () => {
      setIsLoading(true);
      setTimeout(() => {
        setKpis(generateROIKPIs());
        setDisruptions(generateDisruptionSavings(40));
        setCrewData(generateCrewOptimization(30));
        setFlightData(generateFlightOperationsSavings(30));
        setInsights(generateAISavingsInsights(20));
        setTimeline(generateTimelineData(30));
        setCalcInputs(generateROICalculatorDefaults());
        setIsLoading(false);
      }, 800);
    };
    loadData();
  }, []);

  const updateFilters = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    toast.success('Filters applied');
  };

  const resetFilters = () => {
    setFilters({
      timeRange: '30d',
      airports: [],
      fleet: [],
      routes: [],
      crewType: [],
      category: []
    });
    toast.info('Filters reset');
  };

  const applyOptimization = (insightId) => {
    setInsights(prev => prev.map(i => i.id === insightId ? { ...i, status: 'Applied' } : i));
    toast.success('Optimization applied successfully. Recalculating savings...');
    
    // Simulate KPI update
    setTimeout(() => {
      setKpis(prev => ({
        ...prev,
        totalSavings: prev.totalSavings + 150000,
        monthlySavings: prev.monthlySavings + 12500
      }));
    }, 1500);
  };

  const simulateSavings = (insightId) => {
    toast.info('Running simulation engine...', { duration: 2000 });
    setTimeout(() => {
      toast.success('Simulation complete. View detailed report in insights panel.');
    }, 2500);
  };

  const updateROICalculatorInputs = (newInputs) => {
    setCalcInputs(prev => ({ ...prev, ...newInputs }));
  };

  const saveScenario = (scenarioName) => {
    toast.success(`Scenario "${scenarioName}" saved successfully`);
  };

  const value = {
    kpis,
    disruptions,
    crewData,
    flightData,
    insights,
    timeline,
    calcInputs,
    filters,
    isLoading,
    updateFilters,
    resetFilters,
    applyOptimization,
    simulateSavings,
    updateROICalculatorInputs,
    saveScenario
  };

  return (
    <AviationROISavingsContext.Provider value={value}>
      {children}
    </AviationROISavingsContext.Provider>
  );
};