import React, { createContext, useContext, useState, useEffect } from 'react';
import { generateEnhancedDisruptions } from '@/lib/aviationDisruptionEnhanced.js';
import { generateFlights, generateCrew, generateTravel, generateAircraft } from '@/lib/aviationComprehensiveData.js';
import { generateMaritimeDisruptions } from '@/lib/maritimeDisruptionData.js';
import { toast } from 'sonner';

const DemoStateContext = createContext();

export const useDemo = () => {
  const context = useContext(DemoStateContext);
  if (!context) throw new Error('useDemo must be used within a DemoStateProvider');
  return context;
};

export const DemoStateProvider = ({ children }) => {
  // Existing Maritime/Aviation State
  const [enhancedDisruptions, setEnhancedDisruptions] = useState([]);
  const [selectedDisruption, setSelectedDisruption] = useState(null);
  const [automationMode, setAutomationMode] = useState('Assisted');
  const [totalSavings, setTotalSavings] = useState(0);
  const [decisionLog, setDecisionLog] = useState([]);

  const [flights, setFlights] = useState([]);
  const [crew, setCrew] = useState([]);
  const [travelBookings, setTravelBookings] = useState([]);
  const [aircraft, setAircraft] = useState([]);
  const [financials, setFinancials] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [complianceItems, setComplianceItems] = useState([]);
  const [messages, setMessages] = useState([]);

  const [searchQuery, setSearchQuery] = useState('');
  const [filteredCrewList, setFilteredCrewList] = useState([]);

  // --- NEW CRUISE MODE STATE ---
  const [operatingMode, setOperatingModeState] = useState('cargo'); // 'cargo' | 'cruise'
  const [cruiseScenario, setCruiseScenarioState] = useState('large'); // 'small' | 'large' | 'full'
  const [passengerCount, setPassengerCount] = useState(3500);
  const [cruiseModules, setCruiseModules] = useState({
    safety: true,
    hotel: true,
    health: true,
    environmental: true,
    operations: true,
    guest: true
  });

  // --- MARITIME DISRUPTIONS STATE ---
  const [maritimeDisruptions, setMaritimeDisruptions] = useState([]);

  // Initialize mode from localStorage
  useEffect(() => {
    const savedMode = localStorage.getItem('operion_operatingMode');
    if (savedMode === 'cruise' || savedMode === 'cargo') {
      setOperatingModeState(savedMode);
    }
    const savedScenario = localStorage.getItem('operion_cruiseScenario');
    if (savedScenario) {
      setCruiseScenarioState(savedScenario);
      updatePassengerCount(savedScenario);
    }
  }, []);

  const updatePassengerCount = (scenario) => {
    if (scenario === 'small') setPassengerCount(800);
    else if (scenario === 'large') setPassengerCount(3500);
    else if (scenario === 'full') setPassengerCount(5400);
  };

  const setOperatingMode = (mode) => {
    setOperatingModeState(mode);
    localStorage.setItem('operion_operatingMode', mode);
    toast.success(`${mode === 'cruise' ? 'Cruise' : 'Cargo'} Mode Activated`);
  };

  const setCruiseScenario = (scenario) => {
    setCruiseScenarioState(scenario);
    updatePassengerCount(scenario);
    localStorage.setItem('operion_cruiseScenario', scenario);
    toast.info(`Scenario updated to ${scenario} capacity`);
  };

  const toggleCruiseModule = (moduleName) => {
    setCruiseModules(prev => ({ ...prev, [moduleName]: !prev[moduleName] }));
  };

  const getCruiseData = () => {
    return {
      operatingMode,
      cruiseScenario,
      passengerCount,
      cruiseModules
    };
  };
  // -----------------------------

  useEffect(() => {
    setEnhancedDisruptions(generateEnhancedDisruptions(35));
    setFlights(generateFlights(25));
    const generatedCrew = generateCrew(35);
    setCrew(generatedCrew);
    setFilteredCrewList(generatedCrew);
    setTravelBookings(generateTravel(25));
    setAircraft(generateAircraft(18));
    setMaritimeDisruptions(generateMaritimeDisruptions());
    
    setFinancials(Array.from({ length: 15 }, (_, i) => ({
      id: `FIN-${i}`, category: 'Operational', description: `Expense ${i}`, amount: Math.floor(Math.random() * 10000), budget: 10000, status: 'Pending', date: new Date().toISOString()
    })));
    setNotifications(Array.from({ length: 20 }, (_, i) => ({
      id: `NOT-${i}`, 
      type: 'Alert', 
      severity: ['Critical', 'High', 'Medium', 'Low'][Math.floor(Math.random() * 4)], 
      title: `System Alert ${i}`, 
      message: 'Please review the latest updates.', 
      status: 'Active', 
      time: `${Math.floor(Math.random() * 12) + 1}h ago`,
      read: Math.random() > 0.5
    })));
    setComplianceItems(Array.from({ length: 12 }, (_, i) => ({
      id: `CMP-${i}`, type: 'Audit', title: `Safety Check ${i}`, description: 'Routine safety inspection.', status: 'Open', severity: 'Medium', dueDate: new Date().toISOString()
    })));
    setMessages(Array.from({ length: 25 }, (_, i) => ({
      id: `MSG-${i}`, from: 'System', to: 'All Crew', subject: `Update ${i}`, body: 'Please be advised of the following changes.', status: 'Delivered', timestamp: new Date().toISOString()
    })));
  }, []);

  // Live Simulation for Maritime Disruptions
  useEffect(() => {
    if (maritimeDisruptions.length === 0) return;

    const interval = setInterval(() => {
      setMaritimeDisruptions(prev => prev.map(disruption => {
        // 10% chance to update a disruption
        if (Math.random() > 0.9) {
          const statuses = ['Active', 'Monitoring', 'Resolved'];
          const severities = ['Low', 'Medium', 'High'];
          
          // Slight movement for active/monitoring vessels
          let newLat = disruption.location.lat;
          let newLon = disruption.location.lon;
          
          if (disruption.status !== 'Resolved') {
            newLat += (Math.random() * 0.2 - 0.1);
            newLon += (Math.random() * 0.2 - 0.1);
          }

          return {
            ...disruption,
            location: { lat: newLat, lon: newLon },
            status: Math.random() > 0.7 ? statuses[Math.floor(Math.random() * statuses.length)] : disruption.status,
            severity: Math.random() > 0.8 ? severities[Math.floor(Math.random() * severities.length)] : disruption.severity,
            timestamp: new Date().toISOString() // Update timestamp on change
          };
        }
        return disruption;
      }));
    }, 15000); // Every 15 seconds

    return () => clearInterval(interval);
  }, [maritimeDisruptions.length]);

  useEffect(() => {
    if (!searchQuery || searchQuery.trim() === '') {
      setFilteredCrewList(crew);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = crew.filter(member => 
        member.name?.toLowerCase().includes(query) ||
        member.role?.toLowerCase().includes(query) ||
        member.vessel?.toLowerCase().includes(query) ||
        member.status?.toLowerCase().includes(query)
      );
      setFilteredCrewList(filtered);
    }
  }, [searchQuery, crew]);

  const applySolution = (disruptionId, solution) => {
    setEnhancedDisruptions(prev => prev.map(d => 
      d.id === disruptionId ? { ...d, status: 'Resolved' } : d
    ));
    if (solution.costImpact < 0) {
      setTotalSavings(prev => prev + Math.abs(solution.costImpact));
    }
    setDecisionLog(prev => [{
      id: Date.now(),
      action: `Applied: ${solution.actionSummary}`,
      timestamp: new Date().toISOString(),
      impact: solution.costImpact
    }, ...prev]);
    toast.success('Solution applied successfully');
  };

  const updateFlight = (updated) => setFlights(prev => prev.map(f => f.id === updated.id ? updated : f));
  const updateCrewMember = (updated) => setCrew(prev => prev.map(c => c.id === updated.id ? updated : c));
  const updateBooking = (updated) => setTravelBookings(prev => prev.map(b => b.id === updated.id ? updated : b));
  const updateAircraft = (updated) => setAircraft(prev => prev.map(a => a.id === updated.id ? updated : a));
  const updateFinancial = (updated) => setFinancials(prev => prev.map(f => f.id === updated.id ? updated : f));
  const updateNotification = (updated) => setNotifications(prev => prev.map(n => n.id === updated.id ? updated : n));
  const updateCompliance = (updated) => setComplianceItems(prev => prev.map(c => c.id === updated.id ? updated : c));
  const updateMessage = (updated) => setMessages(prev => prev.map(m => m.id === updated.id ? updated : m));

  const markNotificationRead = (notificationId) => {
    setNotifications(prev => prev.map(n => 
      n.id === notificationId ? { ...n, read: true } : n
    ));
  };

  const value = {
    enhancedDisruptions, selectedDisruption, setSelectedDisruption,
    automationMode, setAutomationMode, totalSavings, decisionLog, applySolution,
    flights, updateFlight,
    crew, updateCrewMember,
    travelBookings, updateBooking,
    aircraft, updateAircraft,
    financials, updateFinancial,
    notifications, updateNotification, markNotificationRead,
    complianceItems, updateCompliance,
    messages, updateMessage,
    searchQuery, setSearchQuery,
    filteredCrewList,
    // Cruise Mode Exports
    operatingMode, setOperatingMode,
    cruiseScenario, setCruiseScenario,
    passengerCount,
    cruiseModules, toggleCruiseModule,
    getCruiseData,
    // Maritime Disruptions
    maritimeDisruptions
  };

  return <DemoStateContext.Provider value={value}>{children}</DemoStateContext.Provider>;
};