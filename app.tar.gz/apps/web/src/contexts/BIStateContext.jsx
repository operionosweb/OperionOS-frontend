import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  generateKPIMetrics, generateOTPTrendData, generateCostPerRouteData, 
  generateDelayCausesData, generateAirportDelayHeatmap, generateCostAccumulationData, 
  generateAIInsights, generateRouteMetrics, generateCrewMetrics, 
  generateDisruptionData, generatePredictiveData, generateFinancialData, 
  generateLiveFeedData 
} from '@/lib/biComprehensiveData.js';

const BIStateContext = createContext();

export const useBIState = () => {
  const context = useContext(BIStateContext);
  if (!context) throw new Error('useBIState must be used within a BIStateProvider');
  return context;
};

export const BIStateProvider = ({ children }) => {
  const [kpiMetrics, setKPIMetrics] = useState(generateKPIMetrics());
  const [chartData, setChartData] = useState({
    otpTrend: generateOTPTrendData(),
    costPerRoute: generateCostPerRouteData(),
    delayCauses: generateDelayCausesData(),
    airportHeatmap: generateAirportDelayHeatmap(),
    costAccumulation: generateCostAccumulationData()
  });
  const [insights, setInsights] = useState(generateAIInsights());
  const [routeMetrics, setRouteMetrics] = useState(generateRouteMetrics());
  const [crewMetrics, setCrewMetrics] = useState(generateCrewMetrics());
  const [disruptionData, setDisruptionData] = useState(generateDisruptionData());
  const [predictiveData, setPredictiveData] = useState(generatePredictiveData());
  const [financialData, setFinancialData] = useState(generateFinancialData());
  const [liveFeedData, setLiveFeedData] = useState(generateLiveFeedData());
  
  const [filters, setFilters] = useState({
    dateRange: '30d',
    airports: [],
    aircraftTypes: [],
    routes: [],
    crewRoles: [],
    search: ''
  });

  const [selectedKPI, setSelectedKPI] = useState(null);
  const [selectedChart, setSelectedChart] = useState(null);
  const [reportConfig, setReportConfig] = useState(null);
  const [isLiveFeedPaused, setIsLiveFeedPaused] = useState(false);

  // Simulate live feed updates
  useEffect(() => {
    if (isLiveFeedPaused) return;
    
    const interval = setInterval(() => {
      const events = ['Delay', 'Disruption', 'Crew Change', 'Maintenance', 'Weather Alert'];
      const newEvent = {
        id: `EVT-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: events[Math.floor(Math.random() * events.length)],
        message: `Live update: Flight ${Math.floor(Math.random() * 9000) + 1000} status changed.`,
        severity: ['low', 'medium', 'high', 'critical'][Math.floor(Math.random() * 4)]
      };
      
      setLiveFeedData(prev => [newEvent, ...prev].slice(0, 50));
    }, 8000);
    
    return () => clearInterval(interval);
  }, [isLiveFeedPaused]);

  const updateFilters = (newFilters) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
    // In a real app, this would trigger data refetching based on filters
  };

  const resetFilters = () => {
    setFilters({
      dateRange: '30d', airports: [], aircraftTypes: [], routes: [], crewRoles: [], search: ''
    });
  };

  const dismissInsight = (id) => {
    setInsights(prev => prev.filter(i => i.id !== id));
  };

  const value = {
    kpiMetrics, setKPIMetrics,
    chartData, setChartData,
    insights, setInsights, dismissInsight,
    routeMetrics, crewMetrics, disruptionData, predictiveData, financialData,
    liveFeedData, isLiveFeedPaused, setIsLiveFeedPaused,
    filters, updateFilters, resetFilters,
    selectedKPI, setSelectedKPI,
    selectedChart, setSelectedChart,
    reportConfig, setReportConfig
  };

  return <BIStateContext.Provider value={value}>{children}</BIStateContext.Provider>;
};