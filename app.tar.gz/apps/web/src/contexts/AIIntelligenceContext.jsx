
import React, { createContext, useState, useEffect, useCallback } from 'react';
import { globalAIEngine } from '@/lib/aiIntelligenceEngine.js';

export const AIIntelligenceContext = createContext(null);

export function AIIntelligenceProvider({ children }) {
  const [state, setState] = useState({
    insights: [],
    recommendations: [],
    contextMetrics: {},
    isLoading: true,
    lastUpdate: null
  });

  useEffect(() => {
    // Initialize engine
    globalAIEngine.subscribe();
    
    // Initial analysis trigger (mocking initial data load if empty)
    globalAIEngine.triggerAnalysis();

    const unsubscribe = globalAIEngine.onUpdate((data) => {
      setState({
        insights: data.insights,
        recommendations: data.recommendations,
        contextMetrics: data.contextMetrics,
        isLoading: false,
        lastUpdate: data.contextMetrics.lastUpdate
      });
    });

    return () => {
      unsubscribe();
      globalAIEngine.unsubscribe();
    };
  }, []);

  const refreshInsights = useCallback(() => {
    setState(prev => ({ ...prev, isLoading: true }));
    globalAIEngine.triggerAnalysis();
  }, []);

  const clearInsights = useCallback(() => {
    setState(prev => ({ ...prev, insights: [], recommendations: [] }));
  }, []);

  return (
    <AIIntelligenceContext.Provider value={{ ...state, refreshInsights, clearInsights }}>
      {children}
    </AIIntelligenceContext.Provider>
  );
}
