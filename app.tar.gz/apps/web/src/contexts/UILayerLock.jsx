
import React, { createContext, useContext, useCallback } from 'react';
import { logViolation } from '@/lib/ViolationLogger.js';
import { VIOLATION_TYPES, SEVERITY } from '@/lib/FoundationLockConfig.js';
import { ensureUserAction } from '@/lib/EventDrivenValidator.js';

const UILayerLockContext = createContext(null);

export const UILayerLockProvider = ({ children }) => {
  
  const enforceEventDrivenRender = useCallback((event) => {
    return ensureUserAction(event);
  }, []);

  const blockCascadingRender = useCallback((componentName) => {
    logViolation(VIOLATION_TYPES.RENDER, SEVERITY.WARNING, `Potential cascading render checked in ${componentName}`);
  }, []);

  return (
    <UILayerLockContext.Provider value={{ enforceEventDrivenRender, blockCascadingRender }}>
      {children}
    </UILayerLockContext.Provider>
  );
};

export const useUILayerLock = () => {
  const context = useContext(UILayerLockContext);
  if (!context) throw new Error('useUILayerLock must be used within UILayerLockProvider');
  return context;
};
