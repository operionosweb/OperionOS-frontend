
import React, { createContext, useState, useEffect, useRef, useCallback } from 'react';
import { useEventContext } from '@/contexts/EventContext.jsx';
import { ContractMonitoringEngine } from '@/lib/contractMonitoringEngine.js';
import { generateMockFleetContracts } from '@/lib/mockData/fleetContracts.js';
import { analyzeContractRisk } from '@/lib/contractAnalysis.js';

export const ContractMonitoringContext = createContext(null);

export function ContractMonitoringProvider({ children }) {
  const { eventBus } = useEventContext() || {};
  const engineRef = useRef(new ContractMonitoringEngine());
  
  const [state, setState] = useState({
    contracts: [],
    alerts: [],
    exposureMetrics: { totalExposure: 0, averageExposure: 0, highestExposure: null },
    riskScores: {},
    lastMonitoredAt: null,
    exposureTrend: [] // Array of { timestamp, value }
  });

  // Initial load
  useEffect(() => {
    const initialContracts = generateMockFleetContracts().map(analyzeContractRisk);
    runMonitoring(initialContracts);
  }, []);

  const runMonitoring = useCallback((contractsToMonitor) => {
    const result = engineRef.current.monitorFleetContracts(contractsToMonitor);
    
    setState(prev => {
      // Merge new alerts with existing unacknowledged ones, avoiding exact duplicates
      const existingActive = prev.alerts.filter(a => !a.dismissed);
      const newAlerts = result.alerts.filter(na => 
        !existingActive.some(ea => ea.contractId === na.contractId && ea.type === na.type)
      );
      
      const updatedTrend = [...prev.exposureTrend, { 
        timestamp: new Date().toISOString(), 
        value: result.exposureMetrics.totalExposure 
      }].slice(-20); // Keep last 20 data points

      const riskScoresMap = {};
      result.analyzedContracts.forEach(c => {
        riskScoresMap[c.contract_id] = c.monitoring.riskScore;
      });

      return {
        contracts: result.analyzedContracts,
        alerts: [...newAlerts, ...existingActive].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp)),
        exposureMetrics: result.exposureMetrics,
        riskScores: riskScoresMap,
        lastMonitoredAt: new Date().toISOString(),
        exposureTrend: updatedTrend
      };
    });
  }, []);

  // Subscribe to events
  useEffect(() => {
    if (!eventBus) return;

    const handleContractUpdate = (payload) => {
      setState(prev => {
        const updatedContracts = [...prev.contracts];
        const idx = updatedContracts.findIndex(c => c.contract_id === payload.data.contract_id);
        const analyzed = analyzeContractRisk(payload.data);
        
        if (idx >= 0) updatedContracts[idx] = analyzed;
        else updatedContracts.push(analyzed);
        
        // Defer monitoring to avoid React state update loops
        setTimeout(() => runMonitoring(updatedContracts), 0);
        return prev;
      });
    };

    const handleSyncComplete = () => {
      // Re-run monitoring on full sync
      setState(prev => {
        setTimeout(() => runMonitoring(prev.contracts), 0);
        return prev;
      });
    };

    const unsubContract = eventBus.subscribe('CONTRACT_UPDATED', handleContractUpdate);
    const unsubSync = eventBus.subscribe('DATA_SYNC_COMPLETED', handleSyncComplete);

    return () => {
      unsubContract();
      unsubSync();
    };
  }, [eventBus, runMonitoring]);

  const acknowledgeAlert = useCallback((alertId) => {
    setState(prev => ({
      ...prev,
      alerts: prev.alerts.map(a => a.id === alertId ? { ...a, acknowledged: true } : a)
    }));
  }, []);

  const dismissAlert = useCallback((alertId) => {
    setState(prev => ({
      ...prev,
      alerts: prev.alerts.map(a => a.id === alertId ? { ...a, dismissed: true } : a)
    }));
  }, []);

  const triggerMonitoring = useCallback(() => {
    setState(prev => {
      runMonitoring(prev.contracts);
      return prev;
    });
  }, [runMonitoring]);

  const value = {
    ...state,
    acknowledgeAlert,
    dismissAlert,
    triggerMonitoring
  };

  return (
    <ContractMonitoringContext.Provider value={value}>
      {children}
    </ContractMonitoringContext.Provider>
  );
}
