
import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { EventEmitter } from '@/lib/eventBus.js';
import { DataSyncManager } from '@/lib/dataSyncManager.js';
import { DATA_SYNC_STARTED, DATA_SYNC_COMPLETED } from '@/types/events.js';

const EventContext = createContext(null);

export function EventProvider({ children }) {
  const eventBusRef = useRef(new EventEmitter());
  const syncManagerRef = useRef(new DataSyncManager(eventBusRef.current));
  
  const [syncState, setSyncState] = useState(syncManagerRef.current.getStatus());

  useEffect(() => {
    const bus = eventBusRef.current;
    const manager = syncManagerRef.current;

    const handleSyncStart = () => setSyncState(manager.getStatus());
    const handleSyncComplete = () => setSyncState(manager.getStatus());

    bus.subscribe(DATA_SYNC_STARTED, handleSyncStart);
    bus.subscribe(DATA_SYNC_COMPLETED, handleSyncComplete);

    return () => {
      bus.unsubscribe(DATA_SYNC_STARTED, handleSyncStart);
      bus.unsubscribe(DATA_SYNC_COMPLETED, handleSyncComplete);
      manager.stop();
    };
  }, []);

  const value = {
    eventBus: eventBusRef.current,
    syncManager: syncManagerRef.current,
    syncState
  };

  return (
    <EventContext.Provider value={value}>
      {children}
    </EventContext.Provider>
  );
}

export function useEventContext() {
  const context = useContext(EventContext);
  if (!context) {
    throw new Error('useEventContext must be used within an EventProvider');
  }
  return context;
}
