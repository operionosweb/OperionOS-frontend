
import React, { createContext, useState, useEffect, useCallback, useRef } from 'react';
import { ContractForecastingEngine } from '@/lib/contractForecastingEngine.js';

export const ForecastingContext = createContext(null);

const CACHE_KEY = 'contract_forecasts_cache';
const CACHE_TTL = 60 * 60 * 1000; // 1 hour

export function ForecastingProvider({ children }) {
  const [forecasts, setForecasts] = useState(new Map());
  const [isCalculating, setIsCalculating] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const engineRef = useRef(new ContractForecastingEngine());

  // Load from cache on mount
  useEffect(() => {
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) {
        const { data, timestamp } = JSON.parse(cached);
        if (Date.now() - timestamp < CACHE_TTL) {
          setForecasts(new Map(Object.entries(data)));
          setLastUpdated(new Date(timestamp).toISOString());
        }
      }
    } catch (e) {
      console.error('Failed to load forecasts from cache', e);
    }
  }, []);

  const saveToCache = useCallback((newForecasts) => {
    try {
      const dataObj = Object.fromEntries(newForecasts.entries());
      localStorage.setItem(CACHE_KEY, JSON.stringify({
        data: dataObj,
        timestamp: Date.now()
      }));
    } catch (e) {
      console.error('Failed to save forecasts to cache', e);
    }
  }, []);

  const calculateForecasts = useCallback((contracts) => {
    setIsCalculating(true);
    
    // Simulate async calculation for UI responsiveness
    setTimeout(() => {
      setForecasts(prev => {
        const next = new Map(prev);
        contracts.forEach(contract => {
          const contractId = contract.contract_id || contract.id;
          const previous = next.get(contractId);
          const forecast = engineRef.current.generateForecast(contract, previous);
          next.set(contractId, forecast);
        });
        
        saveToCache(next);
        setLastUpdated(new Date().toISOString());
        setIsCalculating(false);
        return next;
      });
    }, 300);
  }, [saveToCache]);

  const getForecast = useCallback((contractId) => {
    return forecasts.get(contractId) || null;
  }, [forecasts]);

  const value = {
    forecasts,
    isCalculating,
    lastUpdated,
    calculateForecasts,
    getForecast
  };

  return (
    <ForecastingContext.Provider value={value}>
      {children}
    </ForecastingContext.Provider>
  );
}
