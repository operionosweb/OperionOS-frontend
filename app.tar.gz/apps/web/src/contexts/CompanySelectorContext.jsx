
import React, { createContext, useContext } from 'react';
import { useCompanySelector } from '@/hooks/useCompanySelector.js';

const CompanySelectorContext = createContext(null);

export const CompanySelectorProvider = ({ children }) => {
  // The useCompanySelector hook handles the logic.
  // By ensuring CompanySelectorProvider is nested inside TabProvider in App.jsx,
  // any useTabData calls within useCompanySelector will safely resolve.
  const selectorState = useCompanySelector();

  return (
    <CompanySelectorContext.Provider value={selectorState}>
      {children}
    </CompanySelectorContext.Provider>
  );
};

export const useCompanySelectorContext = () => {
  const context = useContext(CompanySelectorContext);
  if (!context) {
    throw new Error('useCompanySelectorContext must be used within a CompanySelectorProvider');
  }
  return context;
};
