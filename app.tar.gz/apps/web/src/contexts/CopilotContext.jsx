
import React, { createContext, useContext, useEffect, useMemo } from 'react';
import { useCopilotEngine } from '@/hooks/useCopilotEngine.js';
import { useAuthGuard } from '@/hooks/useAuthGuard.js';

const CopilotContext = createContext(null);

export function CopilotProvider({ children }) {
  const engineState = useCopilotEngine();
  const { isAuthenticated, user } = useAuthGuard();
  const { updateContext } = engineState;

  // Clear context and pause engine if logged out
  // Using user?.role as dependency instead of the full user object to prevent unnecessary triggers
  useEffect(() => {
    if (!isAuthenticated) {
      updateContext({ userRole: 'unauthenticated' });
    } else if (user) {
      updateContext({ userRole: user.role || 'viewer' });
    }
  }, [isAuthenticated, user?.role, updateContext]);

  // Memoize the context value to prevent unnecessary re-renders of consumers
  const contextValue = useMemo(() => ({
    ...engineState,
    isAuthenticated
  }), [engineState, isAuthenticated]);

  return (
    <CopilotContext.Provider value={contextValue}>
      {children}
    </CopilotContext.Provider>
  );
}

export function useCopilot() {
  const context = useContext(CopilotContext);
  if (!context) {
    throw new Error('useCopilot must be used within a CopilotProvider');
  }
  return context;
}
