import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  getAircraftData, 
  getContractData, 
  updateAircraftField as updateMockAircraft, 
  updateContractField as updateMockContract 
} from '@/lib/aviationFleetData.js';

const AviationContext = createContext();

export const useAviationData = () => {
  const context = useContext(AviationContext);
  if (!context) throw new Error('useAviationData must be used within an AviationDataProvider');
  return context;
};

export const AviationDataProvider = ({ children }) => {
  const [aircraft, setAircraft] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [savedScenarios, setSavedScenarios] = useState([]);

  useEffect(() => {
    setAircraft(getAircraftData());
    setContracts(getContractData());
  }, []);

  const getAircraftList = () => aircraft;
  const getContractList = () => contracts;

  const filterAircraft = (type, leaseStatus) => {
    return aircraft.filter(a => {
      const matchType = type === 'All' || !type ? true : a.type === type;
      const matchStatus = leaseStatus === 'All' || !leaseStatus ? true : a.leaseType === leaseStatus;
      return matchType && matchStatus;
    });
  };

  const filterContracts = (lessor, riskLevel) => {
    return contracts.filter(c => {
      const matchLessor = lessor === 'All' || !lessor ? true : c.lessor === lessor;
      const matchRisk = riskLevel === 'All' || !riskLevel ? true : c.riskLevel === riskLevel;
      return matchLessor && matchRisk;
    });
  };

  const updateAircraftField = (id, field, value) => {
    const updated = updateMockAircraft(id, field, value);
    setAircraft(getAircraftData());
    return updated;
  };

  const updateContractField = (id, field, value) => {
    const updated = updateMockContract(id, field, value);
    setContracts(getContractData());
    return updated;
  };

  const saveScenario = (scenario) => {
    setSavedScenarios(prev => {
      const newScenarios = [{ ...scenario, id: Date.now() }, ...prev];
      return newScenarios.slice(0, 5); // Keep max 5
    });
  };

  const getSavedScenarios = () => savedScenarios;

  const deleteSavedScenario = (id) => {
    setSavedScenarios(prev => prev.filter(s => s.id !== id));
  };

  const value = {
    aircraft,
    contracts,
    getAircraftList,
    getContractList,
    filterAircraft,
    filterContracts,
    updateAircraftField,
    updateContractField,
    saveScenario,
    getSavedScenarios,
    deleteSavedScenario
  };

  return (
    <AviationContext.Provider value={value}>
      {children}
    </AviationContext.Provider>
  );
};