import React, { createContext, useContext, useState, useMemo } from 'react';
import { kpiData, savingsLog, opportunities, vessels, crew, recommendations, chartData } from '@/lib/roiSavingsData.js';

const ROISavingsContext = createContext();

export const useROISavings = () => {
  const context = useContext(ROISavingsContext);
  if (!context) {
    throw new Error('useROISavings must be used within a ROISavingsProvider');
  }
  return context;
};

export const ROISavingsProvider = ({ children }) => {
  // Global Filters
  const [globalFilters, setGlobalFilters] = useState({
    vessel: 'All',
    region: 'All',
    timePeriod: 'YTD'
  });

  // State
  const [logs, setLogs] = useState(savingsLog);
  const [opps, setOpps] = useState(opportunities);
  const [vesselData, setVesselData] = useState(vessels);
  const [crewData, setCrewData] = useState(crew);
  const [recs, setRecs] = useState(recommendations);

  // Actions
  const updateGlobalFilter = (key, value) => {
    setGlobalFilters(prev => ({ ...prev, [key]: value }));
  };

  const applySimulation = (opportunityId) => {
    // Move opportunity to savings log as pending
    const opp = opps.find(o => o.id === opportunityId);
    if (opp) {
      const newLog = {
        id: `SL${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        vessel: 'Multiple',
        category: opp.category,
        recommendation: opp.recommendation,
        action: 'Simulation Applied',
        amount: opp.amount,
        status: 'Pending Verification'
      };
      setLogs([newLog, ...logs]);
      setOpps(opps.filter(o => o.id !== opportunityId));
    }
  };

  const dismissRecommendation = (id) => {
    setRecs(recs.filter(r => r.id !== id));
  };

  const value = {
    globalFilters,
    updateGlobalFilter,
    kpiData,
    savingsLog: logs,
    opportunities: opps,
    vessels: vesselData,
    crew: crewData,
    recommendations: recs,
    chartData,
    applySimulation,
    dismissRecommendation
  };

  return (
    <ROISavingsContext.Provider value={value}>
      {children}
    </ROISavingsContext.Provider>
  );
};