
import React, { createContext, useContext, useState, useEffect } from 'react';

const DemoLayerContext = createContext(null);

// Static, deterministic mock data
const STATIC_DEMO_DATA = {
  crew: [
    { id: '1', name: 'Maya Chen', role: 'Captain', status: 'Active' },
    { id: '2', name: 'Raj Patel', role: 'First Officer', status: 'Standby' }
  ],
  fleet: [
    { id: 'F1', name: 'Alpha-X1', type: 'Aircraft', status: 'Active' },
    { id: 'F2', name: 'Beta-V2', type: 'Vessel', status: 'Maintenance' }
  ],
  operations: [
    { id: 'O1', type: 'Flight', destination: 'LHR', status: 'On Time' }
  ]
};

export const DemoLayerProvider = ({ children, activeCompanyId }) => {
  const [demoData, setDemoData] = useState({ crew: [], fleet: [], operations: [] });
  const isDemoActive = activeCompanyId === '6c091a44-952c-4433-944d-c18d02574003';

  // Load ONCE on mount or company change
  useEffect(() => {
    if (isDemoActive) {
      setDemoData(STATIC_DEMO_DATA);
    } else {
      setDemoData({ crew: [], fleet: [], operations: [] });
    }
  }, [isDemoActive]);

  const triggerDeterministicUpdate = (type, payload) => {
    setDemoData(prev => ({ ...prev, [type]: payload }));
  };

  return (
    <DemoLayerContext.Provider value={{
      demoData,
      isDemoActive,
      triggerDeterministicUpdate
    }}>
      {children}
    </DemoLayerContext.Provider>
  );
};

export const useDemoLayer = () => {
  const ctx = useContext(DemoLayerContext);
  if (!ctx) throw new Error('useDemoLayer must be used within DemoLayerProvider');
  return ctx;
};
