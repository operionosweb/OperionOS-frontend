
import React, { createContext, useContext, useState, useCallback } from 'react';

const TabStateContext = createContext(null);

export const TabStateProvider = ({ children }) => {
  const [activeTab, setActiveTab] = useState('overview');

  const handleTabChange = useCallback((tabId) => {
    setActiveTab(tabId);
  }, []);

  return (
    <TabStateContext.Provider value={{ activeTab, handleTabChange }}>
      {children}
    </TabStateContext.Provider>
  );
};

export const useTabState = () => {
  const ctx = useContext(TabStateContext);
  if (!ctx) {
    throw new Error('useTabState must be used within a TabStateProvider');
  }
  return ctx;
};
