
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import ScrollToTop from '@/components/ScrollToTop.jsx';
import HomePage from '@/pages/HomePage.jsx';
import PlatformPage from '@/pages/PlatformPage.jsx';
import ProvidersIntegrationPage from '@/pages/ProvidersIntegrationPage.jsx';
import FeaturesPage from '@/pages/FeaturesPage.jsx';
import IndustriesPage from '@/pages/IndustriesPage.jsx';
import MaritimePage from '@/pages/MaritimePage.jsx';
import OffshorePage from '@/pages/OffshorePage.jsx';
import SolutionsPage from '@/pages/SolutionsPage.jsx';
import PricingPage from '@/pages/PricingPage.jsx';
import ContactPage from '@/pages/ContactPage.jsx';
import ContactSalesPage from '@/pages/ContactSalesPage.jsx';
import ContactUsPage from '@/pages/ContactUsPage.jsx';
import MissionControlPage from '@/pages/MissionControlPage.jsx';
import AboutUsPage from '@/pages/AboutUsPage.jsx';
import SustainabilityImpactPage from '@/pages/SustainabilityImpactPage.jsx';
import ROIPage from '@/pages/ROIPage.jsx';
import LoginPage from '@/pages/LoginPage.jsx';
import ResetPasswordPage from '@/pages/ResetPasswordPage.jsx';

// Legal & Compliance Pages
import PrivacyPolicyPage from '@/pages/PrivacyPolicyPage.jsx';
import TermsOfServicePage from '@/pages/TermsOfServicePage.jsx';
import SecurityPage from '@/pages/SecurityPage.jsx';
import ArchitecturePage from '@/pages/ArchitecturePage.jsx';
import GlobalCompliancePage from '@/pages/GlobalCompliancePage.jsx';

// Simulators
import SavingsSimulatorPage from '@/pages/SavingsSimulatorPage.jsx';
import MaritimeSavingsSimulator from '@/pages/MaritimeSavingsSimulator.jsx';
import AviationSavingsSimulator from '@/pages/AviationSavingsSimulator.jsx';
import OffshoreSavingsSimulatorPage from '@/pages/OffshoreSavingsSimulatorPage.jsx';

// Maritime Demo Pages
import MaritimeDemoPage from '@/pages/MaritimeDemoPage.jsx';
import CrewDemoPage from '@/pages/CrewDemoPage.jsx';
import TravelDemoPage from '@/pages/TravelDemoPage.jsx';
import PlanningDemoPage from '@/pages/PlanningDemoPage.jsx';
import DisruptionsPage from '@/pages/DisruptionsPage.jsx';
import VesselOperationsPage from '@/pages/VesselOperationsPage.jsx';
import ROISavingsPage from '@/pages/ROISavingsPage.jsx';

// Aviation Demo Pages
import AviationDemoPage from '@/pages/AviationDemoPage.jsx';
import AviationROISavingsPage from '@/pages/AviationROISavingsPage.jsx';
import AircraftDetailPage from '@/pages/AircraftDetailPage.jsx';
import ScenarioSimulator from '@/pages/ScenarioSimulator.jsx';
import { AviationDataProvider } from '@/contexts/AviationContextData.jsx';
import { AviationFleetProvider } from '@/contexts/AviationFleetContext.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';

// Shared/BI Demo Pages
import IntelligencePage from '@/pages/IntelligencePage.jsx';

// Global Contexts
import { ImpersonationProvider } from '@/contexts/ImpersonationContext.jsx';
import { TabProvider } from '@/contexts/TabProvider.jsx';
import { CompanySelectorProvider } from '@/contexts/CompanySelectorContext.jsx';
import { ExperienceLayerProvider } from '@/contexts/ExperienceLayerProvider.jsx';
import { FoundationLockProvider } from '@/components/FoundationLock.jsx';
import { CompanyProvider } from '@/contexts/CompanyContext.jsx';
import { ForecastingProvider } from '@/contexts/ForecastingContext.jsx';
import { FinancialSimulationProvider } from '@/contexts/FinancialSimulationContext.jsx';
import { AIIntelligenceProvider } from '@/contexts/AIIntelligenceContext.jsx';
import { CopilotProvider } from '@/contexts/CopilotContext.jsx';
import { ActionableAIProvider } from '@/contexts/ActionableAIContext.jsx';
import LifecycleRouter from '@/components/LifecycleRouter.jsx';
import ControlPanelPage from '@/pages/ControlPanelPage.jsx';
import Toast from '@/components/ui/Toast.jsx';

function App() {
  return (
    <CompanyProvider>
      <ImpersonationProvider>
        <TabProvider>
          <CompanySelectorProvider>
            <ExperienceLayerProvider>
              <FoundationLockProvider>
                <ForecastingProvider>
                  <FinancialSimulationProvider>
                    <AIIntelligenceProvider>
                      <CopilotProvider>
                        <ActionableAIProvider>
                          <BrowserRouter>
                            <ScrollToTop />
                            <Toast />
                            <Routes>
                              <Route path="/" element={<HomePage />} />
                              <Route path="/platform" element={<PlatformPage />} />
                              <Route path="/providers" element={<ProvidersIntegrationPage />} />
                              <Route path="/features" element={<FeaturesPage />} />
                              <Route path="/industries" element={<IndustriesPage />} />
                              <Route path="/maritime" element={<MaritimePage />} />
                              <Route path="/offshore" element={<OffshorePage />} />
                              <Route path="/solutions" element={<SolutionsPage />} />
                              <Route path="/pricing" element={<PricingPage />} />
                              <Route path="/roi" element={<ROIPage />} />
                              <Route path="/contact" element={<ContactPage />} />
                              <Route path="/contact-sales" element={<ContactSalesPage />} />
                              <Route path="/contact-us" element={<ContactUsPage />} />
                              <Route path="/demo" element={<MissionControlPage />} />
                              <Route path="/about" element={<AboutUsPage />} />
                              <Route path="/sustainability-impact" element={<SustainabilityImpactPage />} />
                              
                              {/* Super Admin Control Center */}
                              <Route path="/control-center" element={<ControlPanelPage />} />
                              
                              {/* Standard User Onboarding/Routing */}
                              <Route path="/onboarding" element={<LifecycleRouter />} />
                              
                              <Route path="/login" element={<LoginPage />} />
                              <Route path="/reset-password" element={<ResetPasswordPage />} />
                              
                              {/* Legal & Compliance */}
                              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
                              <Route path="/terms-of-service" element={<TermsOfServicePage />} />
                              <Route path="/security" element={<SecurityPage />} />
                              <Route path="/architecture" element={<ArchitecturePage />} />
                              <Route path="/global-compliance" element={<GlobalCompliancePage />} />
                              
                              {/* Simulators */}
                              <Route path="/savings-simulator" element={<SavingsSimulatorPage />} />
                              <Route path="/maritime-savings-simulator" element={<MaritimeSavingsSimulator />} />
                              <Route path="/aviation-savings-simulator" element={<AviationSavingsSimulator />} />
                              <Route path="/roi/offshore-simulator" element={<OffshoreSavingsSimulatorPage />} />
                              
                              {/* Maritime Demo Routes */}
                              <Route path="/demo/maritime" element={<MaritimeDemoPage />} />
                              <Route path="/demo/maritime/crew" element={<CrewDemoPage />} />
                              <Route path="/demo/maritime/travel" element={<TravelDemoPage />} />
                              <Route path="/demo/maritime/disruptions" element={<DisruptionsPage />} />
                              <Route path="/demo/maritime/planning" element={<PlanningDemoPage />} />
                              <Route path="/demo/maritime/vessel-operations" element={<VesselOperationsPage />} />
                              <Route path="/demo/maritime/intelligence" element={<IntelligencePage />} />
                              <Route path="/demo/maritime/roi-savings" element={<ROISavingsPage />} />
                              
                              {/* Aviation Demo Routes wrapped in global providers */}
                              <Route path="/demo/aviation/*" element={
                                <AviationDataProvider>
                                  <AviationFleetProvider>
                                    <DemoStateProvider>
                                      <Routes>
                                        <Route path="/" element={<Navigate to="/demo/aviation/fleet" replace />} />
                                        <Route path="fleet" element={<AviationDemoPage />} />
                                        <Route path="contracts" element={<AviationDemoPage />} />
                                        <Route path="financials" element={<AviationDemoPage />} />
                                        <Route path="scenarios" element={<ScenarioSimulator />} />
                                        <Route path="crew" element={<AviationDemoPage />} />
                                        <Route path="travel" element={<AviationDemoPage />} />
                                        <Route path="disruptions" element={<AviationDemoPage />} />
                                        <Route path="flights" element={<AviationDemoPage />} />
                                        <Route path="financial" element={<AviationDemoPage />} />
                                        <Route path="notifications" element={<AviationDemoPage />} />
                                        <Route path="compliance" element={<AviationDemoPage />} />
                                        <Route path="comms" element={<AviationDemoPage />} />
                                        <Route path="maintenance" element={<AviationDemoPage />} />
                                        <Route path="aircraft/:aircraftId" element={<AircraftDetailPage />} />
                                      </Routes>
                                    </DemoStateProvider>
                                  </AviationFleetProvider>
                                </AviationDataProvider>
                              } />
                              
                              <Route path="/aviation-roi-savings" element={<AviationROISavingsPage />} />
                              
                              {/* Global BI Route */}
                              <Route path="/intelligence" element={<IntelligencePage />} />
                              
                              <Route path="*" element={<HomePage />} />
                            </Routes>
                          </BrowserRouter>
                        </ActionableAIProvider>
                      </CopilotProvider>
                    </AIIntelligenceProvider>
                  </FinancialSimulationProvider>
                </ForecastingProvider>
              </FoundationLockProvider>
            </ExperienceLayerProvider>
          </CompanySelectorProvider>
        </TabProvider>
      </ImpersonationProvider>
    </CompanyProvider>
  );
}

export default App;
