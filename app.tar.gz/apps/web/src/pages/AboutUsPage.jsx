import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Users, 
  Plane, 
  Ship, 
  AlertTriangle, 
  CalendarClock, 
  BrainCircuit, 
  TrendingUp,
  CheckCircle2,
  ArrowRight,
  Target,
  Lightbulb,
  BarChart3,
  ShieldCheck,
  Zap
} from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button.jsx';

const AboutUsPage = () => {
  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "-100px" },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    initial: { opacity: 0 },
    whileInView: { opacity: 1 },
    viewport: { once: true, margin: "-100px" },
    transition: { staggerChildren: 0.1 }
  };

  const staggerItem = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>{`About Us | Operion`}</title>
        <meta name="description" content="Learn about Operion, the operating system for global crew management across aviation, maritime, and offshore industries." />
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        <section className="relative py-24 md:py-32 lg:py-40 bg-secondary text-secondary-foreground overflow-hidden">
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary via-transparent to-transparent pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <motion.div 
              className="max-w-3xl"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance leading-tight tracking-tight">
                About Operion
              </h1>
              <p className="text-xl md:text-2xl font-medium text-primary mb-4">
                The Operating System for Global Crew Management
              </p>
              <p className="text-lg md:text-xl text-secondary-foreground/80 leading-relaxed max-w-2xl">
                We are a leading crew management operating system helping aviation, maritime, and offshore companies manage crew operations.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <motion.div {...fadeIn}>
                <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">What is Operion?</h2>
                <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
                  <p>
                    Operion is a unified platform designed specifically for the unique challenges of global crew operations. We bridge the gap between disparate systems, bringing together rotation optimization, compliance tracking, and disruption management.
                  </p>
                  <p>
                    Instead of relying on fragmented spreadsheets and legacy software, Operion provides a single source of truth. Our AI-driven architecture doesn't just report on what happened—it predicts what will happen and prescribes the optimal path forward for your workforce.
                  </p>
                </div>
              </motion.div>
              <motion.div 
                className="relative rounded-2xl overflow-hidden shadow-2xl aspect-square lg:aspect-auto lg:h-[500px] bg-muted"
                {...fadeIn}
              >
                <img 
                  src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=2070&auto=format&fit=crop" 
                  alt="Professionals analyzing global operations data on a digital interface" 
                  className="w-full h-full object-cover opacity-90 mix-blend-multiply"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-secondary/80 to-transparent flex items-end p-8">
                  <div className="text-secondary-foreground">
                    <p className="text-2xl font-bold mb-2">Unified Crew Operations</p>
                    <p className="text-secondary-foreground/80">One platform for your entire global workforce.</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <motion.div 
                {...fadeIn}
                className="bg-primary text-primary-foreground rounded-3xl p-10 md:p-12 shadow-xl"
              >
                <Target className="w-12 h-12 mb-8 opacity-80" />
                <h2 className="text-3xl font-bold mb-6">Our Vision</h2>
                <p className="text-xl leading-relaxed opacity-90">
                  To become the global operating system for crew management across all industries, setting the standard for operational excellence and human capital optimization.
                </p>
              </motion.div>
              
              <motion.div 
                {...fadeIn}
                transition={{ delay: 0.2 }}
                className="bg-background text-foreground rounded-3xl p-10 md:p-12 shadow-xl"
              >
                <Lightbulb className="w-12 h-12 mb-8 text-primary" />
                <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
                <p className="text-xl leading-relaxed text-muted-foreground">
                  To optimize crew operations and ensure regulatory compliance.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <motion.div 
                className="order-2 lg:order-1 grid grid-cols-2 gap-4"
                variants={staggerContainer}
                initial="initial"
                whileInView="whileInView"
              >
                <motion.div variants={staggerItem} className="bg-muted rounded-2xl p-6 aspect-square flex flex-col justify-center items-center text-center">
                  <BrainCircuit className="w-10 h-10 text-primary mb-4" />
                  <span className="font-semibold">Operational efficiency</span>
                </motion.div>
                <motion.div variants={staggerItem} className="bg-primary text-primary-foreground rounded-2xl p-6 aspect-square flex flex-col justify-center items-center text-center translate-y-8">
                  <Zap className="w-10 h-10 mb-4" />
                  <span className="font-semibold">Crew safety and compliance</span>
                </motion.div>
                <motion.div variants={staggerItem} className="bg-secondary text-secondary-foreground rounded-2xl p-6 aspect-square flex flex-col justify-center items-center text-center">
                  <ShieldCheck className="w-10 h-10 mb-4" />
                  <span className="font-semibold">Reliability and transparency</span>
                </motion.div>
                <motion.div variants={staggerItem} className="bg-muted rounded-2xl p-6 aspect-square flex flex-col justify-center items-center text-center translate-y-8">
                  <BarChart3 className="w-10 h-10 text-primary mb-4" />
                  <span className="font-semibold">Measurable ROI</span>
                </motion.div>
              </motion.div>

              <motion.div className="order-1 lg:order-2" {...fadeIn}>
                <h2 className="text-3xl md:text-4xl font-bold mb-8 text-balance">Why Choose Operion?</h2>
                <ul className="space-y-6">
                  {[
                    "AI-powered scheduling that learns from your operations",
                    "End-to-end compliance visibility across all departments",
                    "Real-time disruption handling for proactive management",
                    "Cross-module integration eliminating data silos",
                    "Measurable operational cost reduction from day one"
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-4">
                      <CheckCircle2 className="w-6 h-6 text-primary shrink-0 mt-0.5" />
                      <span className="text-lg text-muted-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-24 bg-primary text-primary-foreground text-center px-4">
          <div className="max-w-3xl mx-auto">
            <motion.div {...fadeIn}>
              <h2 className="text-3xl md:text-5xl font-bold mb-6 text-balance">See Operion in Action</h2>
              <p className="text-xl mb-10 text-primary-foreground/90">
                Ready to transform your global crew operations? Schedule a personalized demonstration with our experts.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button asChild size="lg" className="bg-background text-foreground hover:bg-background/90 h-14 px-8 text-lg font-semibold">
                  <Link to="/contact-sales">Start Demo</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 h-14 px-8 text-lg font-semibold">
                  <Link to="/contact-sales">Learn More</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default AboutUsPage;