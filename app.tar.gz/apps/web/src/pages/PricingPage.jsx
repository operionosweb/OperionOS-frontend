import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Calculator, Users, ShieldCheck, AlertTriangle, TrendingUp, Clock, CheckCircle2 } from 'lucide-react';

import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button.jsx';

import ValueBreakdownCard from '@/components/pricing/ValueBreakdownCard.jsx';
import CostVsSavingsComparison from '@/components/pricing/CostVsSavingsComparison.jsx';
import PilotProgramSection from '@/components/pricing/PilotProgramSection.jsx';
import TransparencyPanel from '@/components/pricing/TransparencyPanel.jsx';
import AIAssistantTrigger from '@/components/pricing/AIAssistantTrigger.jsx';

const PricingPage = () => {
  const [savingsData, setSavingsData] = useState({
    total: "4.2M",
    range: "€2.5M–€5.2M",
    roiMultiple: "14x",
    paybackMonths: "4.5",
    breakdown: [
      {
        id: "scheduling",
        title: "Intelligent Scheduling",
        amount: "€1.8M",
        description: "Rotation optimization and fatigue management for global workforces.",
        icon: Users
      },
      {
        id: "compliance",
        title: "Automated Compliance",
        amount: "€1.2M",
        description: "Track duty hours, certifications, and regulatory requirements in real-time.",
        icon: ShieldCheck
      },
      {
        id: "disruption",
        title: "Disruption Management",
        amount: "€750K",
        description: "Instant crew reassignment and contingency planning for unforeseen events.",
        icon: AlertTriangle
      },
      {
        id: "efficiency",
        title: "Operational Efficiency",
        amount: "€450K",
        description: "Centralized crew intelligence and reduced operational overhead.",
        icon: TrendingUp
      }
    ]
  });

  useEffect(() => {
    const timer = setTimeout(() => {}, 500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Operational Costs & ROI | Operion</title>
        <meta name="description" content="Turn operational complexity into measurable savings. Discover Operion's value-based engagement and typical 10-20x ROI for crew management." />
      </Helmet>
      
      <Header />
      
      <main className="flex-grow pt-24 pb-20">
        <section className="relative py-20 overflow-hidden border-b border-border/50">
          <div className="absolute inset-0 bg-gradient-to-b from-muted/50 to-background pointer-events-none" />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <TrendingUp className="w-4 h-4" /> Value-Based Investment
              </span>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance tracking-tight">
                Turn Crew Complexity into <span className="text-primary">Measurable Savings</span>
              </h1>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-10 leading-relaxed">
                Operion typically generates 10–20x ROI through scheduling optimization, compliance automation, and reduced operational losses.
              </p>

              <div className="inline-block bg-card border border-border shadow-lg rounded-2xl p-8 mb-10">
                <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider mb-2">Estimated Annual Savings</p>
                <div className="text-5xl md:text-7xl font-extrabold text-foreground tracking-tighter">
                  €{savingsData.total}
                </div>
                <p className="text-sm text-primary font-medium mt-3">
                  Companies like yours typically unlock {savingsData.range} in annual savings.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-base" asChild>
                  <Link to="/savings-simulator">
                    <Calculator className="mr-2 w-5 h-5" /> Run Your Savings Simulation
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-base" asChild>
                  <Link to="/contact-sales">
                    Contact Us for Pilot Program
                  </Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <section className="py-20">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 tracking-tight">Deployment Options</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                We align our success with yours through value-based engagement models.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Starter Plan */}
              <div className="bg-card border border-border rounded-2xl p-8 shadow-sm flex flex-col">
                <h3 className="text-2xl font-bold mb-2">Starter</h3>
                <p className="text-muted-foreground mb-6">For small crew operations (up to 50 crew members)</p>
                <ul className="space-y-4 mb-8 flex-grow">
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>Up to 10 crew movements per month</span>
                  </li>
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>Compliance monitoring</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full" asChild>
                  <Link to="/contact-sales">Contact Sales</Link>
                </Button>
              </div>

              {/* Professional Plan */}
              <div className="bg-card border-2 border-primary rounded-2xl p-8 shadow-md flex flex-col relative transform md:-translate-y-4">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  Recommended
                </div>
                <h3 className="text-2xl font-bold mb-2">Professional</h3>
                <p className="text-muted-foreground mb-6">For mid-size crew operations (50-500 crew members)</p>
                <ul className="space-y-4 mb-8 flex-grow">
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>Unlimited crew movements</span>
                  </li>
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>Compliance monitoring</span>
                  </li>
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>24/7 operational support</span>
                  </li>
                </ul>
                <Button className="w-full" asChild>
                  <Link to="/contact-sales">Contact Sales</Link>
                </Button>
              </div>

              {/* Enterprise Plan */}
              <div className="bg-card border border-border rounded-2xl p-8 shadow-sm flex flex-col">
                <h3 className="text-2xl font-bold mb-2">Enterprise</h3>
                <p className="text-muted-foreground mb-6">For large-scale crew operations (500+ crew members)</p>
                <ul className="space-y-4 mb-8 flex-grow">
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>Unlimited crew movements</span>
                  </li>
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>Advanced crew analytics</span>
                  </li>
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>24/7 operational support</span>
                  </li>
                  <li className="flex items-start gap-3 text-sm">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" /> 
                    <span>Custom AI model training</span>
                  </li>
                </ul>
                <Button variant="outline" className="w-full" asChild>
                  <Link to="/contact-sales">Contact Sales</Link>
                </Button>
              </div>
            </div>
          </section>

          <section className="py-20">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 tracking-tight">Where Your Savings Come From</h2>
              <p className="text-lg text-muted-foreground">Based on typical mid-sized fleet deployments.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {savingsData.breakdown.map((item, index) => (
                <ValueBreakdownCard 
                  key={item.id}
                  title={item.title}
                  amount={item.amount}
                  description={item.description}
                  icon={item.icon}
                  delay={index * 0.1}
                />
              ))}
            </div>
          </section>

          <section className="py-12">
            <div className="bg-secondary text-secondary-foreground rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="md:w-1/2">
                <h2 className="text-3xl font-bold mb-4">Your Return on Operion</h2>
                <p className="text-secondary-foreground/80 text-lg leading-relaxed">
                  Our platform pays for itself within months, not years. The efficiency gains compound over time as the AI learns your specific crew operational patterns.
                </p>
              </div>
              <div className="md:w-1/2 flex flex-col sm:flex-row gap-6 w-full">
                <div className="bg-background/10 rounded-2xl p-6 flex-1 border border-secondary-foreground/10">
                  <div className="text-sm text-secondary-foreground/70 mb-2 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" /> Estimated ROI
                  </div>
                  <div className="text-4xl font-bold">{savingsData.roiMultiple}</div>
                </div>
                <div className="bg-background/10 rounded-2xl p-6 flex-1 border border-secondary-foreground/10">
                  <div className="text-sm text-secondary-foreground/70 mb-2 flex items-center gap-2">
                    <Clock className="w-4 h-4" /> Payback Period
                  </div>
                  <div className="text-4xl font-bold">{savingsData.paybackMonths} <span className="text-xl font-normal">mo</span></div>
                </div>
              </div>
            </div>
          </section>

          <TransparencyPanel />
          <CostVsSavingsComparison />
          <PilotProgramSection />
          <AIAssistantTrigger />

        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default PricingPage;