import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calculator, CheckCircle2, Download, TrendingDown, Clock, Info } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BreadcrumbSchema from '@/components/BreadcrumbSchema.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import InfoTooltip from '@/components/InfoTooltip.jsx';

import { generatePDFReport, calculateSavingsRange } from '@/lib/SavingsCalculationEngine.js';
import ScenarioComparison from '@/components/simulator/ScenarioComparison.jsx';
import CollapsibleExplainabilityPanel from '@/components/simulator/CollapsibleExplainabilityPanel.jsx';
import SavingsRangeVisualization from '@/components/simulator/SavingsRangeVisualization.jsx';
import TrustLayer from '@/components/simulator/TrustLayer.jsx';
import RefinedPilotProgram from '@/components/simulator/RefinedPilotProgram.jsx';
import { formatCurrency, formatNumber } from '@/lib/formatters.js';

const OffshoreSavingsSimulatorPage = () => {
  const [inputs, setInputs] = useState({
    crewCount: 500,
    rotationLength: 28,
    monthlyRotations: 50,
    costPerMovement: 1500,
    disruptionRate: 15
  });

  const [scenarioResults, setScenarioResults] = useState(null);

  // Local calculation engine for Offshore specifics
  const calculateOffshoreSavings = (currentInputs, scenario) => {
    const { monthlyRotations, costPerMovement, disruptionRate } = currentInputs;
    
    // (1) Annual Crew Movements
    const annualMovements = monthlyRotations * 12;
    
    // (2) Estimated Inefficiency Cost
    const inefficiencyCost = annualMovements * costPerMovement * (disruptionRate / 100);

    // (3) Optimization Impact factors
    let improvementFactor;
    switch(scenario) {
      case 'conservative': improvementFactor = 0.15; break;
      case 'aggressive': improvementFactor = 0.25; break;
      case 'expected':
      default: improvementFactor = 0.20; break;
    }

    // (4) Estimated Annual Savings
    const totalSavings = inefficiencyCost * improvementFactor;

    return {
      totalSavings,
      logisticsSavings: totalSavings * 0.50,
      disruptionSavings: totalSavings * 0.30,
      utilizationSavings: totalSavings * 0.20,
      annualMovements,
      inefficiencyCost
    };
  };

  useEffect(() => {
    setScenarioResults({
      conservative: calculateOffshoreSavings(inputs, 'conservative'),
      expected: calculateOffshoreSavings(inputs, 'expected'),
      aggressive: calculateOffshoreSavings(inputs, 'aggressive')
    });
  }, [inputs]);

  const handleSliderChange = (name, value) => {
    setInputs(prev => ({ ...prev, [name]: value[0] }));
  };

  const handleDownloadPDF = async () => {
    toast.loading('Preparing PDF report...');
    try {
      await generatePDFReport();
      toast.dismiss();
      toast.success('Report ready for printing/saving');
    } catch (error) {
      toast.dismiss();
      toast.error('Failed to generate report. Please try again.');
    }
  };

  const renderSlider = (id, label, min, max, step, formatFn, tooltipText) => (
    <div className="bg-background p-4 rounded-xl border border-border/50">
      <InfoTooltip label={label} tooltipText={tooltipText}>
        <div className="flex justify-between items-center mb-3">
          <span className="font-mono font-semibold text-primary bg-primary/10 px-2 py-1 rounded-md text-sm ml-auto">
            {formatFn(inputs[id])}
          </span>
        </div>
        <Slider
          id={id}
          min={min}
          max={max}
          step={step}
          value={[inputs[id]]}
          onValueChange={(val) => handleSliderChange(id, val)}
          className="py-2"
        />
      </InfoTooltip>
    </div>
  );

  const getExplainabilityData = (scenarioKey) => {
    if (!scenarioResults) return null;
    const data = scenarioResults[scenarioKey];
    
    return {
      assumptions: {
        'Total Offshore Crew': `${formatNumber(inputs.crewCount)} personnel`,
        'Rotation Cycle': `${inputs.rotationLength} days`,
        'Annual Movements': `${formatNumber(data.annualMovements)} movements/year`,
        'Cost per Movement': formatCurrency(inputs.costPerMovement),
        'Baseline Disruption Rate': `${inputs.disruptionRate}%`
      },
      breakdown: [
        { label: 'Logistics Optimization', value: data.logisticsSavings },
        { label: 'Disruption Avoidance', value: data.disruptionSavings },
        { label: 'Crew Utilization Gains', value: data.utilizationSavings }
      ],
      adoption: {
        percentage: scenarioKey === 'conservative' ? 30 : scenarioKey === 'expected' ? 70 : 100,
        description: scenarioKey === 'conservative' 
          ? 'Assumes partial rollout and basic shift overlap reductions.'
          : scenarioKey === 'expected'
          ? 'Assumes standardized adoption with full integration of travel planning.'
          : 'Assumes automated end-to-end logistics execution and 100% organizational compliance.'
      },
      timeframe: {
        annualization: 'Values represent a full 12-month operational period.',
        rampUp: 'Assumes a 4-week initial implementation and onboarding phase.',
        realization: 'ROI typically begins compounding in month 2 post-deployment.'
      }
    };
  };

  return (
    <div className="min-h-screen flex flex-col bg-background print:bg-white">
      <Helmet>
        <title>Offshore Operations Savings Simulator | Operion</title>
        <meta name="description" content="Estimate the operational savings from optimizing offshore crew rotations and coordination." />
      </Helmet>

      <BreadcrumbSchema 
        items={[
          { name: 'Home', url: '/' },
          { name: 'ROI', url: '/roi' },
          { name: 'Offshore Savings Simulator', url: '/roi/offshore-simulator' }
        ]} 
      />

      <Header />

      <main className="flex-grow pt-20 print:pt-0">
        {/* Hero Section */}
        <section 
          className="header-hero print-hide"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1616509974337-0001d3d87e80)' }}
        >
          <div className="header-overlay"></div>
          <div className="header-content text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="inline-flex items-center gap-2 rounded-full border border-cyan-500/40 bg-cyan-500/20 px-3 py-1 text-sm font-medium text-cyan-100 mb-6 backdrop-blur-sm">
                <Calculator className="w-4 h-4" />
                <span>Value-Based Engagement</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-6 text-balance tracking-tight">
                Offshore Operations <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">Savings Simulator</span>
              </h1>
              <p className="text-lg md:text-xl text-slate-200 mb-10 max-w-3xl mx-auto text-balance leading-relaxed">
                Estimate the operational savings from optimizing offshore crew rotations and coordination based on your organization's specific metrics.
              </p>
              
              <div className="flex flex-wrap justify-center gap-6 mb-12">
                <div className="flex items-center gap-2 text-sm text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" /> Based on industry benchmarks
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" /> Transparent calculations
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" /> Validated through simulation
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Calculator Section */}
        <section className="py-12 relative z-20 print:mt-0 print:py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
              
              {/* Left Column: Inputs */}
              <div className="xl:col-span-4 space-y-6 print-hide">
                <div className="bg-card rounded-2xl shadow-xl border border-border p-6">
                  <div className="mb-6">
                    <h2 className="text-xl font-bold text-foreground">Operational Parameters</h2>
                    <p className="text-sm text-muted-foreground mt-1">Estimates update instantly based on your inputs.</p>
                  </div>

                  <div className="space-y-4">
                    {renderSlider('crewCount', 'Number of Offshore Crew', 50, 5000, 10, (v) => formatNumber(v), 'Total number of active personnel in offshore rotations.')}
                    {renderSlider('rotationLength', 'Rotation Cycle Length (Days)', 7, 90, 1, (v) => `${v} days`, 'Average length of a single offshore shift/rotation in days.')}
                    {renderSlider('monthlyRotations', 'Monthly Crew Rotations', 10, 1000, 5, (v) => formatNumber(v), 'Average number of complete crew changes taking place each month.')}
                    {renderSlider('costPerMovement', 'Avg. Cost per Movement (€)', 200, 10000, 100, (v) => formatCurrency(v), 'Average end-to-end logistics cost per individual crew member movement.')}
                    {renderSlider('disruptionRate', 'Estimated Disruption Rate (%)', 0, 100, 1, (v) => `${v}%`, 'Percentage of movements affected by delays, weather, or scheduling conflicts.')}
                  </div>
                </div>
              </div>

              {/* Right Column: Results */}
              <div className="xl:col-span-8 space-y-8">
                {scenarioResults && (
                  <div className="bg-card rounded-2xl shadow-xl border border-border p-6 sm:p-8">
                    
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
                      <div>
                        <h2 className="text-2xl font-bold text-foreground">Scenario Analysis</h2>
                        <p className="text-muted-foreground text-sm mt-1">Operion typically saves offshore operators between {formatCurrency(scenarioResults.conservative.totalSavings)} and {formatCurrency(scenarioResults.aggressive.totalSavings)} annually.</p>
                      </div>
                      
                      <Button variant="outline" size="sm" onClick={handleDownloadPDF} className="print-hide shrink-0">
                        <Download className="w-4 h-4 mr-2" /> Export PDF
                      </Button>
                    </div>

                    {/* Custom Primary Output Display */}
                    <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/5 border border-cyan-500/20 rounded-2xl p-6 sm:p-8 mb-10 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4 pointer-events-none" />
                      
                      <h3 className="text-sm font-semibold uppercase tracking-wider text-cyan-800 dark:text-cyan-300 mb-2">
                        Expected Annual Savings
                      </h3>
                      <div className="text-4xl md:text-6xl font-extrabold text-cyan-600 dark:text-cyan-400 tabular-nums tracking-tight mb-6">
                        {formatCurrency(scenarioResults.expected.totalSavings)}
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6 border-t border-cyan-500/20">
                        <div className="flex items-start gap-4">
                          <div className="p-2.5 bg-emerald-500/10 rounded-xl text-emerald-600 dark:text-emerald-400 shrink-0">
                            <TrendingDown className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground text-base">Disruption Reduction</h4>
                            <p className="text-emerald-600 dark:text-emerald-400 font-bold text-lg">20% Decrease</p>
                            <p className="text-sm text-muted-foreground mt-1">In delayed crew changes and overlapping layovers</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-4">
                          <div className="p-2.5 bg-blue-500/10 rounded-xl text-blue-600 dark:text-blue-400 shrink-0">
                            <Clock className="w-6 h-6" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-foreground text-base">Improved Crew Utilization</h4>
                            <p className="text-blue-600 dark:text-blue-400 font-bold text-lg">+15% Productive Time</p>
                            <p className="text-sm text-muted-foreground mt-1">Achieved through optimized rotation planning</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mb-10">
                      <SavingsRangeVisualization 
                        {...calculateSavingsRange(scenarioResults)} 
                      />
                    </div>

                    <div className="mb-10">
                      <ScenarioComparison scenarios={scenarioResults} />
                    </div>

                    <div className="space-y-4 mb-10">
                      <h3 className="text-lg font-semibold text-foreground mb-4">Detailed Scenario Assumptions</h3>
                      <CollapsibleExplainabilityPanel 
                        scenarioName="Expected"
                        {...getExplainabilityData('expected')}
                      />
                      <CollapsibleExplainabilityPanel 
                        scenarioName="Conservative"
                        {...getExplainabilityData('conservative')}
                      />
                    </div>

                    <TrustLayer />

                    {/* Important Integration Note */}
                    <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-5 flex gap-4 mt-10">
                      <Info className="w-6 h-6 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-sm font-semibold text-blue-900 dark:text-blue-200 mb-1">Important Integration Note</h4>
                        <p className="text-sm text-blue-800/80 dark:text-blue-300/80 leading-relaxed">
                          Operion improves offshore operational efficiency by optimizing planning and coordination. Execution of crew movements is handled via integrated external providers.
                        </p>
                      </div>
                    </div>

                    <div className="mt-8 text-center border-t border-border pt-6 flex flex-wrap justify-center gap-4">
                      <Button asChild variant="outline">
                        <Link to="/roi">Back to ROI Overview</Link>
                      </Button>
                      <Button asChild variant="ghost">
                        <Link to="/aviation-savings-simulator">Aviation Simulator</Link>
                      </Button>
                      <Button asChild variant="ghost">
                        <Link to="/maritime-savings-simulator">Maritime Simulator</Link>
                      </Button>
                    </div>

                    <div className="mt-8 text-center">
                      <p className="text-xs text-muted-foreground max-w-2xl mx-auto">
                        * Actual results depend on implementation depth, organizational adoption, and specific operational constraints. These figures are estimates for evaluation purposes.
                      </p>
                    </div>

                  </div>
                )}
              </div>

            </div>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <RefinedPilotProgram industry="offshore" />
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default OffshoreSavingsSimulatorPage;