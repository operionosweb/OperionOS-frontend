import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useLocation, useNavigate } from 'react-router-dom';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import DecisionAlertsSystem from '@/components/demo/aviation/DecisionAlertsSystem.jsx';
import DecisionInsightsPanel from '@/components/demo/aviation/DecisionInsightsPanel.jsx';
import {
  MissionControlDashboard,
  AviationFleetOverview,
  AviationContractsSection,
  AviationFinancialDashboard,
  AviationScenarioSimulator,
  FlightOperationsSection,
  CrewManagementSection,
  CrewTravelLogisticsSection,
  DisruptionManagementSection,
  FinancialControlSection,
  NotificationsCenterSection,
  ComplianceSafetySection,
  CommunicationHubSection,
  AircraftMaintenanceSection
} from '@/components/demo/aviation/AviationSections.jsx';

const AviationDemoPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const path = location.pathname;
  let content = <MissionControlDashboard />;
  let title = "Mission Control";

  if (path.includes('/fleet')) {
    content = <AviationFleetOverview onRunScenario={(id) => navigate(`/demo/aviation/scenarios?aircraft=${id}`)} />;
    title = "Fleet Overview";
  } else if (path.includes('/contracts')) {
    content = <AviationContractsSection />;
    title = "Contract Intelligence";
  } else if (path.includes('/financials')) {
    content = <AviationFinancialDashboard />;
    title = "Financial Dashboard";
  } else if (path.includes('/scenarios')) {
    const params = new URLSearchParams(location.search);
    content = <AviationScenarioSimulator initialAircraftId={params.get('aircraft')} />;
    title = "Scenario Simulator";
  } else if (path.includes('/crew')) {
    content = <CrewManagementSection />;
    title = "Crew Management";
  } else if (path.includes('/travel')) {
    content = <CrewTravelLogisticsSection />;
    title = "Travel Logistics";
  } else if (path.includes('/disruptions')) {
    content = <DisruptionManagementSection />;
    title = "Disruption Management";
  } else if (path.includes('/flights')) {
    content = <FlightOperationsSection />;
    title = "Flight Operations";
  } else if (path.includes('/financial')) {
    content = <FinancialControlSection />;
    title = "Financial Control";
  } else if (path.includes('/notifications')) {
    content = <NotificationsCenterSection />;
    title = "Notifications";
  } else if (path.includes('/compliance')) {
    content = <ComplianceSafetySection />;
    title = "Compliance & Safety";
  } else if (path.includes('/comms')) {
    content = <CommunicationHubSection />;
    title = "Communication Hub";
  } else if (path.includes('/maintenance')) {
    content = <AircraftMaintenanceSection />;
    title = "Aircraft Maintenance";
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Helmet><title>{title} | Operion Aviation</title></Helmet>
      
      <LeftSidebar industry="aviation" isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} isMobile={isMobile} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <DemoHeader isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-6 lg:p-8 bg-muted/10">
          <div className="max-w-7xl mx-auto">
            <DecisionAlertsSystem />
            <DecisionInsightsPanel />
            {content}
          </div>
        </main>
      </div>
      
      {isMobile && <BottomNavigation />}
    </div>
  );
};

export default AviationDemoPage;