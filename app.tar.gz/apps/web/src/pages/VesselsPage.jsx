import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import Header from '@/components/Header.jsx';
import { generateVessels, generateInsights, handleAction } from '@/lib/vesselData.js';
import { 
  OperationsDashboard, SearchFilterBar, AIInsightsCard, 
  VesselProfilePanel, ActionModal 
} from '@/components/vessels/VesselComponents.jsx';
import MapContainer from '@/components/vessels/MapContainer.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card } from '@/components/ui/card.jsx';
import { Ship, ArrowRight, Activity, CheckCircle2 } from 'lucide-react';

const VesselsPage = () => {
  const [allVessels, setAllVessels] = useState([]);
  const [insights, setInsights] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showOwnedOnly, setShowOwnedOnly] = useState(false);
  const [selectedVessel, setSelectedVessel] = useState(null);
  const [actionState, setActionState] = useState({ isOpen: false, type: null, data: null, isProcessing: false });

  useEffect(() => {
    setAllVessels(generateVessels(200));
    setInsights(generateInsights());
  }, []);

  const filteredVessels = useMemo(() => {
    return allVessels.filter(v => {
      const matchesSearch = v.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            v.imo.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesOwnership = showOwnedOnly ? v.isOwned : true;
      return matchesSearch && matchesOwnership;
    });
  }, [allVessels, searchQuery, showOwnedOnly]);

  const handleActionConfirm = async () => {
    setActionState(prev => ({ ...prev, isProcessing: true }));
    await handleAction(actionState.type, actionState.data);
    setActionState({ isOpen: false, type: null, data: null, isProcessing: false });
    // In a real app, we'd show a toast here
  };

  return (
    <>
      <Helmet>
        <title>Global Vessel Intelligence | Crew & Travel</title>
        <meta name="description" content="Track every vessel. Manage your fleet. Control your crew — all in one system." />
      </Helmet>

      <div className="min-h-screen bg-[#0B1220] text-white pb-24">
        <Header />

        {/* Hero Section */}
        <section className="relative pt-32 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="absolute inset-0 z-0 overflow-hidden rounded-b-[3rem] opacity-30 pointer-events-none">
            <img 
              src="https://images.unsplash.com/photo-1590497008246-8f3634db768b" 
              alt="Vessel at sea"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#0B1220]/40 via-[#0B1220]/80 to-[#0B1220]"></div>
          </div>

          <div className="relative z-10 text-center max-w-4xl mx-auto">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-6xl font-bold mb-6 text-balance"
            >
              Global Vessel <span className="text-primary">Intelligence</span> Platform
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
              className="text-xl text-gray-400 mb-10"
            >
              Track every vessel. Manage your fleet. Control your crew — all in one system.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-white px-8">
                Explore Fleet
              </Button>
              <Button size="lg" variant="outline" onClick={() => setShowOwnedOnly(true)} className="border-white/20 text-white hover:bg-white/10 px-8">
                View My Vessels
              </Button>
            </motion.div>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <OperationsDashboard vessels={allVessels} />
          
          <SearchFilterBar 
            onSearch={setSearchQuery} 
            onToggleOwned={() => setShowOwnedOnly(!showOwnedOnly)} 
            showOwnedOnly={showOwnedOnly} 
          />

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-12">
            <div className="lg:col-span-3">
              <MapContainer vessels={filteredVessels} onVesselClick={setSelectedVessel} />
            </div>
            <div className="space-y-4">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" /> AI Insights
              </h3>
              <AnimatePresence>
                {insights.map(insight => (
                  <AIInsightsCard 
                    key={insight.id} 
                    insight={insight} 
                    onDismiss={(id) => setInsights(prev => prev.filter(i => i.id !== id))}
                    onAction={(data) => setActionState({ isOpen: true, type: data.action, data, isProcessing: false })}
                  />
                ))}
              </AnimatePresence>
              {insights.length === 0 && (
                <div className="text-center p-6 border border-white/10 rounded-xl bg-white/5 text-gray-500">
                  <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>All clear. No active insights.</p>
                </div>
              )}
            </div>
          </div>

          {/* My Vessels Grid */}
          {showOwnedOnly && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-16">
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-2"><Ship className="h-6 w-6 text-primary"/> My Fleet</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredVessels.filter(v => v.isOwned).map(vessel => (
                  <Card key={vessel.id} className="glass-panel p-6 border-white/10 hover:border-primary/50 transition-colors cursor-pointer" onClick={() => setSelectedVessel(vessel)}>
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-white">{vessel.name}</h3>
                        <p className="text-sm text-gray-400">{vessel.type}</p>
                      </div>
                      <div className={`px-2 py-1 rounded text-xs font-medium ${vessel.status === 'Active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                        {vessel.status}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                      <div><span className="text-gray-500 block">Crew</span><span className="text-white font-medium">{vessel.crew.length} Onboard</span></div>
                      <div><span className="text-gray-500 block">Destination</span><span className="text-white font-medium">{vessel.destination}</span></div>
                    </div>
                    <Button variant="ghost" className="w-full bg-white/5 hover:bg-white/10 text-white justify-between">
                      Manage Vessel <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Card>
                ))}
              </div>
            </motion.div>
          )}
        </div>

        <AnimatePresence>
          {selectedVessel && (
            <VesselProfilePanel 
              vessel={selectedVessel} 
              onClose={() => setSelectedVessel(null)} 
              onCrewClick={(crew) => setActionState({ isOpen: true, type: 'Manage Crew', data: crew, isProcessing: false })}
            />
          )}
        </AnimatePresence>

        <ActionModal 
          isOpen={actionState.isOpen} 
          onClose={() => !actionState.isProcessing && setActionState({ ...actionState, isOpen: false })}
          title={actionState.type || 'Confirm Action'}
          onConfirm={handleActionConfirm}
          isProcessing={actionState.isProcessing}
        />
      </div>
    </>
  );
};

export default VesselsPage;