import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Building2, Plane, FileText, Users, HeartHandshake as Handshake, Workflow, Network, Settings2, Database, Lock, RotateCcw, Send, Map, Monitor, CheckCircle2, XCircle, ArrowRight } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import SEOHead from '@/components/SEOHead.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';

const ProvidersIntegrationPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SEOHead 
        title="Integrate External Providers | Operion"
        description="Learn how Operion integrates with external travel and logistics providers to execute crew movements without replacing them."
        keywords="crew operations, provider integration, travel coordination, external providers"
      />
      
      <Header />

      <main className="flex-grow pt-20">
        
        {/* SECTION 1 - HERO */}
        <section className="relative py-20 md:py-28 lg:py-32 overflow-hidden bg-muted/30 border-b border-border">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-bold text-primary mb-8 uppercase tracking-wider">
                <Network className="w-4 h-4 mr-2" /> Orchestration Ecosystem
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6 text-balance max-w-5xl mx-auto">
                Integrate External Providers Seamlessly
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-10">
                Operion connects with your existing travel and logistics providers to execute crew movements—without replacing them.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4 w-full sm:w-auto">
                <Button asChild size="lg" className="h-14 px-8 text-lg font-bold w-full sm:w-auto shadow-md">
                  <a href="#integration-tech">View Integrations</a>
                </Button>
                <Button asChild size="lg" variant="outline" className="h-14 px-8 text-lg font-bold w-full sm:w-auto">
                  <Link to="/contact-sales">Request Demo</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* SECTION 2 - HOW IT WORKS */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How Operion Integrates With Your Providers</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                A continuous orchestration loop between your operational demands and provider fulfillment.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
              <div className="hidden lg:block absolute top-12 left-[12%] right-[12%] h-0.5 bg-border/60 z-0"></div>
              
              {[
                { title: "Plan Crew Movements", desc: "Operion optimizes rotations and schedules based on your internal rules.", icon: Map },
                { title: "Send Execution Requests", desc: "Automated API orders are dispatched to your selected providers.", icon: Send },
                { title: "Providers Execute", desc: "Your airlines, TMCs, and hotels process the movements using their systems.", icon: Building2 },
                { title: "Track in Real Time", desc: "Status updates and confirmations sync back into your operational dashboard.", icon: Monitor }
              ].map((step, i) => (
                <div key={i} className="bg-card border border-border rounded-2xl p-6 shadow-sm relative z-10 transition-transform hover:-translate-y-1">
                  <div className="w-12 h-12 bg-primary/10 text-primary rounded-xl flex items-center justify-center font-bold mb-5 border border-primary/20">
                    <step.icon className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-lg mb-2">{i + 1}. {step.title}</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 3 - PROVIDER CATEGORIES */}
        <section className="py-24 bg-muted/30 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16 md:flex md:items-end md:justify-between">
              <div className="max-w-2xl">
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Provider Categories We Connect With</h2>
                <p className="text-lg text-muted-foreground">
                  Our flexible API layer supports connections across the entire logistics ecosystem.
                </p>
              </div>
              <div className="mt-6 md:mt-0 max-w-sm bg-primary/10 border border-primary/20 rounded-xl p-4">
                <p className="text-sm font-semibold text-primary">
                  Operion does not own or manage travel inventory. We orchestrate execution through your existing providers.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center mb-6">
                    <Handshake className="w-7 h-7 text-secondary" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Travel Management Companies</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    Integrate seamlessly with TMCs to push approved movements. Compatible with BizAway, Egencia, TravelPerk, Concur, and customized agency APIs.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center mb-6">
                    <Plane className="w-7 h-7 text-secondary" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Airlines & Transport APIs</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    Direct NDC or proprietary API connections to major carriers, global distribution systems (GDS), and specialized ground logistics operators.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center mb-6">
                    <FileText className="w-7 h-7 text-secondary" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Visa & Documentation Services</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    Connect with immigration systems and private visa processors to automate clearance checks before movement orders are executed.
                  </p>
                </CardContent>
              </Card>

              <Card className="border border-border shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-8">
                  <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center mb-6">
                    <Users className="w-7 h-7 text-secondary" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Internal HR & Crew Systems</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    Sync crew rosters, medical certifications, and payroll data from your existing ERP systems to fuel the orchestration engine.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* SECTION 4 - WHY INTEGRATION */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Why Integration Over Replacement</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Modernizing your crew operations doesn't mean tearing up the contracts you already trust.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex gap-4 p-6 rounded-2xl border border-border bg-card">
                <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <Handshake className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold mb-2">Keep Existing Relationships</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    Maintain your negotiated rates and service level agreements with current agencies and airlines without disruption.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 p-6 rounded-2xl border border-border bg-card">
                <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <Workflow className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold mb-2">No Workflow Disruption</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    Providers continue to use the tools they know. Operion acts as the invisible intelligence layer driving their actions.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 p-6 rounded-2xl border border-border bg-card">
                <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <Settings2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold mb-2">Centralized Operational Control</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    Manage multi-provider operations from a single dashboard. Enforce unified compliance rules across all external partners.
                  </p>
                </div>
              </div>

              <div className="flex gap-4 p-6 rounded-2xl border border-border bg-card">
                <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                  <Network className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold mb-2">Flexibility & Scalability</h3>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    Easily plug in new providers or swap existing ones as your operational footprint grows or requirements change.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 5 - TECHNICAL OVERVIEW */}
        <section id="integration-tech" className="py-24 bg-secondary text-secondary-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16 text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Integration Technology</h2>
              <p className="text-lg text-secondary-foreground/80 max-w-2xl mx-auto">
                Secure, resilient, and built for mission-critical synchronization.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
              <div className="bg-background/5 border border-secondary-foreground/10 rounded-2xl p-8 backdrop-blur-sm">
                <div className="w-12 h-12 rounded-xl bg-background/20 flex items-center justify-center mb-6">
                  <Database className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">API-Based Integrations</h3>
                <p className="text-secondary-foreground/70 leading-relaxed">
                  RESTful and GraphQL endpoints designed for robust, bi-directional data flow. We support standard industry protocols and custom mappings for legacy systems.
                </p>
              </div>

              <div className="bg-background/5 border border-secondary-foreground/10 rounded-2xl p-8 backdrop-blur-sm">
                <div className="w-12 h-12 rounded-xl bg-background/20 flex items-center justify-center mb-6">
                  <Lock className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">Secure Data Exchange</h3>
                <p className="text-secondary-foreground/70 leading-relaxed">
                  Enterprise-grade encryption (AES-256) ensures crew PII and operational data remains protected across the entire transmission pipeline.
                </p>
              </div>

              <div className="bg-background/5 border border-secondary-foreground/10 rounded-2xl p-8 backdrop-blur-sm">
                <div className="w-12 h-12 rounded-xl bg-background/20 flex items-center justify-center mb-6">
                  <RotateCcw className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">Real-Time Synchronization</h3>
                <p className="text-secondary-foreground/70 leading-relaxed">
                  Webhook-driven architecture ensures that status changes, delays, and confirmations are reflected in Operion instantly without polling overhead.
                </p>
              </div>

              <div className="bg-background/5 border border-secondary-foreground/10 rounded-2xl p-8 backdrop-blur-sm">
                <div className="w-12 h-12 rounded-xl bg-background/20 flex items-center justify-center mb-6">
                  <Network className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">Fallback Coordination</h3>
                <p className="text-secondary-foreground/70 leading-relaxed">
                  For providers without modern APIs, Operion automates secure email/PDF dispatching and optical character recognition (OCR) ingestion for offline routing.
                </p>
              </div>
            </div>

            <div className="text-center p-4 bg-background/10 rounded-xl border border-secondary-foreground/20 inline-block mx-auto">
              <p className="text-sm font-medium">
                This is a business-level overview. Technical details are available in our integration documentation.
              </p>
            </div>
          </div>
        </section>

        {/* SECTION 6 - POSITIONING STATEMENT */}
        <section className="py-24 bg-background">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">What Operion Is NOT</h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-medium">
                Operion is not a travel booking platform. It is the operational layer that coordinates crew movements while external providers execute travel.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
              <div className="bg-card border border-emerald-500/20 rounded-3xl overflow-hidden shadow-sm">
                <div className="bg-emerald-500/10 px-8 py-6 border-b border-emerald-500/20">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <CheckCircle2 className="w-6 h-6 text-emerald-500" /> What Operion DOES
                  </h3>
                </div>
                <div className="p-8">
                  <ul className="space-y-5">
                    {[
                      "Calculates optimal crew movement plans",
                      "Validates duty hours and compliance rules",
                      "Sends automated execution requests to providers",
                      "Monitors provider execution statuses",
                      "Aggregates data into a single operational view",
                      "Automatically handles disruption logic"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                        <span className="text-foreground font-medium">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              
              <div className="bg-card border border-destructive/20 rounded-3xl overflow-hidden shadow-sm">
                <div className="bg-destructive/10 px-8 py-6 border-b border-destructive/20">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <XCircle className="w-6 h-6 text-destructive" /> What Operion does NOT do
                  </h3>
                </div>
                <div className="p-8">
                  <ul className="space-y-5">
                    {[
                      "Act as an Online Travel Agency (OTA)",
                      "Maintain commercial travel inventory",
                      "Process payments directly to airlines/hotels",
                      "Negotiate travel rates with carriers",
                      "Compete with Travel Management Companies",
                      "Issue physical tickets or boarding passes"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <XCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                        <span className="text-foreground font-medium">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 7 - CTA SECTION */}
        <section className="py-24 bg-primary text-primary-foreground text-center border-t border-primary/20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Ready to Integrate?
            </h2>
            <p className="text-xl text-primary-foreground/90 mb-10 leading-relaxed max-w-2xl mx-auto">
              Connect your providers and take control of crew operations. Standard integrations take days, not months.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild size="lg" className="bg-background text-foreground hover:bg-background/90 rounded-full px-8 text-lg h-14 font-bold shadow-xl transition-all hover:scale-105">
                <Link to="/contact-sales">Connect Your Providers</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent border-2 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 rounded-full px-8 text-lg h-14 font-bold transition-colors">
                <Link to="/architecture">View Integration Docs</Link>
              </Button>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </div>
  );
};

export default ProvidersIntegrationPage;