import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingDown, ShieldCheck, Users, Clock, ArrowRight, Calculator, HeartHandshake as Handshake, BarChart3, Activity, Network, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import SEOHead from '@/components/SEOHead.jsx';

const ROIPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SEOHead 
        title="ROI & Impact | Operion Crew Management"
        description="Measure the financial and operational impact of optimized crew operations. Discover how Operion reduces inefficiencies, compliance risks, and disruption costs."
        keywords="crew management ROI, operational efficiency, disruption recovery cost, crew utilization, compliance risk reduction"
      />
      
      <Header />

      <main className="flex-grow pt-20">
        {/* Temporary Validation Test Text - Visible to screen readers for verification */}
        <div className="sr-only">This is the correct ROI page. Routing is fixed.</div>

        {/* 1. Hero Section */}
        <section 
          className="header-hero"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1625296276703-3fbc924f07b5)' }}
        >
          <div className="header-overlay"></div>
          <div className="header-content">
            <div className="max-w-3xl">
              <div className="inline-flex items-center rounded-full border border-primary/40 bg-primary/20 px-3 py-1 text-sm font-semibold text-primary-foreground mb-6 backdrop-blur-sm">
                MEASURABLE IMPACT
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-white mb-6 text-balance" style={{ letterSpacing: '-0.02em' }}>
                Measure the Impact of Optimized Crew Operations
              </h1>
              <p className="text-xl text-slate-200 mb-10 leading-relaxed max-w-2xl">
                Transform your crew logistics from a cost center into a strategic advantage through improved planning, seamless coordination, and proactive disruption management.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 text-lg h-14 transition-all">
                  <Link to="/savings-simulator">
                    <Calculator className="mr-2 w-5 h-5" /> Calculate Your ROI
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="rounded-full px-8 text-lg h-14 border-white/20 text-white hover:bg-white/10 bg-black/20 backdrop-blur-sm transition-all">
                  <Link to="/demo">Explore the Platform</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* 2. Key Value Drivers */}
        <section className="py-20 bg-muted/30 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16 max-w-2xl">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Key Value Drivers</h2>
              <p className="text-lg text-muted-foreground">
                Operion targets the most expensive inefficiencies in global crew operations, delivering compounding returns across your organization.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
              <div className="bg-card border border-border rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                  <TrendingDown className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Reduced Crew Travel Inefficiencies</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Minimize overlapping logistics, unnecessary layovers, and suboptimal routing by generating holistic movement plans that align with operational schedules.
                </p>
              </div>
              
              <div className="bg-card border border-border rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                  <Activity className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Fewer Disruption-Related Costs</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Recover faster from delays and cancellations. Operion instantly identifies the most cost-effective recovery scenarios, preventing cascading operational failures.
                </p>
              </div>
              
              <div className="bg-card border border-border rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Improved Crew Utilization</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Maximize productive duty time while strictly adhering to fatigue rules. Better rotation planning means fewer standby crews required and lower overtime expenses.
                </p>
              </div>
              
              <div className="bg-card border border-border rounded-2xl p-8 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-6">
                  <ShieldCheck className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">Lower Compliance Risks</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Automated tracking of certifications, visas, and duty limits prevents costly regulatory fines and avoids the operational halt of deploying non-compliant crew.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 3. ROI Breakdown */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-20">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">Where the Savings Happen</h2>
            </div>

            <div className="space-y-24">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="order-2 lg:order-1">
                  <div className="flex items-center gap-3 mb-4">
                    <BarChart3 className="w-6 h-6 text-primary" />
                    <h3 className="text-2xl font-semibold text-foreground">Planning Optimization</h3>
                  </div>
                  <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                    Manual scheduling leaves money on the table. Our AI engine evaluates millions of permutations to find the optimal balance between operational requirements, crew fatigue, and logistical costs before a single movement is executed.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-foreground">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span>Reduce total required standby headcount</span>
                    </li>
                    <li className="flex items-start gap-3 text-foreground">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span>Minimize deadhead and repositioning flights</span>
                    </li>
                  </ul>
                </div>
                <div className="order-1 lg:order-2 bg-muted rounded-2xl aspect-video flex items-center justify-center border border-border p-8">
                  <div className="w-full h-full bg-card rounded-xl shadow-sm border border-border flex flex-col p-6">
                    <div className="h-4 w-1/3 bg-muted rounded mb-8"></div>
                    <div className="flex-grow flex items-end gap-4">
                      <div className="w-1/4 bg-primary/20 h-[60%] rounded-t-md"></div>
                      <div className="w-1/4 bg-primary/40 h-[80%] rounded-t-md"></div>
                      <div className="w-1/4 bg-primary/60 h-[40%] rounded-t-md"></div>
                      <div className="w-1/4 bg-primary h-[100%] rounded-t-md"></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="bg-muted rounded-2xl aspect-video flex items-center justify-center border border-border p-8">
                  <div className="w-full h-full bg-card rounded-xl shadow-sm border border-border flex items-center justify-center relative overflow-hidden">
                    <Network className="w-24 h-24 text-primary/20 absolute" />
                    <div className="flex gap-4 z-10">
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30"><Users className="w-5 h-5 text-primary" /></div>
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30"><Handshake className="w-5 h-5 text-primary" /></div>
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30"><Clock className="w-5 h-5 text-primary" /></div>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <Network className="w-6 h-6 text-primary" />
                    <h3 className="text-2xl font-semibold text-foreground">Better Coordination</h3>
                  </div>
                  <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                    Siloed communication leads to missed connections and wasted hotel nights. Operion acts as the central nervous system, ensuring that when a schedule changes, all downstream logistics are automatically updated.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3 text-foreground">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span>Eliminate no-show fees for ground transport and hotels</span>
                    </li>
                    <li className="flex items-start gap-3 text-foreground">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span>Reduce manual coordination hours by operations staff</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Example Scenarios */}
        <section className="py-24 bg-muted/30 border-y border-border">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Real-World Impact Scenarios</h2>
              <p className="text-lg text-muted-foreground">
                How optimized operations translate directly to the bottom line.
              </p>
            </div>

            <div className="space-y-6">
              <div className="bg-card border-l-4 border-l-primary border-y border-r border-border rounded-r-2xl p-6 md:p-8 shadow-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">Missed Crew Rotation Avoided</h3>
                    <p className="text-muted-foreground">
                      A delayed inbound flight threatens a vessel departure. Operion instantly identifies an alternative compliant crew member already in the port city, avoiding a 12-hour operational delay.
                    </p>
                  </div>
                  <div className="shrink-0 bg-muted px-4 py-3 rounded-xl text-center min-w-[140px]">
                    <span className="block text-sm font-medium text-muted-foreground uppercase tracking-wider mb-1">Est. Savings</span>
                    <span className="text-2xl font-bold text-foreground">$45,000+</span>
                  </div>
                </div>
              </div>

              <div className="bg-card border-l-4 border-l-primary border-y border-r border-border rounded-r-2xl p-6 md:p-8 shadow-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">Reduced Idle Crew Time</h3>
                    <p className="text-muted-foreground">
                      By optimizing the overlap between off-signing and on-signing crews, hotel nights and per-diem costs are reduced by an average of 1.5 days per rotation cycle across the fleet.
                    </p>
                  </div>
                  <div className="shrink-0 bg-muted px-4 py-3 rounded-xl text-center min-w-[140px]">
                    <span className="block text-sm font-medium text-muted-foreground uppercase tracking-wider mb-1">Est. Savings</span>
                    <span className="text-2xl font-bold text-foreground">12-15%</span>
                    <span className="block text-xs text-muted-foreground mt-1">of logistics budget</span>
                  </div>
                </div>
              </div>

              <div className="bg-card border-l-4 border-l-primary border-y border-r border-border rounded-r-2xl p-6 md:p-8 shadow-sm">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">Faster Disruption Recovery</h3>
                    <p className="text-muted-foreground">
                      During a severe weather event, automated reassignment algorithms process 500+ crew changes in minutes, maintaining compliance and minimizing the need for premium last-minute travel bookings.
                    </p>
                  </div>
                  <div className="shrink-0 bg-muted px-4 py-3 rounded-xl text-center min-w-[140px]">
                    <span className="block text-sm font-medium text-muted-foreground uppercase tracking-wider mb-1">Recovery Time</span>
                    <span className="text-2xl font-bold text-foreground">80% Faster</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 5. Integration Note */}
        <section className="py-16 bg-secondary text-secondary-foreground">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-center gap-8 bg-secondary-foreground/5 rounded-3xl p-8 md:p-12 border border-secondary-foreground/10">
              <div className="shrink-0 bg-background/10 p-4 rounded-2xl">
                <Handshake className="w-12 h-12 text-secondary-foreground" />
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-bold mb-3">We Orchestrate. Your Providers Execute.</h2>
                <p className="text-secondary-foreground/80 text-lg leading-relaxed max-w-3xl">
                  Operion is an operational intelligence layer, not a marketplace. We integrate directly with your existing travel management companies, airlines, and ground logistics partners via API. You keep your negotiated rates and trusted relationships; we provide the automation to make them work together flawlessly.
                </p>
                <Button asChild variant="link" className="text-secondary-foreground hover:text-secondary-foreground/80 p-0 h-auto mt-4 text-base font-semibold">
                  <Link to="/providers" className="flex items-center">
                    Learn about Provider Integration <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* 6. Call to Action */}
        <section className="py-24 bg-background text-center">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Ready to See Your Potential Savings?</h2>
            <p className="text-xl text-muted-foreground mb-10">
              Schedule a personalized demonstration to see how Operion can streamline your specific operational challenges.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 text-lg h-14 transition-all">
                <Link to="/contact-sales">Book a Demo</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-full px-8 text-lg h-14 border-border text-foreground hover:bg-muted transition-all">
                <Link to="/savings-simulator">Try the Simulator</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default ROIPage;