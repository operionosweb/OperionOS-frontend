import React from 'react';
import LegalPageLayout from '@/components/LegalPageLayout.jsx';

const TermsOfServicePage = () => {
  const sections = [
    {
      id: 'introduction',
      title: '1. Introduction & Acceptance of Terms',
      content: (
        <>
          <p>
            Welcome to Operion. These Terms of Service ("Terms") govern your access to and use of the Operion platform, website, and related services (collectively, the "Service").
          </p>
          <p>
            By accessing or using the Service, you agree to be bound by these Terms. If you disagree with any part of the terms, then you may not access the Service. If you are using the Service on behalf of an organization, you represent that you have the authority to bind that organization to these Terms.
          </p>
        </>
      )
    },
    {
      id: 'description-of-service',
      title: '2. Description of Service',
      content: (
        <>
          <p>
            Operion provides an AI-powered operational efficiency platform designed for the aviation and maritime industries. The Service includes tools for crew management, flight/vessel operations, disruption recovery, and business intelligence analytics.
          </p>
          <p>
            We reserve the right to modify, suspend, or discontinue the Service (or any part thereof) at any time, with or without notice. We will not be liable to you or to any third party for any modification, suspension, or discontinuance of the Service.
          </p>
        </>
      )
    },
    {
      id: 'user-responsibilities',
      title: '3. User Responsibilities',
      content: (
        <>
          <p>As a user of the Operion platform, you agree to:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>Provide accurate, current, and complete information during the registration process.</li>
            <li>Maintain the security and confidentiality of your account credentials.</li>
            <li>Promptly notify us of any unauthorized use of your account or any other breach of security.</li>
            <li>Use the Service in compliance with all applicable local, state, national, and international laws and regulations.</li>
            <li>Not use the Service for any illegal or unauthorized purpose.</li>
          </ul>
        </>
      )
    },
    {
      id: 'account-usage',
      title: '4. Account Usage',
      content: (
        <>
          <p>
            Your account is for your exclusive use. You may not authorize others to use your account, and you may not assign or otherwise transfer your account to any other person or entity.
          </p>
          <p>
            We reserve the right to terminate accounts, refuse service, or cancel orders at our sole discretion if we believe that your conduct violates applicable law or is harmful to our interests.
          </p>
        </>
      )
    },
    {
      id: 'payment-pricing',
      title: '5. Payment & Pricing',
      content: (
        <>
          <p>
            Access to certain features of the Service requires payment of fees. Pricing is determined by your organization's Master Service Agreement (MSA) or the pricing tier selected during registration.
          </p>
          <p>
            All fees are exclusive of all taxes, levies, or duties imposed by taxing authorities, and you shall be responsible for payment of all such taxes, levies, or duties. We reserve the right to change our pricing upon 30 days notice.
          </p>
        </>
      )
    },
    {
      id: 'intellectual-property',
      title: '6. Intellectual Property',
      content: (
        <>
          <p>
            The Service and its original content, features, and functionality are and will remain the exclusive property of Operion and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries.
          </p>
          <p>
            Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Operion.
          </p>
        </>
      )
    },
    {
      id: 'limitation-of-liability',
      title: '7. Limitation of Liability',
      content: (
        <>
          <p>
            In no event shall Operion, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>Your access to or use of or inability to access or use the Service;</li>
            <li>Any conduct or content of any third party on the Service;</li>
            <li>Any content obtained from the Service; and</li>
            <li>Unauthorized access, use or alteration of your transmissions or content.</li>
          </ul>
        </>
      )
    },
    {
      id: 'termination',
      title: '8. Termination',
      content: (
        <>
          <p>
            We may terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.
          </p>
          <p>
            Upon termination, your right to use the Service will immediately cease. If you wish to terminate your account, you may simply discontinue using the Service or contact your account administrator.
          </p>
        </>
      )
    },
    {
      id: 'governing-law',
      title: '9. Governing Law',
      content: (
        <>
          <p>
            These Terms shall be governed and construed in accordance with the laws of the State of Delaware, United States, without regard to its conflict of law provisions.
          </p>
          <p>
            Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect.
          </p>
        </>
      )
    },
    {
      id: 'contact-information',
      title: '10. Contact Information',
      content: (
        <>
          <p>If you have any questions about these Terms, please contact our Legal Department:</p>
          <div className="bg-muted/50 p-6 rounded-xl border border-border mt-6">
            <p className="font-medium text-foreground mb-2">Operion Legal Team</p>
            <p>Email: <a href="mailto:legal@operion.com" className="text-primary hover:underline">legal@operion.com</a></p>
            <p className="mt-2">Address: 1209 North Orange Street, Wilmington, DE 19801</p>
          </div>
        </>
      )
    }
  ];

  return (
    <LegalPageLayout
      seoTitle="Terms of Service | Operion"
      seoDescription="Legal terms governing your use of Operion's operational efficiency platform. Read our complete terms and conditions."
      title="Terms of Service"
      description="The legal agreement governing your use of Operion's platform and services."
      lastUpdated="November 1, 2025"
      sections={sections}
    />
  );
};

export default TermsOfServicePage;