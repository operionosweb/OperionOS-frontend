import React from 'react';
import LegalPageLayout from '@/components/LegalPageLayout.jsx';

const ArchitecturePage = () => {
  const sections = [
    {
      id: 'system-overview',
      title: '1. System Overview',
      content: (
        <>
          <p>
            The Operion platform is built on a modern, cloud-native architecture designed specifically to handle the high-throughput, low-latency demands of global aviation and maritime operations. 
          </p>
          <p>
            Our system utilizes a microservices-based approach, allowing independent scaling of critical components such as the AI optimization engine, real-time telemetry ingestion, and user-facing dashboards.
          </p>
        </>
      )
    },
    {
      id: 'data-flow',
      title: '2. Data Flow',
      content: (
        <>
          <p>
            Data flows through the Operion ecosystem in a secure, predictable manner:
          </p>
          <ol className="list-decimal pl-6 space-y-3 mt-4">
            <li><strong>Ingestion:</strong> Telemetry, crew updates, and weather data are ingested via high-throughput API gateways and message brokers (e.g., Apache Kafka).</li>
            <li><strong>Processing:</strong> Stream processing engines normalize, validate, and enrich the incoming data in real-time.</li>
            <li><strong>Analysis:</strong> Our proprietary AI models evaluate the data against operational constraints to generate optimization recommendations.</li>
            <li><strong>Delivery:</strong> Results are pushed to the frontend clients via WebSockets for live updates, while historical data is aggregated for BI reporting.</li>
          </ol>
        </>
      )
    },
    {
      id: 'core-components',
      title: '3. Core Components',
      content: (
        <>
          <h3 className="text-xl font-semibold text-foreground mt-6 mb-4">Frontend</h3>
          <p>
            The user interface is a Single Page Application (SPA) built with <strong>React.js</strong>. It leverages modern state management and component-driven design to deliver a highly responsive experience. We utilize WebSockets for real-time map updates and disruption alerts, ensuring dispatchers see changes the millisecond they occur.
          </p>

          <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">Backend</h3>
          <p>
            Our backend services are primarily written in <strong>Node.js</strong> and <strong>Express.js</strong>, providing a fast, non-blocking I/O model perfect for handling thousands of concurrent operational events. Computationally heavy AI tasks are offloaded to specialized Python microservices.
          </p>

          <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">Data Layer</h3>
          <p>
            We employ a polyglot persistence strategy to match the right database to the right workload:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>Relational Data:</strong> PostgreSQL for transactional integrity (user accounts, billing, core operational records).</li>
            <li><strong>Time-Series Data:</strong> Specialized time-series databases for vessel/aircraft telemetry and historical tracking.</li>
            <li><strong>Caching:</strong> Redis clusters for session management and sub-millisecond query responses.</li>
          </ul>
        </>
      )
    },
    {
      id: 'scalability-performance',
      title: '4. Scalability & Performance',
      content: (
        <>
          <p>
            Operion is designed to scale horizontally. Our infrastructure is containerized using Docker and orchestrated via Kubernetes. This allows us to automatically spin up additional compute resources during peak operational hours or major weather events that trigger high volumes of disruption recalculations.
          </p>
          <p>
            We maintain a global Content Delivery Network (CDN) to ensure that static assets and frontend applications load instantly for crew members and operators, regardless of their geographic location.
          </p>
        </>
      )
    },
    {
      id: 'integration-capabilities',
      title: '5. Integration Capabilities',
      content: (
        <>
          <p>
            We understand that Operion must fit into your existing IT ecosystem. Our platform exposes a comprehensive suite of RESTful and GraphQL APIs.
          </p>
          <p>
            We provide pre-built connectors for common industry systems, including:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>Legacy Crew Management Systems (CMS)</li>
            <li>Global Distribution Systems (GDS) for travel booking</li>
            <li>Maintenance, Repair, and Overhaul (MRO) software</li>
            <li>HR and Payroll platforms (Workday, SAP)</li>
          </ul>
        </>
      )
    },
    {
      id: 'security-by-design',
      title: '6. Security by Design',
      content: (
        <>
          <p>
            Architecture and security are inseparable at Operion. Our network topology enforces strict boundaries between public-facing APIs, internal microservices, and data storage layers. 
          </p>
          <p>
            All inter-service communication is authenticated and encrypted. For a detailed breakdown of our security controls, please review our <a href="/security" className="text-primary hover:underline">Security Page</a>.
          </p>
        </>
      )
    }
  ];

  return (
    <LegalPageLayout
      seoTitle="Platform Architecture | Operion"
      seoDescription="Understand how Operion's cloud-native architecture delivers scalability, reliability, and performance for maritime and aviation operations."
      title="Platform Architecture"
      description="How Operion's platform is designed for scalability, reliability, and performance."
      lastUpdated="February 22, 2026"
      sections={sections}
    />
  );
};

export default ArchitecturePage;