import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import CrewDatabaseTable from '@/components/demo/crew/CrewDatabaseTable.jsx';
import CrewProfilePanel from '@/components/demo/crew/CrewProfilePanel.jsx';
import { Users, ShieldAlert, Plane, BrainCircuit } from 'lucide-react';
import { Card } from '@/components/ui/card.jsx';

const CrewDemoPageContent = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();
  const [selectedCrew, setSelectedCrew] = useState(null);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <LeftSidebar 
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        isMobile={isMobile}
      />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Sticky Header */}
        <div className="sticky top-0 z-30">
          <DemoHeader 
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
          />
        </div>
        
        {/* Scrollable Main Content */}
        <main className="flex-1 overflow-y-auto pb-24 md:pb-8">
          <div className="max-w-7xl mx-auto p-4 md:p-6 lg:p-8 space-y-8">
            
            {/* Section Header (Scrolls naturally) */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">Crew Intelligence</h1>
                <p className="text-muted-foreground mt-2 text-lg">Manage global personnel, certifications, and assignments.</p>
              </div>
            </div>

            {/* Quick Insights Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="p-4 flex items-center gap-4 border-border shadow-sm">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Crew</p>
                  <p className="text-2xl font-bold">1,248</p>
                </div>
              </Card>
              <Card className="p-4 flex items-center gap-4 border-border shadow-sm">
                <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center text-destructive">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Expiring Certs</p>
                  <p className="text-2xl font-bold">14</p>
                </div>
              </Card>
              <Card className="p-4 flex items-center gap-4 border-border shadow-sm">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500">
                  <Plane className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">In Transit</p>
                  <p className="text-2xl font-bold">42</p>
                </div>
              </Card>
              <Card className="p-4 flex items-center gap-4 border-border shadow-sm">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                  <BrainCircuit className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">AI Insights</p>
                  <p className="text-2xl font-bold">3 Active</p>
                </div>
              </Card>
            </div>

            {/* Main Database Table */}
            <div className="space-y-4">
              <h2 className="text-xl font-bold">Crew Database</h2>
              <CrewDatabaseTable onOpenProfile={setSelectedCrew} />
            </div>

          </div>
        </main>
      </div>

      {isMobile && <BottomNavigation />}

      <CrewProfilePanel 
        crew={selectedCrew} 
        isOpen={!!selectedCrew} 
        onClose={() => setSelectedCrew(null)} 
      />
    </div>
  );
};

const CrewDemoPage = () => {
  return (
    <DemoStateProvider>
      <Helmet>
        <title>Crew Intelligence | Operion Maritime</title>
      </Helmet>
      <CrewDemoPageContent />
    </DemoStateProvider>
  );
};

export default CrewDemoPage;