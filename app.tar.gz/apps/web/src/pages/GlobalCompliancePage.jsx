import React from 'react';
import LegalPageLayout from '@/components/LegalPageLayout.jsx';

const GlobalCompliancePage = () => {
  const sections = [
    {
      id: 'overview',
      title: '1. Overview',
      content: (
        <>
          <p>
            Operating globally in the aviation and maritime sectors requires strict adherence to a complex web of international regulations. Operion is committed to maintaining the highest standards of compliance to ensure our customers can operate confidently across borders.
          </p>
          <p>
            Our compliance program is continuously audited and updated to reflect the latest legal, security, and industry-specific requirements.
          </p>
        </>
      )
    },
    {
      id: 'gdpr',
      title: '2. GDPR (EU Data Protection)',
      content: (
        <>
          <p>
            Operion is fully compliant with the General Data Protection Regulation (GDPR). We act as a Data Processor for our enterprise clients and provide the necessary tools to help you fulfill your obligations as a Data Controller.
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>Data Processing Agreements (DPA):</strong> Standardized DPAs available for all EU/EEA customers.</li>
            <li><strong>Right to be Forgotten:</strong> Automated tools to purge crew member data upon request.</li>
            <li><strong>Privacy by Design:</strong> Data minimization and pseudonymization built into our core architecture.</li>
          </ul>
        </>
      )
    },
    {
      id: 'data-residency',
      title: '3. Data Residency & Sovereignty',
      content: (
        <>
          <p>
            We understand that many national regulations require operational data to remain within specific geographic borders. Operion offers flexible data residency options:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>EU Region:</strong> Data hosted exclusively in Frankfurt (AWS/GCP) to satisfy European sovereignty requirements.</li>
            <li><strong>US Region:</strong> Data hosted in US-East and US-West for North American operators.</li>
            <li><strong>APAC Region:</strong> Dedicated hosting options in Singapore and Sydney for Asia-Pacific clients.</li>
          </ul>
        </>
      )
    },
    {
      id: 'industry-standards',
      title: '4. Industry Standards',
      content: (
        <>
          <p>Operion maintains certifications and alignments with critical global standards:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>ISO/IEC 27001:2022:</strong> Certified Information Security Management System (ISMS).</li>
            <li><strong>SOC 2 Type II:</strong> Annual audits verifying our controls over security, availability, and confidentiality.</li>
            <li><strong>NIST CSF:</strong> Alignment with the National Institute of Standards and Technology Cybersecurity Framework.</li>
            <li><strong>ISO 9001:2015:</strong> Certified Quality Management Systems ensuring consistent service delivery.</li>
          </ul>
        </>
      )
    },
    {
      id: 'regulatory-awareness',
      title: '5. Maritime & Aviation Regulatory Awareness',
      content: (
        <>
          <p>
            Beyond IT compliance, our platform's logic engine is built to understand and enforce industry-specific operational regulations:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>Aviation:</strong> Built-in rule engines for FAA Part 117, EASA FTL, and ICAO fatigue risk management systems.</li>
            <li><strong>Maritime:</strong> Compliance tracking for MLC 2006 (Maritime Labour Convention), STCW rest hours, and IMO regulations.</li>
            <li><strong>Emissions:</strong> Tracking and reporting tools aligned with EU ETS (Emissions Trading System) and CORSIA requirements.</li>
          </ul>
        </>
      )
    },
    {
      id: 'contact-compliance',
      title: '6. Contact & Inquiries',
      content: (
        <>
          <p>
            For audit requests, compliance documentation, or specific regulatory inquiries, please reach out to our dedicated compliance teams:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="bg-muted/50 p-6 rounded-xl border border-border">
              <p className="font-medium text-foreground mb-2">Data Protection Officer</p>
              <p>Email: <a href="mailto:dpo@operion.com" className="text-primary hover:underline">dpo@operion.com</a></p>
              <p className="text-sm text-muted-foreground mt-2">For GDPR, CCPA, and privacy-related matters.</p>
            </div>
            <div className="bg-muted/50 p-6 rounded-xl border border-border">
              <p className="font-medium text-foreground mb-2">Compliance Team</p>
              <p>Email: <a href="mailto:compliance@operion.com" className="text-primary hover:underline">compliance@operion.com</a></p>
              <p className="text-sm text-muted-foreground mt-2">For SOC 2 reports, ISO certificates, and audits.</p>
            </div>
          </div>
        </>
      )
    }
  ];

  return (
    <LegalPageLayout
      seoTitle="Global Compliance | Operion"
      seoDescription="Operion complies with GDPR, ISO 27001, SOC 2, and industry-specific regulations for maritime and aviation."
      title="Global Compliance"
      description="How Operion meets international regulatory requirements and industry standards."
      lastUpdated="March 5, 2026"
      sections={sections}
    />
  );
};

export default GlobalCompliancePage;