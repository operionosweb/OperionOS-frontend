import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Anchor, ShieldCheck, Clock, TrendingDown, ArrowRight } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ROISavingsProvider } from '@/contexts/ROISavingsContext.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';

import KPICardsSection from '@/components/roi/KPICardsSection.jsx';
import SavingsLogSection from '@/components/roi/SavingsLogSection.jsx';
import PendingOpportunitiesSection from '@/components/roi/PendingOpportunitiesSection.jsx';
import VesselAnalysisSection from '@/components/roi/VesselAnalysisSection.jsx';
import CrewAnalysisSection from '@/components/roi/CrewAnalysisSection.jsx';
import SavingsByCategorySection from '@/components/roi/SavingsByCategorySection.jsx';
import AIRecommendationsSection from '@/components/roi/AIRecommendationsSection.jsx';
import OffshoreSavingsSimulator from '@/components/roi/OffshoreSavingsSimulator.jsx';

const ROISavingsContent = () => {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
      {/* Header & Global Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground">ROI & Savings Tracking</h1>
          <p className="text-sm text-muted-foreground mt-1">Monitor financial impact and AI-driven cost reductions.</p>
        </div>
        <div className="flex items-center gap-3">
          <Select defaultValue="YTD">
            <SelectTrigger className="w-[120px] touch-target bg-background">
              <SelectValue placeholder="Time Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="YTD">Year to Date</SelectItem>
              <SelectItem value="Q1">Q1 2026</SelectItem>
              <SelectItem value="2025">2025 Full Year</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="All">
            <SelectTrigger className="w-[140px] touch-target bg-background">
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">Global Fleet</SelectItem>
              <SelectItem value="APAC">APAC Region</SelectItem>
              <SelectItem value="EMEA">EMEA Region</SelectItem>
              <SelectItem value="AMER">Americas</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full space-y-6">
        <div className="overflow-x-auto hide-scrollbar pb-2 -mx-4 px-4 sm:mx-0 sm:px-0">
          <TabsList className="bg-muted/50 p-1 h-auto inline-flex w-max min-w-full sm:min-w-0">
            <TabsTrigger value="dashboard" className="touch-target px-4 py-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Dashboard</TabsTrigger>
            <TabsTrigger value="log" className="touch-target px-4 py-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Savings Log</TabsTrigger>
            <TabsTrigger value="opportunities" className="touch-target px-4 py-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Opportunities</TabsTrigger>
            <TabsTrigger value="vessels" className="touch-target px-4 py-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Vessel Analysis</TabsTrigger>
            <TabsTrigger value="crew" className="touch-target px-4 py-2 rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm">Crew Analysis</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="dashboard" className="space-y-6 md:space-y-8 outline-none mt-0">
          <KPICardsSection />
          <SavingsByCategorySection />
          
          <div>
            <h2 className="text-xl font-bold mb-4">Top AI Recommendations</h2>
            <AIRecommendationsSection />
          </div>

          {/* Offshore Operations Impact Section */}
          <div className="mt-12 mb-8 pt-8 border-t border-border">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
              <div className="max-w-3xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-4">
                  <Anchor className="w-4 h-4" />
                  Offshore Sector
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                  Offshore Operations Impact
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed">
                  Discover how optimized crew rotations and streamlined logistics drive significant financial and operational benefits for offshore platforms, rigs, and specialized vessels.
                </p>
              </div>
              <Button asChild variant="outline" className="shrink-0 rounded-full">
                <Link to="/roi/offshore-simulator">
                  Open Offshore Simulator <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Card 1: Crew Rotation */}
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center mb-5">
                  <Clock className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-3">Crew Rotation Improvements</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Minimize idle time and overlap during shift changes. Automated scheduling ensures crews arrive exactly when needed, reducing unnecessary accommodation and per-diem costs.
                </p>
              </div>
              
              {/* Card 2: Operational Efficiency */}
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-5">
                  <TrendingDown className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-3">Operational Efficiency Gains</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Streamline complex multi-leg journeys (flights, helicopters, ground transport) into a single cohesive itinerary, reducing administrative overhead by up to 40%.
                </p>
              </div>
              
              {/* Card 3: Compliance & Safety */}
              <div className="bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center mb-5">
                  <ShieldCheck className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-3">Compliance & Safety</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Proactively manage fatigue rules and certification requirements before deployment, eliminating the risk of operational halts due to non-compliant crew members.
                </p>
              </div>
            </div>
          </div>
          
          {/* Offshore Simulator appended to dashboard */}
          <OffshoreSavingsSimulator />
        </TabsContent>

        <TabsContent value="log" className="outline-none mt-0">
          <SavingsLogSection />
        </TabsContent>

        <TabsContent value="opportunities" className="outline-none mt-0">
          <PendingOpportunitiesSection />
        </TabsContent>

        <TabsContent value="vessels" className="outline-none mt-0">
          <VesselAnalysisSection />
        </TabsContent>

        <TabsContent value="crew" className="outline-none mt-0">
          <CrewAnalysisSection />
        </TabsContent>
      </Tabs>
    </div>
  );
};

const ROISavingsPage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  return (
    <DemoStateProvider>
      <ROISavingsProvider>
        <Helmet>
          <title>ROI & Savings Tracking | Operion</title>
        </Helmet>

        <div className="flex h-screen bg-background overflow-hidden">
          <LeftSidebar 
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
            isMobile={isMobile}
          />
          
          <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
            <DemoHeader 
              isMobileMenuOpen={isMobileMenuOpen}
              setIsMobileMenuOpen={setIsMobileMenuOpen}
            />
            
            <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
              <ROISavingsContent />
            </main>
          </div>

          {isMobile && <BottomNavigation />}
        </div>
      </ROISavingsProvider>
    </DemoStateProvider>
  );
};

export default ROISavingsPage;