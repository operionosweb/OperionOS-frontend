import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Calculator, 
  Droplet, 
  Wrench, 
  Clock, 
  Leaf, 
  TrendingUp, 
  Ship, 
  Plane,
  CheckCircle2,
  ArrowRight,
  BarChart3,
  ShieldCheck,
  Target,
  Lightbulb
} from 'lucide-react';

import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-100px" },
  transition: { duration: 0.5 }
};

const staggerContainer = {
  initial: { opacity: 0 },
  whileInView: { opacity: 1 },
  viewport: { once: true, margin: "-100px" },
  transition: { staggerChildren: 0.1 }
};

const SavingsSimulatorPage = () => {
  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebPage",
        "name": "Savings Simulator | Operion Operational Efficiency Tools",
        "description": "Understand how Operion calculates savings in maritime and aviation operations through data-driven simulation models. Explore fuel, maintenance, and operational efficiency savings.",
        "url": "https://operion.com/savings-simulator"
      },
      {
        "@type": "Organization",
        "name": "Operion",
        "url": "https://operion.com",
        "logo": "https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/d4c3af1ba833729da85b67b90bdf2c04.png"
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://operion.com/" },
          { "@type": "ListItem", "position": 2, "name": "Savings Simulator", "item": "https://operion.com/savings-simulator" }
        ]
      }
    ]
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Savings Simulator | Operion Operational Efficiency Tools</title>
        <meta name="description" content="Understand how Operion calculates savings in maritime and aviation operations through data-driven simulation models. Explore fuel, maintenance, and operational efficiency savings." />
        <script type="application/ld+json">{JSON.stringify(structuredData)}</script>
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        {/* HERO SECTION */}
        <section className="relative py-20 lg:py-32 overflow-hidden bg-slate-950">
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary/20 via-slate-950 to-slate-950"></div>
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] mix-blend-overlay"></div>
          </div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-sm font-medium text-primary-foreground mb-6">
                <Calculator className="w-4 h-4" />
                <span>ROI & Efficiency Modeling</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-6 text-balance">
                Understand Your Operational <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-teal-400">Savings Potential</span>
              </h1>
              <p className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl mx-auto text-balance leading-relaxed">
                Explore how Operion calculates savings across maritime and aviation operations using data-driven simulation models.
              </p>
              
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button asChild size="lg" className="rounded-full px-8 h-14 text-base font-semibold">
                  <Link to="/maritime-savings-simulator">Maritime Savings Simulator</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="rounded-full px-8 h-14 text-base font-semibold bg-transparent text-white border-slate-700 hover:bg-slate-800 hover:text-white">
                  <Link to="/aviation-savings-simulator">Aviation Savings Simulator</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* SECTION 1 — HOW THE SIMULATORS WORK */}
        <section className="py-20 lg:py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How the Simulators Work</h2>
              <p className="text-lg text-muted-foreground">
                Our simulation models use industry benchmarks and your specific operational data to project potential efficiency gains.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div {...fadeIn} className="space-y-8">
                {[
                  { step: '01', title: 'Input Your Data', desc: 'Provide basic operational metrics like fleet size, fuel costs, and maintenance budgets.' },
                  { step: '02', title: 'Run Simulation Models', desc: 'Our engine applies industry-validated efficiency factors to your baseline costs.' },
                  { step: '03', title: 'Receive Scenario Analysis', desc: 'View Conservative, Expected, and Aggressive savings projections based on adoption levels.' },
                  { step: '04', title: 'Download Your Report', desc: 'Export a detailed PDF breakdown to share with stakeholders and decision-makers.' }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-4">
                    <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg">
                      {item.step}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-foreground mb-2">{item.title}</h3>
                      <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </motion.div>

              <motion.div {...fadeIn} className="bg-muted/50 rounded-2xl p-8 border border-border">
                <h3 className="text-xl font-bold text-foreground mb-6">Key Features</h3>
                <ul className="space-y-4">
                  {[
                    'Real-time dynamic calculations',
                    'Industry-specific benchmark data',
                    'Transparent formula disclosures',
                    'Multi-scenario outcome modeling',
                    'Exportable executive summaries'
                  ].map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-foreground font-medium">{feature}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </div>
          </div>
        </section>

        {/* SECTION 2A — MARITIME CALCULATION MODEL */}
        <section className="py-20 bg-slate-50 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="mb-12">
              <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Maritime Operations Savings Model</h3>
              <p className="text-lg text-muted-foreground max-w-3xl">
                The maritime simulator evaluates four primary cost centers to determine where AI-driven routing and scheduling can reduce overhead.
              </p>
            </motion.div>

            <motion.div variants={staggerContainer} initial="initial" whileInView="whileInView" viewport={{ once: true }} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Droplet, title: 'Fuel Optimization', desc: 'Savings from AI-optimized routing and speed profiles.', range: '5–12% reduction' },
                { icon: Wrench, title: 'Maintenance Optimization', desc: 'Predictive maintenance reducing parts and labor waste.', range: '10–20% reduction' },
                { icon: Clock, title: 'Downtime Reduction', desc: 'Recovered operational days from fewer unplanned repairs.', range: '10–25% reduction' },
                { icon: Leaf, title: 'Emissions Cost (EU ETS)', desc: 'Avoided carbon tax liabilities from reduced fuel burn.', range: 'Directly tied to fuel' }
              ].map((card, idx) => (
                <motion.div key={idx} variants={fadeIn}>
                  <Card className="h-full border-border/50 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-6 flex flex-col h-full">
                      <div className="w-12 h-12 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center mb-4">
                        <card.icon className="w-6 h-6" />
                      </div>
                      <h4 className="text-lg font-semibold text-foreground mb-2">{card.title}</h4>
                      <p className="text-sm text-muted-foreground mb-4 flex-grow">{card.desc}</p>
                      <div className="text-sm font-medium text-blue-600 bg-blue-500/10 px-3 py-1.5 rounded-md inline-block w-fit">
                        Est: {card.range}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* SECTION 2B — AVIATION CALCULATION MODEL */}
        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="mb-12">
              <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Aviation Operations Savings Model</h3>
              <p className="text-lg text-muted-foreground max-w-3xl">
                The aviation simulator targets high-impact areas where crew scheduling, flight profiles, and disruption management yield the highest returns.
              </p>
            </motion.div>

            <motion.div variants={staggerContainer} initial="initial" whileInView="whileInView" viewport={{ once: true }} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { icon: Droplet, title: 'Fuel Efficiency', desc: 'Optimized flight profiles and reduced taxi times.', range: '4–10% reduction' },
                { icon: Wrench, title: 'Maintenance Optimization', desc: 'Fewer unscheduled AOG events through predictive analytics.', range: '8–15% reduction' },
                { icon: Clock, title: 'Delay Reduction', desc: 'Mitigation of reactionary delays and faster recovery.', range: '8–20% reduction' },
                { icon: TrendingUp, title: 'Operational Efficiency', desc: 'Better crew pairings and ground resource allocation.', range: '5–15% improvement' }
              ].map((card, idx) => (
                <motion.div key={idx} variants={fadeIn}>
                  <Card className="h-full border-border/50 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-6 flex flex-col h-full">
                      <div className="w-12 h-12 rounded-xl bg-teal-500/10 text-teal-600 flex items-center justify-center mb-4">
                        <card.icon className="w-6 h-6" />
                      </div>
                      <h4 className="text-lg font-semibold text-foreground mb-2">{card.title}</h4>
                      <p className="text-sm text-muted-foreground mb-4 flex-grow">{card.desc}</p>
                      <div className="text-sm font-medium text-teal-600 bg-teal-500/10 px-3 py-1.5 rounded-md inline-block w-fit">
                        Est: {card.range}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* SECTION 3 — TRANSPARENCY & SCENARIO MODEL */}
        <section className="py-20 lg:py-24 bg-slate-900 text-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Transparency & Scenario-Based Modeling</h2>
              <p className="text-lg text-slate-400">
                We believe in realistic projections, not inflated marketing numbers. Our simulators use a three-tier scenario model to reflect real-world variability.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { icon: BarChart3, title: 'Results Are Estimates', desc: 'Calculations are based on industry averages and the inputs you provide. They represent potential outcomes, not guaranteed financial returns.' },
                { icon: Target, title: 'How Scenarios Work', desc: 'We provide Conservative, Expected, and Aggressive projections to account for different levels of software adoption and organizational change management.' },
                { icon: ShieldCheck, title: 'What Drives Variability', desc: 'Actual savings depend on your existing baseline efficiency, fleet age, operational constraints, and how deeply you integrate our APIs.' },
                { icon: Lightbulb, title: 'Why This Matters', desc: 'By providing a range rather than a single inflated number, we help you build realistic business cases for internal stakeholder approval.' }
              ].map((item, idx) => (
                <motion.div key={idx} {...fadeIn} className="bg-slate-800/50 border border-slate-700 rounded-2xl p-8">
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-slate-700/50 rounded-lg shrink-0">
                      <item.icon className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h4 className="text-xl font-semibold text-white mb-2">{item.title}</h4>
                      <p className="text-slate-400 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 4 — WHY THIS TOOL EXISTS */}
        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Why Operion Built This Tool</h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { title: 'Reducing Uncertainty', desc: 'Enterprise software investments require clear ROI justification. We provide the math upfront.' },
                { title: 'Early-Stage Estimation', desc: 'Get a sense of potential value before committing to lengthy discovery calls or data audits.' },
                { title: 'Supporting Pilot Selection', desc: 'Identify which operational areas (fuel, maintenance, crew) offer the highest immediate return.' },
                { title: 'Building Confidence', desc: 'Transparent formulas build trust. We show you exactly how we arrive at our projections.' }
              ].map((item, idx) => (
                <motion.div key={idx} {...fadeIn} className="border-l-2 border-primary/20 pl-6">
                  <h4 className="text-lg font-semibold text-foreground mb-2">{item.title}</h4>
                  <p className="text-muted-foreground">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 5 — NAVIGATION TO SIMULATORS */}
        <section className="py-20 bg-slate-50 border-t border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Explore Your Savings Potential</h2>
              <p className="text-lg text-muted-foreground">Select your industry to launch the interactive calculator.</p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              <motion.div {...fadeIn}>
                <Link to="/maritime-savings-simulator" className="block group">
                  <Card className="h-full border-border shadow-sm hover:shadow-xl hover:border-blue-500/30 transition-all duration-300 overflow-hidden">
                    <div className="h-2 bg-blue-500 w-full"></div>
                    <CardContent className="p-8 flex flex-col items-center text-center">
                      <div className="w-20 h-20 rounded-full bg-blue-50 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <Ship className="w-10 h-10 text-blue-600" />
                      </div>
                      <h3 className="text-2xl font-bold text-foreground mb-3">Maritime Simulator</h3>
                      <p className="text-muted-foreground mb-8">
                        Calculate ROI for cargo vessels, tankers, and specialized maritime fleets based on fuel, maintenance, and downtime metrics.
                      </p>
                      <div className="flex items-center text-blue-600 font-semibold group-hover:translate-x-2 transition-transform">
                        Launch Maritime Simulator <ArrowRight className="ml-2 w-5 h-5" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>

              <motion.div {...fadeIn}>
                <Link to="/aviation-savings-simulator" className="block group">
                  <Card className="h-full border-border shadow-sm hover:shadow-xl hover:border-teal-500/30 transition-all duration-300 overflow-hidden">
                    <div className="h-2 bg-teal-500 w-full"></div>
                    <CardContent className="p-8 flex flex-col items-center text-center">
                      <div className="w-20 h-20 rounded-full bg-teal-50 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <Plane className="w-10 h-10 text-teal-600" />
                      </div>
                      <h3 className="text-2xl font-bold text-foreground mb-3">Aviation Simulator</h3>
                      <p className="text-muted-foreground mb-8">
                        Calculate ROI for commercial airlines and cargo operators based on fuel burn, delay minutes, and maintenance costs.
                      </p>
                      <div className="flex items-center text-teal-600 font-semibold group-hover:translate-x-2 transition-transform">
                        Launch Aviation Simulator <ArrowRight className="ml-2 w-5 h-5" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            </div>
          </div>
        </section>

        {/* FOOTER CTA SECTION */}
        <section className="py-24 bg-primary text-primary-foreground text-center">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
                Ready to Validate Your Savings?
              </h2>
              <p className="text-xl text-primary-foreground/80 mb-10 text-balance">
                Start with a simulator, then move to a pilot program to see real-world results on your own fleet.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button asChild size="lg" variant="secondary" className="rounded-full px-8 h-14 text-base font-semibold">
                  <Link to="/demo">Book a Demo</Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="rounded-full px-8 h-14 text-base font-semibold bg-transparent border-primary-foreground/30 hover:bg-primary-foreground/10 text-primary-foreground">
                  <Link to="/contact-sales">Contact Sales</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default SavingsSimulatorPage;