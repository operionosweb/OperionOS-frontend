import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Plane, Ship, Target, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const IndustriesPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Industries | Operion</title>
        <meta name="description" content="Industry-specific solutions powered by Operion OS." />
      </Helmet>
      
      <Header />

      <main className="flex-grow pt-20">
        <section 
          className="header-hero"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1568066857856-da0bebb1ec80)' }}
        >
          <div className="header-overlay"></div>
          <div className="header-content text-center">
            <div className="inline-flex items-center rounded-full border border-primary/40 bg-primary/20 px-4 py-1.5 text-sm font-bold text-primary-foreground mb-8 uppercase tracking-wider backdrop-blur-sm">
              Tailored Solutions
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white mb-6 text-balance">
              Industry Solutions
            </h1>
            <p className="text-lg md:text-xl text-slate-200 leading-relaxed max-w-2xl mx-auto">
              Operion provides specialized crew management operating systems tailored to the unique demands of global industries.
            </p>
          </div>
        </section>

        <section className="py-20 md:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            {/* Aviation */}
            <div className="bg-card border border-border rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all flex flex-col h-full">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 text-primary">
                <Plane className="w-7 h-7" />
              </div>
              <h2 className="text-2xl font-bold mb-4 text-foreground">Aviation</h2>
              <ul className="space-y-4 text-muted-foreground mb-8 flex-grow">
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Manage pilot and crew scheduling across global flight operations</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Optimize crew rotations and ensure compliance with flight regulations</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Reduce crew scheduling costs and improve operational efficiency</span>
                </li>
              </ul>
              <Button asChild className="w-full mt-auto" variant="outline">
                <Link to="/demo/aviation" className="group">
                  Explore Aviation <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>

            {/* Maritime */}
            <div className="bg-card border border-border rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all flex flex-col h-full">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 text-primary">
                <Ship className="w-7 h-7" />
              </div>
              <h2 className="text-2xl font-bold mb-4 text-foreground">Maritime</h2>
              <ul className="space-y-4 text-muted-foreground mb-8 flex-grow">
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Manage vessel crew rotations and sea-based assignments</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Coordinate crew movements between vessels and global ports</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Ensure crew compliance with strict maritime regulations</span>
                </li>
              </ul>
              <Button asChild className="w-full mt-auto" variant="outline">
                <Link to="/maritime" className="group">
                  Explore Maritime <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>

            {/* Offshore */}
            <div className="bg-card border border-border rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all flex flex-col h-full">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 text-primary">
                <Target className="w-7 h-7" />
              </div>
              <h2 className="text-2xl font-bold mb-4 text-foreground">Offshore</h2>
              <ul className="space-y-4 text-muted-foreground mb-8 flex-grow">
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Manage complex offshore crew scheduling and 28/28 rotations</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Coordinate critical logistics to remote offshore platforms</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-primary mt-1">•</span>
                  <span>Ensure safety certification compliance and minimize fatigue</span>
                </li>
              </ul>
              <Button asChild className="w-full mt-auto" variant="outline">
                <Link to="/offshore" className="group">
                  Explore Offshore <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default IndustriesPage;