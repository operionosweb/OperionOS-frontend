import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const ContactPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Contact Sales | Operion</title>
      </Helmet>
      <Header />
      <main className="flex-grow pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Contact Our Team</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          Get in touch with our experts to discuss how Operion can streamline your crew logistics.
        </p>
      </main>
      <Footer />
    </div>
  );
};

export default ContactPage;