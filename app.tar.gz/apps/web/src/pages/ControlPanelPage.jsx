import React, { useState, useMemo, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import TabContainer from '@/components/tabs/TabContainer.jsx';
import AccessDenied from '@/components/AccessDenied.jsx';
import ControlPanelCopilot from '@/components/ControlPanelCopilot.jsx';
import { useUserRole } from '@/hooks/useUserRole.js';
import { useAuthGuard } from '@/hooks/useAuthGuard.js';
import { useCopilot } from '@/contexts/CopilotContext.jsx';
import { 
  ShieldCheck, Activity, BrainCircuit, BellRing, 
  DollarSign, LayoutDashboard, Target, RefreshCw, AlertTriangle, Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Card } from '@/components/ui/card.jsx';

import { generateMockFleetContracts } from '@/lib/mockData/fleetContracts.js';
import { generateAlerts } from '@/lib/alertEngine.js';
import { generateForecasts } from '@/lib/forecastingEngine.js';
import AlertFeed from '@/components/AlertFeed.jsx';

import { EventProvider } from '@/contexts/EventContext.jsx';
import { useDataSync } from '@/hooks/useDataSync.js';
import { AlertProvider } from '@/contexts/AlertContext.jsx';
import { useAlertDetection } from '@/hooks/useAlertDetection.js';
import { ContractMonitoringProvider } from '@/contexts/ContractMonitoringContext.jsx';

// Inner component that uses the context
const ControlPanelContent = () => {
  const { role } = useUserRole();
  const { isAuthenticated } = useAuthGuard();
  const [showIntelligence, setShowIntelligence] = useState(false);
  const [showCopilot, setShowCopilot] = useState(false);
  const { start, stop, isPolling, lastSyncTime, syncError } = useDataSync();
  const copilot = useCopilot();

  useAlertDetection();

  const rawContracts = useMemo(() => generateMockFleetContracts(), []);
  const alerts = useMemo(() => generateAlerts(rawContracts), [rawContracts]);
  const forecasts = useMemo(() => generateForecasts(rawContracts), [rawContracts]);

  useEffect(() => {
    start();
    return () => stop();
  }, [start, stop]);

  useEffect(() => {
    if (copilot?.updateContext) {
      copilot.updateContext({
        contracts: rawContracts,
        alerts: alerts,
        forecastingData: forecasts,
        activeTab: 'dashboard' 
      });
    }
  }, [rawContracts, alerts, forecasts, copilot?.updateContext]);

  if (role !== 'super_admin') {
    return <AccessDenied />;
  }

  const criticalAlerts = alerts.filter(a => a.severity === 'CRITICAL').length;
  const avgProbability = Math.round(
    forecasts.reduce((acc, f) => acc + f.renewal_probability, 0) /
    (forecasts.length || 1)
  );

  const totalExposure = forecasts.reduce(
    (acc, f) => acc + (f.expected_financial_impact < 0 ? Math.abs(f.expected_financial_impact) : 0),
    0
  );

  const formatCurrency = (val) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
      notation: 'compact',
      compactDisplay: 'short'
    }).format(val);

  const systemStatusColor =
    criticalAlerts > 2
      ? 'text-destructive border-destructive/20 bg-destructive/10'
      : criticalAlerts > 0
      ? 'text-amber-500 border-amber-500/20 bg-amber-500/10'
      : 'text-emerald-600 border-emerald-200 bg-emerald-100';

  return (
    <div className="w-full bg-background min-h-screen">
      <Helmet><title>Super Admin Control Panel | Operion</title></Helmet>
      <Header />

      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pt-28">

        {/* HEADER */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-card p-6 rounded-2xl border border-border shadow-sm">

          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-primary" />
              Global Control Panel
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-3">

            <Button onClick={() => setShowIntelligence(!showIntelligence)}>
              Toggle Intelligence
            </Button>

            {/* ✅ FIXED LINE (THIS WAS THE ISSUE BEFORE) */}
            <Button
              onClick={() => setShowCopilot(true)}
            >
              Open Copilot
            </Button>

          </div>
        </div>

        {/* INTELLIGENCE */}
        {showIntelligence && (
          <div className="bg-card p-6 rounded-xl border">
            <AlertFeed alerts={alerts} />
          </div>
        )}

        <TabContainer />

      </div>

      {/* ✅ FIXED: NOW PASSES USER PROP */}
      <ControlPanelCopilot
        isOpen={showCopilot}
        onClose={() => setShowCopilot(false)}
        user={copilot?.user}
      />
    </div>
  );
};

// ERROR BOUNDARY
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return <div>Error in Control Panel</div>;
    }
    return this.props.children;
  }
}

const ControlPanelPage = () => {
  return (
    <ErrorBoundary>
      <EventProvider>
        <AlertProvider>
          <ContractMonitoringProvider>
            <ControlPanelContent />
          </ContractMonitoringProvider>
        </AlertProvider>
      </EventProvider>
    </ErrorBoundary>
  );
};

export default ControlPanelPage;