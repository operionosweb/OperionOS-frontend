import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import CrewMovementExecution from '@/components/demo/logistics/CrewMovementExecution.jsx';

const CrewMovementDemoPage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  return (
    <DemoStateProvider>
      <Helmet>
        <title>Crew Movement Execution Demo | Operion</title>
      </Helmet>

      <div className="flex h-screen bg-background overflow-hidden">
        <LeftSidebar 
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          isMobile={isMobile}
        />
        
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <DemoHeader 
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
          />
          
          <main className="flex-1 overflow-y-auto pb-16 md:pb-0 bg-muted/20">
            <div className="p-4 md:p-6 lg:p-8">
              <div className="max-w-7xl mx-auto space-y-6">
                <div className="mb-6">
                  <h1 className="text-2xl font-bold text-foreground">See how to manage crew movements</h1>
                  <div className="flex flex-wrap gap-4 mt-4">
                    <div className="bg-card border border-border px-4 py-2 rounded-lg text-sm font-medium">Step 1: Generate plan</div>
                    <div className="bg-card border border-border px-4 py-2 rounded-lg text-sm font-medium">Step 2: Validate compliance</div>
                    <div className="bg-card border border-border px-4 py-2 rounded-lg text-sm font-medium">Step 3: Send to providers</div>
                    <div className="bg-card border border-border px-4 py-2 rounded-lg text-sm font-medium">Step 4: Track execution</div>
                  </div>
                </div>
                <CrewMovementExecution />
              </div>
            </div>
          </main>
        </div>

        {isMobile && <BottomNavigation />}
      </div>
    </DemoStateProvider>
  );
};

export default CrewMovementDemoPage;