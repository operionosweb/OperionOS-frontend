import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { DemoStateProvider, useDemo } from '@/contexts/DemoStateContext.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import AnalyticsDashboard from '@/components/demo/AnalyticsDashboard.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { BrainCircuit, Sparkles } from 'lucide-react';

// Cruise Modules
import PassengerSafetyModule from '@/components/demo/cruise/PassengerSafetyModule.jsx';
import HotelOperationsModule from '@/components/demo/cruise/HotelOperationsModule.jsx';
import HealthSanitationModule from '@/components/demo/cruise/HealthSanitationModule.jsx';
import EnvironmentalComplianceCruiseModule from '@/components/demo/cruise/EnvironmentalComplianceCruiseModule.jsx';
import CrossDepartmentOperationsModule from '@/components/demo/cruise/CrossDepartmentOperationsModule.jsx';
import GuestExperienceModule from '@/components/demo/cruise/GuestExperienceModule.jsx';

// Crew Modules
import CrewDatabaseTable from '@/components/demo/crew/CrewDatabaseTable.jsx';
import CrewAnalytics from '@/components/demo/crew/CrewAnalytics.jsx';

// Logistics Module
import GlobalTravelLogistics from '@/components/demo/logistics/GlobalTravelLogistics.jsx';

const generateAIRecommendations = (crew) => {
  if (!crew || crew.length === 0) return ["Awaiting crew data for analysis."];
  
  const estimatedFatigue = crew.map(c => {
    let base = 50;
    const role = c.role?.toLowerCase() || '';
    if (role.includes('captain') || role.includes('master')) base = 75;
    else if (role.includes('chief engineer')) base = 70;
    else if (role.includes('officer')) base = 65;
    if (c.status === 'On Duty') base += 20;
    else base -= 20;
    return { ...c, fatigueScore: Math.max(0, Math.min(100, base)) };
  });

  const recs = [];
  const highRisk = estimatedFatigue.filter(c => c.fatigueScore > 70);
  
  if (highRisk.length > 0) {
    recs.push(`${highRisk.length} crew members are at high fatigue risk. Recommend shift rotation.`);
  }

  const chief = estimatedFatigue.find(c => c.role.toLowerCase().includes('chief engineer'));
  if (chief && chief.fatigueScore > 65) {
    recs.push(`Chief Engineer workload exceeds optimal threshold by 25%.`);
  }

  const deck = estimatedFatigue.filter(c => c.department === 'Deck');
  const engine = estimatedFatigue.filter(c => c.department === 'Engine');
  if (deck.length > engine.length + 2) {
    recs.push(`Engine department is understaffed — consider cross-training.`);
  } else {
    recs.push(`Reassign 1 crew member to reduce operational imbalance.`);
  }

  const captain = estimatedFatigue.find(c => c.role.toLowerCase().includes('captain'));
  if (captain && captain.fatigueScore > 75) {
    recs.push(`Captain fatigue at ${captain.fatigueScore}% — recommend rest period.`);
  }

  if (recs.length < 4) {
    recs.push(`Optimal crew distribution can reduce fatigue risk by 18%.`);
  }
  
  return recs.slice(0, 4);
};

const DemoContent = ({ crewList, setCrewList }) => {
  const { operatingMode, cruiseModules } = useDemo();

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl mx-auto overflow-y-auto">
          <Tabs defaultValue="core" className="w-full">
            <div className="overflow-x-auto pb-2 mb-4 hide-scrollbar">
              <TabsList className="inline-flex w-max min-w-full sm:w-auto">
                <TabsTrigger value="core">Core Operations</TabsTrigger>
                <TabsTrigger value="crew">Crew Management</TabsTrigger>
                <TabsTrigger value="logistics">Global Logistics</TabsTrigger>
                {cruiseModules.safety && <TabsTrigger value="safety">Passenger Safety</TabsTrigger>}
                {cruiseModules.hotel && <TabsTrigger value="hotel">Hotel Ops</TabsTrigger>}
                {cruiseModules.health && <TabsTrigger value="health">Health & Sanitation</TabsTrigger>}
                {cruiseModules.environmental && <TabsTrigger value="environmental">Environmental</TabsTrigger>}
                {cruiseModules.operations && <TabsTrigger value="operations">Cross-Dept Ops</TabsTrigger>}
                {cruiseModules.guest && <TabsTrigger value="guest">Guest Experience</TabsTrigger>}
              </TabsList>
            </div>

            <TabsContent value="core" className="mt-0">
              <AnalyticsDashboard />
            </TabsContent>

            <TabsContent value="crew" className="mt-0 space-y-8">
              <CrewDatabaseTable onCrewChange={setCrewList} />
              <CrewAnalytics crewList={crewList} />
            </TabsContent>

            <TabsContent value="logistics" className="mt-0">
              <GlobalTravelLogistics />
            </TabsContent>
            
            {cruiseModules.safety && (
              <TabsContent value="safety" className="mt-0">
                <PassengerSafetyModule />
              </TabsContent>
            )}
            
            {cruiseModules.hotel && (
              <TabsContent value="hotel" className="mt-0">
                <HotelOperationsModule />
              </TabsContent>
            )}
            
            {cruiseModules.health && (
              <TabsContent value="health" className="mt-0">
                <HealthSanitationModule />
              </TabsContent>
            )}
            
            {cruiseModules.environmental && (
              <TabsContent value="environmental" className="mt-0">
                <EnvironmentalComplianceCruiseModule />
              </TabsContent>
            )}
            
            {cruiseModules.operations && (
              <TabsContent value="operations" className="mt-0">
                <CrossDepartmentOperationsModule />
              </TabsContent>
            )}
            
            {cruiseModules.guest && (
              <TabsContent value="guest" className="mt-0">
                <GuestExperienceModule />
              </TabsContent>
            )}
          </Tabs>
        </div>

        {/* AI Assistant Sidebar */}
        <div className="hidden xl:block w-80 border-l border-border bg-card/30 p-6 overflow-y-auto">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-primary/10 rounded-lg">
              <BrainCircuit className="w-5 h-5 text-primary" />
            </div>
            <h3 className="font-bold text-lg">Operion AI</h3>
          </div>

          <div className="space-y-6">
            <div>
              <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                <Sparkles className="w-3 h-3 text-amber-500" />
                Crew Optimization Intelligence
              </h4>
              <div className="space-y-3">
                {generateAIRecommendations(crewList).map((rec, i) => (
                  <div key={i} className="p-3.5 bg-background border border-border rounded-xl text-sm shadow-sm leading-relaxed">
                    {rec}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const MaritimeDemoPage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();
  const [crewList, setCrewList] = useState([]);

  useEffect(() => {
    if (isMobileMenuOpen && isMobile) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen, isMobile]);

  return (
    <DemoStateProvider>
      <Helmet>
        <title>Dashboard | Operion Maritime</title>
        <meta name="description" content="Interactive demo of the Operion maritime operations platform." />
      </Helmet>

      <div className="flex h-screen bg-background overflow-hidden">
        <LeftSidebar 
          industry="maritime"
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          isMobile={isMobile}
        />
        
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <DemoHeader 
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
          />
          
          <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
            <DemoContent crewList={crewList} setCrewList={setCrewList} />
          </main>
        </div>

        {isMobile && <BottomNavigation />}
      </div>
    </DemoStateProvider>
  );
};

export default MaritimeDemoPage;