import React, { useState, useEffect, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Calculator, CheckCircle2, Download } from 'lucide-react';
import { toast } from 'sonner';

import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import BreadcrumbSchema from '@/components/BreadcrumbSchema.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import InfoTooltip from '@/components/InfoTooltip.jsx';

import { calculateAviationSavings, generatePDFReport, calculateSavingsRange } from '@/lib/SavingsCalculationEngine.js';
import ScenarioComparison from '@/components/simulator/ScenarioComparison.jsx';
import CollapsibleExplainabilityPanel from '@/components/simulator/CollapsibleExplainabilityPanel.jsx';
import SavingsRangeVisualization from '@/components/simulator/SavingsRangeVisualization.jsx';
import TrustLayer from '@/components/simulator/TrustLayer.jsx';
import RefinedPilotProgram from '@/components/simulator/RefinedPilotProgram.jsx';
import { formatCurrency, formatNumber } from '@/lib/formatters.js';

const AviationSavingsSimulator = () => {
  const [inputs, setInputs] = useState({
    fleetSize: 50,
    fuelBurn: 6,
    fuelCost: 850,
    flightsPerYear: 20000,
    flightDuration: 3,
    maintenanceCost: 1200000,
    delayMinutes: 80000
  });

  const [scenarioResults, setScenarioResults] = useState(null);

  useEffect(() => {
    setScenarioResults({
      conservative: calculateAviationSavings(inputs, 'conservative'),
      expected: calculateAviationSavings(inputs, 'expected'),
      aggressive: calculateAviationSavings(inputs, 'aggressive')
    });
  }, [inputs]);

  const handleSliderChange = (name, value) => {
    setInputs(prev => ({ ...prev, [name]: value[0] }));
  };

  const handleDownloadPDF = async () => {
    toast.loading('Preparing PDF report...');
    await generatePDFReport();
    toast.dismiss();
    toast.success('Report ready for printing/saving');
  };

  const renderSlider = (id, label, min, max, step, formatFn, tooltipText) => (
    <div className="bg-background p-4 rounded-xl border border-border/50">
      <InfoTooltip label={label} tooltipText={tooltipText}>
        <div className="flex justify-between items-center mb-3">
          <span className="font-mono font-semibold text-primary bg-primary/10 px-2 py-1 rounded-md text-sm ml-auto">
            {formatFn(inputs[id])}
          </span>
        </div>
        <Slider
          id={id}
          min={min}
          max={max}
          step={step}
          value={[inputs[id]]}
          onValueChange={(val) => handleSliderChange(id, val)}
          className="py-2"
        />
      </InfoTooltip>
    </div>
  );

  const getExplainabilityData = (scenarioKey) => {
    if (!scenarioResults) return null;
    const data = scenarioResults[scenarioKey];
    
    return {
      assumptions: {
        'Fleet Size': `${inputs.fleetSize} aircraft`,
        'Fuel Burn Baseline': `${inputs.fuelBurn} tons/hr per aircraft`,
        'Fuel Price': formatCurrency(inputs.fuelCost),
        'Maintenance Baseline': formatCurrency(inputs.maintenanceCost),
        'Delay Baseline': `${formatNumber(inputs.delayMinutes)} minutes/year`
      },
      breakdown: [
        { label: 'Fuel Optimization', value: data.fuelSavings },
        { label: 'Maintenance Reduction', value: data.maintSavings },
        { label: 'Delay Recovery', value: data.delaySavings },
        { label: 'Operational Efficiency', value: data.operationalSavings }
      ],
      adoption: {
        percentage: scenarioKey === 'conservative' ? 30 : scenarioKey === 'expected' ? 70 : 100,
        description: scenarioKey === 'conservative' 
          ? 'Assumes partial fleet rollout and minimal crew scheduling integration.'
          : scenarioKey === 'expected'
          ? 'Assumes standard fleet-wide adoption with regular usage of core optimization features.'
          : 'Assumes full API integration, automated decision execution, and high organizational compliance.'
      },
      timeframe: {
        annualization: 'Values represent a full 12-month operational period.',
        rampUp: 'Assumes a 3-month initial implementation and learning phase.',
        realization: 'ROI typically begins compounding in month 4 post-deployment.'
      }
    };
  };

  return (
    <div className="min-h-screen flex flex-col bg-background print:bg-white">
      <Helmet>
        <title>Aviation Operations Savings Simulator | Operion</title>
        <meta name="description" content="Calculate realistic operational savings for your airline based on industry benchmarks and transparent assumptions." />
      </Helmet>

      <BreadcrumbSchema 
        items={[
          { name: 'Home', url: '/' },
          { name: 'Aviation Savings Simulator', url: '/aviation-savings-simulator' }
        ]} 
      />

      <Header />

      <main className="flex-grow pt-20 print:pt-0">
        {/* Hero Section */}
        <section 
          className="header-hero print-hide"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1676186318068-df5df0b35130)' }}
        >
          <div className="header-overlay"></div>
          <div className="header-content text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="inline-flex items-center gap-2 rounded-full border border-teal-500/40 bg-teal-500/20 px-3 py-1 text-sm font-medium text-teal-100 mb-6 backdrop-blur-sm">
                <Calculator className="w-4 h-4" />
                <span>Value-Based Engagement</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-6 text-balance tracking-tight">
                Operational Savings, Modeled with <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-400">Real-World Assumptions</span>
              </h1>
              <p className="text-lg md:text-xl text-slate-200 mb-10 max-w-3xl mx-auto text-balance leading-relaxed">
                Explore conservative, expected, and aggressive savings scenarios based on your airline's specific metrics. We align our pricing with the value we generate—typically delivering ROI within 3–6 months.
              </p>
              
              <div className="flex flex-wrap justify-center gap-6 mb-12">
                <div className="flex items-center gap-2 text-sm text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" /> Based on industry benchmarks
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" /> Transparent calculations
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-200">
                  <CheckCircle2 className="w-4 h-4 text-teal-400" /> Validated through simulation
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Calculator Section */}
        <section className="py-12 relative z-20 print:mt-0 print:py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
              
              {/* Left Column: Inputs */}
              <div className="xl:col-span-4 space-y-6 print-hide">
                <div className="bg-card rounded-2xl shadow-xl border border-border p-6">
                  <div className="mb-6">
                    <h2 className="text-xl font-bold text-foreground">Operational Metrics</h2>
                    <p className="text-sm text-muted-foreground mt-1">Estimates update instantly based on your inputs.</p>
                  </div>

                  <div className="space-y-4">
                    {renderSlider('fleetSize', 'Fleet Size', 5, 300, 1, (v) => `${v} aircraft`, 'Total number of aircraft in your operational fleet.')}
                    {renderSlider('fuelBurn', 'Fuel Burn per Flight/Hour', 2, 15, 0.1, (v) => `${v} tons/hr`, 'Average fuel consumption per aircraft per flight hour.')}
                    {renderSlider('fuelCost', 'Fuel Cost (€ per ton)', 600, 1200, 10, (v) => formatCurrency(v), 'Average fuel price paid per ton of aviation fuel.')}
                    {renderSlider('flightsPerYear', 'Flights per Year', 1000, 100000, 1000, (v) => `${formatNumber(v)} flights`, 'Total number of flights operated annually.')}
                    {renderSlider('flightDuration', 'Average Flight Duration', 1, 12, 0.5, (v) => `${v} hours`, 'Average duration of a flight in hours.')}
                    {renderSlider('maintenanceCost', 'Maintenance Cost per Aircraft', 200000, 5000000, 50000, (v) => formatCurrency(v), 'Annual maintenance cost per aircraft.')}
                    {renderSlider('delayMinutes', 'Delay Minutes per Year', 5000, 500000, 5000, (v) => `${formatNumber(v)} mins/yr`, 'Total accumulated delay minutes per year.')}
                  </div>
                </div>
              </div>

              {/* Right Column: Results */}
              <div className="xl:col-span-8 space-y-8">
                {scenarioResults && (
                  <div className="bg-card rounded-2xl shadow-xl border border-border p-6 sm:p-8">
                    
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
                      <div>
                        <h2 className="text-2xl font-bold text-foreground">Scenario Analysis</h2>
                        <p className="text-muted-foreground text-sm mt-1">Operion typically saves airlines between {formatCurrency(scenarioResults.conservative.totalSavings)} and {formatCurrency(scenarioResults.aggressive.totalSavings)} annually.</p>
                      </div>
                      
                      <Button variant="outline" size="sm" onClick={handleDownloadPDF} className="print-hide shrink-0">
                        <Download className="w-4 h-4 mr-2" /> Export PDF
                      </Button>
                    </div>

                    <div className="mb-10">
                      <SavingsRangeVisualization 
                        {...calculateSavingsRange(scenarioResults)} 
                      />
                    </div>

                    <div className="mb-10">
                      <ScenarioComparison scenarios={scenarioResults} />
                    </div>

                    <div className="space-y-4 mb-10">
                      <h3 className="text-lg font-semibold text-foreground mb-4">Detailed Scenario Assumptions</h3>
                      <CollapsibleExplainabilityPanel 
                        scenarioName="Expected"
                        {...getExplainabilityData('expected')}
                      />
                      <CollapsibleExplainabilityPanel 
                        scenarioName="Conservative"
                        {...getExplainabilityData('conservative')}
                      />
                    </div>

                    <TrustLayer />

                    <div className="mt-8 text-center">
                      <p className="text-xs text-muted-foreground">
                        * Actual results depend on implementation depth, organizational adoption, and specific operational constraints. These figures are estimates for evaluation purposes.
                      </p>
                    </div>

                  </div>
                )}
              </div>

            </div>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <RefinedPilotProgram industry="aviation" />
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default AviationSavingsSimulator;