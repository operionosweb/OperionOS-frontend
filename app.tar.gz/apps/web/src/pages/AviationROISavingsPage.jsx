import React from 'react';
import { Helmet } from 'react-helmet';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import { AviationROISavingsProvider } from '@/contexts/AviationROISavingsContext.jsx';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';

import ROIKPIWidgets from '@/components/demo/aviation/ROIKPIWidgets.jsx';
import LiveSavingsCounter from '@/components/demo/aviation/LiveSavingsCounter.jsx';
import SavingsBreakdownSection from '@/components/demo/aviation/SavingsBreakdownSection.jsx';
import BeforeAfterComparison from '@/components/demo/aviation/BeforeAfterComparison.jsx';
import DisruptionSavingsTracking from '@/components/demo/aviation/DisruptionSavingsTracking.jsx';
import AISavingsEngine from '@/components/demo/aviation/AISavingsEngine.jsx';
import InteractiveROICalculator from '@/components/demo/aviation/InteractiveROICalculator.jsx';
import SavingsTimeline from '@/components/demo/aviation/SavingsTimeline.jsx';

const AviationROISavingsContent = () => {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row overflow-hidden">
      <Helmet>
        <title>ROI & Savings Tracking | Operion Aviation</title>
      </Helmet>

      <LeftSidebar industry="aviation" />

      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <DemoHeader title="ROI & Savings Tracking" />
        
        <div className="flex-1 overflow-y-auto pb-24 md:pb-8 hide-scrollbar">
          <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
            
            {/* Top Row: KPIs and Live Counter */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2">
                <ROIKPIWidgets />
              </div>
              <div className="xl:col-span-1">
                <LiveSavingsCounter />
              </div>
            </div>

            {/* Middle Row: Breakdown and Comparison */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <SavingsBreakdownSection />
              <BeforeAfterComparison />
            </div>

            {/* Timeline */}
            <SavingsTimeline />

            {/* Bottom Row: Disruptions and AI Engine */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2">
                <DisruptionSavingsTracking />
              </div>
              <div className="xl:col-span-1">
                <AISavingsEngine />
              </div>
            </div>

            {/* Calculator */}
            <InteractiveROICalculator />

          </div>
        </div>
      </main>

      <BottomNavigation industry="aviation" />
    </div>
  );
};

const AviationROISavingsPage = () => {
  return (
    <DemoStateProvider>
      <AviationROISavingsProvider>
        <AviationROISavingsContent />
      </AviationROISavingsProvider>
    </DemoStateProvider>
  );
};

export default AviationROISavingsPage;