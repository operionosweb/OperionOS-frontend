import React from 'react';
import LegalPageLayout from '@/components/LegalPageLayout.jsx';

const SecurityPage = () => {
  const sections = [
    {
      id: 'overview',
      title: '1. Overview of Security Approach',
      content: (
        <>
          <p>
            At Operion, security is foundational to everything we build. We understand that aviation and maritime operations rely on highly sensitive data, and any compromise can have severe operational and financial consequences.
          </p>
          <p>
            Our security architecture is designed around the principles of defense-in-depth, least privilege, and continuous monitoring. We employ enterprise-grade security controls to protect your data across our entire infrastructure.
          </p>
        </>
      )
    },
    {
      id: 'data-protection',
      title: '2. Data Protection Measures',
      content: (
        <>
          <p>We utilize industry-standard cryptographic protocols to ensure your data remains confidential and untampered with, both when it is moving across networks and when it is stored in our databases.</p>
          
          <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">Encryption in Transit</h3>
          <p>All communications between your devices and Operion's servers, as well as internal communications between our microservices, are encrypted using TLS 1.3. We enforce HTTP Strict Transport Security (HSTS) and do not support legacy, vulnerable protocols.</p>

          <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">Encryption at Rest</h3>
          <p>All customer data stored within the Operion platform is encrypted at rest using AES-256 encryption. This includes primary databases, backups, and object storage. Encryption keys are managed via a secure, centralized Key Management Service (KMS) with strict access controls and automated rotation policies.</p>
        </>
      )
    },
    {
      id: 'access-control',
      title: '3. Access Control & Authentication',
      content: (
        <>
          <p>Operion provides robust identity and access management capabilities to ensure only authorized personnel can access your operational data:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>Single Sign-On (SSO):</strong> Integration with major identity providers (Okta, Azure AD, Google Workspace) via SAML 2.0 and OIDC.</li>
            <li><strong>Multi-Factor Authentication (MFA):</strong> Mandatory MFA support for all administrative access and configurable MFA policies for end-users.</li>
            <li><strong>Role-Based Access Control (RBAC):</strong> Granular permissions allowing you to define exactly what data and actions each user role can access.</li>
            <li><strong>Session Management:</strong> Configurable session timeouts, concurrent session limits, and anomalous login detection.</li>
          </ul>
        </>
      )
    },
    {
      id: 'infrastructure-security',
      title: '4. Infrastructure Security',
      content: (
        <>
          <p>
            Our platform is hosted on top-tier cloud providers (AWS and Google Cloud) that maintain rigorous security compliance standards. Our infrastructure security includes:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>Network Isolation:</strong> Virtual Private Clouds (VPCs) with strict security groups, network ACLs, and private subnets for databases and internal services.</li>
            <li><strong>DDoS Protection:</strong> Edge-level protection against Distributed Denial of Service attacks using advanced Web Application Firewalls (WAF).</li>
            <li><strong>Immutable Infrastructure:</strong> Infrastructure as Code (IaC) deployments ensuring consistent, auditable, and reproducible environments.</li>
          </ul>
        </>
      )
    },
    {
      id: 'monitoring-threat-detection',
      title: '5. Monitoring & Threat Detection',
      content: (
        <>
          <p>
            We maintain 24/7 visibility into our systems to detect and respond to potential security threats in real-time:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>Continuous logging of all system, application, and access events.</li>
            <li>Automated intrusion detection systems (IDS) and anomaly detection algorithms.</li>
            <li>Regular vulnerability scanning of our infrastructure and application code.</li>
            <li>Annual third-party penetration testing by certified security firms.</li>
          </ul>
        </>
      )
    },
    {
      id: 'incident-response',
      title: '6. Incident Response',
      content: (
        <>
          <p>
            Operion maintains a comprehensive Incident Response Plan (IRP) that is tested and updated annually. In the event of a security incident, our dedicated Security Operations Center (SOC) team follows strict protocols for containment, eradication, and recovery.
          </p>
          <p>
            We are committed to transparent communication and will notify affected customers of any confirmed data breaches within the timeframes required by applicable laws and our contractual obligations.
          </p>
        </>
      )
    },
    {
      id: 'compliance-standards',
      title: '7. Compliance Standards',
      content: (
        <>
          <p>
            We align our security practices with leading industry frameworks to provide assurance to our enterprise customers. Operion is actively maintaining compliance with:
          </p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>SOC 2 Type II</li>
            <li>ISO/IEC 27001:2022</li>
            <li>GDPR & CCPA Privacy Frameworks</li>
          </ul>
          <p className="mt-4">For detailed compliance information, please visit our <a href="/global-compliance" className="text-primary hover:underline">Global Compliance</a> page.</p>
        </>
      )
    },
    {
      id: 'continuous-improvement',
      title: '8. Continuous Improvement',
      content: (
        <>
          <p>
            Security is not a static state. We continuously evaluate emerging threats, update our security controls, and train our engineering teams on secure coding practices (OWASP Top 10).
          </p>
          <p>If you have specific security questions or wish to report a vulnerability, please contact our security team:</p>
          <div className="bg-muted/50 p-6 rounded-xl border border-border mt-6">
            <p className="font-medium text-foreground mb-2">Operion Security Team</p>
            <p>Email: <a href="mailto:security@operion.com" className="text-primary hover:underline">security@operion.com</a></p>
            <p className="mt-2">For responsible disclosure, please request our PGP key for encrypted communications.</p>
          </div>
        </>
      )
    }
  ];

  return (
    <LegalPageLayout
      seoTitle="Security | Operion Enterprise Platform"
      seoDescription="Discover how Operion protects your data with enterprise-grade security, encryption, and compliance standards."
      title="Security"
      description="How Operion protects your data and maintains enterprise-grade security standards."
      lastUpdated="January 10, 2026"
      sections={sections}
    />
  );
};

export default SecurityPage;