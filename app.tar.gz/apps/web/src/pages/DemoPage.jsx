import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const DemoPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Request Demo | Operion</title>
      </Helmet>
      <Header />
      <main className="flex-grow pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
        <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">Experience Operion</h1>
        <p className="text-xl text-muted-foreground max-w-3xl">
          See the platform in action and discover the power of AI-driven crew management.
        </p>
      </main>
      <Footer />
    </div>
  );
};

export default DemoPage;