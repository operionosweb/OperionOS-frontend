import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Plane, AlertTriangle, BarChart3, Shield, Layers, ArrowRight, CheckCircle2, Database, Cpu, Link2, Lock, FileText, RotateCcw, Network, HeartHandshake as Handshake, Building2, Car, Plug, Globe, Webhook, FileCode2, XCircle, ArrowLeftRight, Settings2, Workflow } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const TabNavigation = ({ activeTab, setActiveTab }) => (
  <div className="w-full overflow-x-auto hide-scrollbar mb-8 flex justify-center">
    <div className="flex space-x-2 bg-muted p-1.5 rounded-xl min-w-max">
      {['Modules', 'Architecture', 'Security'].map((tab) => (
        <button
          key={tab}
          onClick={() => setActiveTab(tab)}
          className={`flex-1 min-w-[120px] py-2.5 px-6 text-sm font-bold rounded-lg transition-all duration-200 whitespace-nowrap ${
            activeTab === tab
              ? 'bg-primary text-primary-foreground shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-background/50'
          }`}
        >
          {tab}
        </button>
      ))}
    </div>
  </div>
);

const ModuleCard = ({ icon: Icon, title, description, features }) => (
  <div className="bg-card p-6 md:p-10 rounded-3xl shadow-lg border border-border hover:shadow-xl transition-shadow flex flex-col h-full">
    <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6">
      <Icon className="w-7 h-7 text-primary" />
    </div>
    <h3 className="text-2xl font-bold text-foreground mb-4">{title}</h3>
    <p className="text-muted-foreground mb-8 flex-grow text-lg leading-relaxed">{description}</p>
    <ul className="space-y-4 mt-auto">
      {features.map((feature, idx) => (
        <li key={idx} className="flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-[hsl(var(--tertiary))]" />
          <span className="text-sm font-bold text-foreground uppercase tracking-wider">{feature}</span>
        </li>
      ))}
    </ul>
  </div>
);

const ArchitectureCard = ({ icon: Icon, title, description }) => (
  <div className="bg-card p-6 md:p-8 rounded-2xl shadow-md border border-border flex flex-col sm:flex-row items-start gap-4 hover:shadow-lg transition-shadow">
    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
      <Icon className="w-6 h-6 text-primary" />
    </div>
    <div>
      <h4 className="text-xl font-bold text-foreground mb-2">{title}</h4>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  </div>
);

const SecurityCard = ({ icon: Icon, title, description }) => (
  <div className="bg-card p-6 md:p-8 rounded-2xl shadow-md border border-border flex flex-col items-start gap-4 hover:shadow-lg transition-shadow">
    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
      <Icon className="w-6 h-6 text-primary" />
    </div>
    <div>
      <h4 className="text-xl font-bold text-foreground mb-2">{title}</h4>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </div>
  </div>
);

const ModulesContent = () => (
  <motion.div
    key="modules"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3 }}
    className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8"
  >
    <ModuleCard 
      icon={Users} 
      title="Crew OS" 
      description="Real-time workforce management, centralized communication for teams distributed across timezones." 
      features={["Automated Rostering", "Compliance Tracking"]} 
    />
    <ModuleCard 
      icon={Plane} 
      title="Coordination OS" 
      description="Enterprise coordination with seamless external provider integration through a single unified protocol." 
      features={["Multi-Modal Logistics", "Cost Optimization"]} 
    />
    <ModuleCard 
      icon={AlertTriangle} 
      title="Disruption OS" 
      description="The ultimate BROP engine. Automatically recalculates routes, crews, and assets to minimize latencies." 
      features={["Auto-Recovery Engine", "Predictive Delay Logic"]} 
    />
    <ModuleCard 
      icon={BarChart3} 
      title="Intelligence" 
      description="The data-driven conductor. Real-time insights and operational data visualization that provides 360° view of your operations." 
      features={["Strategic Insights", "Global Dashboarding"]} 
    />
  </motion.div>
);

const ArchitectureContent = () => (
  <motion.div
    key="architecture"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3 }}
    className="flex flex-col items-center w-full"
  >
    <div className="text-center mb-10 md:mb-12 max-w-3xl mx-auto">
      <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">System Architecture</h3>
      <p className="text-base md:text-lg text-muted-foreground">
        Operion's architecture is built on a microservices foundation, enabling seamless integration, scalability, and real-time data synchronization across all operational layers.
      </p>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
      <ArchitectureCard 
        icon={Network} 
        title="API Layer" 
        description="RESTful and GraphQL APIs for seamless third-party integrations and real-time data access" 
      />
      <ArchitectureCard 
        icon={Database} 
        title="Data Layer" 
        description="Distributed database architecture with real-time synchronization across global regions" 
      />
      <ArchitectureCard 
        icon={Cpu} 
        title="Processing Engine" 
        description="AI-powered decision engine that processes millions of data points in milliseconds" 
      />
      <ArchitectureCard 
        icon={Link2} 
        title="Integration Layer" 
        description="Native connectors to existing crew management, coordination, and logistics systems" 
      />
    </div>
    <div className="mt-10 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-muted border border-border text-sm font-bold text-foreground shadow-sm">
      <CheckCircle2 className="w-5 h-5 text-[hsl(var(--tertiary))]" />
      Built for enterprise-scale operations with 99.9% uptime SLA
    </div>
  </motion.div>
);

const SecurityContent = () => (
  <motion.div
    key="security"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    transition={{ duration: 0.3 }}
    className="flex flex-col items-center w-full"
  >
    <div className="text-center mb-10 md:mb-12 max-w-3xl mx-auto">
      <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">Security & Compliance</h3>
      <p className="text-base md:text-lg text-muted-foreground">
        Enterprise-grade security with zero-trust architecture, ensuring global teams operate within a fortress of compliance and data integrity.
      </p>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
      <SecurityCard 
        icon={Lock} 
        title="Data Encryption" 
        description="End-to-end encryption for all data in transit and at rest using AES-256" 
      />
      <SecurityCard 
        icon={Shield} 
        title="Access Control" 
        description="Role-based access control (RBAC) with multi-factor authentication (MFA)" 
      />
      <SecurityCard 
        icon={CheckCircle2} 
        title="Compliance" 
        description="SOC 2 Type II, GDPR, HIPAA, and ISO 27001 certified" 
      />
      <SecurityCard 
        icon={FileText} 
        title="Audit Logging" 
        description="Comprehensive audit trails for all system activities and user actions" 
      />
      <SecurityCard 
        icon={RotateCcw} 
        title="Disaster Recovery" 
        description="Automated backup and disaster recovery with <4 hour RTO" 
      />
    </div>
    <div className="mt-10 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-muted border border-border text-sm font-bold text-foreground shadow-sm">
      <Shield className="w-5 h-5 text-primary" />
      Security audits conducted quarterly by third-party firms
    </div>
  </motion.div>
);

const PlatformPage = () => {
  const [activeTab, setActiveTab] = useState('Modules');

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Platform & Orchestration | Operion</title>
        <meta name="description" content="The all-in-one crew management operating system that orchestrates external providers." />
      </Helmet>
      
      <Header />

      <main className="flex-grow pt-20">
        
        {/* Unified Responsive Hero */}
        <section className="py-20 md:py-28 lg:py-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center relative overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm font-bold text-primary mb-8 uppercase tracking-wider">
              <Handshake className="w-4 h-4 mr-2" /> Platform Architecture
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6 text-balance mx-auto max-w-5xl">
              The all-in-one crew management operating system that orchestrates external providers
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-10">
              Operion integrates with external providers for execution. We coordinate crew movements through airlines, hotels, and logistics partners—you manage operations.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 w-full sm:w-auto">
              <Button asChild size="lg" className="h-14 px-8 text-lg font-bold w-full sm:w-auto">
                <Link to="/demo">Start Demo</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-14 px-8 text-lg font-bold w-full sm:w-auto">
                <Link to="/contact">Contact Sales</Link>
              </Button>
            </div>
          </motion.div>
        </section>

        {/* Clarification Banner */}
        <section className="px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto mb-20 relative z-10">
          <div className="bg-secondary text-secondary-foreground rounded-3xl p-8 md:p-12 shadow-2xl border border-border flex flex-col md:flex-row items-center gap-8">
            <div className="shrink-0 p-4 bg-background/10 rounded-2xl border border-secondary-foreground/10">
              <Shield className="w-12 h-12 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-4">Operion is NOT a crew operations marketplace.</h2>
              <p className="text-lg text-secondary-foreground/80 leading-relaxed">
                We don't compete with airlines, hotels, or logistics providers. Instead, we orchestrate your existing provider relationships. Operion does NOT store provider inventory, pricing, or assignment data. We coordinate execution through your providers and track status updates.
              </p>
            </div>
          </div>
        </section>

        {/* Orchestration Section */}
        <section id="providers" className="py-20 bg-muted/30 border-y border-border scroll-mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Provider Integrations</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                Operion sits between your crew operations and your external execution partners, translating complex operational requirements into automated logistics orders.
              </p>
            </div>

            {/* Provider Ecosystem Diagram */}
            <div className="bg-card border border-border rounded-3xl p-8 md:p-12 shadow-sm mb-16 overflow-hidden">
              <div className="flex flex-col lg:flex-row items-center justify-between gap-8 lg:gap-4 relative">
                
                {/* Left: Crew Ops */}
                <div className="w-full lg:w-1/3 bg-background border border-border rounded-2xl p-6 shadow-sm z-10 relative">
                  <div className="text-center mb-6">
                    <h3 className="font-bold text-lg">Your Crew Operations</h3>
                    <p className="text-sm text-muted-foreground">HR, Rosters, Planning</p>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-muted p-3 rounded-lg text-sm font-medium flex items-center justify-center gap-2 border border-border/50">
                      <Users className="w-4 h-4 text-primary" /> Crew Profiles
                    </div>
                    <div className="bg-muted p-3 rounded-lg text-sm font-medium flex items-center justify-center gap-2 border border-border/50">
                      <FileText className="w-4 h-4 text-primary" /> Compliance Rules
                    </div>
                  </div>
                </div>

                {/* Arrows/Connection Logic (Hidden on mobile for simplicity, or vertical) */}
                <div className="flex lg:flex-row flex-col items-center gap-2 text-muted-foreground/50 z-0">
                  <ArrowLeftRight className="w-8 h-8 lg:rotate-0 rotate-90" />
                </div>

                {/* Center: Operion */}
                <div className="w-full lg:w-1/3 bg-primary text-primary-foreground rounded-2xl p-8 shadow-xl z-20 transform scale-105 border border-primary/20 relative">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white/10 to-transparent rounded-2xl pointer-events-none"></div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-white/20 rounded-2xl mx-auto flex items-center justify-center mb-4 backdrop-blur-sm border border-white/20">
                      <Workflow className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="font-bold text-2xl mb-2">Operion OS</h3>
                    <p className="text-primary-foreground/80 text-sm mb-6">The Orchestration Layer</p>
                    <div className="bg-background/20 py-2 px-4 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-sm inline-block border border-white/10">
                      API & Webhook Engine
                    </div>
                  </div>
                </div>

                <div className="flex lg:flex-row flex-col items-center gap-2 text-muted-foreground/50 z-0">
                  <ArrowLeftRight className="w-8 h-8 lg:rotate-0 rotate-90" />
                </div>

                {/* Right: Providers */}
                <div className="w-full lg:w-1/3 bg-background border border-border rounded-2xl p-6 shadow-sm z-10 relative">
                  <div className="text-center mb-6">
                    <h3 className="font-bold text-lg">External Providers</h3>
                    <p className="text-sm text-muted-foreground">Execution & Tracking</p>
                  </div>
                  <div className="space-y-3">
                    <div className="bg-muted p-3 rounded-lg text-sm font-medium flex items-center justify-center gap-2 border border-border/50">
                      <Plane className="w-4 h-4 text-primary" /> Aviation Partners
                    </div>
                    <div className="bg-muted p-3 rounded-lg text-sm font-medium flex items-center justify-center gap-2 border border-border/50">
                      <Building2 className="w-4 h-4 text-primary" /> Accommodation
                    </div>
                  </div>
                </div>

              </div>
            </div>

            {/* How It Works Flow */}
            <div className="mb-20">
              <h3 className="text-2xl font-bold text-center mb-10">How Orchestration Works</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative">
                {/* Connecting Line */}
                <div className="hidden lg:block absolute top-12 left-[10%] right-[10%] h-0.5 bg-border/60 z-0"></div>
                
                {[
                  { title: "Plan", desc: "Operion generates optimal crew movement plans based on your rosters.", icon: Layers },
                  { title: "Validate", desc: "Automated checks ensure duty hours and rest periods meet compliance.", icon: Shield },
                  { title: "Coordinate", desc: "Approved plans are prepared for your external provider network.", icon: Workflow },
                  { title: "Execute", desc: "Operion sends execution orders via API to airlines and hotels.", icon: Plug },
                  { title: "Track", desc: "Real-time webhooks pull status updates back into Mission Control.", icon: Globe },
                  { title: "Manage", desc: "If disruptions occur, Operion automatically recalculates and re-orchestrates.", icon: RotateCcw }
                ].map((step, i) => (
                  <div key={i} className="bg-card border border-border rounded-2xl p-6 shadow-sm relative z-10 hover:-translate-y-1 transition-transform">
                    <div className="w-10 h-10 bg-primary/10 text-primary rounded-xl flex items-center justify-center font-bold mb-4 border border-primary/20">
                      <step.icon className="w-5 h-5" />
                    </div>
                    <h4 className="font-bold text-lg mb-2">{i + 1}. {step.title}</h4>
                    <p className="text-muted-foreground text-sm leading-relaxed">{step.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Does / Does Not Compare */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20">
              <div className="bg-card border border-emerald-500/20 rounded-3xl overflow-hidden shadow-sm">
                <div className="bg-emerald-500/10 px-8 py-6 border-b border-emerald-500/20">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <CheckCircle2 className="w-6 h-6 text-emerald-500" /> What Operion Does
                  </h3>
                </div>
                <div className="p-8">
                  <ul className="space-y-4">
                    {[
                      "Generates optimal crew movement plans",
                      "Validates compliance before execution",
                      "Sends coordination orders to providers",
                      "Tracks real-time status updates via API",
                      "Handles disruptions and re-routing",
                      "Maintains a complete audit trail"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                        <span className="text-foreground font-medium">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="bg-card border border-destructive/20 rounded-3xl overflow-hidden shadow-sm">
                <div className="bg-destructive/10 px-8 py-6 border-b border-destructive/20">
                  <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
                    <XCircle className="w-6 h-6 text-destructive" /> What Operion Does NOT Do
                  </h3>
                </div>
                <div className="p-8">
                  <ul className="space-y-4">
                    {[
                      "Store provider inventory or availability",
                      "Manage pricing or act as a booking engine",
                      "Process payments for flights/hotels",
                      "Replace your existing provider contracts",
                      "Act as a crew operations marketplace (OTA)",
                      "Compete with airlines or logistics providers"
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <XCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                        <span className="text-foreground font-medium">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Provider Types & Integration Methods (Bento Grid) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-card rounded-3xl p-8 border border-border shadow-sm">
                <h3 className="text-2xl font-bold mb-6">Supported Provider Types</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-muted p-5 rounded-2xl flex items-start gap-4">
                    <Plane className="w-8 h-8 text-primary shrink-0" />
                    <div>
                      <h4 className="font-bold mb-1">Airlines & Aviation</h4>
                      <p className="text-sm text-muted-foreground">Commercial carriers and private charter operators.</p>
                    </div>
                  </div>
                  <div className="bg-muted p-5 rounded-2xl flex items-start gap-4">
                    <Building2 className="w-8 h-8 text-primary shrink-0" />
                    <div>
                      <h4 className="font-bold mb-1">Hotels & Accommodations</h4>
                      <p className="text-sm text-muted-foreground">Global hotel chains and specialized crew housing.</p>
                    </div>
                  </div>
                  <div className="bg-muted p-5 rounded-2xl flex items-start gap-4">
                    <Car className="w-8 h-8 text-primary shrink-0" />
                    <div>
                      <h4 className="font-bold mb-1">Ground Transportation</h4>
                      <p className="text-sm text-muted-foreground">Shuttle services, fleet operators, and port transfers.</p>
                    </div>
                  </div>
                  <div className="bg-muted p-5 rounded-2xl flex items-start gap-4">
                    <Plug className="w-8 h-8 text-primary shrink-0" />
                    <div>
                      <h4 className="font-bold mb-1">Custom Providers</h4>
                      <p className="text-sm text-muted-foreground">Niche maritime, offshore, or agency logistics partners.</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-secondary text-secondary-foreground rounded-3xl p-8 shadow-sm flex flex-col justify-center">
                <h3 className="text-2xl font-bold mb-6">Integration Methods</h3>
                <ul className="space-y-5">
                  <li className="flex items-start gap-3">
                    <FileCode2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm">REST API</h4>
                      <p className="text-xs text-secondary-foreground/70">Direct bi-directional sync.</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <Webhook className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm">Webhooks</h4>
                      <p className="text-xs text-secondary-foreground/70">Real-time push notifications.</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <Settings2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm">Manual Coordination</h4>
                      <p className="text-xs text-secondary-foreground/70">Automated email/PDF routing for offline providers.</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <Handshake className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm">Partner Network</h4>
                      <p className="text-xs text-secondary-foreground/70">Pre-built connectors for major operators.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>

          </div>
        </section>

        {/* Core Modules (Tabs section) */}
        <section className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">Core Platform Architecture</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
              Four specialized engines, one unified operating system.
            </p>
            <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
          </div>
          
          <div className="mt-8">
            <AnimatePresence mode="wait">
              {activeTab === 'Modules' && <ModulesContent key="modules" />}
              {activeTab === 'Architecture' && <ArchitectureContent key="arch" />}
              {activeTab === 'Security' && <SecurityContent key="sec" />}
            </AnimatePresence>
          </div>
        </section>

        {/* Easy Provider Setup CTA */}
        <section className="py-24 bg-primary text-primary-foreground text-center">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Easy Provider Setup
            </h2>
            <p className="text-xl text-primary-foreground/90 mb-10 leading-relaxed max-w-2xl mx-auto">
              Connecting Operion to your providers takes days, not months. Bring your own contracts, and we'll configure the routing logic to execute your operations flawlessly.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild size="lg" className="bg-background text-foreground hover:bg-background/90 rounded-full px-8 text-lg h-14 font-bold shadow-xl transition-all hover:scale-105">
                <Link to="/contact">Configure Integration</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent border-2 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 rounded-full px-8 text-lg h-14 font-bold transition-colors">
                <Link to="/demo">Explore Architecture Demo</Link>
              </Button>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </div>
  );
};

export default PlatformPage;