import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { FileText, Search, Upload, AlertCircle, Check } from 'lucide-react';
import { useAviationData } from '@/contexts/AviationContextData.jsx';
import { formatCurrency } from '@/lib/formatters.js';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import { toast } from 'sonner';

import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog.jsx';

const RiskBadge = ({ level }) => {
  const styles = {
    'High': 'bg-destructive/10 text-destructive border-destructive/20',
    'Medium': 'bg-warning/10 text-warning border-warning/20',
    'Low': 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
  };
  return (
    <Badge variant="outline" className={`${styles[level] || styles['Low']} font-semibold`}>
      {level} Risk
    </Badge>
  );
};

const ContractIntelligence = () => {
  const isMobile = useIsMobile();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { filterContracts } = useAviationData();

  const [lessorFilter, setLessorFilter] = useState('All');
  const [riskFilter, setRiskFilter] = useState('All');
  const [search, setSearch] = useState('');
  
  const [selectedContract, setSelectedContract] = useState(null);
  const [uploadOpen, setUploadOpen] = useState(false);

  const filteredData = filterContracts(lessorFilter, riskFilter).filter(c => 
    c.contractId.toLowerCase().includes(search.toLowerCase()) || 
    c.aircraftId.toLowerCase().includes(search.toLowerCase())
  );

  const handleUploadMock = () => {
    setUploadOpen(false);
    toast.success('Contract uploaded and parsed successfully via AI.');
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Helmet><title>Contract Intelligence | Operion Aviation</title></Helmet>
      <LeftSidebar industry="aviation" isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} isMobile={isMobile} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <DemoHeader isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
        
        <main className="flex-1 overflow-y-auto bg-muted/10">
          <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                  <FileText className="w-6 h-6 text-primary" /> Contract Intelligence
                </h1>
                <p className="text-muted-foreground mt-1">AI-powered lease contract analysis and risk tracking.</p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <Button onClick={() => setUploadOpen(true)} className="bg-primary text-primary-foreground">
                  <Upload className="w-4 h-4 mr-2" /> Upload Contract
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 bg-card p-4 rounded-xl border border-border shadow-sm">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="Search Contract or Aircraft ID..." 
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={lessorFilter} onValueChange={setLessorFilter}>
                <SelectTrigger className="w-[160px]"><SelectValue placeholder="Lessor" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Lessors</SelectItem>
                  <SelectItem value="AerCap">AerCap</SelectItem>
                  <SelectItem value="GECAS">GECAS</SelectItem>
                  <SelectItem value="Air Lease Corp">Air Lease Corp</SelectItem>
                  <SelectItem value="Avolon">Avolon</SelectItem>
                  <SelectItem value="SMBC Aviation">SMBC Aviation</SelectItem>
                  <SelectItem value="BOC Aviation">BOC Aviation</SelectItem>
                </SelectContent>
              </Select>
              <Select value={riskFilter} onValueChange={setRiskFilter}>
                <SelectTrigger className="w-[140px]"><SelectValue placeholder="Risk Level" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="All">All Risks</SelectItem>
                  <SelectItem value="High">High Risk</SelectItem>
                  <SelectItem value="Medium">Medium Risk</SelectItem>
                  <SelectItem value="Low">Low Risk</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {isMobile ? (
              <div className="grid grid-cols-1 gap-4">
                {filteredData.map(contract => (
                  <Card key={contract.id} className="cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setSelectedContract(contract)}>
                    <CardContent className="p-4 space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-bold text-lg">{contract.contractId}</h3>
                          <p className="text-sm text-muted-foreground">{contract.aircraftId} • {contract.lessor}</p>
                        </div>
                        <RiskBadge level={contract.riskLevel} />
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-muted-foreground text-xs">Monthly</p>
                          <p className="font-medium">{formatCurrency(contract.monthlyPayment)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Penalty</p>
                          <p className="font-medium text-destructive">{formatCurrency(contract.penaltyClause)}</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-muted-foreground text-xs">End Date</p>
                          <p className="font-medium">{contract.endDate}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead>Contract ID</TableHead>
                      <TableHead>Aircraft ID</TableHead>
                      <TableHead>Lessor</TableHead>
                      <TableHead>End Date</TableHead>
                      <TableHead>Monthly Payment</TableHead>
                      <TableHead>Penalty Clause</TableHead>
                      <TableHead>Risk Level</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredData.map(contract => {
                      const isExpiringSoon = new Date(contract.endDate).getTime() - new Date('2026-04-29').getTime() < 180 * 24 * 60 * 60 * 1000;
                      return (
                        <TableRow 
                          key={contract.id} 
                          className="cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => setSelectedContract(contract)}
                        >
                          <TableCell className="font-bold">
                            <div className="flex items-center gap-2">
                              {contract.contractId}
                              {isExpiringSoon && <AlertCircle className="w-4 h-4 text-warning" title="Expiring < 6 months" />}
                            </div>
                          </TableCell>
                          <TableCell>{contract.aircraftId}</TableCell>
                          <TableCell>{contract.lessor}</TableCell>
                          <TableCell>{contract.endDate}</TableCell>
                          <TableCell>{formatCurrency(contract.monthlyPayment)}</TableCell>
                          <TableCell className={contract.penaltyClause > 500000 ? 'text-destructive font-medium' : ''}>
                            {formatCurrency(contract.penaltyClause)}
                          </TableCell>
                          <TableCell><RiskBadge level={contract.riskLevel} /></TableCell>
                        </TableRow>
                      );
                    })}
                    {filteredData.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No contracts found matching filters.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}

          </div>
        </main>
      </div>
      {isMobile && <BottomNavigation />}

      {/* Contract Detail Modal */}
      <Dialog open={!!selectedContract} onOpenChange={(open) => !open && setSelectedContract(null)}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-xl flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" /> Contract Details
            </DialogTitle>
            <DialogDescription>
              Full parsed details for {selectedContract?.contractId}
            </DialogDescription>
          </DialogHeader>
          {selectedContract && (
            <div className="space-y-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Aircraft ID</p>
                  <p className="font-medium">{selectedContract.aircraftId}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Lessor</p>
                  <p className="font-medium">{selectedContract.lessor}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Start Date</p>
                  <p className="font-medium">{selectedContract.startDate}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">End Date</p>
                  <p className="font-medium">{selectedContract.endDate}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Payment</p>
                  <p className="font-medium">{formatCurrency(selectedContract.monthlyPayment)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Penalty Clause</p>
                  <p className="font-medium text-destructive">{formatCurrency(selectedContract.penaltyClause)}</p>
                </div>
              </div>
              <div className="bg-muted/30 p-4 rounded-lg border border-border/50">
                <p className="text-sm font-medium mb-2">Extracted Key Terms</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{selectedContract.keyTerms}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Upload Modal */}
      <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Upload Lease Contract</DialogTitle>
            <DialogDescription>
              Upload a PDF. Operion AI will automatically extract key terms, dates, and financial obligations.
            </DialogDescription>
          </DialogHeader>
          <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:bg-muted/50 transition-colors cursor-pointer my-4">
            <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm font-medium">Click to browse or drag and drop</p>
            <p className="text-xs text-muted-foreground mt-1">PDF, DOCX up to 10MB</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUploadOpen(false)}>Cancel</Button>
            <Button onClick={handleUploadMock}>Simulate Upload</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
};

export default ContractIntelligence;