import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { Plane, Filter, Search, Edit2, Check } from 'lucide-react';
import { useAviationData } from '@/contexts/AviationContextData.jsx';
import { formatCurrency } from '@/lib/formatters.js';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';

const StatusBadge = ({ status }) => {
  const styles = {
    'Critical': 'bg-destructive/10 text-destructive border-destructive/20',
    'Near Return': 'bg-warning/10 text-warning border-warning/20',
    'Active': 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    'Expired': 'bg-muted text-muted-foreground border-border'
  };
  return (
    <Badge variant="outline" className={`${styles[status] || styles['Active']} font-semibold`}>
      {status}
    </Badge>
  );
};

const EditableCell = ({ value, onSave, type = 'text', formatFn = (v) => v }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [val, setVal] = useState(value);

  const handleSave = () => {
    setIsEditing(false);
    if (val !== value) onSave(type === 'number' ? Number(val) : val);
  };

  if (isEditing) {
    return (
      <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
        <Input 
          type={type} 
          value={val} 
          onChange={e => setVal(e.target.value)} 
          className="h-8 w-24 text-sm"
          autoFocus
          onBlur={handleSave}
          onKeyDown={e => e.key === 'Enter' && handleSave()}
        />
        <Button size="icon" variant="ghost" className="h-8 w-8 text-emerald-500" onClick={handleSave}>
          <Check className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  return (
    <div 
      className="flex items-center gap-2 group cursor-pointer hover:text-primary transition-colors"
      onClick={(e) => { e.stopPropagation(); setIsEditing(true); }}
    >
      <span>{formatFn(value)}</span>
      <Edit2 className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
    </div>
  );
};

const AviationFleetOverview = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { filterAircraft, updateAircraftField } = useAviationData();

  const [typeFilter, setTypeFilter] = useState('All');
  const [leaseFilter, setLeaseFilter] = useState('All');
  const [search, setSearch] = useState('');

  const filteredData = filterAircraft(typeFilter, leaseFilter).filter(a => 
    a.aircraftId.toLowerCase().includes(search.toLowerCase()) || 
    a.lessor.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Helmet><title>Fleet Overview | Operion Aviation</title></Helmet>
      <LeftSidebar industry="aviation" isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} isMobile={isMobile} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <DemoHeader isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
        
        <main className="flex-1 overflow-y-auto bg-muted/10">
          <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                  <Plane className="w-6 h-6 text-primary" /> Fleet Overview
                </h1>
                <p className="text-muted-foreground mt-1">Manage aircraft leases, utilization, and status.</p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative w-full md:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search ID or Lessor..." 
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    className="pl-9 bg-card"
                  />
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-[140px] bg-card"><SelectValue placeholder="Type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Types</SelectItem>
                    <SelectItem value="B737">B737</SelectItem>
                    <SelectItem value="B787">B787</SelectItem>
                    <SelectItem value="A320">A320</SelectItem>
                    <SelectItem value="E195">E195</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={leaseFilter} onValueChange={setLeaseFilter}>
                  <SelectTrigger className="w-[140px] bg-card"><SelectValue placeholder="Lease" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Leases</SelectItem>
                    <SelectItem value="Operating">Operating</SelectItem>
                    <SelectItem value="Finance">Finance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {isMobile ? (
              <div className="grid grid-cols-1 gap-4">
                {filteredData.map(aircraft => (
                  <Card key={aircraft.id} className="cursor-pointer hover:border-primary/50 transition-colors" onClick={() => navigate(`/demo/aviation/aircraft/${aircraft.aircraftId}`)}>
                    <CardContent className="p-4 space-y-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-bold text-lg">{aircraft.aircraftId}</h3>
                          <p className="text-sm text-muted-foreground">{aircraft.type} • {aircraft.leaseType}</p>
                        </div>
                        <StatusBadge status={aircraft.status} />
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-muted-foreground text-xs">Monthly Cost</p>
                          <p className="font-medium">{formatCurrency(aircraft.monthlyCost)}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground text-xs">Utilization</p>
                          <p className="font-medium">{aircraft.utilization}%</p>
                        </div>
                        <div className="col-span-2">
                          <p className="text-muted-foreground text-xs">Lease End</p>
                          <p className="font-medium">{aircraft.leaseEndDate}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead>Aircraft ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Lease Type</TableHead>
                      <TableHead>Monthly Cost</TableHead>
                      <TableHead>Utilization</TableHead>
                      <TableHead>Lease End Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredData.map(aircraft => (
                      <TableRow 
                        key={aircraft.id} 
                        className="cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => navigate(`/demo/aviation/aircraft/${aircraft.aircraftId}`)}
                      >
                        <TableCell className="font-bold">{aircraft.aircraftId}</TableCell>
                        <TableCell>{aircraft.type}</TableCell>
                        <TableCell>{aircraft.leaseType}</TableCell>
                        <TableCell>
                          <EditableCell 
                            value={aircraft.monthlyCost} 
                            type="number"
                            formatFn={formatCurrency}
                            onSave={(val) => updateAircraftField(aircraft.aircraftId, 'monthlyCost', val)} 
                          />
                        </TableCell>
                        <TableCell>
                          <EditableCell 
                            value={aircraft.utilization} 
                            type="number"
                            formatFn={(v) => `${v}%`}
                            onSave={(val) => updateAircraftField(aircraft.aircraftId, 'utilization', val)} 
                          />
                        </TableCell>
                        <TableCell>{aircraft.leaseEndDate}</TableCell>
                        <TableCell><StatusBadge status={aircraft.status} /></TableCell>
                      </TableRow>
                    ))}
                    {filteredData.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No aircraft found matching filters.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}

          </div>
        </main>
      </div>
      {isMobile && <BottomNavigation />}
    </div>
  );
};

export default AviationFleetOverview;