import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import PlanningDashboard from '@/components/demo/planning/PlanningDashboard.jsx';

const PlanningDemoPage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  return (
    <DemoStateProvider>
      <Helmet>
        <title>Rotation Planning | Operion Maritime</title>
      </Helmet>

      <div className="flex h-screen bg-background overflow-hidden">
        <LeftSidebar 
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          isMobile={isMobile}
        />
        
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <DemoHeader 
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
          />
          
          <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
            <PlanningDashboard />
          </main>
        </div>

        {isMobile && <BottomNavigation />}
      </div>
    </DemoStateProvider>
  );
};

export default PlanningDemoPage;