import React from 'react';
import { Helmet } from 'react-helmet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { BIStateProvider } from '@/contexts/BIStateContext.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

import GlobalFiltersPanel from '@/components/demo/intelligence/GlobalFiltersPanel.jsx';
import KPIWidgetsSection from '@/components/demo/intelligence/KPIWidgetsSection.jsx';
import { OTPTrendChart, CostPerRouteChart, DelayCausesChart, AirportDelayHeatmap, CostAccumulationChart } from '@/components/demo/intelligence/BICharts.jsx';
import AIInsightsPanel from '@/components/demo/intelligence/AIInsightsPanel.jsx';
import LiveOperationsFeed from '@/components/demo/intelligence/LiveOperationsFeed.jsx';
import RouteAnalyticsSection from '@/components/demo/intelligence/RouteAnalyticsSection.jsx';
import CrewAnalyticsSection from '@/components/demo/intelligence/CrewAnalyticsSection.jsx';
import CustomReportBuilder from '@/components/demo/intelligence/CustomReportBuilder.jsx';

const IntelligenceDashboard = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const isMobile = useIsMobile();

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Helmet>
        <title>Business Intelligence | Operion Aviation</title>
      </Helmet>

      <LeftSidebar 
        industry="aviation"
        isMobileMenuOpen={isMobileMenuOpen}
        setIsMobileMenuOpen={setIsMobileMenuOpen}
        isMobile={isMobile}
      />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <DemoHeader 
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
        />
        
        <GlobalFiltersPanel />

        <main className="flex-1 overflow-y-auto">
          <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-2">
              <div>
                <h1 className="text-2xl font-bold tracking-tight">Business Intelligence</h1>
                <p className="text-muted-foreground">Comprehensive analytics and AI-driven insights.</p>
              </div>
            </div>

            <KPIWidgetsSection />

            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="w-full justify-start overflow-x-auto hide-scrollbar bg-transparent border-b border-border rounded-none h-auto p-0 mb-6">
                <TabsTrigger value="overview" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-2">Overview</TabsTrigger>
                <TabsTrigger value="routes" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-2">Route Analytics</TabsTrigger>
                <TabsTrigger value="crew" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-2">Crew Analytics</TabsTrigger>
                <TabsTrigger value="reports" className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-2">Custom Reports</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-6 mt-0 animate-in fade-in duration-500">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-6">
                    <OTPTrendChart />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <DelayCausesChart />
                      <CostAccumulationChart />
                    </div>
                    <AirportDelayHeatmap />
                  </div>
                  <div className="space-y-6">
                    <AIInsightsPanel />
                    <LiveOperationsFeed />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="routes" className="mt-0">
                <RouteAnalyticsSection />
              </TabsContent>

              <TabsContent value="crew" className="mt-0">
                <CrewAnalyticsSection />
              </TabsContent>

              <TabsContent value="reports" className="mt-0">
                <CustomReportBuilder />
              </TabsContent>
            </Tabs>

          </div>
        </main>
      </div>
    </div>
  );
};

const IntelligencePage = () => {
  return (
    <DemoStateProvider>
      <BIStateProvider>
        <IntelligenceDashboard />
      </BIStateProvider>
    </DemoStateProvider>
  );
};

export default IntelligencePage;