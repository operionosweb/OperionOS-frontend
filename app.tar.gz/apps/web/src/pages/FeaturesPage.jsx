import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Users, Plane, AlertTriangle, CalendarClock, BrainCircuit, 
  TrendingDown, Ship, Anchor, Settings, Link as LinkIcon, ArrowRight, ShieldCheck
} from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import FeatureCategory from '@/components/FeatureCategory.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';

const coreFeatures = [
  {
    title: "Core Capabilities",
    description: "Operion integrates with external providers for execution. We coordinate crew movements through airlines, hotels, and logistics partners—you manage operations.",
    icon: Users,
    items: [
      {
        id: "feat-1",
        title: "Crew Movement Planning",
        shortDescription: "Generate optimal crew movement plans based on availability, compliance, and cost.",
        businessBenefit: "Reduces scheduling time by 40%",
        features: ["Rule-based assignment engine", "Preference bidding system", "Real-time roster publishing"],
        capabilities: ["Conflict detection", "Draft vs. Published states", "Mobile schedule sync"],
        useCases: ["Monthly roster generation", "Holiday period planning", "Reserve crew allocation"],
        benefits: ["Higher crew satisfaction", "Fewer compliance violations", "Optimized reserve utilization"]
      },
      {
        id: "feat-2",
        title: "Rotation Logistics",
        shortDescription: "Manage crew rotations, rest periods, and accommodation coordination.",
        businessBenefit: "Ensures 100% regulatory compliance",
        features: ["Biomathematical fatigue modeling", "Cumulative duty tracking", "Rest period calculation"],
        capabilities: ["EASA/FAA rule integration", "Pre-flight fatigue alerts", "Post-flight reporting"],
        useCases: ["Long-haul flight planning", "Back-to-back sector assignments", "Timezone crossing analysis"],
        benefits: ["Enhanced flight safety", "Reduced fatigue-related callouts", "Audit-ready compliance logs"]
      },
      {
        id: "feat-3",
        title: "Compliance Monitoring",
        shortDescription: "Monitor duty hours, certifications, and regulatory requirements in real-time.",
        businessBenefit: "Zero expired certification flights",
        features: ["Automated expiry alerts", "Document OCR upload", "Training schedule integration"],
        capabilities: ["Hard-blocks for expired certs", "Bulk renewal tracking", "Digital wallet for crew"],
        useCases: ["Medical renewal tracking", "Simulator session scheduling", "Visa expiration monitoring"],
        benefits: ["Eliminates manual tracking", "Prevents grounding due to paperwork", "Streamlines audits"]
      },
      {
        id: "feat-4",
        title: "Movement Execution Tracking",
        shortDescription: "Track crew movement execution and provider status updates.",
        businessBenefit: "Cuts coordination errors by 95%",
        features: ["External provider API integration", "Policy-driven class selection", "Automated timeline sync"],
        capabilities: ["PNR tracking", "Seat preference mapping", "Baggage allowance handling"],
        useCases: ["Positioning crew to outstations", "Returning crew to base", "Emergency relief movements"],
        benefits: ["Lower coordination overhead", "Zero manual data entry", "Instant timeline delivery"]
      },
      {
        id: "feat-5",
        title: "Disruption Management",
        shortDescription: "Detect disruptions and automatically generate alternative crew movement plans.",
        businessBenefit: "Recovers schedules 3x faster",
        features: ["Crew reassignment automation", "Ripple-effect analysis", "Priority-based recovery"],
        capabilities: ["Scenario simulation", "One-click execution", "Contingency planning"],
        useCases: ["Severe weather groundings", "Aircraft technical swaps", "Airspace closures"],
        benefits: ["Minimizes delay minutes", "Protects downstream flights", "Reduces manual workload during crises"]
      },
      {
        id: "feat-6",
        title: "Crew Visibility",
        shortDescription: "Real-time crew location and movement status visibility.",
        businessBenefit: "Improves on-time performance",
        features: ["Weather pattern analysis", "ATC restriction monitoring", "Historical turnaround data"],
        capabilities: ["Probability scoring", "Early warning alerts", "Mitigation suggestions"],
        useCases: ["Hub congestion management", "Turnaround optimization", "Crew connection protection"],
        benefits: ["Proactive decision making", "Better passenger experience", "Protected crew legality"]
      }
    ]
  }
];

const FeaturesPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Platform Features | Operion</title>
        <meta name="description" content="Explore Operion's capabilities across Aviation, Maritime, and Offshore crew operations." />
      </Helmet>
      
      <Header />

      <main className="flex-grow pt-20">
        
        <section className="py-20 md:py-28 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center relative overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-primary/5 rounded-full blur-3xl -z-10 pointer-events-none"></div>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto"
          >
            <div className="inline-flex items-center rounded-full bg-primary/10 px-4 py-1.5 text-sm font-bold text-primary mb-6 tracking-wide uppercase border border-primary/20">
              Platform Capabilities
            </div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6 text-balance">
              Engineered for Global <span className="text-primary">Crew Ops.</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Explore Operion's comprehensive suite of tools designed to synchronize human resources, compliance, and disruption management across borders.
            </p>
          </motion.div>
        </section>

        <section className="pb-24 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
          <div className="space-y-4">
            {coreFeatures.map((category, idx) => (
              <FeatureCategory 
                key={`core-cat-${idx}`}
                title={category.title}
                description={category.description}
                icon={category.icon}
                items={category.items}
              />
            ))}
          </div>
        </section>

        <section className="py-20 bg-secondary text-secondary-foreground border-t border-border relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary via-transparent to-transparent"></div>
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">See Operion in Action</h2>
            <p className="text-lg text-secondary-foreground/80 mb-10 max-w-2xl mx-auto">
              Discover how our intelligent platform can streamline your crew operations, reduce costs, and ensure compliance today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" asChild className="w-full sm:w-auto h-14 px-8 text-base font-bold shadow-lg">
                <Link to="/contact-sales">Start Demo</Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="w-full sm:w-auto h-14 px-8 text-base font-bold bg-transparent border-secondary-foreground/20 hover:bg-secondary-foreground/10 text-secondary-foreground group">
                <Link to="/contact-sales">
                  Learn More
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </div>
  );
};

export default FeaturesPage;