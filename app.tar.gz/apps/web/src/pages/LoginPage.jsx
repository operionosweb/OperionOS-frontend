import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Lock, ShieldAlert, CheckCircle2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog.jsx';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  // Forgot Password State
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [isResetting, setIsResetting] = useState(false);
  const [resetError, setResetError] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    setIsLoading(true);

    try {
      if (!window.supabaseClient) {
        throw new Error('Supabase client not found');
      }

      const { data, error: signInError } = await window.supabaseClient.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError) {
        alert('Invalid login credentials');
        setIsLoading(false);
        return;
      }

      if (data?.session?.access_token) {
        localStorage.setItem('operion_token', data.session.access_token);
      }

      // Successful login
      navigate('/control-panel');
    } catch (err) {
      console.error('Authentication error:', err);
      alert('Invalid login credentials');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setResetError('');
    setSuccessMessage('');

    if (!resetEmail) {
      setResetError('Please enter your email address');
      return;
    }

    setIsResetting(true);

    try {
      if (!window.supabaseClient) {
        throw new Error('Supabase client not found');
      }

      const { error: resetApiError } = await window.supabaseClient.auth.resetPasswordForEmail(resetEmail);

      if (resetApiError) {
        if (resetApiError.message.toLowerCase().includes('user not found')) {
          setResetError('Email not found');
        } else if (resetApiError.message.toLowerCase().includes('fetch') || resetApiError.message.toLowerCase().includes('network')) {
          setResetError('Network error. Please try again.');
        } else {
          setResetError(resetApiError.message);
        }
        return;
      }

      // Success
      setSuccessMessage('Password reset link sent to your email');
      setIsForgotPasswordOpen(false);
      setResetEmail('');
    } catch (err) {
      console.error('Reset password error:', err);
      setResetError('Network error. Please try again.');
    } finally {
      setIsResetting(false);
    }
  };

  // Clear modal errors when opening/closing
  const handleOpenChange = (open) => {
    setIsForgotPasswordOpen(open);
    if (!open) {
      setResetError('');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Login | Operion</title>
      </Helmet>

      <Header />

      <main className="flex-1 flex items-center justify-center px-4 pt-20 pb-12">
        <Card className="w-full max-w-md border-border/50 shadow-lg bg-card/80 backdrop-blur-sm">
          <CardHeader className="space-y-3 pb-6 text-center">
            <div className="mx-auto w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-2 border border-primary/20">
              <Lock className="w-6 h-6 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold tracking-tight text-foreground">
              Operion Login
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Secure access to Operational Intelligence System
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              {error && (
                <div className="p-3 mb-4 rounded-md bg-destructive/10 border border-destructive/20 flex items-center gap-2 text-sm text-destructive font-medium animate-in fade-in">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {successMessage && (
                <div className="p-3 mb-4 rounded-md bg-green-500/10 border border-green-500/20 flex items-center gap-2 text-sm text-green-600 dark:text-green-400 font-medium animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{successMessage}</span>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11 bg-background"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Password
                  </Label>
                  <button
                    type="button"
                    onClick={() => setIsForgotPasswordOpen(true)}
                    className="text-xs font-medium text-primary hover:text-primary/80 hover:underline transition-colors"
                  >
                    Forgot password?
                  </button>
                </div>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 bg-background"
                />
              </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-11 mt-4 bg-primary text-primary-foreground hover:bg-primary/90 font-medium transition-all"
              >
                {isLoading ? 'Authenticating...' : 'Sign In'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </main>

      {/* Forgot Password Modal */}
      <Dialog open={isForgotPasswordOpen} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-md bg-card">
          <DialogHeader>
            <DialogTitle className="text-xl">Reset Password</DialogTitle>
            <DialogDescription>
              Enter your email to receive a password reset link
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleResetPassword} className="space-y-4 pt-4">
            {resetError && (
              <div className="p-3 rounded-md bg-destructive/10 border border-destructive/20 flex items-center gap-2 text-sm text-destructive font-medium animate-in fade-in">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>{resetError}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="resetEmail" className="text-sm font-medium">
                Email Address
              </Label>
              <Input
                id="resetEmail"
                type="email"
                placeholder="name@example.com"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
                disabled={isResetting}
                className="h-11"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <Button
                type="submit"
                disabled={isResetting}
                className="w-full sm:w-auto min-w-[140px] h-10 transition-all"
              >
                {isResetting ? (
                  <span className="flex items-center gap-2">
                    <span className="h-4 w-4 rounded-full border-2 border-current border-t-transparent animate-spin shrink-0" />
                    Sending...
                  </span>
                ) : (
                  'Send Reset Link'
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default LoginPage;