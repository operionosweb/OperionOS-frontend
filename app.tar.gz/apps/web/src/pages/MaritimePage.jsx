import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import VesselRotationCard from '@/components/maritime/VesselRotationCard.jsx';
import PortLogisticsCard from '@/components/maritime/PortLogisticsCard.jsx';
import MobileOrchestratorCard from '@/components/maritime/MobileOrchestratorCard.jsx';
import ComplianceGrid from '@/components/maritime/ComplianceGrid.jsx';
import MaritimeCTA from '@/components/maritime/MaritimeCTA.jsx';

const MaritimePage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Maritime Logistics | Operion</title>
        <meta name="description" content="Precision Logistics for Global Vessel Rotations powered by Operion OS." />
      </Helmet>
      
      <Header />

      <main className="flex-grow pt-20">
        {/* Blue Status Bar */}
        <div className="w-full h-1.5 bg-primary"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
          {/* Hero Section */}
          <motion.div 
            className="text-center max-w-4xl mx-auto mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-foreground mb-6 text-balance">
              Maritime: Precision <span className="text-primary">Logistics</span> for Global Vessel Rotations
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Synchronize complex crew changes, port logistics, and compliance tracking across your entire global fleet in real-time.
            </p>
          </motion.div>

          {/* Main Two-Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
            {/* Left Column */}
            <motion.div 
              className="lg:col-span-7"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <VesselRotationCard />
            </motion.div>

            {/* Right Column */}
            <motion.div 
              className="lg:col-span-5 flex flex-col gap-6"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <PortLogisticsCard />
              <MobileOrchestratorCard />
            </motion.div>
          </div>

          {/* Compliance Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <ComplianceGrid />
          </motion.div>
        </div>

        {/* CTA Section */}
        <MaritimeCTA />
      </main>

      <Footer />
      
      {/* Mobile Sticky CTA */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 p-4 bg-background/90 backdrop-blur-md border-t border-border z-40">
        <button className="w-full bg-primary text-primary-foreground font-bold py-3.5 rounded-xl shadow-lg">
          Book Live Demo
        </button>
      </div>
    </div>
  );
};

export default MaritimePage;