import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, MapPin, ArrowRight, Building2 } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ContactForm from '@/components/ContactForm.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card } from '@/components/ui/card.jsx';
const ContactSalesPage = () => {
  const scrollToForm = () => {
    const formElement = document.getElementById('contact-form');
    if (formElement) {
      formElement.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  };
  return <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Contact Sales | Operion</title>
        <meta name="description" content="Speak with our team to see how Operion can transform your crew operations." />
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="relative bg-secondary text-secondary-foreground py-20 md:py-32 overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary via-transparent to-transparent"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.h1 initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.5
          }} className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Contact Sales
            </motion.h1>
            <motion.p initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.5,
            delay: 0.1
          }} className="text-lg md:text-xl text-secondary-foreground/80 max-w-2xl mx-auto">
              Speak with our team to see how Operion can transform your crew operations, reduce costs, and improve compliance.
            </motion.p>
          </div>
        </section>

        {/* Main Content Section */}
        <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-16">
              
              {/* Form Column */}
              <div className="lg:col-span-2 order-2 lg:order-1">
                <Card className="p-6 md:p-8 shadow-lg border-border rounded-2xl">
                  <h2 className="text-2xl font-bold mb-6">Send us a message</h2>
                  <ContactForm />
                </Card>
              </div>

              {/* Contact Info Column */}
              <div className="lg:col-span-1 order-1 lg:order-2 space-y-8">
                <div>
                  <h3 className="text-xl font-bold mb-6">Get in touch</h3>
                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Email Us</p>
                        <a href="mailto:operionosweb@gmail.com" className="text-muted-foreground hover:text-primary transition-colors mt-1 inline-block">
                          info@OperionOS.com
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <Building2 className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Global Headquarters</p>
                        <p className="text-muted-foreground mt-1">
                          Operion Systems Inc.<br />
                          100 Maritime Way, Suite 400<br />
                          London, UK
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-muted rounded-2xl p-6 border border-border">
                  <h4 className="font-bold text-lg mb-2">Support Inquiries</h4>
                  <p className="text-muted-foreground text-sm mb-4">
                    Already an Operion customer? Visit our support portal for technical assistance and documentation.
                  </p>
                  <Button variant="outline" className="w-full">
                    Visit Support Portal
                  </Button>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-muted/50 border-t border-border">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">See Operion in Action</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Discover how our intelligent platform can streamline your maritime or aviation operations today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button size="lg" onClick={scrollToForm} className="w-full sm:w-auto h-12 px-8 text-base">
                Request Demo
              </Button>
              <Button size="lg" variant="outline" asChild className="w-full sm:w-auto h-12 px-8 text-base group">
                <Link to="/">
                  Explore Platform
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>;
};
export default ContactSalesPage;