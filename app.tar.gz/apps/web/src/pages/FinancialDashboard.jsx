import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, DollarSign, PieChart as PieChartIcon, BarChart3 } from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, CartesianGrid 
} from 'recharts';
import { useAviationData } from '@/contexts/AviationContextData.jsx';
import { formatCurrency } from '@/lib/formatters.js';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';

const COLORS = {
  'B787': 'hsl(var(--primary))',
  'B737': 'hsl(var(--teal))',
  'A320': 'hsl(var(--warning))',
  'E195': 'hsl(var(--destructive))'
};

const FinancialDashboard = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { getAircraftList } = useAviationData();
  
  const [maintFactor, setMaintFactor] = useState(15); // 15% default

  const aircraft = getAircraftList();

  // Calculations
  const metrics = useMemo(() => {
    let totalMonthly = 0;
    const typeDistribution = { 'B787': 0, 'B737': 0, 'A320': 0, 'E195': 0 };
    
    const enriched = aircraft.map(a => {
      const maintCost = a.monthlyCost * (maintFactor / 100);
      const total = a.monthlyCost + maintCost;
      totalMonthly += total;
      typeDistribution[a.type] += total;
      return { ...a, totalMonthlyCost: total };
    });

    const sortedByCost = [...enriched].sort((a, b) => b.totalMonthlyCost - a.totalMonthlyCost);
    
    const pieData = Object.entries(typeDistribution).map(([name, value]) => ({ name, value }));

    // Expiry timeline
    const expiryCounts = {};
    enriched.forEach(a => {
      const month = a.leaseEndDate.substring(0, 7); // YYYY-MM
      expiryCounts[month] = (expiryCounts[month] || 0) + 1;
    });
    const timelineData = Object.entries(expiryCounts)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([month, count]) => ({ month, count }))
      .slice(0, 12); // Next 12 expiries

    return {
      totalMonthly,
      totalYearly: totalMonthly * 12,
      avgCost: totalMonthly / aircraft.length,
      count: aircraft.length,
      topAircraft: sortedByCost.slice(0, 15),
      pieData,
      timelineData
    };
  }, [aircraft, maintFactor]);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Helmet><title>Financial Dashboard | Operion Aviation</title></Helmet>
      <LeftSidebar industry="aviation" isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} isMobile={isMobile} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <DemoHeader isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
        
        <main className="flex-1 overflow-y-auto bg-muted/10">
          <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                  <TrendingUp className="w-6 h-6 text-primary" /> Financial Dashboard
                </h1>
                <p className="text-muted-foreground mt-1">Fleet cost analysis and lease exposure.</p>
              </div>
              <div className="bg-card border border-border rounded-xl p-3 shadow-sm flex items-center gap-4 min-w-[250px]">
                <span className="text-sm font-medium whitespace-nowrap">Maint. Factor: {maintFactor}%</span>
                <Slider 
                  value={[maintFactor]} 
                  onValueChange={(v) => setMaintFactor(v[0])} 
                  max={30} min={5} step={1} 
                  className="flex-1"
                />
              </div>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="border-border shadow-sm">
                <CardContent className="p-5">
                  <p className="text-sm font-medium text-muted-foreground mb-1">Total Monthly Cost</p>
                  <p className="text-2xl font-bold text-foreground">{formatCurrency(metrics.totalMonthly)}</p>
                </CardContent>
              </Card>
              <Card className="border-border shadow-sm">
                <CardContent className="p-5">
                  <p className="text-sm font-medium text-muted-foreground mb-1">Total Annual Cost</p>
                  <p className="text-2xl font-bold text-primary">{formatCurrency(metrics.totalYearly)}</p>
                </CardContent>
              </Card>
              <Card className="border-border shadow-sm">
                <CardContent className="p-5">
                  <p className="text-sm font-medium text-muted-foreground mb-1">Avg Cost per Aircraft</p>
                  <p className="text-2xl font-bold text-foreground">{formatCurrency(metrics.avgCost)}</p>
                </CardContent>
              </Card>
              <Card className="border-border shadow-sm">
                <CardContent className="p-5">
                  <p className="text-sm font-medium text-muted-foreground mb-1">Active Fleet Size</p>
                  <p className="text-2xl font-bold text-foreground">{metrics.count} Aircraft</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Bar Chart */}
              <Card className="lg:col-span-2 border-border shadow-sm flex flex-col">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2"><BarChart3 className="w-4 h-4 text-primary" /> Top 15 Aircraft by Cost</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 min-h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={metrics.topAircraft} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="hsl(var(--border))" />
                      <XAxis type="number" tickFormatter={(val) => `€${val/1000}k`} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <YAxis dataKey="aircraftId" type="category" stroke="hsl(var(--muted-foreground))" fontSize={12} width={60} />
                      <Tooltip 
                        formatter={(value) => formatCurrency(value)}
                        contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', backgroundColor: 'hsl(var(--card))', color: 'hsl(var(--foreground))' }}
                      />
                      <Bar dataKey="totalMonthlyCost" radius={[0, 4, 4, 0]} onClick={(data) => navigate(`/demo/aviation/aircraft/${data.aircraftId}`)} cursor="pointer">
                        {metrics.topAircraft.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[entry.type] || COLORS['B737']} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Pie Chart */}
              <Card className="border-border shadow-sm flex flex-col">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2"><PieChartIcon className="w-4 h-4 text-primary" /> Cost by Type</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 min-h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie 
                        data={metrics.pieData} 
                        cx="50%" cy="50%" 
                        innerRadius={60} outerRadius={80} 
                        paddingAngle={5} 
                        dataKey="value"
                      >
                        {metrics.pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[entry.name] || COLORS['B737']} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value) => formatCurrency(value)}
                        contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', backgroundColor: 'hsl(var(--card))', color: 'hsl(var(--foreground))' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex flex-wrap justify-center gap-4 mt-4">
                    {metrics.pieData.map(entry => (
                      <div key={entry.name} className="flex items-center gap-2 text-sm">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[entry.name] }} />
                        <span>{entry.name}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Table */}
            <Card className="border-border shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Highest Cost Aircraft (Top 10)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Aircraft ID</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Base Lease</TableHead>
                        <TableHead>Est. Maint.</TableHead>
                        <TableHead>Total Monthly</TableHead>
                        <TableHead>Lease End</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {metrics.topAircraft.slice(0, 10).map(a => (
                        <TableRow key={a.id} className="cursor-pointer hover:bg-muted/50" onClick={() => navigate(`/demo/aviation/aircraft/${a.aircraftId}`)}>
                          <TableCell className="font-bold">{a.aircraftId}</TableCell>
                          <TableCell>{a.type}</TableCell>
                          <TableCell>{formatCurrency(a.monthlyCost)}</TableCell>
                          <TableCell>{formatCurrency(a.totalMonthlyCost - a.monthlyCost)}</TableCell>
                          <TableCell className="font-bold text-primary">{formatCurrency(a.totalMonthlyCost)}</TableCell>
                          <TableCell>{a.leaseEndDate}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

          </div>
        </main>
      </div>
      {isMobile && <BottomNavigation />}
    </div>
  );
};

export default FinancialDashboard;