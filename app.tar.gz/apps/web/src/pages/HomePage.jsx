import React from 'react';
import { Link } from 'react-router-dom';
import { Users, ShieldCheck, AlertTriangle, BrainCircuit, HeartHandshake as Handshake, Globe, Link as LinkIcon, ArrowRight, Plane, Home, BarChart } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import FeatureCard from '@/components/FeatureCard.jsx';
import OperationalFlowStep from '@/components/OperationalFlowStep.jsx';
import IndustrySolutionCard from '@/components/IndustrySolutionCard.jsx';
import MetricsSection from '@/components/MetricsSection.jsx';
import CTASection from '@/components/CTASection.jsx';
import SEOHead from '@/components/SEOHead.jsx';

const HomePage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SEOHead 
        title="OPERION – Operating System for Global Crew Management"
        description="Automate crew scheduling, compliance, and disruption handling across aviation, maritime, and offshore operations."
        keywords="crew management, aviation operations, maritime crew, offshore crew scheduling, compliance tracking, disruption management, crew intelligence, rotation optimization, provider orchestration"
      />
      
      <Header />

      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section 
          className="header-hero"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1688413399498-e35ed74b554f)' }}
        >
          <div className="header-overlay"></div>
          <div className="header-content">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              
              <div className="flex flex-col items-start text-left">
                <div className="inline-flex items-center rounded-full border border-primary/40 bg-primary/20 px-3 py-1 text-sm font-semibold text-primary-foreground mb-6 backdrop-blur-sm">
                  NEXT GEN CREW OPS
                </div>
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-white mb-6 text-balance">
                  Operating System for Global Crew Management
                </h1>
                <p className="text-xl text-slate-200 mb-10 max-w-2xl leading-relaxed">
                  Automate crew scheduling, compliance, and disruption handling—coordinated seamlessly through your external providers.
                </p>
                
                {/* Crew Movement Overview Stats */}
                <div className="grid grid-cols-3 gap-4 w-full mb-10">
                  <div className="flex flex-col p-4 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl shadow-sm">
                    <Users className="w-5 h-5 text-primary-foreground mb-2" />
                    <span className="text-2xl font-bold text-white">1,248</span>
                    <span className="text-xs text-slate-300 uppercase tracking-wider font-semibold">Active movements</span>
                  </div>
                  <div className="flex flex-col p-4 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl shadow-sm">
                    <BarChart className="w-5 h-5 text-primary-foreground mb-2" />
                    <span className="text-2xl font-bold text-white">$2.4M</span>
                    <span className="text-xs text-slate-300 uppercase tracking-wider font-semibold">Total operational cost</span>
                  </div>
                  <div className="flex flex-col p-4 bg-black/40 backdrop-blur-md border border-white/10 rounded-xl shadow-sm">
                    <Home className="w-5 h-5 text-primary-foreground mb-2" />
                    <span className="text-2xl font-bold text-white">8,492</span>
                    <span className="text-xs text-slate-300 uppercase tracking-wider font-semibold">Movements this month</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
                  <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 text-lg h-14 w-full sm:w-auto transition-all">
                    <Link to="/demo" title="Explore Mission Control">Start Demo</Link>
                  </Button>
                  <Button asChild size="lg" variant="outline" className="rounded-full px-8 text-lg h-14 border-white/20 text-white hover:bg-white/10 bg-black/20 backdrop-blur-sm w-full sm:w-auto hidden md:inline-flex transition-all">
                    <Link to="/platform#providers" title="Learn About Provider Orchestration">Learn More</Link>
                  </Button>
                </div>
              </div>

              <div className="relative mt-12 lg:mt-0 hidden lg:block">
                {/* Optional: Keep the dashboard image as a floating element over the hero, or remove it. Keeping it for structure. */}
                <div className="relative rounded-2xl overflow-hidden border border-white/20 shadow-2xl bg-black/50 backdrop-blur-sm aspect-[4/3] md:aspect-video lg:aspect-square flex items-center justify-center transform rotate-2 hover:rotate-0 transition-transform duration-500">
                  <img 
                    src="https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/526028865e51a2d0c573ff528232ff41.png" 
                    alt="Crew Management Dashboard showing rotation optimization and compliance metrics" 
                    className="w-full h-full object-cover opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-black/40 to-transparent"></div>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* Core Capabilities / Feature Cards */}
        <section className="py-20 bg-muted/30 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">Unified Crew Operations</h2>
              <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
                Everything you need to manage crew operations—coordinated through your external providers.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div>
                <h3 className="sr-only">Generate optimal crew movement plans</h3>
                <FeatureCard 
                  icon={Users}
                  title="Generate optimal crew movement plans"
                  description="Rotation optimization and fatigue management for global workforces."
                  showDot={true}
                />
              </div>
              <div>
                <h3 className="sr-only">Execute with compliance</h3>
                <FeatureCard 
                  icon={ShieldCheck}
                  title="Execute with compliance"
                  description="Track duty hours, certifications, and regulatory requirements in real-time."
                  showDot={true}
                />
              </div>
              <div>
                <h3 className="sr-only">Track crew operations in real-time</h3>
                <FeatureCard 
                  icon={AlertTriangle}
                  title="Track crew operations in real-time"
                  description="Instant crew reassignment and contingency planning for unforeseen events."
                  showDot={true}
                />
              </div>
              <div>
                <h3 className="sr-only">Centralized Crew Intelligence</h3>
                <FeatureCard 
                  icon={BrainCircuit}
                  title="Crew Intelligence"
                  description="Seamlessly coordinate movement execution via external providers and optimize costs."
                  showDot={true}
                />
              </div>
            </div>
          </div>
        </section>

        {/* Provider Partnerships Banner */}
        <section className="py-24 bg-background relative overflow-hidden">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl -z-10 translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-card border border-border shadow-xl rounded-3xl p-8 md:p-16 flex flex-col lg:flex-row items-center gap-12">
              <div className="lg:w-1/2">
                <div className="inline-flex items-center rounded-full bg-secondary/10 px-3 py-1 text-sm font-semibold text-secondary mb-6 border border-secondary/20">
                  <Handshake className="w-4 h-4 mr-2" /> Provider Partnerships
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
                  We Orchestrate. Your Providers Execute.
                </h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Operion is not a crew operations marketplace. We integrate directly with your existing airlines, hotels, and ground logistics partners. Generate the plan in Operion, and we'll automatically route the execution orders to the providers you already trust.
                </p>
                <ul className="space-y-4 mb-8">
                  <li className="flex items-center gap-3 text-foreground font-medium">
                    <LinkIcon className="w-5 h-5 text-primary" /> Connect via REST API, Webhooks, or Partner Network
                  </li>
                  <li className="flex items-center gap-3 text-foreground font-medium">
                    <Globe className="w-5 h-5 text-primary" /> Track live status updates from external systems
                  </li>
                </ul>
                <Button asChild size="lg">
                  <Link to="/platform#providers">
                    Explore Provider Orchestration <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
              </div>
              <div className="lg:w-1/2 w-full flex justify-center">
                <div className="relative w-full max-w-md aspect-square">
                  {/* Abstract visualization of orchestration */}
                  <div className="absolute inset-0 border border-dashed border-border rounded-full animate-[spin_40s_linear_infinite]"></div>
                  <div className="absolute inset-4 border border-border rounded-full animate-[spin_30s_linear_infinite_reverse]"></div>
                  
                  <div className="absolute inset-0 flex items-center justify-center z-10">
                    <div className="bg-primary text-primary-foreground font-bold p-6 rounded-2xl shadow-xl z-20">
                      Operion OS
                    </div>
                  </div>
                  
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 bg-card border border-border px-4 py-2 rounded-xl shadow-md text-sm font-semibold flex items-center gap-2">
                    <Plane className="w-4 h-4 text-muted-foreground" /> Aviation Partners
                  </div>
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-4 bg-card border border-border px-4 py-2 rounded-xl shadow-md text-sm font-semibold flex items-center gap-2">
                    <Users className="w-4 h-4 text-muted-foreground" /> Crew Rosters
                  </div>
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 bg-card border border-border px-4 py-2 rounded-xl shadow-md text-sm font-semibold flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-muted-foreground" /> Compliance
                  </div>
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 bg-card border border-border px-4 py-2 rounded-xl shadow-md text-sm font-semibold flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-muted-foreground" /> Live Alerts
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Operational Flow Section */}
        <section className="py-24 bg-muted/30 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-bold mb-16 text-center text-foreground">Reduce operational costs by 20-30%</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div>
                <h3 className="text-xl font-semibold mb-2">Automate crew scheduling and rotations</h3>
                <OperationalFlowStep 
                  number="1"
                  title="Ingest & Map"
                  description="Connect your existing HR and operational systems. We seamlessly integrate your crew data."
                />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Ensure regulatory compliance</h3>
                <OperationalFlowStep 
                  number="2"
                  title="Simulate & Solve"
                  description="AI engine generates optimal crew assignments, balancing fatigue rules and operational needs."
                />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Real-time disruption management</h3>
                <OperationalFlowStep 
                  number="3"
                  title="Coordinate & Monitor"
                  description="Deploy schedules to external providers in real-time and track compliance across all crew instantly."
                />
              </div>
            </div>
          </div>
        </section>

        <MetricsSection />

        {/* Industry Solutions */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">Industry-Specific Crew Solutions</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <h3 className="sr-only">Aviation Operations</h3>
                <IndustrySolutionCard 
                  image="https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=2074&auto=format&fit=crop"
                  title="Aviation"
                  description="Manage pilot and crew scheduling, compliance, and disruption across global flight operations."
                  link="/demo/aviation"
                />
              </div>
              <div>
                <h3 className="sr-only">Maritime Operations</h3>
                <IndustrySolutionCard 
                  image="https://images.unsplash.com/photo-1494412519320-aa613dfb7738?q=80&w=2070&auto=format&fit=crop"
                  title="Maritime"
                  description="Optimize vessel crew rotations, compliance, and operational efficiency across international waters."
                  link="/demo/maritime"
                />
              </div>
              <div>
                <h3 className="sr-only">Offshore Energy</h3>
                <IndustrySolutionCard 
                  image="https://images.unsplash.com/photo-1616509974337-0001d3d87e80?q=80&w=2070&auto=format&fit=crop"
                  title="Offshore Energy"
                  description="Manage offshore crew scheduling, complex rotations, and strict safety compliance for rigs and platforms."
                  link="/industries"
                />
              </div>
            </div>
          </div>
        </section>

        <CTASection />
      </main>

      <Footer />
    </div>
  );
};

export default HomePage;