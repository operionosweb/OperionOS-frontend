import React from 'react';
import LegalPageLayout from '@/components/LegalPageLayout.jsx';

const PrivacyPolicyPage = () => {
  const sections = [
    {
      id: 'introduction',
      title: '1. Introduction',
      content: (
        <>
          <p>
            At Operion, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our operational efficiency platform.
          </p>
          <p>
            Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site or use our services.
          </p>
        </>
      )
    },
    {
      id: 'data-we-collect',
      title: '2. Data We Collect',
      content: (
        <>
          <p>We collect information that identifies, relates to, describes, references, is capable of being associated with, or could reasonably be linked, directly or indirectly, with a particular consumer or device.</p>
          
          <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">Personal Data</h3>
          <p>While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>Email address</li>
            <li>First name and last name</li>
            <li>Phone number</li>
            <li>Business address, State, Province, ZIP/Postal code, City</li>
          </ul>

          <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">Operational Data</h3>
          <p>To provide our core services, we process operational data related to your aviation or maritime activities. This includes:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>Crew schedules, certifications, and duty logs</li>
            <li>Vessel or aircraft telemetry and routing information</li>
            <li>Maintenance schedules and logs</li>
            <li>Operational disruption reports</li>
          </ul>

          <h3 className="text-xl font-semibold text-foreground mt-8 mb-4">Usage Data</h3>
          <p>Usage Data is collected automatically when using the Service. It may include information such as your Device's Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.</p>
        </>
      )
    },
    {
      id: 'how-we-use-data',
      title: '3. How We Use Data',
      content: (
        <>
          <p>Operion uses the collected data for various purposes:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li>To provide and maintain our Service</li>
            <li>To notify you about changes to our Service</li>
            <li>To allow you to participate in interactive features of our Service when you choose to do so</li>
            <li>To provide customer support</li>
            <li>To gather analysis or valuable information so that we can improve our Service</li>
            <li>To monitor the usage of our Service</li>
            <li>To detect, prevent and address technical issues</li>
            <li>To fulfill our contractual obligations to your organization</li>
          </ul>
        </>
      )
    },
    {
      id: 'data-storage-security',
      title: '4. Data Storage & Security',
      content: (
        <>
          <p>
            The security of your data is important to us. We implement enterprise-grade security measures designed to secure your personal and operational information from accidental loss and from unauthorized access, use, alteration, and disclosure.
          </p>
          <p>
            All information you provide to us is stored on our secure servers behind firewalls. Any payment transactions and highly sensitive operational data will be encrypted using SSL/TLS technology.
          </p>
          <p>
            While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security as no method of transmission over the Internet, or method of electronic storage is 100% secure.
          </p>
        </>
      )
    },
    {
      id: 'data-sharing',
      title: '5. Data Sharing',
      content: (
        <>
          <p>We may share your information with third parties only in the ways that are described in this privacy policy:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>Service Providers:</strong> We may share your information with third-party vendors, service providers, contractors, or agents who perform services for us or on our behalf.</li>
            <li><strong>Business Transfers:</strong> We may share or transfer your information in connection with, or during negotiations of, any merger, sale of company assets, financing, or acquisition of all or a portion of our business to another company.</li>
            <li><strong>Legal Obligations:</strong> We may disclose your information where we are legally required to do so in order to comply with applicable law, governmental requests, a judicial proceeding, court order, or legal process.</li>
          </ul>
        </>
      )
    },
    {
      id: 'user-rights',
      title: '6. User Rights (GDPR Aligned)',
      content: (
        <>
          <p>If you are a resident of the European Economic Area (EEA), you have certain data protection rights. Operion aims to take reasonable steps to allow you to correct, amend, delete, or limit the use of your Personal Data.</p>
          <p>In certain circumstances, you have the following data protection rights:</p>
          <ul className="list-disc pl-6 space-y-2 mt-4">
            <li><strong>The right to access:</strong> You have the right to request copies of your personal data.</li>
            <li><strong>The right to rectification:</strong> You have the right to request that we correct any information you believe is inaccurate.</li>
            <li><strong>The right to erasure:</strong> You have the right to request that we erase your personal data, under certain conditions.</li>
            <li><strong>The right to restrict processing:</strong> You have the right to request that we restrict the processing of your personal data, under certain conditions.</li>
            <li><strong>The right to object to processing:</strong> You have the right to object to our processing of your personal data, under certain conditions.</li>
            <li><strong>The right to data portability:</strong> You have the right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.</li>
          </ul>
        </>
      )
    },
    {
      id: 'cookies-tracking',
      title: '7. Cookies & Tracking',
      content: (
        <>
          <p>
            We use cookies and similar tracking technologies to track the activity on our Service and hold certain information. Cookies are files with small amount of data which may include an anonymous unique identifier.
          </p>
          <p>
            You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.
          </p>
        </>
      )
    },
    {
      id: 'data-retention',
      title: '8. Data Retention',
      content: (
        <>
          <p>
            We will retain your Personal Data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use your Personal Data to the extent necessary to comply with our legal obligations (for example, if we are required to retain your data to comply with applicable laws), resolve disputes, and enforce our legal agreements and policies.
          </p>
          <p>
            Operational data is retained according to the specific terms outlined in your organization's Master Service Agreement (MSA) with Operion.
          </p>
        </>
      )
    },
    {
      id: 'contact-information',
      title: '9. Contact Information',
      content: (
        <>
          <p>If you have any questions about this Privacy Policy, please contact our Data Protection Officer:</p>
          <div className="bg-muted/50 p-6 rounded-xl border border-border mt-6">
            <p className="font-medium text-foreground mb-2">Operion Privacy Team</p>
            <p>Email: <a href="mailto:privacy@operion.com" className="text-primary hover:underline">privacy@operion.com</a></p>
            <p className="mt-2">We aim to respond to all privacy-related inquiries within 48 business hours.</p>
          </div>
        </>
      )
    }
  ];

  return (
    <LegalPageLayout
      seoTitle="Privacy Policy | Operion Operational Efficiency Platform"
      seoDescription="Learn how Operion collects, uses, and protects your data. GDPR-compliant and transparent data practices."
      title="Privacy Policy"
      description="How Operion collects, uses, and protects your data. Transparent and GDPR-compliant."
      lastUpdated="October 15, 2025"
      sections={sections}
    />
  );
};

export default PrivacyPolicyPage;