import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

import VesselOperationsHeader from '@/components/vessel-ops/VesselOperationsHeader.jsx';
import KPICardsSection from '@/components/vessel-ops/KPICardsSection.jsx';
import VesselFleetOverview from '@/components/vessel-ops/VesselFleetOverview.jsx';
import PortOperationsScheduler from '@/components/vessel-ops/PortOperationsScheduler.jsx';
import CrewVesselSynchronization from '@/components/vessel-ops/CrewVesselSynchronization.jsx';
import LiveVesselTracking from '@/components/vessel-ops/LiveVesselTracking.jsx';
import OperationalAlertsPanel from '@/components/vessel-ops/OperationalAlertsPanel.jsx';
import AnalyticsTab from '@/components/vessel-ops/AnalyticsTab.jsx';
import VesselDetailPanel from '@/components/vessel-ops/VesselDetailPanel.jsx';
import PortDetailPanel from '@/components/vessel-ops/PortDetailPanel.jsx';
import SuggestionDetailPanel from '@/components/vessel-ops/SuggestionDetailPanel.jsx';
import AlertDetailPanel from '@/components/vessel-ops/AlertDetailPanel.jsx';

const VesselOperationsPage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const [view, setView] = useState('map'); // list, map, analytics
  const [filters, setFilters] = useState({ region: 'all', type: 'all', status: 'all' });
  
  // Detail Panel States
  const [selectedVessel, setSelectedVessel] = useState(null);
  const [selectedPort, setSelectedPort] = useState(null);
  const [selectedSuggestion, setSelectedSuggestion] = useState(null);
  const [selectedAlert, setSelectedAlert] = useState(null);

  return (
    <DemoStateProvider>
      <Helmet>
        <title>Vessel Operations | Operion Maritime</title>
      </Helmet>

      <div className="flex h-screen bg-background overflow-hidden">
        <LeftSidebar 
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          isMobile={isMobile}
        />
        
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <DemoHeader 
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
          />
          
          <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
            <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
              <VesselOperationsHeader 
                view={view} 
                setView={setView} 
                filters={filters} 
                setFilters={setFilters} 
              />

              <KPICardsSection />

              <AnimatePresence mode="wait">
                <motion.div
                  key={view}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {view === 'list' && (
                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                      <div className="xl:col-span-2 space-y-6">
                        <VesselFleetOverview onVesselClick={setSelectedVessel} />
                        <PortOperationsScheduler onPortClick={setSelectedPort} />
                        <CrewVesselSynchronization onSuggestionClick={setSelectedSuggestion} />
                      </div>
                      <div className="xl:col-span-1">
                        <OperationalAlertsPanel onAlertClick={setSelectedAlert} />
                      </div>
                    </div>
                  )}

                  {view === 'map' && (
                    <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
                      <div className="xl:col-span-3 space-y-6">
                        <LiveVesselTracking onVesselClick={setSelectedVessel} />
                        <CrewVesselSynchronization onSuggestionClick={setSelectedSuggestion} />
                      </div>
                      <div className="xl:col-span-1 space-y-6">
                        <OperationalAlertsPanel onAlertClick={setSelectedAlert} />
                      </div>
                    </div>
                  )}

                  {view === 'analytics' && (
                    <AnalyticsTab />
                  )}
                </motion.div>
              </AnimatePresence>

              {/* Detail Panels */}
              <VesselDetailPanel 
                vessel={selectedVessel} 
                isOpen={!!selectedVessel} 
                onClose={() => setSelectedVessel(null)} 
              />
              <PortDetailPanel 
                port={selectedPort} 
                isOpen={!!selectedPort} 
                onClose={() => setSelectedPort(null)} 
              />
              <SuggestionDetailPanel 
                suggestion={selectedSuggestion} 
                isOpen={!!selectedSuggestion} 
                onClose={() => setSelectedSuggestion(null)} 
              />
              <AlertDetailPanel 
                alert={selectedAlert} 
                isOpen={!!selectedAlert} 
                onClose={() => setSelectedAlert(null)} 
              />
            </div>
          </main>
        </div>

        {isMobile && <BottomNavigation />}
      </div>
    </DemoStateProvider>
  );
};

export default VesselOperationsPage;