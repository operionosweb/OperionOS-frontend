import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import SustainabilityHero from '@/components/sustainability/SustainabilityHero.jsx';
import SustainabilityTrustSection from '@/components/sustainability/SustainabilityTrustSection.jsx';
import SustainabilityImpactPillars from '@/components/sustainability/SustainabilityImpactPillars.jsx';
import SustainabilitySDGSection from '@/components/sustainability/SustainabilitySDGSection.jsx';
import SustainabilityROItoESG from '@/components/sustainability/SustainabilityROItoESG.jsx';
import SustainabilityIndustryImpact from '@/components/sustainability/SustainabilityIndustryImpact.jsx';
import SustainabilityProofSection from '@/components/sustainability/SustainabilityProofSection.jsx';
import SustainabilityCTASection from '@/components/sustainability/SustainabilityCTASection.jsx';
import BreadcrumbSchema from '@/components/BreadcrumbSchema.jsx';

const SustainabilityImpactPage = () => {
  // Structured Data for SEO
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Operion",
    "url": "https://operion.com",
    "logo": "https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/d4c3af1ba833729da85b67b90bdf2c04.png",
    "description": "AI-powered operational intelligence platform for maritime and aviation industries."
  };

  const webPageSchema = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "name": "Operion Sustainability Impact | Maritime & Aviation Efficiency Platform",
    "description": "Discover how Operion drives operational efficiency while reducing emissions and supporting ESG goals in maritime and aviation industries.",
    "url": "https://operion.com/sustainability-impact"
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>Operion Sustainability Impact | Maritime & Aviation Efficiency Platform</title>
        <meta name="description" content="Discover how Operion drives operational efficiency while reducing emissions and supporting ESG goals in maritime and aviation industries." />
        <meta name="keywords" content="maritime operational efficiency software, aviation crew management optimization, fleet optimization platform, ESG maritime aviation software, sustainability in maritime operations, reduce emissions shipping aviation software, AI operations platform, crew optimization software, reduce fuel consumption fleet, maritime digital transformation platform, aviation efficiency software" />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://operion.com/sustainability-impact" />
        <meta property="og:title" content="Operion Sustainability Impact | Maritime & Aviation Efficiency Platform" />
        <meta property="og:description" content="Discover how Operion drives operational efficiency while reducing emissions and supporting ESG goals in maritime and aviation industries." />
        <meta property="og:image" content="https://images.unsplash.com/photo-1698666348132-fa9121fd6d19?q=80&w=1200&auto=format&fit=crop" />

        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content="https://operion.com/sustainability-impact" />
        <meta property="twitter:title" content="Operion Sustainability Impact | Maritime & Aviation Efficiency Platform" />
        <meta property="twitter:description" content="Discover how Operion drives operational efficiency while reducing emissions and supporting ESG goals in maritime and aviation industries." />
        <meta property="twitter:image" content="https://images.unsplash.com/photo-1698666348132-fa9121fd6d19?q=80&w=1200&auto=format&fit=crop" />
        
        <link rel="canonical" href="https://operion.com/sustainability-impact" />

        {/* Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify(organizationSchema)}
        </script>
        <script type="application/ld+json">
          {JSON.stringify(webPageSchema)}
        </script>
      </Helmet>

      <BreadcrumbSchema 
        items={[
          { name: 'Home', url: '/' },
          { name: 'Sustainability Impact', url: '/sustainability-impact' }
        ]} 
      />

      <Header />

      <main className="flex-grow">
        <SustainabilityHero />
        <SustainabilityTrustSection />
        <SustainabilityImpactPillars />
        <SustainabilitySDGSection />
        <SustainabilityROItoESG />
        <SustainabilityIndustryImpact />
        <SustainabilityProofSection />
        <SustainabilityCTASection />
      </main>

      <Footer />
    </div>
  );
};

export default SustainabilityImpactPage;