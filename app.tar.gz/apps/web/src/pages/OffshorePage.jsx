import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Calendar, Route, Shield, Layers, MapPin, AlertCircle, 
  TrendingDown, ClipboardList, CheckCircle2, Link2, 
  Activity, ShieldCheck, Zap, ClipboardCheck, Eye, ArrowRight 
} from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import SEOHead from '@/components/SEOHead.jsx';
import BreadcrumbSchema from '@/components/BreadcrumbSchema.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import FeatureCard from '@/components/FeatureCard.jsx';

const OffshorePage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SEOHead 
        title="Offshore Crew Operations | Operion"
        description="Plan, manage, and coordinate offshore crew rotations with full operational visibility and control."
        keywords="offshore crew operations, rig rotations, maritime logistics, offshore compliance, crew scheduling"
      />
      
      <Header />

      <main className="flex-grow pt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
          <BreadcrumbSchema 
            items={[
              { name: 'Home', path: '/' },
              { name: 'Industries', path: '/industries' },
              { name: 'Offshore', path: '/offshore' }
            ]} 
          />
        </div>

        {/* SECTION 1 - HERO */}
        <section className="relative pb-20 md:pb-28 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-bold text-primary mb-8 uppercase tracking-wider">
                Industry Solution
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-foreground mb-6 text-balance max-w-5xl mx-auto">
                Offshore Crew Operations, Simplified
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed mb-10">
                Plan, manage, and coordinate offshore crew rotations with full operational visibility and control.
              </p>
              <div className="flex justify-center w-full mb-16">
                <Button asChild size="lg" className="h-14 px-8 text-lg font-bold shadow-lg">
                  <Link to="/contact-sales">Request Demo</Link>
                </Button>
              </div>

              <div className="relative rounded-3xl overflow-hidden border border-border shadow-2xl bg-muted aspect-video max-w-5xl mx-auto flex items-center justify-center group">
                <img 
                  src="https://images.unsplash.com/photo-1563118351-26b2c7381731?q=80&w=2070&auto=format&fit=crop" 
                  alt="Offshore oil rig platform in the ocean" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-background/20 to-transparent"></div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* SECTION 2 - KEY CAPABILITIES */}
        <section className="py-24 bg-muted/30 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Offshore Crew Management Capabilities</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                End-to-end operational control for rigs, platforms, and specialized vessels.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard 
                icon={Calendar}
                title="Manage Offshore Crew Scheduling and Rotations"
                description="Automate complex 28/28 or custom rotation cycles while tracking real-time availability and shift overlap."
              />
              <FeatureCard 
                icon={Route}
                title="Coordinate Crew Movements to Offshore Platforms"
                description="Seamlessly dispatch movement orders for helicopters and supply vessels to external logistics providers."
              />
              <FeatureCard 
                icon={Shield}
                title="Ensure Safety Compliance and Minimize Crew Fatigue"
                description="Monitor survival training certifications (BOSIET/HUET) and track cumulative duty hours to prevent fatigue."
              />
            </div>
          </div>
        </section>

        {/* SECTION 3 - OPERATIONAL CHALLENGES */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Offshore Operations Are Complex</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                We understand the unique constraints of operating in extreme, remote environments.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border border-border shadow-sm hover:shadow-md transition-all">
                <CardContent className="p-8 flex items-start gap-5">
                  <div className="shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <Layers className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Complex Rotation Cycles</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Managing back-to-back shift changes and staggered handovers manually leads to coverage gaps and excessive administrative overhead.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-border shadow-sm hover:shadow-md transition-all">
                <CardContent className="p-8 flex items-start gap-5">
                  <div className="shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Remote Locations and Logistics Constraints</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Coordinating flights, hotels, and final-leg helicopter transfers requires perfect timing. A single delay breaks the entire chain.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-border shadow-sm hover:shadow-md transition-all">
                <CardContent className="p-8 flex items-start gap-5">
                  <div className="shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <AlertCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Strict Safety and Compliance Requirements</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Deploying crew with expired medical or safety certificates poses catastrophic liability and operational risks.
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-border shadow-sm hover:shadow-md transition-all">
                <CardContent className="p-8 flex items-start gap-5">
                  <div className="shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                    <TrendingDown className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">High Cost of Disruptions</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Weather delays and sudden personnel changes lead to massive standby costs and delayed production schedules.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* SECTION 4 - HOW OPERION HELPS */}
        <section className="py-24 bg-muted/30 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">How Operion Optimizes Offshore Crew Operations</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                A unified workflow from schedule creation to final deployment.
              </p>
            </div>

            <div className="relative max-w-4xl mx-auto">
              <div className="hidden md:block absolute left-12 top-10 bottom-10 w-0.5 bg-border/80"></div>
              
              <div className="space-y-12">
                <div className="relative flex flex-col md:flex-row gap-6 md:gap-10">
                  <div className="md:w-24 shrink-0 flex justify-start md:justify-center z-10">
                    <div className="w-16 h-16 rounded-full bg-background border-2 border-primary flex items-center justify-center shadow-md">
                      <ClipboardList className="w-7 h-7 text-primary" />
                    </div>
                  </div>
                  <div className="bg-card border border-border p-6 md:p-8 rounded-2xl shadow-sm flex-grow">
                    <h3 className="text-xl font-bold mb-3">1. Plan Rotations and Assign Crew</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Use our AI-driven scheduling engine to generate optimal rotation rosters based on demand, contract rules, and historical availability.
                    </p>
                  </div>
                </div>

                <div className="relative flex flex-col md:flex-row gap-6 md:gap-10">
                  <div className="md:w-24 shrink-0 flex justify-start md:justify-center z-10">
                    <div className="w-16 h-16 rounded-full bg-background border-2 border-primary flex items-center justify-center shadow-md">
                      <CheckCircle2 className="w-7 h-7 text-primary" />
                    </div>
                  </div>
                  <div className="bg-card border border-border p-6 md:p-8 rounded-2xl shadow-sm flex-grow">
                    <h3 className="text-xl font-bold mb-3">2. Validate Compliance</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Automatically check every assignment against safety regulations, visa requirements, and medical certifications before confirming the movement.
                    </p>
                  </div>
                </div>

                <div className="relative flex flex-col md:flex-row gap-6 md:gap-10">
                  <div className="md:w-24 shrink-0 flex justify-start md:justify-center z-10">
                    <div className="w-16 h-16 rounded-full bg-background border-2 border-primary flex items-center justify-center shadow-md">
                      <Link2 className="w-7 h-7 text-primary" />
                    </div>
                  </div>
                  <div className="bg-card border border-border p-6 md:p-8 rounded-2xl shadow-sm flex-grow">
                    <h3 className="text-xl font-bold mb-3">3. Coordinate Crew Movements via External Providers</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Dispatch travel logistics directly to your connected TMCs, airlines, and specialized helicopter operators via Operion's secure API.
                    </p>
                  </div>
                </div>

                <div className="relative flex flex-col md:flex-row gap-6 md:gap-10">
                  <div className="md:w-24 shrink-0 flex justify-start md:justify-center z-10">
                    <div className="w-16 h-16 rounded-full bg-background border-2 border-primary flex items-center justify-center shadow-md">
                      <Activity className="w-7 h-7 text-primary" />
                    </div>
                  </div>
                  <div className="bg-card border border-border p-6 md:p-8 rounded-2xl shadow-sm flex-grow">
                    <h3 className="text-xl font-bold mb-3">4. Monitor Execution and Handle Disruptions</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Track crew status in real-time. If adverse weather grounds a flight, Operion instantly recalculates and proposes alternative movement plans.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 5 - KEY BENEFITS */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Benefits of Operion for Offshore Operations</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Transform logistical overhead into operational advantage.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="flex flex-col items-center text-center p-8 rounded-3xl bg-muted/40 border border-border/50">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Reduced Operational Risk</h3>
                <p className="text-muted-foreground">
                  Eliminate compliance violations with hard-coded blocks on assigning non-certified or fatigued personnel.
                </p>
              </div>

              <div className="flex flex-col items-center text-center p-8 rounded-3xl bg-muted/40 border border-border/50">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                  <Zap className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Improved Crew Utilization</h3>
                <p className="text-muted-foreground">
                  Maximize productive time on the rig by optimizing transit routes and reducing dead-leg logistics.
                </p>
              </div>

              <div className="flex flex-col items-center text-center p-8 rounded-3xl bg-muted/40 border border-border/50">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                  <ClipboardCheck className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Better Compliance Tracking</h3>
                <p className="text-muted-foreground">
                  Maintain an automated, audit-ready log of all certifications, training renewals, and rest periods.
                </p>
              </div>

              <div className="flex flex-col items-center text-center p-8 rounded-3xl bg-muted/40 border border-border/50">
                <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                  <Eye className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Increased Visibility Across Operations</h3>
                <p className="text-muted-foreground">
                  Gain a single pane of glass into global crew locations, upcoming rotations, and real-time movement statuses.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 6 - INTEGRATION NOTE */}
        <section className="py-24 bg-muted/30 border-y border-border">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="bg-secondary text-secondary-foreground rounded-3xl p-8 md:p-12 shadow-xl border border-secondary-foreground/10 flex flex-col md:flex-row items-center gap-8">
              <div className="shrink-0 p-5 bg-background/10 rounded-2xl border border-secondary-foreground/10">
                <Link2 className="w-12 h-12 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-4">How Operion Works With Your Providers</h2>
                <p className="text-lg text-secondary-foreground/80 leading-relaxed">
                  Operion is not a travel agency. We are the operational orchestration layer. You keep your existing contracts with helicopter operators, commercial airlines, and ground transport providers. Operion seamlessly connects with them to dispatch orders and track execution, giving you complete control without disrupting established partnerships.
                </p>
                <div className="mt-6">
                  <Link to="/providers" className="inline-flex items-center font-bold text-primary hover:text-primary/80 transition-colors">
                    Learn more about provider integration <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 7 - CTA SECTION */}
        <section className="py-24 bg-primary text-primary-foreground text-center">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Ready to Optimize Your Offshore Operations?
            </h2>
            <p className="text-xl text-primary-foreground/90 mb-10 leading-relaxed max-w-2xl mx-auto">
              Equip your coordination teams with the only operating system built specifically for the complexities of remote crew management.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild size="lg" className="bg-background text-foreground hover:bg-background/90 rounded-full px-8 text-lg h-14 font-bold shadow-xl transition-all hover:scale-105">
                <Link to="/contact-sales">Optimize Your Offshore Operations</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent border-2 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 rounded-full px-8 text-lg h-14 font-bold transition-colors">
                <Link to="/demo">Book a Demo</Link>
              </Button>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </div>
  );
};

export default OffshorePage;