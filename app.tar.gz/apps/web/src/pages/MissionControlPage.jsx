import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Users, 
  Plane, 
  Ship, 
  AlertTriangle, 
  CalendarClock, 
  BrainCircuit, 
  TrendingUp,
  CheckCircle2,
  ArrowRight,
  MousePointerClick,
  Compass,
  BarChart,
  Home
} from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button.jsx';

const MissionControlPage = () => {
  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: "-50px" },
    transition: { duration: 0.5 }
  };

  const staggerContainer = {
    initial: { opacity: 0 },
    whileInView: { opacity: 1 },
    viewport: { once: true, margin: "-50px" },
    transition: { staggerChildren: 0.1 }
  };

  const staggerItem = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    transition: { duration: 0.4 }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Helmet>
        <title>{`Crew Operations Command Center | Operion`}</title>
        <meta name="description" content="Access the Operion Mission Control demo. Experience the operating system for global crew management across maritime, aviation, and offshore industries." />
      </Helmet>

      <Header />

      <main className="flex-grow pt-20">
        <section className="relative py-24 md:py-32 lg:py-40 overflow-hidden flex items-center justify-center min-h-[70vh]">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1686061594225-3e92c0cd51b0" 
              alt="Mission Control Center" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-secondary/90 mix-blend-multiply"></div>
            <div className="absolute inset-0 bg-gradient-to-b from-secondary/80 via-secondary/60 to-background"></div>
          </div>
          
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/20 border border-primary/30 text-primary-foreground mb-8 backdrop-blur-sm">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                </span>
                <span className="text-sm font-medium tracking-wide uppercase">Interactive Demo Gateway</span>
              </div>
              
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-white text-balance leading-tight tracking-tight">
                Crew Operations Command Center
              </h1>
              <p className="text-xl md:text-2xl font-medium text-primary mb-6">
                Manage all your crew operations in one place
              </p>
              <p className="text-lg md:text-xl text-white/80 leading-relaxed max-w-3xl mx-auto mb-10">
                Step into the command center. Experience how Operion unifies crew operations, compliance tracking, and disruption recovery into a single, intelligent platform.
              </p>
              
              <Button 
                size="lg" 
                className="h-14 px-8 text-lg font-bold shadow-lg hover:shadow-primary/25 transition-all duration-300"
                onClick={() => {
                  document.getElementById('demo-selection').scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Select Your Industry
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Active Crew Movements Overview */}
        <section className="py-12 bg-muted/30 border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-card p-6 rounded-2xl border border-border shadow-sm flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-xl text-primary">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Active crew movements</p>
                  <p className="text-2xl font-bold text-foreground">1,248</p>
                </div>
              </div>
              <div className="bg-card p-6 rounded-2xl border border-border shadow-sm flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-xl text-primary">
                  <BarChart className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Total operational cost</p>
                  <p className="text-2xl font-bold text-foreground">$2.4M</p>
                </div>
              </div>
              <div className="bg-card p-6 rounded-2xl border border-border shadow-sm flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-xl text-primary">
                  <Home className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Movements this month</p>
                  <p className="text-2xl font-bold text-foreground">8,492</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">What Operion Does</h2>
              <p className="text-lg text-muted-foreground">
                A comprehensive suite of modules designed to work together seamlessly, providing end-to-end control over your global crew operations.
              </p>
            </motion.div>

            <motion.div 
              variants={staggerContainer}
              initial="initial"
              whileInView="whileInView"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {[
                { icon: Users, title: "View all crew movements", desc: "Optimize scheduling, track compliance, and manage certifications in one unified interface." },
                { icon: Plane, title: "Track crew movement status", desc: "Seamlessly coordinate movement execution via external providers." },
                { icon: Ship, title: "Manage crew assignments", desc: "Real-time tracking and synchronization of physical assets with human capital." },
                { icon: AlertTriangle, title: "Get operational alerts", desc: "AI-powered crew reassignment and contingency planning." },
                { icon: CalendarClock, title: "Planning & Forecasting", desc: "Predictive models to anticipate demand and optimize future crew allocations." },
                { icon: BrainCircuit, title: "AI-Powered Intelligence", desc: "Actionable insights derived from millions of data points across your network." },
                { icon: TrendingUp, title: "ROI & Savings Tracking", desc: "Quantifiable metrics proving the financial impact of optimized crew operations." }
              ].map((feature, index) => (
                <motion.div 
                  key={index} 
                  variants={staggerItem}
                  className={`bg-card border border-border rounded-2xl p-8 shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-1 ${index === 6 ? 'md:col-span-2 lg:col-span-3 lg:w-2/3 mx-auto' : ''}`}
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6 text-primary">
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-muted/50 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <motion.div {...fadeIn}>
                <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">Why It Matters</h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  Legacy systems force you to react to problems. Operion empowers you to anticipate them, turning operational complexity into a competitive advantage.
                </p>
                
                <div className="space-y-6">
                  {[
                    { title: "Reduce operational costs", desc: "Eliminate inefficient scheduling and compliance penalties." },
                    { title: "Improve crew utilization", desc: "Ensure the right people are deployed at the right time." },
                    { title: "Handle disruptions faster", desc: "Recover from delays in minutes, not hours." },
                    { title: "Make data-driven decisions", desc: "Replace guesswork with AI-powered recommendations." },
                    { title: "Gain full visibility", desc: "See your entire global operation on a single pane of glass." }
                  ].map((item, i) => (
                    <motion.div 
                      key={i} 
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: i * 0.1 }}
                      viewport={{ once: true }}
                      className="flex items-start gap-4"
                    >
                      <div className="mt-1 bg-primary/10 p-1 rounded-full">
                        <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-foreground">{item.title}</h4>
                        <p className="text-muted-foreground">{item.desc}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
              
              <motion.div 
                {...fadeIn}
                className="relative rounded-2xl overflow-hidden shadow-2xl aspect-square lg:aspect-auto lg:h-[600px] bg-secondary"
              >
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/20 via-secondary to-secondary"></div>
                <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
                  <Compass className="w-24 h-24 text-primary/50 mb-8 animate-[spin_20s_linear_infinite]" />
                  <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Navigate Complexity</h3>
                  <p className="text-white/70 max-w-md">
                    Experience the platform that brings order to the chaos of global crew logistics.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div {...fadeIn}>
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-6">
                <MousePointerClick className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">How to Use the Demo</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Select your industry below to enter the interactive environment. Navigate through the modules using the sidebar or bottom navigation. Click on alerts, crew members, and vessels/flights to see how data flows seamlessly across the platform.
              </p>
            </motion.div>
          </div>
        </section>

        <section id="demo-selection" className="py-20 md:py-28 bg-muted/30 scroll-mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div {...fadeIn} className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-6 text-balance">Select Your Mission</h2>
              <p className="text-lg text-muted-foreground">
                Choose the environment that matches your operational focus.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="group relative rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 flex flex-col min-h-[500px] lg:min-h-[600px]"
              >
                <div className="absolute inset-0 z-0">
                  <img 
                    src="https://images.unsplash.com/photo-1555274397-1b4e1986ce03" 
                    alt="Maritime Operations" 
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-secondary via-secondary/80 to-secondary/30"></div>
                </div>
                
                <div className="relative z-10 flex flex-col h-full p-8 md:p-12">
                  <div className="mb-auto">
                    <div className="w-16 h-16 rounded-2xl bg-primary/20 backdrop-blur-md flex items-center justify-center mb-8 border border-primary/30">
                      <Ship className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">Maritime Demo</h3>
                    <p className="text-lg text-white/80 leading-relaxed max-w-md">
                      Explore vessel operations, crew rotations, compliance tracking, and AI-powered disruption management tailored for maritime operations.
                    </p>
                  </div>
                  
                  <div className="mt-8 pt-8 border-t border-white/20">
                    <Button asChild size="lg" className="w-full sm:w-auto h-14 px-8 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg group-hover:shadow-primary/25 transition-all duration-300">
                      <Link to="/demo/maritime">
                        Launch Maritime Demo
                        <ArrowRight className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="group relative rounded-3xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 flex flex-col min-h-[500px] lg:min-h-[600px]"
              >
                <div className="absolute inset-0 z-0">
                  <img 
                    src="https://images.unsplash.com/photo-1688413399578-14ebdde3666a" 
                    alt="Aviation Operations" 
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-secondary via-secondary/80 to-secondary/30"></div>
                </div>
                
                <div className="relative z-10 flex flex-col h-full p-8 md:p-12">
                  <div className="mb-auto">
                    <div className="w-16 h-16 rounded-2xl bg-primary/20 backdrop-blur-md flex items-center justify-center mb-8 border border-primary/30">
                      <Plane className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">Aviation Demo</h3>
                    <p className="text-lg text-white/80 leading-relaxed max-w-md">
                      Discover crew scheduling, compliance automation, and disruption management designed specifically for complex airline operations.
                    </p>
                  </div>
                  
                  <div className="mt-8 pt-8 border-t border-white/20">
                    <Button asChild size="lg" className="w-full sm:w-auto h-14 px-8 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg group-hover:shadow-primary/25 transition-all duration-300">
                      <Link to="/demo/aviation">
                        Launch Aviation Demo
                        <ArrowRight className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default MissionControlPage;