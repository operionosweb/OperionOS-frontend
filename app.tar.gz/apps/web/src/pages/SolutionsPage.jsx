import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Calendar, CheckCircle, Network, AlertTriangle, BarChart3, 
  FileText, CheckCircle2, Activity, Zap, Shield, 
  Lock, Eye, TrendingUp, ArrowRight, ArrowUpRight 
} from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import SEOHead from '@/components/SEOHead.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';

const SolutionsPage = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <SEOHead 
        title="Solutions | Operion"
        description="Explore Operion's suite of operational tools for crew planning, compliance, coordination, and real-time control."
        keywords="crew operations, crew planning, compliance management, crew coordination, operational control"
      />
      
      <Header />

      <main className="flex-grow pt-20">
        
        {/* HERO SECTION */}
        <section 
          className="header-hero"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1639313521811-fdfb1c040ddb)' }}
        >
          <div className="header-overlay"></div>
          <div className="header-content text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center rounded-full border border-primary/40 bg-primary/20 px-4 py-1.5 text-sm font-bold text-primary-foreground mb-8 uppercase tracking-wider backdrop-blur-sm">
                Operion OS
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-7xl font-extrabold mb-6 text-balance max-w-5xl mx-auto text-white">
                Our Solutions
              </h1>
              <p className="text-lg md:text-xl text-slate-200 max-w-3xl mx-auto leading-relaxed">
                Explore Operion's suite of operational tools designed to plan, coordinate, and optimize global crew movements—while integrating seamlessly with external providers for execution.
              </p>
            </motion.div>
          </div>
        </section>

        {/* SECTION 1 — SOLUTIONS OVERVIEW */}
        <section className="py-20 bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">Complete Crew Operations Management</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Operion provides a modular set of solutions that cover the full lifecycle of crew operations—from planning and compliance to execution and real-time control. Whether managing a handful of specialized offshore rotations or a global aviation network, our platform adapts to your operational scale.
            </p>
          </div>
        </section>

        {/* SECTION 2 — CORE SOLUTIONS (Bento Grid 3 top, 2 bottom) */}
        <section className="py-24 bg-muted/40 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16 md:text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Our Core Solutions</h2>
              <p className="text-lg text-muted-foreground max-w-2xl md:mx-auto">
                Modular tools for every stage of crew operations.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
              {/* Card 1: 2 cols */}
              <Card className="lg:col-span-2 border border-border shadow-sm hover:shadow-md transition-all h-full bg-card">
                <CardContent className="p-8 flex flex-col h-full">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                    <Calendar className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Crew Planning & Rotations</h3>
                  <p className="text-muted-foreground leading-relaxed mt-auto">
                    Plan and manage crew schedules, rotations, and assignments across global operations with full visibility. Operion handles complex multi-week rotations, crew availability constraints, and platform staffing requirements.
                  </p>
                </CardContent>
              </Card>

              {/* Card 2: 2 cols */}
              <Card className="lg:col-span-2 border border-border shadow-sm hover:shadow-md transition-all h-full bg-card">
                <CardContent className="p-8 flex flex-col h-full">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Compliance & Documentation</h3>
                  <p className="text-muted-foreground leading-relaxed mt-auto">
                    Track certifications, visas, medical clearances, and regulatory requirements to ensure every crew member is compliant before deployment. Automated compliance checks prevent violations and reduce operational risk.
                  </p>
                </CardContent>
              </Card>

              {/* Card 3: 2 cols */}
              <Card className="lg:col-span-2 border border-border shadow-sm hover:shadow-md transition-all h-full bg-card">
                <CardContent className="p-8 flex flex-col h-full">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-6">
                    <Network className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3">Crew Movement Coordination</h3>
                  <p className="text-muted-foreground leading-relaxed mt-auto">
                    Coordinate crew movements through integrated external providers while maintaining full operational control and visibility. Operion orchestrates with travel companies, airlines, and logistics providers without replacing them.
                  </p>
                </CardContent>
              </Card>

              {/* Card 4: 3 cols (spans half the bottom row) */}
              <Card className="lg:col-span-3 border border-border shadow-sm hover:shadow-md transition-all h-full bg-card">
                <CardContent className="p-8 flex flex-col sm:flex-row gap-6 items-start h-full">
                  <div className="shrink-0 w-14 h-14 rounded-xl bg-destructive/10 text-destructive flex items-center justify-center">
                    <AlertTriangle className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-3">Disruption Management</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Respond to delays, cancellations, and operational changes with real-time adjustments and automated alerts. Operion identifies disruptions, alerts operations teams, and coordinates alternative plans with providers.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Card 5: 3 cols (spans half the bottom row) */}
              <Card className="lg:col-span-3 border border-border shadow-sm hover:shadow-md transition-all h-full bg-card">
                <CardContent className="p-8 flex flex-col sm:flex-row gap-6 items-start h-full">
                  <div className="shrink-0 w-14 h-14 rounded-xl bg-secondary/10 text-secondary flex items-center justify-center">
                    <BarChart3 className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-3">Operational Control Tower</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Monitor all crew operations from a centralized dashboard with real-time status updates and performance insights. Get complete visibility into crew movements, compliance status, and operational metrics.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* SECTION 3 — HOW IT WORKS */}
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">The Operion Workflow</h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Four steps to optimized crew operations.
              </p>
            </div>

            <div className="relative max-w-5xl mx-auto">
              {/* Connecting line for desktop */}
              <div className="hidden lg:block absolute top-[44px] left-[10%] right-[10%] h-0.5 bg-border z-0"></div>
              
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-10 relative z-10">
                {[
                  {
                    icon: FileText,
                    step: "STEP 1",
                    title: "Plan Crew Operations",
                    description: "Create crew schedules, rotations, and assignments based on operational requirements, crew availability, and platform needs."
                  },
                  {
                    icon: CheckCircle2,
                    step: "STEP 2",
                    title: "Validate Compliance and Constraints",
                    description: "Automated checks verify certifications, medical clearances, rest periods, and regulatory requirements before crew deployment."
                  },
                  {
                    icon: Network,
                    step: "STEP 3",
                    title: "Coordinate Execution via External Providers",
                    description: "Operion sends execution requests to travel and logistics providers. Providers handle transportation and logistics while Operion maintains operational control."
                  },
                  {
                    icon: Activity,
                    step: "STEP 4",
                    title: "Monitor and Optimize in Real Time",
                    description: "Track crew movements, monitor execution status, and respond to disruptions with real-time adjustments and alerts."
                  }
                ].map((item, i) => (
                  <div key={i} className="flex flex-col items-center text-center lg:items-start lg:text-left group">
                    <div className="w-20 h-20 bg-card border-2 border-border group-hover:border-primary rounded-2xl flex items-center justify-center mb-6 shadow-sm transition-colors relative">
                      <div className="absolute -top-3 -right-3 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm shadow-md">
                        {i + 1}
                      </div>
                      <item.icon className="w-8 h-8 text-primary" />
                    </div>
                    <div className="text-xs font-bold tracking-wider text-primary mb-2 uppercase">{item.step}</div>
                    <h3 className="text-lg font-bold mb-3">{item.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 4 — KEY BENEFITS (Bento Grid 2 top, 3 bottom) */}
        <section className="py-24 bg-muted/40 border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16 md:text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Why Choose Operion</h2>
              <p className="text-lg text-muted-foreground max-w-2xl md:mx-auto">
                Measurable operational improvements.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
              {/* Card 1: 6 cols (half width) */}
              <Card className="lg:col-span-6 border border-border shadow-sm hover:shadow-md transition-all bg-card">
                <CardContent className="p-8 flex items-start gap-5">
                  <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Increased Operational Efficiency</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Automated planning and coordination reduce manual work and operational overhead. Operion optimizes crew utilization and minimizes idle time.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Card 2: 6 cols (half width) */}
              <Card className="lg:col-span-6 border border-border shadow-sm hover:shadow-md transition-all bg-card">
                <CardContent className="p-8 flex items-start gap-5">
                  <div className="shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <Shield className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Reduced Disruption Impact</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      Real-time monitoring and automated alerts enable rapid response to disruptions. Operion coordinates alternative plans with providers to minimize operational impact.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Card 3: 4 cols (one third width) */}
              <Card className="lg:col-span-4 border border-border shadow-sm hover:shadow-md transition-all bg-card">
                <CardContent className="p-8">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-5">
                    <Lock className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Improved Compliance and Safety</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Centralized compliance tracking and automated checks ensure regulatory adherence. Operion prevents violations and maintains crew safety standards.
                  </p>
                </CardContent>
              </Card>

              {/* Card 4: 4 cols (one third width) */}
              <Card className="lg:col-span-4 border border-border shadow-sm hover:shadow-md transition-all bg-card">
                <CardContent className="p-8">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-5">
                    <Eye className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Full Visibility Across Crew Operations</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Real-time dashboards provide complete visibility into crew status, movement progress, and operational metrics. Make informed decisions with centralized data.
                  </p>
                </CardContent>
              </Card>

              {/* Card 5: 4 cols (one third width) */}
              <Card className="lg:col-span-4 border border-border shadow-sm hover:shadow-md transition-all bg-card">
                <CardContent className="p-8">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-5">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Better Decision-Making Through Centralized Data</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    All crew operations data flows into one platform. Operion provides insights and analytics to support strategic decision-making and operational optimization.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* SECTION 5 — INTEGRATION NOTE */}
        <section className="py-24 bg-background">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-secondary text-secondary-foreground rounded-3xl p-8 md:p-12 shadow-lg border border-secondary-foreground/10 flex flex-col md:flex-row items-center gap-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-16 opacity-5 pointer-events-none">
                <Network className="w-64 h-64" />
              </div>
              <div className="shrink-0 z-10">
                <div className="w-20 h-20 bg-background/10 backdrop-blur-sm border border-secondary-foreground/20 rounded-2xl flex items-center justify-center">
                  <Network className="w-10 h-10 text-primary" />
                </div>
              </div>
              <div className="z-10">
                <h2 className="text-2xl md:text-3xl font-bold mb-4">How Operion Integrates With Your Operations</h2>
                <p className="text-lg text-secondary-foreground/80 leading-relaxed mb-6">
                  Operion is not a travel booking platform. It integrates with external travel and logistics providers to execute crew movements, while keeping operational control centralized. Your existing provider relationships remain unchanged. Operion orchestrates operations around them, giving you visibility and control without disruption.
                </p>
                <Button asChild variant="link" className="text-primary hover:text-primary/80 p-0 h-auto font-bold text-base">
                  <Link to="/providers" className="flex items-center">
                    Learn about Provider Integration <ArrowUpRight className="w-4 h-4 ml-1" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 6 — CALL TO ACTION */}
        <section className="py-24 bg-primary text-primary-foreground text-center">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Ready to Transform Your Crew Operations?
            </h2>
            <p className="text-xl text-primary-foreground/90 mb-10 leading-relaxed max-w-2xl mx-auto">
              See how Operion can improve planning, compliance, and operational visibility.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button asChild size="lg" className="bg-background text-foreground hover:bg-background/90 rounded-full px-8 text-lg h-14 font-bold shadow-xl transition-all hover:scale-105">
                <Link to="/platform">Explore the Platform</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent border-2 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 rounded-full px-8 text-lg h-14 font-bold transition-colors">
                <Link to="/contact-sales">Request a Demo</Link>
              </Button>
            </div>
          </div>
        </section>

      </main>

      <Footer />
    </div>
  );
};

export default SolutionsPage;