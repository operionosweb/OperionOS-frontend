import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useSearchParams } from 'react-router-dom';
import { Calculator, Save, RefreshCw, ArrowRight, Download, CheckCircle2 } from 'lucide-react';
import { useAviationData } from '@/contexts/AviationContextData.jsx';
import { formatCurrency } from '@/lib/formatters.js';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import { toast } from 'sonner';

import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts';

const ScenarioSimulator = () => {
  const [searchParams] = useSearchParams();
  const initialAircraftId = searchParams.get('aircraft');
  
  const isMobile = useIsMobile();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { getAircraftList, getContractList, saveScenario, getSavedScenarios } = useAviationData();
  
  const aircraftList = getAircraftList();
  const contracts = getContractList();

  // State
  const [selectedAircraftId, setSelectedAircraftId] = useState(initialAircraftId || aircraftList[0]?.aircraftId || '');
  const [scenarioType, setScenarioType] = useState('extend'); // extend, return, replace
  
  // Parameters
  const [extensionYears, setExtensionYears] = useState(3);
  const [newLeaseCost, setNewLeaseCost] = useState(0);
  const [newMaintCost, setNewMaintCost] = useState(0);
  const [penaltyPercent, setPenaltyPercent] = useState(100);
  const [replacementType, setReplacementType] = useState('B787');

  const selectedAircraft = aircraftList.find(a => a.aircraftId === selectedAircraftId);
  const selectedContract = contracts.find(c => c.aircraftId === selectedAircraftId);

  // Initialize defaults when aircraft changes
  useEffect(() => {
    if (selectedAircraft) {
      setNewLeaseCost(selectedAircraft.monthlyCost * 0.9); // Assume 10% discount on extension
      setNewMaintCost(selectedAircraft.monthlyCost * 0.2); // Assume higher maint on older plane
    }
  }, [selectedAircraftId, selectedAircraft]);

  if (!selectedAircraft || !selectedContract) return null;

  // Calculations
  const currentMonthly = selectedAircraft.monthlyCost + (selectedAircraft.monthlyCost * 0.15);
  const currentAnnual = currentMonthly * 12;
  
  let newMonthly = 0;
  let oneTimeCost = 0;
  let comparisonYears = extensionYears;

  if (scenarioType === 'extend') {
    newMonthly = newLeaseCost + newMaintCost;
  } else if (scenarioType === 'return') {
    oneTimeCost = selectedContract.penaltyClause * (penaltyPercent / 100);
    newMonthly = 0;
    comparisonYears = 1; // Compare over 1 year for return
  } else if (scenarioType === 'replace') {
    newMonthly = newLeaseCost + newMaintCost;
    oneTimeCost = selectedContract.penaltyClause * (penaltyPercent / 100);
  }

  const currentTotalPeriod = currentAnnual * comparisonYears;
  const newTotalPeriod = (newMonthly * 12 * comparisonYears) + oneTimeCost;
  const savings = currentTotalPeriod - newTotalPeriod;
  const savingsPercent = (savings / currentTotalPeriod) * 100;

  const chartData = [
    { name: 'Current Trajectory', cost: currentTotalPeriod, fill: 'hsl(var(--muted-foreground))' },
    { name: 'Proposed Scenario', cost: newTotalPeriod, fill: savings > 0 ? 'hsl(var(--primary))' : 'hsl(var(--destructive))' }
  ];

  const handleSave = () => {
    saveScenario({
      aircraftId: selectedAircraftId,
      type: scenarioType,
      savings,
      date: new Date().toISOString()
    });
    toast.success('Scenario saved successfully');
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Helmet><title>Scenario Simulator | Operion Aviation</title></Helmet>
      <LeftSidebar industry="aviation" isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} isMobile={isMobile} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <DemoHeader isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
        
        <main className="flex-1 overflow-y-auto bg-muted/10">
          <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                  <Calculator className="w-6 h-6 text-primary" /> Scenario Simulator
                </h1>
                <p className="text-muted-foreground mt-1">Model lease extensions, early returns, and replacements.</p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" onClick={() => {
                  setScenarioType('extend');
                  setExtensionYears(3);
                  setNewLeaseCost(selectedAircraft.monthlyCost * 0.9);
                }}>
                  <RefreshCw className="w-4 h-4 mr-2" /> Reset
                </Button>
                <Button onClick={handleSave} className="bg-primary text-primary-foreground">
                  <Save className="w-4 h-4 mr-2" /> Save Scenario
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Inputs Column */}
              <div className="lg:col-span-4 space-y-6">
                <Card className="border-border shadow-sm">
                  <CardHeader className="pb-4 border-b border-border/50">
                    <CardTitle className="text-lg">Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4 space-y-6">
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Target Aircraft</label>
                      <Select value={selectedAircraftId} onValueChange={setSelectedAircraftId}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {aircraftList.map(a => (
                            <SelectItem key={a.aircraftId} value={a.aircraftId}>{a.aircraftId} ({a.type})</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Scenario Type</label>
                      <Select value={scenarioType} onValueChange={setScenarioType}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="extend">Extend Lease</SelectItem>
                          <SelectItem value="return">Early Return</SelectItem>
                          <SelectItem value="replace">Replace Aircraft</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="pt-4 border-t border-border/50 space-y-6">
                      {(scenarioType === 'extend' || scenarioType === 'replace') && (
                        <>
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <label className="text-sm font-medium">Duration (Years)</label>
                              <span className="text-sm font-bold text-primary">{extensionYears}</span>
                            </div>
                            <Slider value={[extensionYears]} onValueChange={v => setExtensionYears(v[0])} min={1} max={10} step={1} />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">New Base Lease (Monthly)</label>
                            <Input type="number" value={newLeaseCost} onChange={e => setNewLeaseCost(Number(e.target.value))} />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Est. Maintenance (Monthly)</label>
                            <Input type="number" value={newMaintCost} onChange={e => setNewMaintCost(Number(e.target.value))} />
                          </div>
                        </>
                      )}

                      {(scenarioType === 'return' || scenarioType === 'replace') && (
                        <>
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <label className="text-sm font-medium">Penalty Negotiation (%)</label>
                              <span className="text-sm font-bold text-destructive">{penaltyPercent}%</span>
                            </div>
                            <Slider value={[penaltyPercent]} onValueChange={v => setPenaltyPercent(v[0])} min={0} max={100} step={5} />
                            <p className="text-xs text-muted-foreground">Base penalty: {formatCurrency(selectedContract.penaltyClause)}</p>
                          </div>
                        </>
                      )}

                      {scenarioType === 'replace' && (
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Replacement Type</label>
                          <Select value={replacementType} onValueChange={setReplacementType}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="B737">B737 MAX</SelectItem>
                              <SelectItem value="B787">B787-9</SelectItem>
                              <SelectItem value="A320">A320neo</SelectItem>
                              <SelectItem value="A350">A350-900</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>

                  </CardContent>
                </Card>
              </div>

              {/* Outputs Column */}
              <div className="lg:col-span-8 space-y-6">
                
                {/* Metrics */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Card className="border-border shadow-sm bg-card">
                    <CardContent className="p-5">
                      <p className="text-sm font-medium text-muted-foreground mb-1">Net Impact ({comparisonYears} Yr)</p>
                      <p className={`text-3xl font-extrabold ${savings > 0 ? 'text-emerald-500' : 'text-destructive'}`}>
                        {savings > 0 ? '+' : ''}{formatCurrency(savings)}
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-border shadow-sm bg-card">
                    <CardContent className="p-5">
                      <p className="text-sm font-medium text-muted-foreground mb-1">Efficiency Change</p>
                      <p className={`text-3xl font-extrabold ${savingsPercent > 0 ? 'text-emerald-500' : 'text-destructive'}`}>
                        {savingsPercent > 0 ? '+' : ''}{savingsPercent.toFixed(1)}%
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="border-border shadow-sm bg-card">
                    <CardContent className="p-5">
                      <p className="text-sm font-medium text-muted-foreground mb-1">One-Time Costs</p>
                      <p className="text-3xl font-extrabold text-foreground">{formatCurrency(oneTimeCost)}</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Comparison Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="border-border shadow-sm bg-muted/30">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base text-muted-foreground">Current Trajectory</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-xs text-muted-foreground uppercase">Monthly Total</p>
                        <p className="text-xl font-bold">{formatCurrency(currentMonthly)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground uppercase">Annual Total</p>
                        <p className="text-xl font-bold">{formatCurrency(currentAnnual)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground uppercase">End Date</p>
                        <p className="text-base font-medium">{selectedContract.endDate}</p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-primary/20 shadow-sm bg-primary/5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-10"><ArrowRight className="w-16 h-16" /></div>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-base text-primary">Proposed Scenario</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 relative z-10">
                      <div>
                        <p className="text-xs text-primary/70 uppercase">New Monthly Total</p>
                        <p className="text-xl font-bold text-primary">{formatCurrency(newMonthly)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-primary/70 uppercase">New Annual Total</p>
                        <p className="text-xl font-bold text-primary">{formatCurrency(newMonthly * 12)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-primary/70 uppercase">Status</p>
                        <p className="text-base font-medium text-primary">
                          {scenarioType === 'extend' ? `Extended by ${extensionYears} yrs` : 
                           scenarioType === 'return' ? 'Returned Early' : 
                           `Replaced with ${replacementType}`}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Chart */}
                <Card className="border-border shadow-sm">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Total Cost Comparison ({comparisonYears} Year Period)</CardTitle>
                  </CardHeader>
                  <CardContent className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                        <YAxis tickFormatter={(val) => `€${(val/1000000).toFixed(1)}M`} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                        <Tooltip 
                          formatter={(value) => formatCurrency(value)}
                          contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', backgroundColor: 'hsl(var(--card))', color: 'hsl(var(--foreground))' }}
                        />
                        <Bar dataKey="cost" radius={[4, 4, 0, 0]}>
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

              </div>
            </div>

          </div>
        </main>
      </div>
      {isMobile && <BottomNavigation />}
    </div>
  );
};

export default ScenarioSimulator;