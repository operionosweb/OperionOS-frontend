import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  AlertTriangle, Clock, MapPin, Users, Ship, TrendingDown, 
  Activity, ShieldAlert, ChevronRight, Search, Filter, 
  ArrowUpDown, CheckCircle2, Zap, BarChart3, PieChart as PieChartIcon
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, CartesianGrid 
} from 'recharts';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';

import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import BottomNavigation from '@/components/demo/BottomNavigation.jsx';
import { DemoStateProvider } from '@/contexts/DemoStateContext.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

import LiveGlobalDisruptionMap from '@/components/demo/LiveGlobalDisruptionMap.jsx';
import DisruptionDetailModal from '@/components/demo/DisruptionDetailModal.jsx';
import StrategyConfirmationModal from '@/components/demo/StrategyConfirmationModal.jsx';

// --- MOCK DATA ---
const MOCK_ALERTS = [
  { id: 'A1', title: 'Port Congestion - Rotterdam', desc: 'Severe congestion causing 14h delays for inbound vessels.', severity: 'Critical', time: '10 mins ago', vessel: 'Atlantic Sentinel', crew: 24, impact: '$42k', status: 'Active', type: 'Port' },
  { id: 'A2', title: 'Weather Warning - Singapore Strait', desc: 'Typhoon approaching. Rerouting recommended.', severity: 'High', time: '1 hour ago', vessel: 'Pacific Voyager', crew: 18, impact: '$15k', status: 'Monitoring', type: 'Weather' },
  { id: 'A3', title: 'Crew Medical Emergency', desc: 'Chief Engineer requires immediate medevac.', severity: 'Critical', time: '2 hours ago', vessel: 'CMA CGM Orpheus', crew: 1, impact: '$28k', status: 'Action Required', type: 'Crew' },
  { id: 'A4', title: 'Engine Maintenance Delay', desc: 'Unexpected part replacement needed.', severity: 'Medium', time: '5 hours ago', vessel: 'Global Mariner', crew: 12, impact: '$8k', status: 'Active', type: 'Maintenance' },
  { id: 'A5', title: 'Customs Clearance Hold', desc: 'Documentation error delaying cargo discharge.', severity: 'Low', time: '1 day ago', vessel: 'Desert Star', crew: 0, impact: '$2k', status: 'Resolved', type: 'Admin' },
];

const MOCK_VESSELS = [
  { id: 'V1', name: 'Atlantic Sentinel', type: 'Container', location: 'Rotterdam Approach', status: 'Delayed', disruptions: 2, impact: 'High' },
  { id: 'V2', name: 'Pacific Voyager', type: 'Bulk Carrier', location: 'South China Sea', status: 'Rerouting', disruptions: 1, impact: 'Medium' },
  { id: 'V3', name: 'CMA CGM Orpheus', type: 'Container', location: 'Gulf of Mexico', status: 'Critical', disruptions: 3, impact: 'Critical' },
  { id: 'V4', name: 'Global Mariner', type: 'Tanker', location: 'Tokyo Bay', status: 'Maintenance', disruptions: 1, impact: 'Low' },
];

const MOCK_CREW = [
  { id: 'C1', name: 'Marcus Chen', role: 'Chief Engineer', vessel: 'CMA CGM Orpheus', status: 'Medical Leave', disruptions: 2, impact: 'High' },
  { id: 'C2', name: 'Sarah Jenkins', role: 'Captain', vessel: 'Atlantic Sentinel', status: 'Active', disruptions: 1, impact: 'Medium' },
  { id: 'C3', name: 'Raj Patel', role: 'First Officer', vessel: 'Pacific Voyager', status: 'Active', disruptions: 1, impact: 'Low' },
  { id: 'C4', name: 'Elena Rostova', role: 'Able Seaman', vessel: 'Global Mariner', status: 'Delayed Transit', disruptions: 3, impact: 'High' },
  { id: 'C5', name: 'David Kim', role: 'Cook', vessel: 'Desert Star', status: 'Active', disruptions: 0, impact: 'None' },
];

const MOCK_TIMELINE = [
  { id: 'T1', type: 'Disruption Triggered', time: '10:00 AM', desc: 'Port congestion reported at Rotterdam.', vessel: 'Atlantic Sentinel', status: 'Critical' },
  { id: 'T2', type: 'AI Analysis', time: '10:05 AM', desc: 'Impact calculated: 14h delay, $42k cost.', vessel: 'Atlantic Sentinel', status: 'Info' },
  { id: 'T3', type: 'Recommendation Generated', time: '10:06 AM', desc: 'Speed reduction recommended to save fuel.', vessel: 'Atlantic Sentinel', status: 'Action Required' },
  { id: 'T4', type: 'Schedule Adjusted', time: '11:30 AM', desc: 'ETA updated for downstream ports.', vessel: 'Pacific Voyager', status: 'Resolved' },
  { id: 'T5', type: 'Crew Reassigned', time: '01:15 PM', desc: 'Standby engineer deployed to Houston.', vessel: 'CMA CGM Orpheus', status: 'Resolved' },
  { id: 'T6', type: 'Disruption Triggered', time: '02:00 PM', desc: 'Typhoon warning issued.', vessel: 'Pacific Voyager', status: 'High' },
  { id: 'T7', type: 'Route Optimization', time: '02:15 PM', desc: 'New waypoint coordinates sent to ECDIS.', vessel: 'Pacific Voyager', status: 'Resolved' },
  { id: 'T8', type: 'Resolved', time: '04:00 PM', desc: 'Customs hold cleared.', vessel: 'Desert Star', status: 'Resolved' },
];

const MOCK_RECOMMENDATIONS = [
  { id: 'R1', title: 'Reduce Speed to 12kts', desc: 'Align arrival with berth availability to save fuel.', impact: '+$12k Savings', vessels: 1, confidence: 'High' },
  { id: 'R2', title: 'Reroute via Sunda Strait', desc: 'Avoid typhoon path. Adds 4h but ensures safety.', impact: 'Risk Mitigated', vessels: 1, confidence: 'High' },
  { id: 'R3', title: 'Deploy Standby Crew', desc: 'Fly reserve engineer from Miami to Houston.', impact: '-12h Delay', vessels: 1, confidence: 'Medium' },
  { id: 'R4', title: 'Bypass Port Call', desc: 'Skip congested port and discharge at alternate hub.', impact: '-24h Delay', vessels: 2, confidence: 'Low' },
];

const CHART_COLORS = ['hsl(var(--primary))', 'hsl(var(--teal))', 'hsl(var(--warning))', 'hsl(var(--critical))'];

// --- HELPER COMPONENTS ---
const SeverityBadge = ({ severity }) => {
  const colors = {
    Critical: 'bg-[hsl(var(--critical))]/10 text-[hsl(var(--critical))] border-[hsl(var(--critical))]/20',
    High: 'bg-[hsl(var(--warning))]/10 text-[hsl(var(--warning))] border-[hsl(var(--warning))]/20',
    Medium: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    Low: 'bg-[hsl(var(--teal))]/10 text-[hsl(var(--teal))] border-[hsl(var(--teal))]/20',
  };
  return (
    <Badge variant="outline" className={`${colors[severity] || 'bg-muted'} font-bold tracking-wider text-[10px] uppercase`}>
      {severity}
    </Badge>
  );
};

const DisruptionsPage = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  // State
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [strategyModalOpen, setStrategyModalOpen] = useState(false);
  const [selectedStrategy, setSelectedStrategy] = useState('');
  
  // Filters
  const [alertSearch, setAlertSearch] = useState('');
  const [alertSeverity, setAlertSeverity] = useState('All');

  // Handlers
  const handleSelectIncident = (incident) => setSelectedIncident(incident);
  const handleApplyStrategy = (strategyName) => {
    setSelectedStrategy(strategyName);
    setStrategyModalOpen(true);
  };
  const handleStrategyConfirmed = () => {
    setStrategyModalOpen(false);
    setSelectedIncident(null);
  };

  // Filtered Data
  const filteredAlerts = useMemo(() => {
    return MOCK_ALERTS.filter(a => {
      const matchesSearch = a.title.toLowerCase().includes(alertSearch.toLowerCase()) || a.desc.toLowerCase().includes(alertSearch.toLowerCase());
      const matchesSeverity = alertSeverity === 'All' || a.severity === alertSeverity;
      return matchesSearch && matchesSeverity;
    });
  }, [alertSearch, alertSeverity]);

  return (
    <DemoStateProvider>
      <Helmet>
        <title>Disruption Control | Operion Maritime</title>
      </Helmet>

      <div className="flex h-screen bg-background overflow-hidden">
        <LeftSidebar 
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          isMobile={isMobile}
        />
        
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <DemoHeader 
            isMobileMenuOpen={isMobileMenuOpen}
            setIsMobileMenuOpen={setIsMobileMenuOpen}
          />
          
          <main className="flex-1 overflow-y-auto pb-16 md:pb-0">
            <div className="min-h-full bg-background pb-20">
              {/* Header */}
              <header className="bg-card border-b border-border relative z-30">
                <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                      <span>Mission Control</span>
                      <ChevronRight className="w-3 h-3" />
                      <span className="text-foreground font-medium">Disruptions</span>
                    </div>
                    <h1 className="text-xl sm:text-2xl font-bold tracking-tight leading-none">Disruptions Command Center</h1>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button variant="outline" className="hidden sm:flex touch-target">Export Report</Button>
                    <Button className="bg-primary text-primary-foreground touch-target">
                      <Zap className="w-4 h-4 mr-2" /> Auto-Resolve All
                    </Button>
                  </div>
                </div>
              </header>

              <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
                
                {/* Top Row: Map & Impact Metrics */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Global Map */}
                  <div className="lg:col-span-2 h-[400px] sm:h-[500px] lg:h-[600px] rounded-2xl overflow-hidden border border-border shadow-sm relative z-0">
                    <LiveGlobalDisruptionMap onMarkerClick={handleSelectIncident} />
                  </div>

                  {/* Impact Metrics */}
                  <div className="space-y-4 flex flex-col">
                    <h2 className="text-lg font-bold flex items-center gap-2">
                      <Activity className="w-5 h-5 text-primary" /> Live Impact Analysis
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 flex-1">
                      <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow cursor-pointer touch-target">
                        <p className="text-sm font-medium text-muted-foreground mb-1">Total Vessels Affected</p>
                        <div className="flex items-end justify-between">
                          <p className="text-3xl font-extrabold">12</p>
                          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">+3 Today</Badge>
                        </div>
                      </div>
                      <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow cursor-pointer touch-target">
                        <p className="text-sm font-medium text-muted-foreground mb-1">Total Crew Affected</p>
                        <div className="flex items-end justify-between">
                          <p className="text-3xl font-extrabold">48</p>
                          <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">+12 Today</Badge>
                        </div>
                      </div>
                      <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow cursor-pointer touch-target">
                        <p className="text-sm font-medium text-muted-foreground mb-1">Est. Revenue Loss</p>
                        <div className="flex items-end justify-between">
                          <p className="text-3xl font-extrabold text-[hsl(var(--critical))]">$142k</p>
                          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">+15%</Badge>
                        </div>
                      </div>
                      <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow cursor-pointer touch-target">
                        <p className="text-sm font-medium text-muted-foreground mb-1">Ops Efficiency Loss</p>
                        <div className="flex items-end justify-between">
                          <p className="text-3xl font-extrabold text-[hsl(var(--warning))]">8.4%</p>
                          <Badge variant="outline" className="bg-[hsl(var(--teal))]/10 text-[hsl(var(--teal))] border-[hsl(var(--teal))]/20">-2.1%</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Middle Row: Alerts & Recommendations */}
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                  {/* Alerts Section */}
                  <div className="xl:col-span-2 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <h2 className="text-lg font-bold flex items-center gap-2">
                        <ShieldAlert className="w-5 h-5 text-destructive" /> Active Disruption Alerts
                      </h2>
                      <div className="flex items-center gap-2">
                        <div className="relative flex-1 sm:w-64">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input 
                            placeholder="Search alerts..." 
                            className="pl-9 h-10 touch-target"
                            value={alertSearch}
                            onChange={(e) => setAlertSearch(e.target.value)}
                          />
                        </div>
                        <Select value={alertSeverity} onValueChange={setAlertSeverity}>
                          <SelectTrigger className="w-[130px] h-10 touch-target">
                            <SelectValue placeholder="Severity" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="All">All Severities</SelectItem>
                            <SelectItem value="Critical">Critical</SelectItem>
                            <SelectItem value="High">High</SelectItem>
                            <SelectItem value="Medium">Medium</SelectItem>
                            <SelectItem value="Low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <AnimatePresence>
                        {filteredAlerts.map((alert, idx) => (
                          <motion.div
                            key={alert.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            transition={{ delay: idx * 0.05 }}
                            onClick={() => handleSelectIncident(alert)}
                            className="bg-card border border-border rounded-2xl p-5 shadow-sm hover:shadow-lg hover:-translate-y-1 hover:border-primary/30 transition-all cursor-pointer touch-target flex flex-col"
                          >
                            <div className="flex justify-between items-start mb-3">
                              <SeverityBadge severity={alert.severity} />
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Clock className="w-3 h-3" /> {alert.time}
                              </span>
                            </div>
                            <h3 className="font-bold text-base mb-1 leading-tight">{alert.title}</h3>
                            <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">{alert.desc}</p>
                            
                            <div className="grid grid-cols-3 gap-2 pt-3 border-t border-border/50 text-center">
                              <div>
                                <p className="text-[10px] text-muted-foreground uppercase font-semibold">Vessel</p>
                                <p className="text-xs font-medium truncate px-1">{alert.vessel}</p>
                              </div>
                              <div className="border-x border-border/50">
                                <p className="text-[10px] text-muted-foreground uppercase font-semibold">Crew</p>
                                <p className="text-xs font-medium">{alert.crew}</p>
                              </div>
                              <div>
                                <p className="text-[10px] text-muted-foreground uppercase font-semibold">Impact</p>
                                <p className="text-xs font-bold text-[hsl(var(--critical))]">{alert.impact}</p>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </AnimatePresence>
                      {filteredAlerts.length === 0 && (
                        <div className="col-span-full py-12 text-center text-muted-foreground bg-muted/20 rounded-2xl border border-dashed border-border">
                          <CheckCircle2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                          <p>No alerts match your filters.</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Recommendations Section */}
                  <div className="space-y-4">
                    <h2 className="text-lg font-bold flex items-center gap-2">
                      <Zap className="w-5 h-5 text-[hsl(var(--warning))]" /> AI Recommendations
                    </h2>
                    <div className="space-y-3">
                      {MOCK_RECOMMENDATIONS.map((rec) => (
                        <div key={rec.id} className="bg-primary/5 border border-primary/20 rounded-xl p-4 hover:bg-primary/10 transition-colors cursor-pointer touch-target">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-bold text-sm text-foreground">{rec.title}</h4>
                            <Badge variant="secondary" className="text-[10px]">{rec.confidence} Conf.</Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mb-3">{rec.desc}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-[hsl(var(--teal))]">{rec.impact}</span>
                            <Button size="sm" className="h-7 text-xs" onClick={(e) => { e.stopPropagation(); handleApplyStrategy(rec.title); }}>
                              Apply
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Charts Section */}
                <div className="space-y-4">
                  <h2 className="text-lg font-bold flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-primary" /> Analytics & Trends
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-card border border-border rounded-2xl p-5 shadow-sm h-[300px] flex flex-col">
                      <h3 className="text-sm font-bold mb-4">Disruption Frequency by Type</h3>
                      <div className="flex-1 min-h-0">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie data={[
                              { name: 'Weather', value: 35 },
                              { name: 'Port', value: 45 },
                              { name: 'Crew', value: 15 },
                              { name: 'Maintenance', value: 5 }
                            ]} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                              {CHART_COLORS.map((color, index) => <Cell key={`cell-${index}`} fill={color} />)}
                            </Pie>
                            <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                    
                    <div className="bg-card border border-border rounded-2xl p-5 shadow-sm h-[300px] flex flex-col">
                      <h3 className="text-sm font-bold mb-4">Resolution Time Trend (Hours)</h3>
                      <div className="flex-1 min-h-0">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart data={[
                            { day: 'Mon', time: 12 }, { day: 'Tue', time: 10 }, { day: 'Wed', time: 14 },
                            { day: 'Thu', time: 8 }, { day: 'Fri', time: 6 }, { day: 'Sat', time: 5 }
                          ]}>
                            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                            <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                            <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                            <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }} />
                            <Line type="monotone" dataKey="time" stroke="hsl(var(--primary))" strokeWidth={3} dot={{ r: 4, fill: 'hsl(var(--primary))' }} />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Entities Tabs (Vessels, Crew, Timeline) */}
                <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
                  <Tabs defaultValue="vessels" className="w-full">
                    <div className="border-b border-border px-4 py-2 overflow-x-auto hide-scrollbar">
                      <TabsList className="bg-transparent h-12 p-0 gap-6 justify-start w-max">
                        <TabsTrigger value="vessels" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-2 h-12 touch-target">
                          <Ship className="w-4 h-4 mr-2" /> Affected Vessels
                        </TabsTrigger>
                        <TabsTrigger value="crew" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-2 h-12 touch-target">
                          <Users className="w-4 h-4 mr-2" /> Affected Crew
                        </TabsTrigger>
                        <TabsTrigger value="timeline" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-2 h-12 touch-target">
                          <Clock className="w-4 h-4 mr-2" /> Event Timeline
                        </TabsTrigger>
                      </TabsList>
                    </div>

                    <div className="p-4 sm:p-6">
                      <TabsContent value="vessels" className="mt-0 outline-none">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                          {MOCK_VESSELS.map(vessel => (
                            <div key={vessel.id} className="border border-border rounded-xl p-4 hover:border-primary/50 transition-colors cursor-pointer touch-target">
                              <div className="flex justify-between items-start mb-2">
                                <h4 className="font-bold text-sm">{vessel.name}</h4>
                                <Badge variant="outline" className="text-[10px]">{vessel.status}</Badge>
                              </div>
                              <p className="text-xs text-muted-foreground mb-3">{vessel.type} • {vessel.location}</p>
                              <div className="flex justify-between items-center text-xs">
                                <span className="font-medium text-muted-foreground">Disruptions: {vessel.disruptions}</span>
                                <span className={`font-bold ${vessel.impact === 'Critical' ? 'text-destructive' : 'text-foreground'}`}>
                                  {vessel.impact} Impact
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </TabsContent>

                      <TabsContent value="crew" className="mt-0 outline-none">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                          {MOCK_CREW.map(crew => (
                            <div key={crew.id} className="border border-border rounded-xl p-4 hover:border-primary/50 transition-colors cursor-pointer touch-target flex items-center gap-3">
                              <img src={`https://i.pravatar.cc/150?u=${crew.id}`} alt={crew.name} className="w-10 h-10 rounded-full border border-border" />
                              <div className="flex-1 min-w-0">
                                <h4 className="font-bold text-sm truncate">{crew.name}</h4>
                                <p className="text-[10px] text-muted-foreground truncate">{crew.role}</p>
                                <p className="text-[10px] font-medium text-primary truncate mt-0.5">{crew.status}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </TabsContent>

                      <TabsContent value="timeline" className="mt-0 outline-none">
                        <div className="space-y-4 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border before:to-transparent">
                          {MOCK_TIMELINE.map((event, idx) => (
                            <div key={event.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-background bg-muted text-muted-foreground shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                                {event.status === 'Resolved' ? <CheckCircle2 className="w-4 h-4 text-[hsl(var(--teal))]" /> : <Activity className="w-4 h-4" />}
                              </div>
                              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-border bg-card shadow-sm hover:shadow-md transition-shadow">
                                <div className="flex items-center justify-between mb-1">
                                  <span className="text-xs font-bold text-primary uppercase tracking-wider">{event.type}</span>
                                  <span className="text-xs text-muted-foreground">{event.time}</span>
                                </div>
                                <p className="text-sm text-foreground mb-2">{event.desc}</p>
                                <Badge variant="secondary" className="text-[10px]">{event.vessel}</Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </TabsContent>
                    </div>
                  </Tabs>
                </div>

              </div>
            </div>
          </main>
        </div>

        {isMobile && <BottomNavigation />}
      </div>

      {/* Modals */}
      <DisruptionDetailModal 
        isOpen={!!selectedIncident} 
        onClose={() => setSelectedIncident(null)} 
        incident={selectedIncident}
        onApplyStrategy={handleApplyStrategy}
      />

      <StrategyConfirmationModal 
        isOpen={strategyModalOpen}
        onClose={() => setStrategyModalOpen(false)}
        strategyName={selectedStrategy}
        onConfirm={handleStrategyConfirmed}
      />
    </DemoStateProvider>
  );
};

export default DisruptionsPage;