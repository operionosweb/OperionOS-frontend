import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useAviationFleet } from '@/contexts/AviationFleetContext.jsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { ArrowLeft, Plane, DollarSign, FileText, Calendar, Calculator, ChevronRight, Activity, AlertTriangle } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters.js';
import { calculateMonthsRemaining } from '@/lib/aviationFleetIntelligenceData.js';
import DemoHeader from '@/components/demo/DemoHeader.jsx';
import LeftSidebar from '@/components/demo/LeftSidebar.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

const AircraftDetailPageContent = () => {
  const { aircraftId } = useParams();
  const navigate = useNavigate();
  const { aircraft, contracts } = useAviationFleet();
  
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const ac = aircraft.find(a => a.aircraftId === aircraftId);
  const relatedContracts = contracts.filter(c => c.aircraftId === aircraftId);
  const activeContract = relatedContracts[0]; // Assuming first is active for demo

  if (!ac) return <div className="p-8 text-center flex items-center justify-center h-full">Aircraft not found.</div>;

  const monthsRemaining = calculateMonthsRemaining(ac.leaseEndDate);
  const totalMonths = activeContract ? calculateMonthsRemaining(activeContract.endDate) + calculateMonthsRemaining(activeContract.startDate) * -1 : 120;
  const elapsedMonths = totalMonths > 0 ? totalMonths - monthsRemaining : 0;
  const progressPercent = Math.min(100, Math.max(0, (elapsedMonths / totalMonths) * 100)) || 0;

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Helmet><title>{`Aircraft ${ac.aircraftId} | Operion Aviation`}</title></Helmet>

      <LeftSidebar industry="aviation" isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} isMobile={isMobile} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <DemoHeader isMobileMenuOpen={isMobileMenuOpen} setIsMobileMenuOpen={setIsMobileMenuOpen} />
        
        <main className="flex-1 overflow-y-auto bg-muted/10 p-4 md:p-6 lg:p-8">
          <div className="max-w-6xl mx-auto space-y-6">
            
            {/* Breadcrumbs */}
            <div className="flex items-center text-sm text-muted-foreground mb-4">
              <Link to="/demo/aviation/fleet" className="hover:text-foreground transition-colors">Fleet</Link>
              <ChevronRight className="w-4 h-4 mx-1" />
              <span className="text-foreground font-medium">{ac.aircraftId}</span>
            </div>

            {/* Header Block */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-card p-6 rounded-2xl border border-border shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
              <div className="flex items-center gap-4 relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border border-primary/20">
                  <Plane className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-3">
                    <h1 className="text-3xl font-bold tracking-tight">{ac.aircraftId}</h1>
                    <Badge variant="outline" className={monthsRemaining < 6 ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'}>
                      {ac.status}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground mt-1 text-sm font-medium">{ac.aircraftType} • {ac.leaseType} Lease • {ac.utilization}% Utilization</p>
                </div>
              </div>
              <div className="flex gap-2 w-full md:w-auto relative z-10">
                <Button variant="outline" className="flex-1 md:flex-none" onClick={() => navigate('/demo/aviation/contracts')}>
                  <FileText className="w-4 h-4 mr-2" /> Contracts
                </Button>
                <Button className="flex-1 md:flex-none bg-primary text-primary-foreground shadow-md hover:bg-primary/90 transition-all" onClick={() => navigate(`/demo/aviation/scenarios?aircraft=${ac.aircraftId}`)}>
                  <Calculator className="w-4 h-4 mr-2" /> Run Scenario
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Financial Exposure Block */}
              <div className="lg:col-span-2 space-y-6">
                <Card className="bg-card border-border shadow-sm">
                  <CardHeader className="pb-2 border-b border-border/50">
                    <CardTitle className="text-lg flex items-center gap-2"><DollarSign className="w-5 h-5 text-primary" /> Financial Exposure</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Monthly Rate</p>
                        <p className="text-xl font-bold text-foreground">{formatCurrency(ac.totalMonthlyCost)}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Cost per Flight Hr</p>
                        <p className="text-xl font-bold text-foreground">{formatCurrency(ac.costPerFlightHour)}</p>
                      </div>
                      <div className="space-y-1 col-span-2 md:col-span-2">
                        <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Remaining Liability</p>
                        <p className="text-2xl font-extrabold text-destructive">{formatCurrency(ac.remainingLiability)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Enhanced Timeline View */}
                <Card className="bg-card border-border shadow-sm">
                  <CardHeader className="pb-2 border-b border-border/50">
                    <CardTitle className="text-lg flex items-center gap-2"><Calendar className="w-5 h-5 text-amber-500" /> Lifecycle Timeline</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-8 pb-6">
                    <div className="relative">
                      <div className="h-3 bg-muted rounded-full overflow-hidden border border-border/50">
                        <div className="h-full bg-primary transition-all duration-1000 relative" style={{ width: `${progressPercent}%` }}>
                           <div className="absolute inset-0 bg-white/20 w-full h-full animate-pulse" />
                        </div>
                      </div>
                      
                      {/* Timeline Markers */}
                      <div className="absolute top-4 left-0 -translate-x-1/2 flex flex-col items-center">
                        <div className="w-1 h-3 bg-border mb-1" />
                        <span className="text-xs font-semibold">{activeContract ? activeContract.startDate : 'Start'}</span>
                        <span className="text-[10px] text-muted-foreground">Inception</span>
                      </div>
                      
                      <div className="absolute top-4 right-0 translate-x-1/2 flex flex-col items-center text-right">
                        <div className="w-1 h-3 bg-destructive/50 mb-1" />
                        <span className="text-xs font-semibold text-destructive">{ac.leaseEndDate}</span>
                        <span className="text-[10px] text-muted-foreground">Expiry</span>
                      </div>

                      {/* Current Position */}
                      <div className="absolute -top-3 -translate-x-1/2 flex flex-col items-center" style={{ left: `${progressPercent}%` }}>
                        <div className="bg-primary text-primary-foreground text-xs font-bold px-2 py-0.5 rounded shadow-sm mb-1 whitespace-nowrap">
                          {monthsRemaining} mo left
                        </div>
                        <div className="w-4 h-4 rounded-full bg-primary border-4 border-background shadow-md z-10" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Linked Contracts & Relationships */}
              <div className="space-y-6">
                <Card className="bg-card border-border shadow-sm h-full flex flex-col">
                  <CardHeader className="pb-2 border-b border-border/50">
                    <CardTitle className="text-lg flex items-center gap-2"><FileText className="w-5 h-5 text-secondary" /> Linked Contracts</CardTitle>
                    <CardDescription>Associated legal agreements</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4 flex-1 flex flex-col gap-3">
                    {relatedContracts.length > 0 ? relatedContracts.map(c => (
                      <div key={c.contractId} className="p-3 rounded-xl border border-border bg-muted/20 hover:bg-muted/50 transition-colors cursor-pointer" onClick={() => navigate('/demo/aviation/contracts')}>
                        <div className="flex justify-between items-start mb-2">
                          <span className="font-semibold text-sm">{c.contractId}</span>
                          <Badge variant="outline" className={c.riskScore > 70 ? 'text-destructive border-destructive/30' : 'text-primary border-primary/30'}>
                            {c.riskLevel} Risk
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground space-y-1">
                          <p>Lessor: {c.lessor}</p>
                          <p>Penalty: {formatCurrency(c.penaltyClause)}</p>
                        </div>
                      </div>
                    )) : (
                      <div className="text-sm text-muted-foreground flex items-center justify-center h-full py-8 text-center border border-dashed border-border rounded-xl">
                        No active contracts linked.
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>

          </div>
        </main>
      </div>
    </div>
  );
};

const AircraftDetailPage = () => <AircraftDetailPageContent />;

export default AircraftDetailPage;