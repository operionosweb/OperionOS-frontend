
export const FEATURE_FLAGS = {
  ENABLE_DEMO_DATA: true,
  ENABLE_SEARCH: true,
  ENABLE_FILTERS: true,
  ENABLE_SORT: true,
  ENABLE_PAGINATION: true,
  ENABLE_CHARTS: true,
  ENABLE_ACTIVITY_FEED: true,
  ENABLE_SYSTEM_LOGS: true
};

export const getFeatureFlag = (key) => {
  if (key === 'ENABLE_DEMO_DATA') {
    const stored = localStorage.getItem('ENABLE_DEMO_DATA');
    if (stored !== null) return stored === 'true';
  }
  return FEATURE_FLAGS[key];
};

export const setFeatureFlag = (key, value) => {
  if (key === 'ENABLE_DEMO_DATA') {
    localStorage.setItem('ENABLE_DEMO_DATA', String(value));
    window.dispatchEvent(new Event('feature_flags_updated'));
  }
};
