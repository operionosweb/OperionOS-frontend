
import { getFeatureFlag } from './featureFlags.js';

export const ENABLE_DEMO_DATA = getFeatureFlag('ENABLE_DEMO_DATA');

export const MOCK_DATA_CONFIG = {
  RECORD_COUNT: 30,
  ACTIVITY_COUNT: 10,
  DETERMINISTIC_SEED: 42
};
