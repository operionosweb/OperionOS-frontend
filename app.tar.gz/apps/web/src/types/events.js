
/**
 * Event Type Constants
 */
export const CONTRACT_UPDATED = 'CONTRACT_UPDATED';
export const FLEET_UPDATED = 'FLEET_UPDATED';
export const USER_UPDATED = 'USER_UPDATED';
export const ALERT_TRIGGERED = 'ALERT_TRIGGERED';
export const DATA_SYNC_STARTED = 'DATA_SYNC_STARTED';
export const DATA_SYNC_COMPLETED = 'DATA_SYNC_COMPLETED';

const VALID_EVENTS = [
  CONTRACT_UPDATED,
  FLEET_UPDATED,
  USER_UPDATED,
  ALERT_TRIGGERED,
  DATA_SYNC_STARTED,
  DATA_SYNC_COMPLETED
];

/**
 * @typedef {Object} EventPayload
 * @property {string} [contractId] - ID of the contract (if applicable)
 * @property {string} [fleetId] - ID of the fleet/vessel (if applicable)
 * @property {string} [userId] - ID of the user (if applicable)
 * @property {string} [alertId] - ID of the alert (if applicable)
 * @property {Object} [changes] - Object containing changed fields
 * @property {Object} [data] - Full data object
 * @property {number} timestamp - Unix timestamp of the event
 * @property {'poll'|'manual'|'system'} source - Source of the event
 */

/**
 * Validates an event payload based on its type.
 * @param {string} eventType 
 * @param {EventPayload} payload 
 * @returns {boolean}
 */
export function validateEventPayload(eventType, payload) {
  if (!VALID_EVENTS.includes(eventType)) {
    console.warn(`Invalid event type: ${eventType}`);
    return false;
  }
  
  if (!payload || typeof payload !== 'object') {
    console.warn('Payload must be an object');
    return false;
  }

  if (!payload.timestamp) {
    payload.timestamp = Date.now();
  }

  if (!payload.source) {
    payload.source = 'system';
  }

  return true;
}
