
import { useEffect, useRef } from 'react';
import { useEventContext } from '@/contexts/EventContext.jsx';
import { useAlert } from '@/contexts/AlertContext.jsx';
import { AlertDetectionEngine } from '@/lib/alertDetectionEngine.js';

export function useAlertDetection() {
  const { eventBus } = useEventContext();
  const { addAlert } = useAlert();
  const engineRef = useRef(null);

  useEffect(() => {
    if (!eventBus) return;

    if (!engineRef.current) {
      engineRef.current = new AlertDetectionEngine(eventBus);
    }

    const engine = engineRef.current;

    const handleContractUpdate = (payload) => engine.monitorContractUpdates(payload);
    const handleFleetUpdate = (payload) => engine.monitorFleetUpdates(payload);
    const handleUserUpdate = (payload) => engine.monitorUserUpdates(payload);
    const handleAlertCreated = (payload) => {
      if (payload?.alert) {
        addAlert(payload.alert);
      }
    };

    const unsubContract = eventBus.subscribe('CONTRACT_UPDATED', handleContractUpdate);
    const unsubFleet = eventBus.subscribe('FLEET_UPDATED', handleFleetUpdate);
    const unsubUser = eventBus.subscribe('USER_UPDATED', handleUserUpdate);
    const unsubAlertCreated = eventBus.subscribe('ALERT_CREATED', handleAlertCreated);

    return () => {
      unsubContract();
      unsubFleet();
      unsubUser();
      unsubAlertCreated();
    };
  }, [eventBus, addAlert]);

  return engineRef.current;
}
