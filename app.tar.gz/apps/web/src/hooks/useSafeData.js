
import { useState, useEffect } from 'react';
import { getMockData } from '@/lib/mockData/index.js';
import { getFeatureFlag } from '@/config/featureFlags.js';

export function useSafeData(realData, mockDataKey) {
  const [data, setData] = useState([]);

  useEffect(() => {
    const handleUpdate = () => {
      if (realData && realData.length > 0) {
        setData(realData);
      } else if (getFeatureFlag('ENABLE_DEMO_DATA')) {
        const mockData = getMockData();
        setData(mockData[mockDataKey] || []);
      } else {
        setData([]);
      }
    };

    handleUpdate();
    window.addEventListener('feature_flags_updated', handleUpdate);
    return () => window.removeEventListener('feature_flags_updated', handleUpdate);
  }, [realData, mockDataKey]);

  return data;
}
