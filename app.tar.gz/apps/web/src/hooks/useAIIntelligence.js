
import { useContext, useEffect, useRef } from 'react';
import { AIIntelligenceContext } from '@/contexts/AIIntelligenceContext.jsx';
import { globalAIEngine } from '@/lib/aiIntelligenceEngine.js';

export function useAIIntelligence(injectedContext = null) {
  const context = useContext(AIIntelligenceContext);
  const prevContextRef = useRef(null);
  
  if (!context) {
    throw new Error('useAIIntelligence must be used within an AIIntelligenceProvider');
  }

  // If injected context is provided, update the global AI engine context
  useEffect(() => {
    if (injectedContext && injectedContext.isAuthenticated) {
      // Only trigger update if context actually changed significantly to avoid infinite loops
      const contextChanged = JSON.stringify(injectedContext.lastUpdated) !== JSON.stringify(prevContextRef.current?.lastUpdated);
      
      if (contextChanged) {
        prevContextRef.current = injectedContext;
        
        // Inject specific data into the AI engine
        if (injectedContext.contracts) globalAIEngine.updateContext('contracts', injectedContext.contracts);
        if (injectedContext.fleets) globalAIEngine.updateContext('fleets', injectedContext.fleets);
        if (injectedContext.alerts) globalAIEngine.updateContext('alerts', injectedContext.alerts);
        
        // Pass the full injected context for role-based and tab-specific analysis
        globalAIEngine.updateContext('injectedState', injectedContext);
      }
    }
  }, [injectedContext]);

  // Filter insights based on role and active tab if injectedContext is provided
  let filteredInsights = context.insights;
  let filteredRecommendations = context.recommendations;

  if (injectedContext && injectedContext.isAuthenticated) {
    const { userRole, activeTab } = injectedContext;
    
    // Role-based filtering
    if (userRole === 'Operator') {
      filteredInsights = filteredInsights.filter(i => i.category !== 'financial');
      filteredRecommendations = filteredRecommendations.filter(r => r.category !== 'financial');
    }
    
    // Tab-specific prioritization (sort relevant insights higher)
    if (activeTab) {
      const tabCategoryMap = {
        'contracts': ['renewal', 'risk'],
        'financials': ['financial', 'optimization'],
        'alerts': ['trend', 'risk']
      };
      
      const relevantCategories = tabCategoryMap[activeTab] || [];
      if (relevantCategories.length > 0) {
        filteredInsights = [...filteredInsights].sort((a, b) => {
          const aRelevant = relevantCategories.includes(a.category) ? 1 : 0;
          const bRelevant = relevantCategories.includes(b.category) ? 1 : 0;
          return bRelevant - aRelevant || b.priority - a.priority;
        });
      }
    }
  }

  return {
    ...context,
    insights: filteredInsights,
    recommendations: filteredRecommendations
  };
}
