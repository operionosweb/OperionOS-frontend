
import { useState, useMemo } from 'react';

export function useSort(data, initialField = 'created_at', initialDirection = 'desc') {
  const [sortConfig, setSortConfig] = useState({ field: initialField, direction: initialDirection });

  const sortedData = useMemo(() => {
    if (!data || data.length === 0 || !sortConfig.field) return data;

    return [...data].sort((a, b) => {
      const aVal = a[sortConfig.field];
      const bVal = b[sortConfig.field];

      if (aVal === bVal) return 0;
      
      const comparison = aVal > bVal ? 1 : -1;
      return sortConfig.direction === 'asc' ? comparison : -comparison;
    });
  }, [data, sortConfig]);

  const requestSort = (field) => {
    setSortConfig(prev => ({
      field,
      direction: prev.field === field && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  return { sortConfig, requestSort, sortedData };
}
