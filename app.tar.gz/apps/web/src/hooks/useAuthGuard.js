
import { useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient.js';

export function useAuthGuard() {
  const [authState, setAuthState] = useState({
    isAuthenticated: pb.authStore.isValid,
    user: pb.authStore.model,
    isLoading: true
  });

  useEffect(() => {
    // Initial check complete
    setAuthState(prev => ({ ...prev, isLoading: false }));

    // Subscribe to auth state changes
    const unsubscribe = pb.authStore.onChange((token, model) => {
      try {
        setAuthState({
          isAuthenticated: pb.authStore.isValid,
          user: model || null,
          isLoading: false
        });
      } catch (error) {
        console.error('Auth state change error:', error);
        setAuthState({
          isAuthenticated: false,
          user: null,
          isLoading: false
        });
      }
    });

    return () => {
      unsubscribe();
    };
  }, []);

  return authState;
}
