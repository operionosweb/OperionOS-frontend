
import { useState, useMemo } from 'react';

export function useFilter(data, initialFilters = {}) {
  const [filters, setFilters] = useState(initialFilters);

  const filteredData = useMemo(() => {
    if (!data || data.length === 0) return data;
    
    return data.filter(item => {
      return Object.entries(filters).every(([key, value]) => {
        if (!value || value === 'all') return true;
        return String(item[key]).toLowerCase() === String(value).toLowerCase();
      });
    });
  }, [data, filters]);

  const updateFilter = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters(initialFilters);
  };

  return { filters, updateFilter, clearFilters, filteredData };
}
