import { useState, useEffect, useCallback } from 'react';
import { getInitialVessels, simulateMovement } from '@/lib/vesselMapData.js';

export const useVesselTracking = () => {
  const [vessels, setVessels] = useState([]);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Initialize data
    setVessels(getInitialVessels());
    setIsInitialized(true);
  }, []);

  useEffect(() => {
    if (!isInitialized) return;

    // Simulate real-time movement every 3 seconds
    const intervalId = setInterval(() => {
      setVessels(prevVessels => 
        prevVessels.map(vessel => simulateMovement(vessel))
      );
    }, 3000);

    return () => clearInterval(intervalId);
  }, [isInitialized]);

  const getVesselById = useCallback((id) => {
    return vessels.find(v => v.id === id);
  }, [vessels]);

  return {
    vessels,
    getVesselById,
    isInitialized
  };
};