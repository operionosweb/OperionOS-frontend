
import { useState, useEffect } from 'react';
import { useUserRole } from './useUserRole.js';
import { determineLifecycleStage } from '@/lib/lifecycleUtils.js';

export function useLifecycleStage() {
  const { role } = useUserRole();
  const [stage, setStage] = useState(() => determineLifecycleStage(role));

  useEffect(() => {
    setStage(determineLifecycleStage(role));
    
    // Listen for storage changes that might affect lifecycle
    const handleStorageChange = (e) => {
      if (e.key === 'operion_lifecycle_state' || !e.key) {
        setStage(determineLifecycleStage(role));
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [role]);

  // Force a re-evaluation (useful after completing onboarding)
  const refreshStage = () => {
    setStage(determineLifecycleStage(role));
  };

  return {
    stage,
    refreshStage
  };
}
