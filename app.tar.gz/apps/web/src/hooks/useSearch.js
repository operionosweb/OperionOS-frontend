
import { useState, useMemo } from 'react';

export function useSearch(data, searchFields = []) {
  const [searchQuery, setSearchQuery] = useState('');

  const searchedData = useMemo(() => {
    if (!searchQuery || !data || data.length === 0) return data;
    
    const lowerQuery = searchQuery.toLowerCase();
    return data.filter(item => {
      return searchFields.some(field => {
        const value = item[field];
        return value && String(value).toLowerCase().includes(lowerQuery);
      });
    });
  }, [data, searchQuery, searchFields]);

  return { searchQuery, setSearchQuery, searchedData };
}
