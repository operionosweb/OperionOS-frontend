
import { useEffect, useState, useCallback } from 'react';
import { useEventContext } from '@/contexts/EventContext.jsx';

/**
 * Hook to subscribe to real-time events
 * @param {string} eventType 
 * @param {Function} [callback] Optional callback to run on event
 * @returns {{ latestEvent: any, timestamp: number|null }}
 */
export function useRealTimeEvents(eventType, callback) {
  const { eventBus } = useEventContext();
  const [latestEvent, setLatestEvent] = useState(null);
  const [timestamp, setTimestamp] = useState(null);

  const handleEvent = useCallback((payload) => {
    setLatestEvent(payload);
    setTimestamp(payload.timestamp || Date.now());
    if (callback && typeof callback === 'function') {
      callback(payload);
    }
  }, [callback]);

  useEffect(() => {
    if (!eventType) return;
    
    const unsubscribe = eventBus.subscribe(eventType, handleEvent);
    
    return () => {
      unsubscribe();
    };
  }, [eventBus, eventType, handleEvent]);

  return { latestEvent, timestamp };
}
