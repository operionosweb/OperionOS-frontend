import { useEffect } from 'react';
import { useMap } from 'react-leaflet';

export const useMapTouchControl = (mapInstance) => {
  useEffect(() => {
    if (!mapInstance) return;

    let touchStartListener;
    let touchMoveListener;
    let touchEndListener;

    const applyControls = () => {
      // (1) Detect device type using window.innerWidth
      const width = window.innerWidth;
      const isMobile = width <= 768;
      const isTablet = width > 768 && width <= 1024;
      const container = mapInstance.getContainer();

      // Clean up previous listeners
      if (touchStartListener) container.removeEventListener('touchstart', touchStartListener);
      if (touchMoveListener) container.removeEventListener('touchmove', touchMoveListener);
      if (touchEndListener) container.removeEventListener('touchend', touchEndListener);

      if (isMobile || isTablet) {
        // (2) Disable single-finger pan on mobile by default
        mapInstance.dragging.disable();
        mapInstance.scrollWheelZoom.disable();
        
        // Enable two-finger touch zoom natively via Leaflet
        if (mapInstance.touchZoom) {
          mapInstance.touchZoom.enable();
        }

        // (3) Enable two-finger pan/zoom by detecting touch event length
        touchStartListener = (e) => {
          if (e.touches.length >= 2) {
            // Two fingers detected: enable map panning
            mapInstance.dragging.enable();
          } else {
            // Single finger: disable map panning to allow page scroll
            mapInstance.dragging.disable();
          }
        };

        // (4) Add touch event listeners for move
        touchMoveListener = (e) => {
          if (e.touches.length >= 2) {
            // Keep dragging enabled for two fingers
            mapInstance.dragging.enable();
          } else {
            // (5) Prevent default map pan on single-finger drag but allow page scroll
            mapInstance.dragging.disable();
          }
        };

        // Reset state on touch end
        touchEndListener = (e) => {
          if (e.touches.length < 2) {
            mapInstance.dragging.disable();
          }
        };

        container.addEventListener('touchstart', touchStartListener, { passive: true });
        container.addEventListener('touchmove', touchMoveListener, { passive: true });
        container.addEventListener('touchend', touchEndListener, { passive: true });
      } else {
        // Desktop: enable all mouse-based navigation
        mapInstance.dragging.enable();
        mapInstance.scrollWheelZoom.enable();
        mapInstance.doubleClickZoom.enable();
        if (mapInstance.touchZoom) {
          mapInstance.touchZoom.enable();
        }
      }
    };

    applyControls();
    window.addEventListener('resize', applyControls);

    return () => {
      window.removeEventListener('resize', applyControls);
      const container = mapInstance.getContainer();
      if (touchStartListener) container.removeEventListener('touchstart', touchStartListener);
      if (touchMoveListener) container.removeEventListener('touchmove', touchMoveListener);
      if (touchEndListener) container.removeEventListener('touchend', touchEndListener);
    };
  }, [mapInstance]);
};

// (6) Export MapTouchHandler component that wraps map container with proper touch-action CSS
export const MapTouchHandler = () => {
  const map = useMap();
  useMapTouchControl(map);
  return null;
};