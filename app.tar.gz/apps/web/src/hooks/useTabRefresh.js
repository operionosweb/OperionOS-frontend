
import { useState, useCallback } from 'react';
import { clearCacheForTab, saveToCache } from '@/lib/TabDataCache.js';

export function useTabRefresh(tabId, companyId, fetcher, onRefreshSuccess) {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(null);

  const handleRefresh = useCallback(async () => {
    if (!tabId || !companyId) return;
    
    setLoading(true);
    clearCacheForTab(tabId, companyId);
    
    try {
      const res = await fetcher();
      saveToCache(tabId, companyId, res);
      setData(res);
      if (onRefreshSuccess) onRefreshSuccess(res);
    } catch (err) {
      console.error(`[useTabRefresh] Error fetching ${tabId}:`, err);
    } finally {
      setLoading(false);
    }
  }, [tabId, companyId, fetcher, onRefreshSuccess]);

  return { data, loading, handleRefresh };
}
