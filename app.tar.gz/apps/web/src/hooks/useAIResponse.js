
import { useState, useCallback } from 'react';
import apiServerClient from '@/lib/apiServerClient.js';

export function useAIResponse() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchResponse = useCallback(async (message, context = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiServerClient.fetch('/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message, context })
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Failed to fetch AI response');
      }
      
      const data = await response.json();
      
      // Handle standard response formats from the backend
      return data.response || data.reply || data.text || "I'm sorry, I couldn't process that response.";
    } catch (err) {
      console.error('AI Response Error:', err);
      setError(err.message);
      return "I encountered an error connecting to the intelligence engine. Please try again.";
    } finally {
      setLoading(false);
    }
  }, []);

  return { fetchResponse, loading, error };
}
