
import { useContext, useMemo } from 'react';
import { FinancialSimulationContext } from '@/contexts/FinancialSimulationContext.jsx';

export function useFinancialSimulation(contract) {
  const context = useContext(FinancialSimulationContext);
  
  if (!context) {
    throw new Error('useFinancialSimulation must be used within a FinancialSimulationProvider');
  }

  const { calculateSimulation, simulationCache } = context;
  const contractId = contract?.contract_id || contract?.id;

  const simulationData = useMemo(() => {
    if (!contract || !contractId) return null;
    
    // If it's already in cache, use it, otherwise calculate it
    if (simulationCache.has(contractId)) {
      return simulationCache.get(contractId);
    }
    
    return calculateSimulation(contract);
  }, [contract, contractId, simulationCache, calculateSimulation]);

  return {
    ...simulationData,
    calculateSimulation
  };
}
