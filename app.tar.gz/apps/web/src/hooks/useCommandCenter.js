
import { useState, useCallback } from 'react';
import { parseCommand } from '@/lib/CommandParser.js';
import { isValidCommand } from '@/lib/CommandValidator.js';
import { executeCommand } from '@/lib/CommandExecutor.js';

export function useCommandCenter(handlers) {
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [history, setHistory] = useState([]);

  const handleCommandSubmit = useCallback((input) => {
    setError(null);
    setResult(null);
    
    try {
      const parsed = parseCommand(input);
      
      if (!isValidCommand(parsed)) {
        throw new Error("Command validation failed. Invalid parameters or target.");
      }
      
      const successMessage = executeCommand(parsed, handlers);
      setResult(successMessage);
      setHistory(prev => [{ input, result: successMessage, timestamp: new Date().toISOString() }, ...prev]);
      return true;
    } catch (err) {
      setError(err.message);
      setHistory(prev => [{ input, error: err.message, timestamp: new Date().toISOString() }, ...prev]);
      return false;
    }
  }, [handlers]);

  const clearHistory = useCallback(() => {
    setHistory([]);
    setResult(null);
    setError(null);
  }, []);

  return { result, error, history, handleCommandSubmit, clearHistory };
}
