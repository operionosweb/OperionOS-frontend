
import { useState } from 'react';

export function useDetailPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [itemType, setItemType] = useState(null);

  const openPanel = (item, type) => {
    setSelectedItem(item);
    setItemType(type);
    setIsOpen(true);
  };

  const closePanel = () => {
    setIsOpen(false);
    setTimeout(() => {
      setSelectedItem(null);
      setItemType(null);
    }, 300);
  };

  return { isOpen, selectedItem, itemType, openPanel, closePanel };
}
