
import { useContext, useEffect, useState, useMemo } from 'react';
import { ForecastingContext } from '@/contexts/ForecastingContext.jsx';
import { generateAIRecommendation, generateSuggestedActions } from '@/lib/aiRecommendationGenerator.js';

export function useContractForecasting(contract) {
  const context = useContext(ForecastingContext);
  const [localForecast, setLocalForecast] = useState(null);
  const [error, setError] = useState(null);

  if (!context) {
    throw new Error('useContractForecasting must be used within a ForecastingProvider');
  }

  const { getForecast, calculateForecasts, isCalculating } = context;
  const contractId = contract?.contract_id || contract?.id;

  useEffect(() => {
    if (!contract || !contractId) {
      setLocalForecast(null);
      return;
    }

    try {
      const existing = getForecast(contractId);
      if (!existing) {
        calculateForecasts([contract]);
      } else {
        setLocalForecast(existing);
      }
    } catch (err) {
      setError(err.message);
    }
  }, [contract, contractId, getForecast, calculateForecasts]);

  const enrichedForecast = useMemo(() => {
    if (!localForecast) return null;
    
    const aiRecommendation = generateAIRecommendation(
      localForecast.renewalProbability,
      localForecast.riskScore,
      localForecast.exposureIndex
    );
    
    const suggestedActions = generateSuggestedActions(
      localForecast.renewalProbability,
      localForecast.riskScore,
      localForecast.exposureIndex
    );

    return {
      ...localForecast,
      aiRecommendation,
      suggestedActions
    };
  }, [localForecast]);

  return {
    forecast: enrichedForecast,
    isLoading: isCalculating && !localForecast,
    error
  };
}
