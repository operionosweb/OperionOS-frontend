
import { useState, useEffect, useCallback, useRef } from 'react';
import { copilotEngineInstance } from '@/lib/CopilotContextEngine.js';
import { generateAlerts, defaultAlertGenerator } from '@/lib/CopilotAlertGenerator.js';
import { recommendActions } from '@/lib/CopilotActionRecommender.js';
import { getPageAwareInsights, getPageAwareActions } from '@/lib/CopilotPageAwareness.js';

export function useCopilotEngine() {
  const [copilotState, setCopilotState] = useState({
    context: copilotEngineInstance.getContext(),
    alerts: [],
    actions: [],
    healthScore: 100,
    lastUpdate: Date.now()
  });

  const pollIntervalRef = useRef(null);

  const calculateHealthScore = useCallback((alerts) => {
    let penalty = 0;
    alerts.forEach(a => {
      if (a.severity === 'critical') penalty += 15;
      else if (a.severity === 'warning') penalty += 5;
    });
    return Math.max(0, 100 - penalty);
  }, []);

  const runAnalysisCycle = useCallback((currentContext) => {
    const rawAlerts = generateAlerts(currentContext);
    const rawActions = recommendActions(currentContext, rawAlerts);
    
    const activeTab = currentContext.activeTab;
    const pageAlerts = getPageAwareInsights(currentContext, rawAlerts, activeTab);
    const pageActions = getPageAwareActions(rawActions, activeTab);

    setCopilotState(prev => ({
      context: currentContext,
      alerts: pageAlerts,
      actions: pageActions,
      healthScore: calculateHealthScore(rawAlerts),
      lastUpdate: Date.now()
    }));
  }, [calculateHealthScore]);

  useEffect(() => {
    // Initial analysis
    runAnalysisCycle(copilotEngineInstance.getContext());

    // Subscribe to context updates
    const unsubscribe = copilotEngineInstance.subscribeToUpdates((newContext) => {
      runAnalysisCycle(newContext);
    });

    // Start 15s polling
    pollIntervalRef.current = setInterval(() => {
      copilotEngineInstance.refreshContext();
    }, 15000);

    return () => {
      unsubscribe();
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [runAnalysisCycle]);

  const refreshNow = useCallback(() => {
    copilotEngineInstance.refreshContext();
  }, []);

  const dismissAlert = useCallback((id) => {
    defaultAlertGenerator.dismissAlert(id);
    runAnalysisCycle(copilotEngineInstance.getContext());
  }, [runAnalysisCycle]);

  const executeAction = useCallback((action) => {
    console.log(`[Copilot] Executing action: ${action.title}`, action.target);
    // In a real app, this would trigger routing or modal dispatches
    // For now, we simulate success
  }, []);

  // Memoize updateContext to prevent infinite loops in consumers' useEffects
  const updateContext = useCallback((data) => {
    copilotEngineInstance.updateContext(data);
  }, []);

  return {
    ...copilotState,
    updateContext,
    refreshNow,
    dismissAlert,
    executeAction
  };
}
