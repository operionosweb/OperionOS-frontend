import { useEffect, useCallback } from 'react';
import { useOperionOS } from '@/contexts/OperionOSContext.jsx';
import { toast } from 'sonner';

export const useDemoIsolationGuard = () => {
  const { isDemo, getActiveLayer, activeCompanyId } = useOperionOS();

  const validateDataAccess = useCallback((dataType, dataIsMocked) => {
    const layer = getActiveLayer();
    
    if (layer === 'SYSTEM_LAYER' && dataIsMocked) {
      console.warn(`[ISOLATION BREACH] Real company ${activeCompanyId} accessed mocked ${dataType} data.`);
      toast.error('System validation error: Cross-layer data access detected.', { id: 'iso-breach' });
      return false;
    }
    
    if (layer === 'DEMO_LAYER' && !dataIsMocked) {
      console.warn(`[ISOLATION BREACH] Demo company accessed production ${dataType} data.`);
      toast.error('System validation error: Demo environment accessing production data.', { id: 'iso-breach' });
      return false;
    }
    
    return true;
  }, [getActiveLayer, activeCompanyId]);

  const validateFeatureAccess = useCallback((featureName, requiresDemo) => {
    if (requiresDemo && !isDemo()) {
      console.warn(`[ISOLATION GUARD] Feature ${featureName} blocked for System Layer.`);
      return false;
    }
    return true;
  }, [isDemo]);

  // Automatically monitor layer shifts
  useEffect(() => {
    console.log(`[OS CORE] Active Environment Layer: ${getActiveLayer()}`);
  }, [getActiveLayer]);

  return {
    validateDataAccess,
    validateFeatureAccess
  };
};