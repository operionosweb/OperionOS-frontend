
import { useContext, useMemo } from 'react';
import { ContractMonitoringContext } from '@/contexts/ContractMonitoringContext.jsx';
import { differenceInDays, parseISO } from 'date-fns';

export function useContractMonitoring() {
  const context = useContext(ContractMonitoringContext);
  
  if (!context) {
    throw new Error('useContractMonitoring must be used within a ContractMonitoringProvider');
  }

  const {
    contracts,
    alerts,
    exposureMetrics,
    riskScores,
    lastMonitoredAt,
    exposureTrend,
    acknowledgeAlert,
    dismissAlert,
    triggerMonitoring
  } = context;

  const getAlertsByType = (type) => {
    return alerts.filter(a => a.type === type && !a.dismissed);
  };

  const getContractsByRiskLevel = (level) => {
    return contracts.filter(c => (c.risk_level || '').toLowerCase() === level.toLowerCase());
  };

  const getExpiringContracts = (daysThreshold = 30) => {
    return contracts.filter(c => {
      if (!c.expiry_date) return false;
      const days = differenceInDays(parseISO(c.expiry_date), new Date());
      return days >= 0 && days <= daysThreshold;
    }).sort((a, b) => {
      const daysA = differenceInDays(parseISO(a.expiry_date), new Date());
      const daysB = differenceInDays(parseISO(b.expiry_date), new Date());
      return daysA - daysB;
    });
  };

  const getHighRiskContracts = () => {
    return contracts.filter(c => 
      (c.monitoring?.riskScore >= 60) || 
      ((c.risk_level || '').toLowerCase() === 'high')
    ).sort((a, b) => (b.monitoring?.riskScore || 0) - (a.monitoring?.riskScore || 0));
  };

  const getFinancialExposure = () => {
    return exposureMetrics;
  };

  const activeAlerts = useMemo(() => alerts.filter(a => !a.dismissed), [alerts]);
  const criticalAlerts = useMemo(() => activeAlerts.filter(a => a.severity === 'critical'), [activeAlerts]);
  const warningAlerts = useMemo(() => activeAlerts.filter(a => a.severity === 'warning'), [activeAlerts]);

  return {
    contracts,
    alerts: activeAlerts,
    criticalAlerts,
    warningAlerts,
    exposureMetrics,
    riskScores,
    lastMonitoredAt,
    exposureTrend,
    triggerMonitoring,
    getAlertsByType,
    getContractsByRiskLevel,
    getExpiringContracts,
    getHighRiskContracts,
    getFinancialExposure,
    acknowledgeAlert,
    dismissAlert
  };
}
