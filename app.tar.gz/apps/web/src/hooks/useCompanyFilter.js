import { useImpersonation } from '@/contexts/ImpersonationContext.jsx';

export const useCompanyFilter = () => {
  const { activeCompanyId } = useImpersonation();

  const applyCompanyFilter = (query, column = 'tenant_id') => {
    if (activeCompanyId) {
      return query.eq(column, activeCompanyId);
    }
    return query;
  };

  return applyCompanyFilter;
};