
import { useState, useEffect } from 'react';
import { getFromCache, saveToCache } from '@/lib/TabDataCache.js';

export function useTabData(tabId, companyId, fetcher) {
  const [state, setState] = useState({ data: null, loading: true, error: null });

  useEffect(() => {
    let isMounted = true;
    
    if (!tabId || !companyId) return;

    const cached = getFromCache(tabId, companyId);

    if (cached) {
      setState({ data: cached.data, loading: false, error: null });
    } else {
      setState(s => ({ ...s, loading: true, error: null }));
      
      fetcher()
        .then(res => {
          if (isMounted) {
            saveToCache(tabId, companyId, res);
            setState({ data: res, loading: false, error: null });
          }
        })
        .catch(err => {
          if (isMounted) {
            setState({ data: null, loading: false, error: err.message || 'Failed to fetch data' });
          }
        });
    }

    return () => {
      isMounted = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tabId, companyId]);

  return state;
}
