
import { useCallback } from 'react';
import { useEventContext } from '@/contexts/EventContext.jsx';

/**
 * Hook to interact with the DataSyncManager
 */
export function useDataSync() {
  const { syncManager, syncState } = useEventContext();

  const start = useCallback(() => {
    syncManager.start();
  }, [syncManager]);

  const stop = useCallback(() => {
    syncManager.stop();
  }, [syncManager]);

  const triggerSync = useCallback(() => {
    syncManager.sync('manual');
  }, [syncManager]);

  return {
    ...syncState,
    start,
    stop,
    triggerSync
  };
}
