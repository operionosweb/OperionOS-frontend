
import { useState, useEffect } from 'react';
import { PRODUCT_TIERS, TIER_FEATURES } from '@/constants/tiers.js';

export function useProductTier() {
  // In a real app, this would come from a billing/company context
  const [tier, setTier] = useState(() => {
    return localStorage.getItem('operion_mock_tier') || PRODUCT_TIERS.ENTERPRISE;
  });

  const setMockTier = (newTier) => {
    setTier(newTier);
    localStorage.setItem('operion_mock_tier', newTier);
    window.dispatchEvent(new Event('tier_changed'));
  };

  useEffect(() => {
    const handleTierChange = () => {
      setTier(localStorage.getItem('operion_mock_tier') || PRODUCT_TIERS.ENTERPRISE);
    };
    window.addEventListener('tier_changed', handleTierChange);
    return () => window.removeEventListener('tier_changed', handleTierChange);
  }, []);

  const features = TIER_FEATURES[tier] || [];

  const hasFeature = (featureKey) => {
    return features.includes(featureKey);
  };

  const hasTierAccess = (allowedTiers) => {
    if (!allowedTiers || !Array.isArray(allowedTiers)) return false;
    return allowedTiers.includes(tier);
  };

  return {
    tier,
    features,
    hasFeature,
    hasTierAccess,
    setMockTier
  };
}
