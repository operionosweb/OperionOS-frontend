
import { useState, useCallback, useEffect } from 'react';
import { useAuthGuard } from './useAuthGuard.js';

export function useAIContextInjection(initialParams = {}) {
  const { isAuthenticated, user } = useAuthGuard();

  const buildContext = useCallback((params, currentUser, isAuth) => {
    return {
      userId: currentUser?.id || null,
      userRole: currentUser?.role || 'viewer',
      isAuthenticated: isAuth,
      activeTab: params.activeTab || 'dashboard',
      selectedEntity: params.selectedEntity || null,
      dashboardMetrics: params.dashboardMetrics || {},
      contracts: params.contracts || [],
      fleets: params.fleets || [],
      users: params.users || [],
      alerts: params.alerts || [],
      monitoringState: params.monitoringState || {},
      forecastingData: params.forecastingData || {},
      financialData: params.financialData || {},
      lastUpdated: new Date().toISOString()
    };
  }, []);

  const [context, setContext] = useState(() => buildContext(initialParams, user, isAuthenticated));

  // Update context when auth state changes
  useEffect(() => {
    setContext(prev => buildContext(prev, user, isAuthenticated));
  }, [user, isAuthenticated, buildContext]);

  const updateContext = useCallback((newParams) => {
    setContext(prev => ({
      ...prev,
      ...newParams,
      lastUpdated: new Date().toISOString()
    }));
  }, []);

  const clearContext = useCallback(() => {
    setContext(buildContext({}, null, false));
  }, [buildContext]);

  return { context, updateContext, clearContext };
}
