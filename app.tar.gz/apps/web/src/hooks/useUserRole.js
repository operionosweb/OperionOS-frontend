
import { useState, useEffect } from 'react';
import { ROLES, ROLE_PERMISSIONS } from '@/constants/roles.js';

export function useUserRole() {
  // In a real app, this would come from an auth context or API
  const [role, setRole] = useState(() => {
    return localStorage.getItem('operion_mock_role') || ROLES.SUPER_ADMIN;
  });

  const setMockRole = (newRole) => {
    setRole(newRole);
    localStorage.setItem('operion_mock_role', newRole);
    // Dispatch event so other components can update if needed
    window.dispatchEvent(new Event('role_changed'));
  };

  useEffect(() => {
    const handleRoleChange = () => {
      setRole(localStorage.getItem('operion_mock_role') || ROLES.SUPER_ADMIN);
    };
    window.addEventListener('role_changed', handleRoleChange);
    return () => window.removeEventListener('role_changed', handleRoleChange);
  }, []);

  const permissions = ROLE_PERMISSIONS[role] || ROLE_PERMISSIONS[ROLES.VIEWER];

  const hasPermission = (permissionKey) => {
    return permissions[permissionKey] === true;
  };

  const hasRoleAccess = (allowedRoles) => {
    if (!allowedRoles || !Array.isArray(allowedRoles)) return false;
    return allowedRoles.includes(role);
  };

  return {
    role,
    permissions,
    hasPermission,
    hasRoleAccess,
    setMockRole
  };
}
