import { useCallback } from 'react';
import pb from '@/lib/pocketbaseClient.js';
import { useOperionOS } from '@/contexts/OperionOSContext.jsx';
import { generateCrew, generateAircraft } from '@/lib/aviationComprehensiveData.js';
import { generateEnhancedDisruptions } from '@/lib/aviationDisruptionEnhanced.js';

export const useLayerRouter = () => {
  const { isDemo, getActiveLayer, activeCompanyId } = useOperionOS();

  // Route Crew Data Fetching
  const fetchCrewData = useCallback(async (tenantId) => {
    const layer = getActiveLayer();
    console.log(`[LayerRouter] Routing fetchCrewData to ${layer}`);
    
    if (isDemo()) {
      // Demo Layer: Return simulated isolated data
      return generateCrew(35);
    } else {
      // System Layer: Production PocketBase Query
      if (!tenantId) return [];
      try {
        // Map to users collection as personnel
        const records = await pb.collection('users').getFullList({
          $autoCancel: false,
          sort: '-created'
        });
        return records.map(r => ({ ...r, role: r.role || 'crew', name: r.name || r.email }));
      } catch (error) {
        console.error('[LayerRouter] System Layer Fetch Error:', error);
        return [];
      }
    }
  }, [isDemo, getActiveLayer]);

  // Route Fleet Data Fetching
  const fetchFleetData = useCallback(async (tenantId) => {
    const layer = getActiveLayer();
    console.log(`[LayerRouter] Routing fetchFleetData to ${layer}`);
    
    if (isDemo()) {
      return generateAircraft(18);
    } else {
      if (!tenantId) return [];
      try {
        // Fallback or specific collection mapping if fleet exists.
        // Assuming empty array if no specific fleet collection is defined in DB schema.
        return []; 
      } catch (error) {
        console.error('[LayerRouter] System Layer Fetch Error:', error);
        return [];
      }
    }
  }, [isDemo, getActiveLayer]);

  // Route Operations Data Fetching
  const fetchOperationsData = useCallback(async () => {
    if (isDemo()) {
      return generateEnhancedDisruptions(15);
    } else {
      try {
        const records = await pb.collection('movement_plans').getFullList({
          $autoCancel: false,
          sort: '-created'
        });
        return records;
      } catch (error) {
        console.error('[LayerRouter] System Layer Fetch Error:', error);
        return [];
      }
    }
  }, [isDemo]);

  return {
    fetchCrewData,
    fetchFleetData,
    fetchOperationsData
  };
};