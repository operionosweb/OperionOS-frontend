
import { useState, useEffect, useCallback } from 'react';
import pb from '@/lib/pocketbaseClient.js';
import { useImpersonation } from '@/contexts/ImpersonationContext.jsx';
import { useTabData } from '@/contexts/TabProvider.jsx';

export const useCompanySelector = () => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { activeCompanyId, setActiveCompany } = useImpersonation();
  const { clearCache } = useTabData();

  const loadCompanies = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Fetch users to represent accessible companies as per requirements
      const users = await pb.collection('users').getFullList({ $autoCancel: false });
      const list = users.map(u => ({ id: u.id, name: `${u.name} Operations` }));
      
      // Always ensure Demo Company is present
      if (!list.find(c => c.id === '6c091a44-952c-4433-944d-c18d02574003')) {
        list.push({ id: '6c091a44-952c-4433-944d-c18d02574003', name: 'Demo Company' });
      }
      
      setCompanies(list);
    } catch (err) {
      console.error('[CompanySelector] Fetch error:', err);
      setError(err.message);
      // Graceful fallback to Demo Company on failure
      setCompanies([{ id: '6c091a44-952c-4433-944d-c18d02574003', name: 'Demo Company' }]);
    } finally {
      setLoading(false);
    }
  }, []);

  // Load once on mount
  useEffect(() => {
    loadCompanies();
  }, [loadCompanies]);

  // Set default company if none selected and companies are loaded
  useEffect(() => {
    if (!activeCompanyId && companies.length > 0) {
      const defaultComp = companies.find(c => c.id === '6c091a44-952c-4433-944d-c18d02574003') || companies[0];
      setActiveCompany(defaultComp.id, defaultComp.name);
    }
  }, [activeCompanyId, companies, setActiveCompany]);

  const handleCompanyChange = useCallback((id) => {
    const comp = companies.find(c => c.id === id);
    if (comp) {
      setActiveCompany(comp.id, comp.name);
      clearCache(); // Trigger data refresh for all tabs
    }
  }, [companies, setActiveCompany, clearCache]);

  return { 
    companies, 
    activeCompanyId, 
    loading, 
    error, 
    handleCompanyChange, 
    retry: loadCompanies 
  };
};
