import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bell } from 'lucide-react';
import ImpersonationBanner from '@/components/ImpersonationBanner.jsx';
import HamburgerMenu from '@/components/HamburgerMenu.jsx';
import AlertFeedPanel from '@/components/AlertFeedPanel.jsx';
import { useAlert } from '@/contexts/AlertContext.jsx';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet.jsx';
import { cn } from '@/lib/utils.js';

const Header = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const { alertStats } = useAlert();

  useEffect(() => {
    const checkAuth = async () => {
      if (window.supabaseClient) {
        try {
          const { data: { user }, error } = await window.supabaseClient.auth.getUser();
          if (error) throw error;
          setUser(user);
        } catch (error) {
          console.error('Error checking auth status:', error.message);
        }
      }
    };

    checkAuth();

    let subscription;
    if (window.supabaseClient) {
      const { data } = window.supabaseClient.auth.onAuthStateChange((_event, session) => {
        setUser(session?.user || null);
      });
      subscription = data.subscription;
    }

    return () => {
      if (subscription) subscription.unsubscribe();
    };
  }, []);

  const handleLogout = async () => {
    if (window.supabaseClient) {
      try {
        const { error } = await window.supabaseClient.auth.signOut();
        if (error) throw error;
        setUser(null);
        navigate('/login');
      } catch (error) {
        console.error('Error logging out:', error.message);
      }
    }
  };

  const totalUnread = alertStats?.total || 0;
  const hasCritical = alertStats?.critical > 0;
  const hasWarning = alertStats?.warning > 0;

  const badgeColor = hasCritical 
    ? 'bg-destructive text-destructive-foreground' 
    : hasWarning 
      ? 'bg-amber-500 text-white' 
      : 'bg-blue-500 text-white';

  return (
    <>
      <div className="fixed top-0 left-0 right-0 z-50 flex flex-col">
        <ImpersonationBanner />
        <header className="header-container">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              
              {/* Left Side - Logo Only */}
              <Link to="/" className="flex items-center shrink-0 transition-opacity hover:opacity-90">
                <img 
                  src="https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/d4c3af1ba833729da85b67b90bdf2c04.png" 
                  alt="Operion Logo" 
                  className="h-8 w-auto"
                />
              </Link>

              {/* Right Side - Alerts & Hamburger Menu */}
              <div className="flex items-center gap-4">
                
                <Sheet>
                  <SheetTrigger asChild>
                    <button className="relative p-2 rounded-full hover:bg-muted transition-colors focus:outline-none focus:ring-2 focus:ring-ring">
                      <Bell className="w-5 h-5 text-foreground" />
                      {totalUnread > 0 && (
                        <span className={cn(
                          "absolute top-1 right-1 flex items-center justify-center min-w-[18px] h-[18px] text-[10px] font-bold rounded-full px-1 border-2 border-background",
                          badgeColor
                        )}>
                          {totalUnread > 99 ? '99+' : totalUnread}
                        </span>
                      )}
                    </button>
                  </SheetTrigger>
                  <SheetContent side="right" className="w-full sm:max-w-md p-0 border-l border-border">
                    <AlertFeedPanel />
                  </SheetContent>
                </Sheet>

                <HamburgerMenu user={user} onLogout={handleLogout} />
              </div>

            </div>
          </div>
        </header>
      </div>
      
      {/* Spacer to prevent content from hiding under fixed header + banner */}
      <div className="h-20 w-full" />
    </>
  );
};

export default Header;
