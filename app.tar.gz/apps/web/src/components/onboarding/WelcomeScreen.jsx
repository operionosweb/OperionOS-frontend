
import React from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Rocket } from 'lucide-react';

export default function WelcomeScreen({ onNext }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="w-20 h-20 bg-primary/10 rounded-2xl flex items-center justify-center mb-8">
        <Rocket className="w-10 h-10 text-primary" />
      </div>
      
      <h1 className="text-4xl font-bold text-foreground mb-4 tracking-tight">
        Welcome to Operion
      </h1>
      
      <p className="text-xl text-muted-foreground max-w-[600px] mb-10 leading-relaxed">
        Let's get your operational environment configured. We'll set up your company profile and invite your team to get started.
      </p>

      <Button size="lg" onClick={onNext} className="text-lg px-8 h-14 rounded-full">
        Get Started
      </Button>
    </div>
  );
}
