
import React, { useState } from 'react';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Plus, Trash2 } from 'lucide-react';
import OnboardingHeader from './OnboardingHeader.jsx';
import OnboardingFooter from './OnboardingFooter.jsx';

export default function RoleAssignmentSetup({ onNext, onBack }) {
  const [invites, setInvites] = useState([
    { email: '', role: 'operator' }
  ]);

  const updateInvite = (index, field, value) => {
    const newInvites = [...invites];
    newInvites[index][field] = value;
    setInvites(newInvites);
  };

  const addInvite = () => {
    setInvites([...invites, { email: '', role: 'viewer' }]);
  };

  const removeInvite = (index) => {
    setInvites(invites.filter((_, i) => i !== index));
  };

  const handleContinue = () => {
    // In a real app, dispatch invites here
    onNext();
  };

  return (
    <div className="animate-in fade-in slide-in-from-right-4 duration-300">
      <OnboardingHeader 
        currentStep={2} 
        totalSteps={3} 
        title="Invite Your Team" 
        description="Add team members and assign their initial roles."
      />
      
      <div className="space-y-4 py-4">
        {invites.map((invite, index) => (
          <div key={index} className="flex items-end gap-3">
            <div className="flex-1 space-y-2">
              {index === 0 && <Label>Email Address</Label>}
              <Input 
                type="email"
                value={invite.email} 
                onChange={(e) => updateInvite(index, 'email', e.target.value)} 
                placeholder="colleague@company.com" 
                className="text-foreground"
              />
            </div>
            <div className="w-[180px] space-y-2">
              {index === 0 && <Label>Role</Label>}
              <Select 
                value={invite.role} 
                onValueChange={(val) => updateInvite(index, 'role', val)}
              >
                <SelectTrigger className="text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Manager (Admin)</SelectItem>
                  <SelectItem value="operator">Operator</SelectItem>
                  <SelectItem value="viewer">Viewer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => removeInvite(index)}
              disabled={invites.length === 1}
              className="mb-[2px] text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        ))}

        <Button 
          variant="outline" 
          onClick={addInvite}
          className="w-full mt-4 border-dashed"
        >
          <Plus className="w-4 h-4 mr-2" /> Add Another Member
        </Button>
      </div>

      <OnboardingFooter 
        onBack={onBack} 
        onNext={handleContinue} 
        onSkip={onNext}
        canSkip={true}
      />
    </div>
  );
}
