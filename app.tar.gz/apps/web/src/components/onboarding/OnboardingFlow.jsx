
import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card.jsx';
import WelcomeScreen from './WelcomeScreen.jsx';
import CompanyProfileSetup from './CompanyProfileSetup.jsx';
import RoleAssignmentSetup from './RoleAssignmentSetup.jsx';
import LaunchScreen from './LaunchScreen.jsx';
import { saveLifecycleState } from '@/lib/lifecycleUtils.js';

export default function OnboardingFlow({ onComplete }) {
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    // Mark onboarding as started
    saveLifecycleState({ onboardingStarted: true });
  }, []);

  const handleNext = () => {
    setCurrentStep(prev => prev + 1);
  };

  const handleBack = () => {
    setCurrentStep(prev => Math.max(0, prev - 1));
  };

  return (
    <div className="min-h-screen bg-muted/30 flex items-center justify-center p-4 sm:p-8">
      <Card className="w-full max-w-2xl p-6 sm:p-10 shadow-xl border-border/50 bg-card">
        {currentStep === 0 && <WelcomeScreen onNext={handleNext} />}
        {currentStep === 1 && <CompanyProfileSetup onNext={handleNext} onBack={handleBack} />}
        {currentStep === 2 && <RoleAssignmentSetup onNext={handleNext} onBack={handleBack} />}
        {currentStep === 3 && <LaunchScreen onComplete={onComplete} />}
      </Card>
    </div>
  );
}
