
import React, { useState } from 'react';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import OnboardingHeader from './OnboardingHeader.jsx';
import OnboardingFooter from './OnboardingFooter.jsx';
import { useCompanyContext } from '@/hooks/useCompanyContext.js';

export default function CompanyProfileSetup({ onNext, onBack }) {
  const { companyProfile, updateCompanyProfile } = useCompanyContext();
  
  const [formData, setFormData] = useState({
    companyName: companyProfile.name || '',
    industry: companyProfile.industry || '',
    crewSize: companyProfile.crewSize || ''
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleContinue = () => {
    updateCompanyProfile({
      name: formData.companyName,
      industry: formData.industry,
      crewSize: parseInt(formData.crewSize, 10) || 0
    });
    onNext();
  };

  const isValid = formData.companyName.trim() !== '' && formData.industry !== '' && formData.crewSize !== '';

  return (
    <div className="animate-in fade-in slide-in-from-right-4 duration-300">
      <OnboardingHeader 
        currentStep={1} 
        totalSteps={3} 
        title="Company Profile" 
        description="Tell us a bit about your organization to tailor your experience."
      />
      
      <div className="space-y-6 py-4">
        <div className="space-y-2">
          <Label htmlFor="companyName">Company Name <span className="text-destructive">*</span></Label>
          <Input 
            id="companyName" 
            value={formData.companyName} 
            onChange={(e) => handleChange('companyName', e.target.value)} 
            placeholder="e.g. Oceanic Logistics" 
            className="h-12 text-foreground"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="industry">Primary Industry <span className="text-destructive">*</span></Label>
          <Select 
            value={formData.industry} 
            onValueChange={(val) => handleChange('industry', val)}
          >
            <SelectTrigger id="industry" className="h-12 text-foreground">
              <SelectValue placeholder="Select industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Aviation">Aviation</SelectItem>
              <SelectItem value="Maritime">Maritime</SelectItem>
              <SelectItem value="Both">Both (Aviation & Maritime)</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="crewSize">Estimated Crew Size <span className="text-destructive">*</span></Label>
          <Input 
            id="crewSize" 
            type="number"
            min="1"
            value={formData.crewSize} 
            onChange={(e) => handleChange('crewSize', e.target.value)} 
            placeholder="e.g. 150" 
            className="h-12 text-foreground"
          />
        </div>
      </div>

      <OnboardingFooter 
        onBack={onBack} 
        onNext={handleContinue} 
        isNextDisabled={!isValid} 
      />
    </div>
  );
}
