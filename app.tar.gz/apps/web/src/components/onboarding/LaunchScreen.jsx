
import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { CheckCircle2, Loader2 } from 'lucide-react';
import { markOnboardingComplete } from '@/lib/lifecycleUtils.js';

export default function LaunchScreen({ onComplete }) {
  const [isProvisioning, setIsProvisioning] = useState(true);

  useEffect(() => {
    // Simulate provisioning delay
    const timer = setTimeout(() => {
      setIsProvisioning(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleLaunch = () => {
    markOnboardingComplete('current_user_id'); // In real app, pass actual user ID
    onComplete();
  };

  return (
    <div className="flex flex-col items-center justify-center text-center py-16 animate-in fade-in duration-500">
      {isProvisioning ? (
        <div className="flex flex-col items-center">
          <Loader2 className="w-16 h-16 text-primary animate-spin mb-6" />
          <h2 className="text-2xl font-bold text-foreground mb-2">Provisioning Workspace...</h2>
          <p className="text-muted-foreground">Setting up your environment and applying configurations.</p>
        </div>
      ) : (
        <div className="flex flex-col items-center animate-in zoom-in-95 duration-500">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-3xl font-bold text-foreground mb-4">You're All Set!</h2>
          <p className="text-lg text-muted-foreground max-w-[500px] mb-10">
            Your Operion control panel is ready. We've customized your experience based on your profile.
          </p>
          <Button size="lg" onClick={handleLaunch} className="text-lg px-8 h-14 rounded-full">
            Launch Control Panel
          </Button>
        </div>
      )}
    </div>
  );
}
