
import React from 'react';
import { Checkbox } from '@/components/ui/checkbox.jsx';
import { Label } from '@/components/ui/label.jsx';
import OnboardingHeader from './OnboardingHeader.jsx';
import OnboardingFooter from './OnboardingFooter.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Users, Ship, Activity } from 'lucide-react';

export default function InitialDataSetup({ data, updateData, onNext, onBack }) {
  const options = data.sampleData || { crew: true, fleet: true, movements: true };

  const toggleOption = (key) => {
    updateData({ sampleData: { ...options, [key]: !options[key] } });
  };

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <OnboardingHeader currentStep={4} totalSteps={5} title="Generate Starter Data" />
      <p className="text-gray-500 mb-6">Start with simulated data so your dashboard isn't empty. You can delete this later.</p>

      <div className="space-y-4">
        <Card>
          <CardContent className="p-4 flex items-start gap-4">
            <Checkbox id="data-crew" checked={options.crew} onCheckedChange={() => toggleOption('crew')} className="mt-1" />
            <div>
              <Label htmlFor="data-crew" className="text-base font-semibold flex items-center gap-2">
                <Users className="w-4 h-4" /> Crew Manifest Data
              </Label>
              <p className="text-sm text-gray-500">Generates 50+ mock crew members with certifications and schedules.</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-start gap-4">
            <Checkbox id="data-fleet" checked={options.fleet} onCheckedChange={() => toggleOption('fleet')} className="mt-1" />
            <div>
              <Label htmlFor="data-fleet" className="text-base font-semibold flex items-center gap-2">
                <Ship className="w-4 h-4" /> Fleet & Asset Data
              </Label>
              <p className="text-sm text-gray-500">Creates sample vessels or aircraft based on your selected industry.</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-start gap-4">
            <Checkbox id="data-movements" checked={options.movements} onCheckedChange={() => toggleOption('movements')} className="mt-1" />
            <div>
              <Label htmlFor="data-movements" className="text-base font-semibold flex items-center gap-2">
                <Activity className="w-4 h-4" /> Logistics & Movements
              </Label>
              <p className="text-sm text-gray-500">Populates historical and active crew movement plans for analytics.</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <OnboardingFooter onBack={onBack} onNext={onNext} nextLabel="Prepare Environment" />
    </div>
  );
}
