
import React from 'react';

export default function OnboardingHeader({ currentStep, totalSteps, title, description }) {
  const progress = Math.max(5, (currentStep / totalSteps) * 100);

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm font-medium text-muted-foreground tracking-wide uppercase">
          Step {currentStep} of {totalSteps}
        </span>
      </div>
      
      <div className="w-full h-2 bg-secondary rounded-full overflow-hidden mb-8">
        <div 
          className="h-full bg-primary transition-all duration-500 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>

      <h1 className="text-3xl font-bold text-foreground mb-2 tracking-tight">{title}</h1>
      {description && (
        <p className="text-lg text-muted-foreground">{description}</p>
      )}
    </div>
  );
}
