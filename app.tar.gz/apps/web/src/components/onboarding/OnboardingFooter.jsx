
import React from 'react';
import { Button } from '@/components/ui/button.jsx';

export default function OnboardingFooter({ 
  onBack, 
  onNext, 
  onSkip, 
  canSkip = false, 
  isNextDisabled = false,
  nextLabel = "Continue",
  showBack = true
}) {
  return (
    <div className="flex items-center justify-between pt-8 mt-8 border-t border-border">
      <div>
        {showBack && (
          <Button variant="ghost" onClick={onBack} className="text-muted-foreground">
            Back
          </Button>
        )}
      </div>
      <div className="flex items-center gap-3">
        {canSkip && onSkip && (
          <Button variant="ghost" onClick={onSkip} className="text-muted-foreground">
            Skip for now
          </Button>
        )}
        <Button onClick={onNext} disabled={isNextDisabled} className="min-w-[120px]">
          {nextLabel}
        </Button>
      </div>
    </div>
  );
}
