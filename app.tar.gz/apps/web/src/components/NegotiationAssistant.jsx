
import React, { useMemo, useState } from 'react';
import { MessageSquare as MessageSquareQuote, Scale, TrendingDown, Target, Layers, FileCheck, CheckCircle2, ChevronRight, FileText } from 'lucide-react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { generateNegotiationAssistant } from '@/lib/negotiationAssistant.js';

const NegotiationAssistant = ({ contract }) => {
  const [isPlanOpen, setIsPlanOpen] = useState(false);
  const aiData = useMemo(() => generateNegotiationAssistant(contract), [contract]);

  if (!contract || !aiData) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-muted/20 rounded-xl border border-dashed border-border h-full">
        <MessageSquareQuote className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
        <h3 className="text-lg font-medium text-foreground">Select a Contract</h3>
        <p className="text-muted-foreground text-sm mt-1">
          Choose a contract to generate an AI negotiation strategy.
        </p>
      </div>
    );
  }

  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  return (
    <div className="space-y-6">
      
      {/* Header Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-muted/30 p-4 rounded-xl border border-border">
        <div>
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <Scale className="w-5 h-5 text-primary" /> AI Strategy Engine
          </h3>
          <p className="text-sm text-muted-foreground mt-1">Confidence Score: {aiData.confidence_level}% based on 10k+ similar contracts</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" className="bg-background">
            <FileText className="w-4 h-4 mr-2" /> Export Strategy
          </Button>
          <Button onClick={() => setIsPlanOpen(true)} className="bg-primary text-primary-foreground hover:bg-primary/90">
            <MessageSquareQuote className="w-4 h-4 mr-2" /> View Full Plan
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Benchmarking & Timing */}
        <div className="space-y-6">
          <Card className="p-5 border-border shadow-sm">
            <div className="flex items-center gap-2 mb-4 text-foreground font-semibold">
              <Target className="w-4 h-4 text-primary" /> Price Benchmarking
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Market Benchmark</p>
                <p className="text-xl font-bold tabular-nums">{formatCurrency(aiData.price_benchmarking.market_benchmark)}</p>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border">
                <span className="text-sm font-medium">Current Price</span>
                <span className="font-semibold tabular-nums">{formatCurrency(aiData.price_benchmarking.current_price)}</span>
              </div>
              <Badge variant={aiData.price_benchmarking.variance_percentage > 0 ? 'destructive' : 'success'} className="w-full justify-center py-1">
                {Math.abs(aiData.price_benchmarking.variance_percentage)}% {aiData.price_benchmarking.recommendation}
              </Badge>
            </div>
          </Card>

          <Card className="p-5 border-border shadow-sm">
            <div className="flex items-center gap-2 mb-4 text-foreground font-semibold">
              <TrendingDown className="w-4 h-4 text-primary" /> Early Renewal Timing
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Optimal Window</p>
                <p className="text-sm font-medium">{aiData.early_renewal_timing.optimal_window}</p>
              </div>
              <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <p className="text-xs font-semibold text-emerald-700 uppercase tracking-wider mb-1">Projected Savings</p>
                <p className="text-xl font-bold text-emerald-700 tabular-nums">{formatCurrency(aiData.early_renewal_timing.cost_savings)}</p>
              </div>
              <ul className="space-y-2">
                {aiData.early_renewal_timing.risk_mitigation.map((risk, i) => (
                  <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{risk}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Card>
        </div>

        {/* Middle & Right Column: Tactics & Consolidation */}
        <div className="lg:col-span-2 space-y-6">
          
          <Card className="p-5 border-border shadow-sm border-l-4 border-l-primary">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-foreground font-semibold">
                <FileCheck className="w-4 h-4 text-primary" /> Renegotiation Strategy
              </div>
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                Target: {aiData.renegotiation_strategy.optimal_timing}
              </Badge>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">Primary Tactics</h4>
                <ul className="space-y-3">
                  {aiData.renegotiation_strategy.tactics.map((tactic, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2 bg-muted/30 p-2.5 rounded-md border border-border">
                      <ChevronRight className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      <span>{tactic}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-sm font-medium text-foreground mb-2">Leverage Points</h4>
                <ul className="space-y-2">
                  {aiData.renegotiation_strategy.leverage_points.map((point, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary shrink-0 mt-2" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-4 p-3 rounded-lg bg-background border border-border">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Expected Strategy Savings</p>
                  <p className="text-lg font-bold text-foreground tabular-nums">{formatCurrency(aiData.renegotiation_strategy.expected_savings)}</p>
                </div>
              </div>
            </div>
          </Card>

          <div className="grid sm:grid-cols-2 gap-6">
            <Card className="p-5 border-border shadow-sm">
              <div className="flex items-center gap-2 mb-4 text-foreground font-semibold">
                <Layers className="w-4 h-4 text-primary" /> Consolidation Opportunity
              </div>
              <div className="mb-4">
                <p className="text-3xl font-black text-foreground tabular-nums mb-1">{aiData.consolidation_opportunities.similar_contracts}</p>
                <p className="text-sm text-muted-foreground">Similar active contracts found</p>
              </div>
              <p className="text-sm font-medium text-foreground mb-1">Strategy</p>
              <p className="text-sm text-muted-foreground mb-3">{aiData.consolidation_opportunities.strategy}</p>
              <div className="pt-3 border-t border-border flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Timeline: {aiData.consolidation_opportunities.timeline}</span>
                <span className="text-sm font-bold text-emerald-600">{formatCurrency(aiData.consolidation_opportunities.potential_savings)}</span>
              </div>
            </Card>

            <Card className="p-5 border-border shadow-sm">
              <div className="flex items-center gap-2 mb-4 text-foreground font-semibold">
                <Scale className="w-4 h-4 text-primary" /> Penalty Leverage
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-xs font-medium text-foreground mb-2">Key Negotiation Points</p>
                  <ul className="space-y-2">
                    {aiData.penalty_leverage.negotiation_points.slice(0, 3).map((point, i) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0 mt-2" />
                        <span className="line-clamp-2">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>
          </div>

        </div>
      </div>

      <Dialog open={isPlanOpen} onOpenChange={setIsPlanOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageSquareQuote className="w-5 h-5 text-primary" />
              Generated Negotiation Plan
            </DialogTitle>
            <DialogDescription>
              AI-formulated strategy based on contract metadata and market benchmarks.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4 p-6 bg-muted/30 rounded-xl border border-border text-sm text-foreground whitespace-pre-wrap font-mono leading-relaxed">
            {aiData.negotiation_plan}
          </div>
          <div className="mt-6 flex justify-end gap-3">
            <Button variant="outline" onClick={() => setIsPlanOpen(false)}>Close</Button>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <FileText className="w-4 h-4 mr-2" /> Download Plan
            </Button>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
};

export default NegotiationAssistant;
