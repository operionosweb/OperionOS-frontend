
import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs.jsx';
import { BrainCircuit, X, Minimize2, Maximize2, RefreshCw, Sparkles } from 'lucide-react';
import { useAIIntelligence } from '@/hooks/useAIIntelligence.js';
import { useAuthGuard } from '@/hooks/useAuthGuard.js';
import AIInsightCard from './AIInsightCard.jsx';
import AIRecommendationList from './AIRecommendationList.jsx';
import { cn } from '@/lib/utils.js';

// Error Boundary for AI Panel
class AIErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error("AI Assistant Error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 text-center text-sm text-muted-foreground bg-card border border-border rounded-xl">
          <BrainCircuit className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p>AI Assistant temporarily unavailable.</p>
          <Button variant="outline" size="sm" className="mt-4" onClick={() => this.setState({ hasError: false })}>
            Retry
          </Button>
        </div>
      );
    }
    return this.props.children;
  }
}

function AIAssistantPanelContent({ isOpen, onClose, injectedContext }) {
  const [isMinimized, setIsMinimized] = useState(false);
  const { insights, recommendations, contextMetrics, isLoading, refreshInsights, clearInsights } = useAIIntelligence(injectedContext);
  const { isAuthenticated } = useAuthGuard();

  // Clear state on logout
  useEffect(() => {
    if (!isAuthenticated) {
      clearInsights();
    }
  }, [isAuthenticated, clearInsights]);

  if (!isOpen) return null;

  if (isMinimized) {
    return (
      <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-4">
        <Button 
          onClick={() => setIsMinimized(false)} 
          className="h-14 px-6 rounded-full shadow-xl bg-primary hover:bg-primary/90 text-primary-foreground flex items-center gap-3"
        >
          <BrainCircuit className="w-5 h-5" />
          <span className="font-semibold">AI Assistant Active</span>
          {insights.length > 0 && (
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-destructive text-destructive-foreground text-xs font-bold ml-1">
              {insights.length}
            </span>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[400px] bg-background border-l border-border shadow-2xl z-50 flex flex-col animate-in slide-in-from-right-full duration-300">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border bg-card">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-primary/10 rounded-lg">
            <BrainCircuit className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-base font-bold text-foreground leading-none">Operion AI</h2>
            <p className="text-xs text-muted-foreground mt-1">Intelligence Engine</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={refreshInsights} disabled={isLoading}>
            <RefreshCw className={cn("w-4 h-4", isLoading && "animate-spin")} />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={() => setIsMinimized(true)}>
            <Minimize2 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Context Summary */}
      <div className="p-4 bg-muted/30 border-b border-border grid grid-cols-3 gap-3">
        <div className="text-center">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Contracts</p>
          <p className="text-lg font-bold text-foreground">{contextMetrics?.contractCount || 0}</p>
        </div>
        <div className="text-center border-l border-r border-border">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Alerts</p>
          <p className="text-lg font-bold text-foreground">{contextMetrics?.alertCount || 0}</p>
        </div>
        <div className="text-center">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Insights</p>
          <p className="text-lg font-bold text-primary">{insights.length}</p>
        </div>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="insights" className="flex-1 flex flex-col overflow-hidden">
        <div className="px-4 pt-3 border-b border-border">
          <TabsList className="w-full grid grid-cols-2 bg-muted/50">
            <TabsTrigger value="insights" className="text-xs">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" /> Insights
            </TabsTrigger>
            <TabsTrigger value="actions" className="text-xs">
              Action Plan
            </TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="flex-1 p-4">
          <TabsContent value="insights" className="m-0 space-y-4 focus-visible:outline-none">
            {isLoading && insights.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <RefreshCw className="w-6 h-6 animate-spin mb-3 opacity-50" />
                <p className="text-sm">Analyzing context streams...</p>
              </div>
            ) : insights.length > 0 ? (
              insights.slice(0, 10).map(insight => (
                <AIInsightCard key={insight.id} insight={insight} />
              ))
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <p className="text-sm">No active insights detected.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="actions" className="m-0 focus-visible:outline-none">
            <AIRecommendationList recommendations={recommendations} />
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}

export default function AIAssistantPanel(props) {
  const { isAuthenticated, isLoading } = useAuthGuard();

  // Auth Gating: Return null if not authenticated
  if (isLoading || !isAuthenticated) {
    return null;
  }

  return (
    <AIErrorBoundary>
      <AIAssistantPanelContent {...props} />
    </AIErrorBoundary>
  );
}
