
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Card } from '@/components/ui/card.jsx';
import { calculateTotalPenaltyExposure } from '@/lib/penaltyExposureCalculator.js';

export default function PenaltyExposureSection({ penalties, currency = 'USD' }) {
  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(val);
  const totals = calculateTotalPenaltyExposure(penalties);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4 bg-card border-border shadow-sm">
          <p className="text-sm font-medium text-muted-foreground mb-1">Total Expected Exposure</p>
          <p className="text-2xl font-bold text-warning-foreground">{formatCurrency(totals.totalExpected)}</p>
        </Card>
        <Card className="p-4 bg-card border-border shadow-sm border-l-4 border-l-destructive">
          <p className="text-sm font-medium text-muted-foreground mb-1">Worst Case Scenario</p>
          <p className="text-2xl font-bold text-destructive">{formatCurrency(totals.totalWorstCase)}</p>
        </Card>
        <Card className="p-4 bg-card border-border shadow-sm">
          <p className="text-sm font-medium text-muted-foreground mb-1">Max Probability</p>
          <p className="text-2xl font-bold text-foreground">{totals.totalProbability}%</p>
        </Card>
      </div>

      <div className="rounded-xl border border-border overflow-hidden bg-card">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead>Penalty Type</TableHead>
              <TableHead>Trigger Condition</TableHead>
              <TableHead className="text-right">Probability</TableHead>
              <TableHead className="text-right">Expected Value</TableHead>
              <TableHead className="text-right">Worst Case</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {penalties.map((p, idx) => (
              <TableRow key={idx}>
                <TableCell className="font-medium text-foreground capitalize">{p.penaltyType.replace('_', ' ')}</TableCell>
                <TableCell className="text-muted-foreground text-sm">{p.triggerCondition}</TableCell>
                <TableCell className="text-right text-muted-foreground">{p.probability}%</TableCell>
                <TableCell className="text-right font-medium text-warning-foreground">{formatCurrency(p.expectedValue)}</TableCell>
                <TableCell className="text-right font-medium text-destructive">{formatCurrency(p.worstCaseAmount)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
