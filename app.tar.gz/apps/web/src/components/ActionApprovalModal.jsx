
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { AlertTriangle, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { useAuthGuard } from '@/hooks/useAuthGuard.js';

export default function ActionApprovalModal({ action, isOpen, onClose, onConfirm }) {
  const { user } = useAuthGuard();
  const [isConfirming, setIsConfirming] = useState(false);

  if (!action) return null;

  const handleConfirm = () => {
    setIsConfirming(true);
    // Small delay for UX feel
    setTimeout(() => {
      onConfirm();
      setIsConfirming(false);
    }, 400);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[450px] border-destructive/20">
        <DialogHeader>
          <div className="mx-auto w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
            <ShieldAlert className="w-6 h-6 text-destructive" />
          </div>
          <DialogTitle className="text-center text-xl">Confirm Execution</DialogTitle>
          <DialogDescription className="text-center">
            You are about to authorize an automated system action.
          </DialogDescription>
        </DialogHeader>

        <div className="my-4 p-4 rounded-lg bg-muted/50 border border-border space-y-3">
          <div>
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Action</p>
            <p className="text-sm font-medium text-foreground">{action.title}</p>
          </div>
          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-border/50">
            <div>
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Target Entities</p>
              <p className="text-sm font-medium text-foreground">{action.targetEntities?.length || 0}</p>
            </div>
            <div>
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Authorized By</p>
              <p className="text-sm font-medium text-foreground">{user?.name || 'Admin User'}</p>
            </div>
          </div>
        </div>

        <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-500">
          <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed">
            <strong className="block mb-1">Warning: System Modification</strong>
            This action will modify live system state. Ensure you have reviewed the expected impact. This action is logged for audit purposes.
          </div>
        </div>

        <DialogFooter className="mt-6 sm:justify-center gap-3">
          <Button variant="outline" onClick={onClose} disabled={isConfirming} className="w-full sm:w-auto">
            Cancel
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleConfirm} 
            disabled={isConfirming}
            className="w-full sm:w-auto gap-2"
          >
            {isConfirming ? 'Authorizing...' : 'Authorize & Execute'}
            {!isConfirming && <CheckCircle2 className="w-4 h-4" />}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
