
import React, { useEffect, useRef, useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Map, Navigation } from 'lucide-react';
import { generateAircraftRoutes } from '@/lib/investorModeHelpers.js';

const LiveAircraftMap = ({ fleetList = [] }) => {
  const canvasRef = useRef(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const { nodes, connections } = generateAircraftRoutes();
  
  // Animation state ref to avoid React state re-renders at 60fps
  const animState = useRef({
    aircraft: [],
    lastTime: 0
  });

  useEffect(() => {
    // Initialize aircraft positions based on fleet data
    if (!fleetList || fleetList.length === 0) {
      animState.current.aircraft = [];
      return;
    }

    const nodeKeys = Object.keys(nodes);
    if (nodeKeys.length === 0) {
      animState.current.aircraft = [];
      return;
    }
    
    animState.current.aircraft = fleetList
      .filter(asset => asset && typeof asset === 'object') // Validate asset exists and is an object
      .map((asset, i) => {
        const startIdx = i % nodeKeys.length;
        const endIdx = (i + 1) % nodeKeys.length;
        
        // Provide defensive defaults for all properties
        const assetId = asset.id || `aircraft-${i}`;
        const assetName = asset.name || asset.type || `Aircraft ${i + 1}`;
        const assetType = asset.type || 'Unknown';
        
        return {
          id: assetId,
          name: String(assetName), // Ensure name is always a string
          type: String(assetType),
          startNode: nodeKeys[startIdx],
          endNode: nodeKeys[endIdx],
          progress: Math.random(),
          speed: 0.0003 + (Math.random() * 0.0002)
        };
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fleetList]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    let animationFrameId;

    const draw = (timestamp) => {
      const deltaTime = animState.current.lastTime ? timestamp - animState.current.lastTime : 0;
      animState.current.lastTime = timestamp;

      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const width = canvas.width;
      const height = canvas.height;

      // Draw connections
      ctx.lineWidth = 2;
      ctx.strokeStyle = 'rgba(100, 116, 139, 0.2)'; // muted border
      connections.forEach(conn => {
        // Validate connection properties exist
        if (!conn || !conn.from || !conn.to) return;
        
        const n1 = nodes[conn.from];
        const n2 = nodes[conn.to];
        
        // Validate nodes exist and have coordinates
        if (!n1 || !n2 || typeof n1.x !== 'number' || typeof n1.y !== 'number' || 
            typeof n2.x !== 'number' || typeof n2.y !== 'number') {
          return;
        }
        
        ctx.beginPath();
        ctx.moveTo((n1.x / 100) * width, (n1.y / 100) * height);
        ctx.lineTo((n2.x / 100) * width, (n2.y / 100) * height);
        ctx.stroke();
      });

      // Update and draw aircraft
      animState.current.aircraft.forEach(ac => {
        // Validate aircraft object has required properties
        if (!ac || typeof ac.progress !== 'number' || typeof ac.speed !== 'number') {
          return;
        }

        ac.progress += ac.speed * deltaTime;
        
        if (ac.progress >= 1) {
          ac.progress = 0;
          ac.startNode = ac.endNode;
          
          // Pick random new destination connected to current node
          const possible = connections
            .filter(c => c && c.from && c.to && (c.from === ac.startNode || c.to === ac.startNode))
            .map(c => c.from === ac.startNode ? c.to : c.from);
          
          ac.endNode = possible.length > 0 ? possible[Math.floor(Math.random() * possible.length)] : Object.keys(nodes)[0];
        }

        const start = nodes[ac.startNode];
        const end = nodes[ac.endNode];
        
        // Validate start and end nodes exist with valid coordinates
        if (!start || !end || typeof start.x !== 'number' || typeof start.y !== 'number' ||
            typeof end.x !== 'number' || typeof end.y !== 'number') {
          return;
        }
        
        const currentX = start.x + (end.x - start.x) * ac.progress;
        const currentY = start.y + (end.y - start.y) * ac.progress;
        
        const px = (currentX / 100) * width;
        const py = (currentY / 100) * height;

        // Draw aircraft blip
        ctx.beginPath();
        ctx.arc(px, py, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#3b82f6'; // primary blue
        ctx.fill();
        
        // Draw pulse
        ctx.beginPath();
        ctx.arc(px, py, 8 + Math.sin(timestamp * 0.005) * 2, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(59, 130, 246, 0.4)';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Label - with defensive checks
        if (ac.name && typeof ac.name === 'string') {
          ctx.font = '10px Inter, system-ui, sans-serif';
          ctx.fillStyle = 'rgba(100, 116, 139, 0.8)';
          const labelText = ac.name.substring(0, 6);
          ctx.fillText(labelText, px + 10, py + 4);
        }
      });

      // Draw nodes
      Object.entries(nodes).forEach(([nodeKey, node]) => {
        // Validate node has required properties
        if (!node || typeof node.x !== 'number' || typeof node.y !== 'number') {
          return;
        }
        
        const px = (node.x / 100) * width;
        const py = (node.y / 100) * height;
        
        ctx.beginPath();
        ctx.arc(px, py, 6, 0, Math.PI * 2);
        ctx.fillStyle = '#0f172a'; // dark bg
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#cbd5e1'; // slate-300
        ctx.stroke();
        
        // Draw node label with defensive check
        if (node.name && typeof node.name === 'string') {
          ctx.font = '600 12px Inter, system-ui, sans-serif';
          ctx.fillStyle = '#475569'; // slate-600
          const textWidth = ctx.measureText(node.name).width;
          ctx.fillText(node.name, px - (textWidth / 2), py - 12);
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    animationFrameId = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [nodes, connections]);

  return (
    <Card className="border-border shadow-sm bg-card overflow-hidden col-span-full">
      <CardHeader className="pb-3 border-b border-border/50 flex flex-row items-center justify-between bg-muted/10">
        <CardTitle className="text-sm font-bold flex items-center gap-2 uppercase tracking-wider text-muted-foreground">
          <Map className="w-4 h-4 text-primary" /> Live European Airspace Simulation
        </CardTitle>
        <Badge variant="outline" className="font-mono text-xs tracking-tight bg-primary/5">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse mr-2 inline-block" />
          ACTIVE
        </Badge>
      </CardHeader>
      <CardContent className="p-0 relative bg-slate-50 dark:bg-slate-950/20">
        {/* Aspect ratio container */}
        <div className="relative w-full pb-[45%] min-h-[300px]">
          <canvas 
            ref={canvasRef} 
            className="absolute inset-0 w-full h-full"
            width={800}
            height={400}
            style={{ width: '100%', height: '100%' }}
          />
        </div>
        
        <div className="absolute bottom-4 left-4 bg-background/80 backdrop-blur-sm p-3 rounded-lg border border-border/50 text-xs shadow-sm">
          <div className="font-semibold mb-2 text-foreground flex items-center gap-1.5">
            <Navigation className="w-3 h-3 text-muted-foreground" />
            Legend
          </div>
          <div className="flex items-center gap-4 text-muted-foreground">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-primary block" /> Active Aircraft
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full border-2 border-slate-300 dark:border-slate-600 block" /> Route Node
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LiveAircraftMap;
