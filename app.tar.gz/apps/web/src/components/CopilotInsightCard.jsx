
import React, { useState } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';
import { AlertCircle, Info, Zap, ChevronDown, ChevronUp, X } from 'lucide-react';
import { cn } from '@/lib/utils.js';

export default function CopilotInsightCard({ alert, onDismiss, onExecute }) {
  const [isOpen, setIsOpen] = useState(false);

  const getSeverityConfig = (severity) => {
    switch (severity) {
      case 'critical': return { color: 'bg-destructive/10 text-destructive border-destructive/20', icon: AlertCircle, label: 'Critical' };
      case 'warning': return { color: 'bg-amber-500/10 text-amber-700 border-amber-500/20', icon: AlertCircle, label: 'Warning' };
      case 'info': 
      default: return { color: 'bg-blue-500/10 text-blue-700 border-blue-500/20', icon: Info, label: 'Info' };
    }
  };

  const config = getSeverityConfig(alert.severity);
  const Icon = config.icon;

  return (
    <Card className="overflow-hidden border-border bg-card shadow-sm hover:shadow-md transition-all group">
      <div className="p-4">
        <div className="flex items-start justify-between gap-3 mb-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className={cn("px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1", config.color)}>
              <Icon className="w-3 h-3" />
              {config.label}
            </Badge>
            <Badge variant="secondary" className="bg-muted text-muted-foreground text-[10px] font-mono">
              Score: {alert.priority}
            </Badge>
          </div>
          <button 
            onClick={() => onDismiss(alert.id)}
            className="text-muted-foreground opacity-0 group-hover:opacity-100 hover:text-foreground transition-opacity"
            aria-label="Dismiss"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        <h4 className="text-sm font-semibold text-foreground leading-snug mb-1.5">
          {alert.title}
        </h4>
        <p className="text-xs text-muted-foreground leading-relaxed">
          {alert.message}
        </p>

        <Collapsible open={isOpen} onOpenChange={setIsOpen} className="mt-3">
          <div className="flex items-center justify-between">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-primary hover:text-primary/80 hover:bg-primary/5 -ml-2">
                {isOpen ? 'Hide Details' : 'View Details'}
                {isOpen ? <ChevronUp className="w-3 h-3 ml-1" /> : <ChevronDown className="w-3 h-3 ml-1" />}
              </Button>
            </CollapsibleTrigger>
            {alert.suggestedActions?.length > 0 && (
              <Button 
                size="sm" 
                className="h-7 text-xs px-3 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => onExecute({ target: alert.relatedEntity, action: alert.suggestedActions[0] })}
              >
                Take Action
              </Button>
            )}
          </div>
          
          <CollapsibleContent className="pt-3 pb-1 animate-in fade-in slide-in-from-top-2">
            <div className="p-3 rounded-lg bg-muted/50 border border-border text-xs text-foreground space-y-2">
              <p>{alert.details}</p>
              {alert.suggestedActions?.length > 1 && (
                <div className="pt-2 border-t border-border/50">
                  <span className="font-semibold text-muted-foreground mb-1 block">Alternative Actions:</span>
                  <ul className="list-disc pl-4 text-muted-foreground">
                    {alert.suggestedActions.slice(1).map((act, i) => (
                      <li key={i} className="capitalize">{act.replace(/_/g, ' ')}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </Card>
  );
}
