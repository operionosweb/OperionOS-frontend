
import React from 'react';
import { useProductTier } from '@/hooks/useProductTier.js';
import UpgradePrompt from '@/components/UpgradePrompt.jsx';

export default function TierGate({ allowedTiers, feature, featureName, children, hideFallback = false }) {
  const { hasTierAccess, hasFeature } = useProductTier();

  let isAllowed = false;

  if (allowedTiers) {
    isAllowed = hasTierAccess(allowedTiers);
  } else if (feature) {
    isAllowed = hasFeature(feature);
  } else {
    isAllowed = true;
  }

  if (!isAllowed) {
    if (hideFallback) return null;
    
    // Determine the minimum required tier for the prompt
    const requiredTier = allowedTiers ? allowedTiers[0] : 'Professional';
    
    return (
      <UpgradePrompt 
        featureName={featureName || feature || 'This feature'} 
        requiredTier={requiredTier} 
      />
    );
  }

  return <>{children}</>;
}
