import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import MetricBadge from './MetricBadge.jsx';

const CrewManifestCard = ({ icon: Icon, title, description }) => {
  return (
    <Card className="p-6 border-none shadow-md bg-card flex flex-col md:flex-row gap-6 items-start md:items-center">
      <div className="flex-1">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <h3 className="text-xl font-bold text-foreground">{title}</h3>
        </div>
        <p className="text-muted-foreground">{description}</p>
      </div>
      <div className="flex gap-6 bg-muted/50 p-4 rounded-xl w-full md:w-auto">
        <MetricBadge label="Active Deployments" value="1,284" />
        <MetricBadge label="Compliance Rate" value="99.8%" className="text-[hsl(var(--tertiary))]" />
      </div>
    </Card>
  );
};

export default CrewManifestCard;