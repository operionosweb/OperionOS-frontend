import React from 'react';
import { Link } from 'react-router-dom';

const ICON_URL = "https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/0a6ef4c20a5fc168f5b6bb2c4a4331eb.png";
const FULL_URL = "https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/5909974ba8ca4bf20e5a9bd6fffb41ab.png";

const Logo = ({ variant = 'full', size = 'md', isClickable = true, className = "" }) => {
  const isIcon = variant === 'icon';
  const src = isIcon ? ICON_URL : FULL_URL;
  
  let sizeClasses = "";
  if (isIcon) {
    sizeClasses = size === 'sm' ? 'h-6' : size === 'md' ? 'h-8' : 'h-10';
  } else {
    sizeClasses = size === 'sm' ? 'h-6' : size === 'md' ? 'h-8' : 'h-10 md:h-12';
  }

  const imgElement = (
    <img 
      src={src} 
      alt="Operion Logo" 
      className={`object-contain ${sizeClasses} ${className}`}
    />
  );

  if (isClickable) {
    return (
      <Link 
        to="/" 
        className="inline-flex items-center justify-center hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-lg"
      >
        {imgElement}
      </Link>
    );
  }

  return <div className="inline-flex items-center justify-center">{imgElement}</div>;
};

export default Logo;