import React, { useState, useRef, useEffect } from 'react';
import { Info, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

const InfoTooltip = ({ label, tooltipText, children, className }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const containerRef = useRef(null);
  const tooltipRef = useRef(null);
  const [position, setPosition] = useState({ 
    top: 'auto', 
    bottom: '100%', 
    left: '50%', 
    transform: 'translateX(-50%)',
    arrowClass: 'bottom-[-5px] left-1/2 -translate-x-1/2 border-b border-r'
  });

  // Detect mobile screen size
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Handle click outside for desktop
  useEffect(() => {
    if (isMobile) return;

    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobile]);

  // Prevent body scroll when mobile sheet is open
  useEffect(() => {
    if (isMobile && isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobile, isOpen]);

  // Calculate desktop position
  useEffect(() => {
    if (!isMobile && isOpen && containerRef.current && tooltipRef.current) {
      const iconRect = containerRef.current.getBoundingClientRect();
      const tooltipRect = tooltipRef.current.getBoundingClientRect();
      const viewportWidth = window.innerWidth;
      
      let newPos = { ...position };
      let arrowClass = 'bottom-[-5px] left-1/2 -translate-x-1/2 border-b border-r';

      // Vertical positioning: prefer above, fallback below
      if (iconRect.top - tooltipRect.height - 12 < 0) {
        newPos.bottom = 'auto';
        newPos.top = 'calc(100% + 8px)';
        arrowClass = 'top-[-5px] left-1/2 -translate-x-1/2 border-t border-l';
      } else {
        newPos.bottom = 'calc(100% + 8px)';
        newPos.top = 'auto';
        arrowClass = 'bottom-[-5px] left-1/2 -translate-x-1/2 border-b border-r';
      }

      // Horizontal positioning: adjust if too close to screen edges
      const idealLeft = iconRect.left + iconRect.width / 2 - tooltipRect.width / 2;
      const idealRight = idealLeft + tooltipRect.width;

      if (idealLeft < 16) {
        newPos.left = '0%';
        newPos.right = 'auto';
        newPos.transform = 'translateX(-12px)';
        arrowClass = arrowClass.replace('left-1/2 -translate-x-1/2', 'left-[16px]');
      } else if (idealRight > viewportWidth - 16) {
        newPos.left = 'auto';
        newPos.right = '0%';
        newPos.transform = 'translateX(12px)';
        arrowClass = arrowClass.replace('left-1/2 -translate-x-1/2', 'right-[16px]');
      } else {
        newPos.left = '50%';
        newPos.right = 'auto';
        newPos.transform = 'translateX(-50%)';
      }

      newPos.arrowClass = arrowClass;
      setPosition(newPos);
    }
  }, [isOpen, isMobile]);

  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-center gap-2">
        {label && <label className="text-sm font-medium text-foreground">{label}</label>}
        <div 
          className="relative flex items-center" 
          ref={containerRef}
          onMouseEnter={() => !isMobile && setIsOpen(true)}
          onMouseLeave={() => !isMobile && setIsOpen(false)}
          onClick={() => setIsOpen(!isOpen)}
        >
          <Info className="w-4 h-4 text-muted-foreground cursor-pointer hover:text-foreground transition-colors" />
          
          <AnimatePresence>
            {isOpen && !isMobile && (
              <motion.div
                ref={tooltipRef}
                initial={{ opacity: 0, y: position.bottom === 'auto' ? -4 : 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: position.bottom === 'auto' ? -4 : 4 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
                style={{
                  top: position.top,
                  bottom: position.bottom,
                  left: position.left,
                  right: position.right,
                  transform: position.transform,
                }}
                className="absolute z-50 w-max max-w-[250px] p-3 bg-popover text-popover-foreground text-[13px] leading-relaxed rounded-xl shadow-[0_2px_8px_rgba(0,0,0,0.1)] border border-border pointer-events-none"
              >
                {tooltipText}
                <div className={cn("absolute w-2.5 h-2.5 bg-popover border-border rotate-45", position.arrowClass)} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      {children}

      {/* Mobile Bottom Sheet */}
      <AnimatePresence>
        {isOpen && isMobile && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[100] bg-background/80 backdrop-blur-sm"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 z-[101] bg-popover border-t border-border rounded-t-2xl shadow-2xl max-h-[90vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-center pt-3 pb-2">
                <div className="w-12 h-1.5 bg-muted rounded-full" />
              </div>
              <div className="px-6 pb-8 pt-2 overflow-y-auto">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-semibold text-foreground pr-4">{label || 'Information'}</h3>
                  <button 
                    onClick={() => setIsOpen(false)}
                    className="p-1 -mr-1 text-muted-foreground hover:text-foreground rounded-full hover:bg-muted transition-colors"
                    aria-label="Close tooltip"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {tooltipText}
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

export default InfoTooltip;