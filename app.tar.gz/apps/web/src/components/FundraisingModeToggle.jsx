
import React from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Diamond } from 'lucide-react';
import { useOperionOS } from '@/contexts/OperionOSContext.jsx';

const FundraisingModeToggle = () => {
  const { isDemo, isFundraisingMode, setIsFundraisingMode } = useOperionOS();

  if (!isDemo()) return null;

  return (
    <Button
      variant={isFundraisingMode ? "default" : "outline"}
      size="sm"
      onClick={() => setIsFundraisingMode(!isFundraisingMode)}
      className={`h-9 px-4 transition-all duration-300 font-semibold ${
        isFundraisingMode 
          ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-md border-indigo-600' 
          : 'border-border/50 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 dark:hover:bg-indigo-950/30 text-muted-foreground'
      }`}
    >
      <Diamond className={`w-4 h-4 mr-2 ${isFundraisingMode ? 'text-white' : 'text-indigo-500'}`} />
      {isFundraisingMode ? 'Fundraising Active' : 'Fundraising View'}
    </Button>
  );
};

export default FundraisingModeToggle;
