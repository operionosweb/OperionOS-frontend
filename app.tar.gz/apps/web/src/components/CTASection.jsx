import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const CTASection = () => {
  return (
    <section className="relative py-20 md:py-28 lg:py-32 bg-secondary text-secondary-foreground overflow-hidden">
      {/* Gradient overlay for depth */}
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-primary via-transparent to-transparent pointer-events-none"></div>
      
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 text-balance leading-tight">
            Ready to synchronize your global crew operations?
          </h2>
          
          <p className="text-lg md:text-xl text-secondary-foreground/90 mb-10 max-w-3xl mx-auto leading-relaxed">
            Join the next generation of aviation and maritime management. Deploy the operating system that transforms how you manage crew logistics, compliance, and disruptions in real-time.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              asChild 
              size="lg" 
              className="w-full sm:w-auto h-14 px-8 text-base font-bold bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg transition-all duration-300 active:scale-95"
            >
              <Link to="/contact-sales">
                Request Demo
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
            
            <Button 
              asChild 
              size="lg" 
              variant="outline" 
              className="w-full sm:w-auto h-14 px-8 text-base font-bold border-primary/30 text-primary hover:bg-primary/10 transition-all duration-300"
            >
              <Link to="/features">
                Explore Features
              </Link>
            </Button>
          </div>

          {/* Trust indicators */}
          <div className="mt-12 pt-8 border-t border-secondary-foreground/20 flex flex-col sm:flex-row items-center justify-center gap-8 text-sm text-secondary-foreground/70">
            <div className="flex items-center gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>No credit card required</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>30-minute personalized demo</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-primary font-bold">✓</span>
              <span>Enterprise-grade security</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;