
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Search, Command as CmdIcon, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

const CommandCenterSafeMode = ({ open, onOpenChange }) => {
  const [query, setQuery] = useState('');
  const [confirmAction, setConfirmAction] = useState(null);

  const staticCommands = [
    { id: 'maint', label: 'Schedule Maintenance', action: () => toast.success('Maintenance explicitly scheduled.') },
    { id: 'reassign', label: 'Reassign Crew', action: () => toast.success('Crew explicitly reassigned.') },
    { id: 'audit', label: 'Run Compliance Audit', action: () => toast.success('Audit successfully run.') }
  ];

  const handleExecute = (cmd) => {
    setConfirmAction(null);
    cmd.action();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl bg-card border border-border">
        {confirmAction ? (
          <div className="p-6 text-center space-y-4">
            <DialogTitle>Confirm Action</DialogTitle>
            <DialogDescription>Are you sure you want to execute: {confirmAction.label}?</DialogDescription>
            <div className="flex justify-center gap-3 mt-4">
              <Button variant="outline" onClick={() => setConfirmAction(null)}>Cancel</Button>
              <Button onClick={() => handleExecute(confirmAction)} className="bg-primary text-primary-foreground">
                <CheckCircle className="w-4 h-4 mr-2" /> Confirm
              </Button>
            </div>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><CmdIcon className="w-5 h-5 text-primary" /> Command Center</DialogTitle>
            </DialogHeader>
            <div className="flex items-center gap-2 mb-4">
              <Search className="w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search explicit commands..." 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {staticCommands
                .filter(cmd => cmd.label.toLowerCase().includes(query.toLowerCase()))
                .map(cmd => (
                  <Button
                    key={cmd.id}
                    variant="ghost"
                    className="w-full justify-start text-left font-normal border border-transparent hover:border-border/50 hover:bg-muted"
                    onClick={() => setConfirmAction(cmd)}
                  >
                    {cmd.label}
                  </Button>
                ))}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default CommandCenterSafeMode;
