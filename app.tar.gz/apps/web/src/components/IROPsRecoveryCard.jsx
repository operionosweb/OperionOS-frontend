import React from 'react';
import { Zap } from 'lucide-react';

const IROPsRecoveryCard = () => {
  return (
    <div className="bg-secondary text-secondary-foreground p-6 rounded-2xl shadow-lg border border-secondary-foreground/10 flex flex-col">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-[hsl(var(--tertiary))]/20 flex items-center justify-center">
          <Zap className="w-5 h-5 text-[hsl(var(--tertiary))]" />
        </div>
        <h3 className="text-lg font-bold text-white">IROPs Recovery</h3>
      </div>
      
      <p className="text-sm text-secondary-foreground/70 mb-6 leading-relaxed">
        AI-driven simulation engine automatically recalculates optimal crew recovery paths during irregular operations.
      </p>

      <div className="space-y-3">
        <div className="bg-white/5 border border-[hsl(var(--tertiary))]/30 p-3 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-[hsl(var(--tertiary))]"></div>
            <span className="text-sm font-medium text-white">Scenario Beta: Optimized</span>
          </div>
          <span className="text-sm font-bold text-[hsl(var(--tertiary))]">-$24k Loss</span>
        </div>
        
        <div className="bg-white/5 border border-destructive/30 p-3 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-destructive"></div>
            <span className="text-sm font-medium text-white">Scenario Alpha: Standard</span>
          </div>
          <span className="text-sm font-bold text-destructive">-$18k Loss</span>
        </div>
      </div>
    </div>
  );
};

export default IROPsRecoveryCard;