
import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { AlertCircle, Info, Zap, ShieldAlert, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils.js';
import { ACTION_STATUS } from '@/lib/ActionableAIEngine.js';

export default function ActionCard({ action, onReview, onCancel }) {
  const getSeverityConfig = (severity) => {
    switch (severity?.toLowerCase()) {
      case 'critical': return { color: 'bg-destructive/10 text-destructive border-destructive/20', icon: AlertCircle, label: 'Critical' };
      case 'warning': return { color: 'bg-amber-500/10 text-amber-700 border-amber-500/20', icon: ShieldAlert, label: 'Warning' };
      default: return { color: 'bg-blue-500/10 text-blue-700 border-blue-500/20', icon: Info, label: 'Info' };
    }
  };

  const getStatusConfig = (status) => {
    switch (status) {
      case ACTION_STATUS.COMPLETED: return { color: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20', icon: CheckCircle2, label: 'Completed' };
      case ACTION_STATUS.FAILED: return { color: 'bg-destructive/10 text-destructive border-destructive/20', icon: XCircle, label: 'Failed' };
      case ACTION_STATUS.EXECUTING: return { color: 'bg-primary/10 text-primary border-primary/20', icon: Zap, label: 'Executing...' };
      case ACTION_STATUS.CANCELLED: return { color: 'bg-muted text-muted-foreground border-border', icon: XCircle, label: 'Cancelled' };
      default: return null;
    }
  };

  const sevConfig = getSeverityConfig(action.severity);
  const statusConfig = getStatusConfig(action.status);
  const SevIcon = sevConfig.icon;
  
  const isPending = action.status === ACTION_STATUS.PENDING;

  return (
    <Card className={cn(
      "overflow-hidden border-border bg-card shadow-sm transition-all",
      isPending ? "hover:shadow-md hover:border-primary/30" : "opacity-75"
    )}>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="outline" className={cn("px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1", sevConfig.color)}>
              <SevIcon className="w-3 h-3" />
              {sevConfig.label}
            </Badge>
            <Badge variant="secondary" className="bg-muted text-muted-foreground text-[10px] font-mono">
              Priority: {action.priority}
            </Badge>
            {statusConfig && (
              <Badge variant="outline" className={cn("px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1", statusConfig.color)}>
                <statusConfig.icon className="w-3 h-3" />
                {statusConfig.label}
              </Badge>
            )}
          </div>
        </div>

        <h4 className="text-sm font-semibold text-foreground leading-snug mb-1.5">
          {action.title}
        </h4>
        <p className="text-xs text-muted-foreground leading-relaxed mb-4 line-clamp-2">
          {action.description}
        </p>

        <div className="grid grid-cols-2 gap-3 mb-4 p-3 rounded-lg bg-muted/40 border border-border/50">
          <div>
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Impact</p>
            <p className="text-xs font-medium text-foreground flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              {action.expectedImpact?.level || 'Unknown'}
            </p>
          </div>
          <div>
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-1">Entities</p>
            <p className="text-xs font-medium text-foreground flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-blue-500" />
              {action.targetEntities?.length || 0} Affected
            </p>
          </div>
        </div>

        {isPending && (
          <div className="flex items-center gap-2 pt-2 border-t border-border/50">
            <Button 
              size="sm" 
              className="flex-1 h-8 text-xs bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={() => onReview(action)}
            >
              Review Action
            </Button>
            <Button 
              size="sm" 
              variant="outline"
              className="h-8 px-3 text-xs text-muted-foreground hover:text-foreground"
              onClick={() => onCancel(action.id)}
            >
              Dismiss
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
