import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Zap, TrendingDown, TrendingUp, Clock, ArrowUpRight } from 'lucide-react';
import { calculateValueImpact } from '@/lib/fundraisingModeHelpers.js';

const formatCurrency = (val) => new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(val);

const OperationalValueImpact = ({ operationsData }) => {
  const impacts = calculateValueImpact(operationsData);

  const cards = [
    {
      title: 'Efficiency Gain',
      value: `+${impacts.efficiencyGain.value}%`,
      description: 'Fleet utilization & routing optimization',
      icon: <Zap className="w-5 h-5 text-emerald-500" />,
      bg: 'bg-emerald-50/50 dark:bg-emerald-950/20',
      border: 'border-emerald-100 dark:border-emerald-900/30'
    },
    {
      title: 'Cost Savings Estimate',
      value: formatCurrency(impacts.costSavings.value),
      description: 'Annualized reduction in OPEX',
      icon: <TrendingDown className="w-5 h-5 text-blue-500" />,
      bg: 'bg-blue-50/50 dark:bg-blue-950/20',
      border: 'border-blue-100 dark:border-blue-900/30'
    },
    {
      title: 'Revenue Uplift',
      value: `+${formatCurrency(impacts.revenueUplift.value)}`,
      description: 'From increased asset availability',
      icon: <TrendingUp className="w-5 h-5 text-indigo-500" />,
      bg: 'bg-indigo-50/50 dark:bg-indigo-950/20',
      border: 'border-indigo-100 dark:border-indigo-900/30'
    },
    {
      title: 'Delay Reduction Impact',
      value: formatCurrency(impacts.delayReduction.value),
      description: 'Saved from compensation & rebooking',
      icon: <Clock className="w-5 h-5 text-amber-500" />,
      bg: 'bg-amber-50/50 dark:bg-amber-950/20',
      border: 'border-amber-100 dark:border-amber-900/30'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, idx) => (
        <Card key={idx} className={`border ${card.border} shadow-sm hover:shadow-md transition-all duration-300 ${card.bg} overflow-hidden group`}>
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div className="p-2.5 bg-background rounded-xl shadow-sm border border-border/50 group-hover:scale-105 transition-transform duration-300">
                {card.icon}
              </div>
              <ArrowUpRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-medium text-muted-foreground tracking-wide">{card.title}</h3>
              <p className="text-2xl font-bold text-foreground tabular-nums tracking-tight">
                {card.value}
              </p>
              <p className="text-xs text-muted-foreground pt-1.5 leading-snug">
                {card.description}
              </p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default OperationalValueImpact;