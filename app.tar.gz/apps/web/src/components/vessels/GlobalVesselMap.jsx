import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, ZoomControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { useVesselTracking } from '@/hooks/useVesselTracking.js';
import VesselMarker from './VesselMarker.jsx';
import VesselDetailsPanel from './VesselDetailsPanel.jsx';
import { MapTouchHandler } from '@/hooks/useMapTouchControl.js';

const GlobalVesselMap = () => {
  const { vessels, isInitialized } = useVesselTracking();
  const [selectedVessel, setSelectedVessel] = useState(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleVesselClick = (vessel) => {
    setSelectedVessel(vessel);
  };

  const handleClosePanel = () => {
    setSelectedVessel(null);
  };

  if (!mounted || !isInitialized) {
    return (
      <div className="map-container bg-[#0a0f1a] animate-pulse rounded-2xl border border-white/10 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-gray-400 font-medium">Initializing Global Fleet Data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="map-container relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl shadow-black/50 bg-[#0B1220]">
      <MapContainer 
        center={[20, 0]} 
        zoom={3} 
        minZoom={2}
        maxZoom={10}
        style={{ height: '100%', width: '100%', background: '#0B1220' }}
        zoomControl={false}
        worldCopyJump={true}
      >
        <MapTouchHandler />
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        
        <ZoomControl position="bottomleft" />

        {vessels.map((vessel) => (
          <VesselMarker 
            key={vessel.id} 
            vessel={vessel} 
            onClick={handleVesselClick} 
          />
        ))}
      </MapContainer>
      
      {/* Map Overlay Gradient for depth */}
      <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_100px_rgba(11,18,32,0.8)] z-[400]" />

      {/* Details Panel */}
      {selectedVessel && (
        <VesselDetailsPanel 
          vessel={selectedVessel} 
          onClose={handleClosePanel} 
        />
      )}
    </div>
  );
};

export default GlobalVesselMap;