import React, { useMemo } from 'react';
import { Marker } from 'react-leaflet';
import L from 'leaflet';

const VesselMarker = ({ vessel, onClick }) => {
  const icon = useMemo(() => {
    let color = '#10B981'; // Emerald for On Route
    let shadowColor = 'rgba(16, 185, 129, 0.4)';
    
    if (vessel.status === 'Delayed') {
      color = '#EF4444'; // Red
      shadowColor = 'rgba(239, 68, 68, 0.4)';
    } else if (vessel.status === 'Docked') {
      color = '#F59E0B'; // Yellow
      shadowColor = 'rgba(245, 158, 11, 0.4)';
    }

    const svgString = `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="${color}" stroke="#ffffff" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(${vessel.heading}deg); filter: drop-shadow(0px 0px 4px ${shadowColor}); transition: transform 1s ease-in-out;">
        <path d="M2 12l10-10 10 10-2 8H4z"/>
      </svg>
    `;

    return L.divIcon({
      className: 'custom-vessel-marker bg-transparent border-0',
      html: `<div class="w-6 h-6 transition-all duration-1000 ease-linear hover:scale-125 cursor-pointer">${svgString}</div>`,
      iconSize: [24, 24],
      iconAnchor: [12, 12],
    });
  }, [vessel.status, vessel.heading]);

  return (
    <Marker 
      position={[vessel.currentPosition.lat, vessel.currentPosition.lng]} 
      icon={icon}
      eventHandlers={{
        click: () => onClick(vessel)
      }}
    />
  );
};

export default VesselMarker;