import React, { useEffect, useState } from 'react';
import { MapContainer as LeafletMap, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MapTouchHandler } from '@/hooks/useMapTouchControl.js';

// Fix Leaflet default icon issue in React
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const createCustomIcon = (status, isOwned) => {
  const color = status === 'Active' ? '#10B981' : status === 'Delayed' ? '#EF4444' : '#F59E0B';
  const size = isOwned ? 16 : 10;
  const border = isOwned ? 'border-2 border-white' : '';
  
  return L.divIcon({
    className: 'custom-vessel-marker',
    html: `<div style="background-color: ${color}; width: ${size}px; height: ${size}px; border-radius: 50%; box-shadow: 0 0 10px ${color};" class="${border}"></div>`,
    iconSize: [size, size],
    iconAnchor: [size/2, size/2]
  });
};

const MapUpdater = ({ center }) => {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, 5, { animate: true });
  }, [center, map]);
  return null;
};

const MapContainer = ({ vessels, onVesselClick }) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return <div className="map-container bg-[#0a0f1a] animate-pulse rounded-2xl border border-white/10" />;

  // Render only a subset if there are too many to keep performance smooth
  const displayVessels = vessels.slice(0, 150);

  return (
    <div className="map-container rounded-2xl overflow-hidden border border-white/10 relative z-0 shadow-2xl shadow-black/50">
      <LeafletMap 
        center={[20, 0]} 
        zoom={3} 
        style={{ height: '100%', width: '100%', background: '#0B1220' }}
        zoomControl={false}
      >
        <MapTouchHandler />
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        {displayVessels.map((vessel) => (
          <Marker 
            key={vessel.id} 
            position={[vessel.lat, vessel.lng]}
            icon={createCustomIcon(vessel.status, vessel.isOwned)}
            eventHandlers={{
              click: () => onVesselClick(vessel),
            }}
          >
            <Popup className="dark-popup">
              <div className="p-1">
                <div className="font-bold text-gray-900">{vessel.name}</div>
                <div className="text-xs text-gray-600">{vessel.type}</div>
                <div className="text-xs mt-1 font-medium text-blue-600">Click for details</div>
              </div>
            </Popup>
          </Marker>
        ))}
      </LeafletMap>
      
      {/* Map Overlay Gradient */}
      <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_100px_rgba(11,18,32,1)] z-[400]" />
    </div>
  );
};

export default MapContainer;