import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Ship, Users, AlertTriangle, DollarSign, Activity, Search, Filter, 
  CheckCircle2, X, ChevronRight, Clock, ShieldAlert, MapPin
} from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Card } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx';

export const OperationsDashboard = ({ vessels }) => {
  const owned = vessels.filter(v => v.isOwned);
  const totalCrew = owned.reduce((acc, v) => acc + v.crew.length, 0);
  const totalAlerts = owned.reduce((acc, v) => acc + v.alerts, 0);

  const metrics = [
    { label: 'My Fleet', value: owned.length, icon: Ship, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'Crew Onboard', value: totalCrew, icon: Users, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'Active Alerts', value: totalAlerts, icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/10' },
    { label: 'Monthly Cost', value: '€1.2M', icon: DollarSign, color: 'text-purple-400', bg: 'bg-purple-500/10' }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      {metrics.map((m, i) => (
        <Card key={i} className="glass-panel p-4 border-white/5">
          <div className="flex items-center gap-3 mb-2">
            <div className={`p-2 rounded-lg ${m.bg}`}><m.icon className={`h-5 w-5 ${m.color}`} /></div>
            <span className="text-sm text-gray-400 font-medium">{m.label}</span>
          </div>
          <div className="text-2xl font-bold text-white">{m.value}</div>
        </Card>
      ))}
    </div>
  );
};

export const SearchFilterBar = ({ onSearch, onToggleOwned, showOwnedOnly }) => (
  <div className="sticky top-20 z-40 glass-panel p-4 mb-6 flex flex-col md:flex-row gap-4 items-center justify-between border-b border-white/10">
    <div className="relative w-full md:w-96">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
      <Input 
        placeholder="Search vessel, IMO, port..." 
        className="pl-10 bg-black/20 border-white/10 text-white placeholder:text-gray-500"
        onChange={(e) => onSearch(e.target.value)}
      />
    </div>
    <div className="flex items-center gap-4 w-full md:w-auto">
      <Button variant="outline" className="border-white/10 text-gray-300 hover:text-white hover:bg-white/5">
        <Filter className="h-4 w-4 mr-2" /> Filters
      </Button>
      <Button 
        onClick={onToggleOwned}
        className={showOwnedOnly ? 'bg-primary text-white' : 'bg-white/5 text-gray-300 hover:bg-white/10'}
      >
        My Vessels Only
      </Button>
    </div>
  </div>
);

export const AIInsightsCard = ({ insight, onDismiss, onAction }) => {
  const colors = {
    warning: 'border-yellow-500/30 bg-yellow-500/5 text-yellow-400',
    success: 'border-emerald-500/30 bg-emerald-500/5 text-emerald-400',
    error: 'border-red-500/30 bg-red-500/5 text-red-400',
    info: 'border-blue-500/30 bg-blue-500/5 text-blue-400'
  };

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95 }}>
      <Card className={`p-4 border ${colors[insight.type]} relative overflow-hidden`}>
        <button onClick={() => onDismiss(insight.id)} className="absolute top-2 right-2 text-gray-500 hover:text-white">
          <X className="h-4 w-4" />
        </button>
        <h4 className="font-semibold mb-1 flex items-center gap-2">
          <Activity className="h-4 w-4" /> {insight.title}
        </h4>
        <p className="text-sm text-gray-300 mb-4">{insight.desc}</p>
        <Button size="sm" onClick={() => onAction(insight)} className="w-full bg-white/10 hover:bg-white/20 text-white">
          {insight.action}
        </Button>
      </Card>
    </motion.div>
  );
};

export const VesselProfilePanel = ({ vessel, onClose, onCrewClick }) => {
  if (!vessel) return null;

  return (
    <motion.div 
      initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
      className="fixed right-0 top-20 bottom-0 w-full md:w-[400px] glass-panel border-l border-white/10 z-50 overflow-y-auto p-6 shadow-2xl shadow-black"
    >
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white">{vessel.name}</h2>
          <p className="text-gray-400 text-sm">{vessel.type} • {vessel.imo}</p>
        </div>
        <button onClick={onClose} className="p-2 bg-white/5 rounded-full hover:bg-white/10"><X className="h-5 w-5" /></button>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
          <div className="text-xs text-gray-500 mb-1">Status</div>
          <div className={`font-medium ${vessel.status === 'Active' ? 'text-emerald-400' : 'text-yellow-400'}`}>{vessel.status}</div>
        </div>
        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
          <div className="text-xs text-gray-500 mb-1">Destination</div>
          <div className="font-medium text-white">{vessel.destination}</div>
        </div>
        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
          <div className="text-xs text-gray-500 mb-1">Speed</div>
          <div className="font-medium text-white">{vessel.speed} knots</div>
        </div>
        <div className="bg-black/20 p-3 rounded-lg border border-white/5">
          <div className="text-xs text-gray-500 mb-1">ETA</div>
          <div className="font-medium text-white">{vessel.eta}</div>
        </div>
      </div>

      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><Users className="h-5 w-5 text-primary"/> Crew Onboard ({vessel.crew.length})</h3>
      <div className="space-y-3">
        {vessel.crew.map(c => (
          <div key={c.id} onClick={() => onCrewClick(c)} className="p-3 bg-white/5 border border-white/5 rounded-xl cursor-pointer hover:bg-white/10 transition-colors flex justify-between items-center">
            <div>
              <div className="font-medium text-white">{c.name}</div>
              <div className="text-xs text-gray-400">{c.role}</div>
            </div>
            <div className="flex flex-col items-end gap-1">
              <Badge variant="outline" className={c.status === 'Onboard' ? 'border-emerald-500/30 text-emerald-400' : 'border-yellow-500/30 text-yellow-400'}>
                {c.status}
              </Badge>
              {c.compliance === 'Risk' && <ShieldAlert className="h-3 w-3 text-red-400" />}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

export const ActionModal = ({ isOpen, onClose, title, onConfirm, isProcessing }) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="bg-[#0B1220] border-white/10 text-white sm:max-w-md">
      <DialogHeader>
        <DialogTitle>{title}</DialogTitle>
      </DialogHeader>
      <div className="py-6 flex flex-col items-center justify-center min-h-[150px]">
        {isProcessing ? (
          <div className="flex flex-col items-center gap-4">
            <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-400">Processing request...</p>
          </div>
        ) : (
          <div className="text-center space-y-4">
            <p className="text-gray-300">Are you sure you want to proceed with this action? This will update the live system.</p>
            <div className="flex gap-3 justify-center mt-6">
              <Button variant="outline" onClick={onClose} className="border-white/10 text-white hover:bg-white/5">Cancel</Button>
              <Button onClick={onConfirm} className="bg-primary hover:bg-primary/90 text-white">Confirm Action</Button>
            </div>
          </div>
        )}
      </div>
    </DialogContent>
  </Dialog>
);