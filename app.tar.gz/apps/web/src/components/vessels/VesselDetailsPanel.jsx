import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Navigation, MapPin, Clock, Activity, Anchor, Ship } from 'lucide-react';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';

const VesselDetailsPanel = ({ vessel, onClose }) => {
  if (!vessel) return null;

  const getStatusColor = (status) => {
    switch (status) {
      case 'On Route': return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'Delayed': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'Docked': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const formatDate = (isoString) => {
    return new Date(isoString).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ x: '100%', opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: '100%', opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="absolute top-4 right-4 bottom-4 w-full max-w-sm z-[1000] pointer-events-auto"
      >
        <div className="h-full glass-panel flex flex-col overflow-hidden shadow-2xl shadow-black/50 border-white/10">
          {/* Header */}
          <div className="p-5 border-b border-white/10 flex justify-between items-start bg-white/5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Ship className="h-5 w-5 text-primary" />
                <h3 className="text-xl font-bold text-white">{vessel.name}</h3>
              </div>
              <p className="text-sm text-gray-400">{vessel.type}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-400 hover:text-white hover:bg-white/10 rounded-full h-8 w-8">
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6 hide-scrollbar">
            
            {/* Status & Speed */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-black/20 rounded-xl p-4 border border-white/5">
                <p className="text-xs text-gray-500 mb-2 uppercase tracking-wider font-semibold">Status</p>
                <Badge variant="outline" className={`${getStatusColor(vessel.status)} px-2 py-1`}>
                  {vessel.status}
                </Badge>
              </div>
              <div className="bg-black/20 rounded-xl p-4 border border-white/5">
                <p className="text-xs text-gray-500 mb-2 uppercase tracking-wider font-semibold">Speed</p>
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-blue-400" />
                  <span className="font-medium text-white">{vessel.speed.toFixed(1)} kts</span>
                </div>
              </div>
            </div>

            {/* Route Info */}
            <div className="bg-black/20 rounded-xl p-4 border border-white/5 space-y-4">
              <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                <Navigation className="h-4 w-4 text-primary" /> Voyage Details
              </h4>
              
              <div className="relative pl-6 space-y-4 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-0.5 before:bg-white/10">
                <div className="relative">
                  <div className="absolute -left-[29px] top-1 h-3 w-3 rounded-full bg-primary ring-4 ring-primary/20" />
                  <p className="text-xs text-gray-500 uppercase tracking-wider">Current Position</p>
                  <p className="text-sm text-white font-medium mt-0.5">
                    {vessel.currentPosition.lat.toFixed(4)}°, {vessel.currentPosition.lng.toFixed(4)}°
                  </p>
                  <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                    <Navigation className="h-3 w-3" style={{ transform: `rotate(${vessel.heading}deg)` }} />
                    Heading: {vessel.heading}°
                  </p>
                </div>
                
                <div className="relative">
                  <div className="absolute -left-[29px] top-1 h-3 w-3 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20" />
                  <p className="text-xs text-gray-500 uppercase tracking-wider">Destination</p>
                  <p className="text-sm text-white font-medium mt-0.5 flex items-center gap-1">
                    <MapPin className="h-3 w-3 text-emerald-400" /> {vessel.destination.port}
                  </p>
                  <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    ETA: {formatDate(vessel.eta)}
                  </p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-3 pt-2">
              <Button className="w-full bg-primary hover:bg-primary/90 text-white">
                View Full Itinerary
              </Button>
              <Button variant="outline" className="w-full border-white/10 text-gray-300 hover:text-white hover:bg-white/10">
                Contact Vessel
              </Button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default VesselDetailsPanel;