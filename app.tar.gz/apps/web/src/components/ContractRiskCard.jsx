
import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { ShieldAlert, Clock, DollarSign, ArrowRight } from 'lucide-react';
import { differenceInDays, parseISO } from 'date-fns';
import { cn } from '@/lib/utils.js';

export default function ContractRiskCard({ contract, onAcknowledge, onViewDetails }) {
  if (!contract) return null;

  const riskScore = contract.monitoring?.riskScore || 0;
  const penaltyAmount = contract.monitoring?.penaltyAmount || 0;
  const daysUntilExpiry = contract.expiry_date ? differenceInDays(parseISO(contract.expiry_date), new Date()) : null;
  
  let scoreColor = 'bg-success';
  let scoreText = 'text-success';
  if (riskScore > 60) {
    scoreColor = 'bg-destructive';
    scoreText = 'text-destructive';
  } else if (riskScore > 30) {
    scoreColor = 'bg-warning';
    scoreText = 'text-warning-foreground';
  }

  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  return (
    <Card className="p-5 flex flex-col h-full transition-all duration-300 hover:-translate-y-1 hover:shadow-lg border-border bg-card">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="font-bold text-lg text-foreground line-clamp-1" title={contract.asset_name || contract.company_name}>
            {contract.asset_name || contract.company_name}
          </h3>
          <p className="text-sm text-muted-foreground">{contract.contract_id}</p>
        </div>
        <Badge variant="outline" className={cn("font-bold", scoreText, "border-current")}>
          {contract.risk_level || 'Unknown'} Risk
        </Badge>
      </div>

      <div className="space-y-4 flex-grow">
        <div>
          <div className="flex justify-between text-sm mb-1.5">
            <span className="text-muted-foreground font-medium">Risk Score</span>
            <span className={cn("font-bold", scoreText)}>{riskScore}/100</span>
          </div>
          <Progress value={riskScore} className="h-2" indicatorClassName={scoreColor} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          {daysUntilExpiry !== null && (
            <div className="bg-muted/50 rounded-lg p-3 flex flex-col">
              <span className="text-xs text-muted-foreground flex items-center gap-1 mb-1">
                <Clock className="w-3 h-3" /> Expiry
              </span>
              <span className={cn("font-semibold text-sm", daysUntilExpiry < 30 ? "text-destructive" : "text-foreground")}>
                {daysUntilExpiry < 0 ? 'Expired' : `${daysUntilExpiry} days`}
              </span>
            </div>
          )}
          
          <div className="bg-muted/50 rounded-lg p-3 flex flex-col">
            <span className="text-xs text-muted-foreground flex items-center gap-1 mb-1">
              <DollarSign className="w-3 h-3" /> Value
            </span>
            <span className="font-semibold text-sm text-foreground">
              {formatCurrency(contract.contract_value)}
            </span>
          </div>
        </div>

        {penaltyAmount > 100000 && (
          <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 p-2.5 rounded-md border border-destructive/20">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span className="font-medium">High Penalty: {formatCurrency(penaltyAmount)}</span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 mt-5 pt-4 border-t border-border">
        <Button variant="outline" size="sm" className="flex-1 text-xs h-8" onClick={() => onViewDetails?.(contract)}>
          Details
        </Button>
        {riskScore > 60 && (
          <Button variant="default" size="sm" className="flex-1 text-xs h-8 bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => onAcknowledge?.(contract)}>
            Acknowledge
          </Button>
        )}
        {daysUntilExpiry !== null && daysUntilExpiry <= 90 && (
          <Button variant="secondary" size="sm" className="flex-1 text-xs h-8">
            Renew <ArrowRight className="w-3 h-3 ml-1" />
          </Button>
        )}
      </div>
    </Card>
  );
}
