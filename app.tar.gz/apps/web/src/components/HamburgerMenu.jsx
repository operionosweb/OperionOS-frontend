
import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Menu, X, LogOut, LayoutDashboard, Settings, HelpCircle, 
  BarChart3, FileSignature, Shield, Ship, Plane, Home, 
  Info, Star, CreditCard, Phone, FileText, ShieldCheck, UserPlus, LogIn
} from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { cn } from '@/lib/utils.js';

export default function HamburgerMenu({ user, onLogout }) {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef(null);
  const location = useLocation();

  const toggleMenu = () => setIsOpen(!isOpen);
  const closeMenu = () => setIsOpen(false);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        closeMenu();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Prevent body scroll when open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const isLinkActive = (href) => {
    if (href === '/' && location.pathname !== '/') return false;
    return location.pathname === href || location.pathname.startsWith(`${href}/`);
  };

  // Navigation Configurations
  const mainNav = [
    { name: 'Dashboard', href: '/control-panel', icon: LayoutDashboard },
    { name: 'Control Panel', href: '/control-panel', icon: Shield },
    { name: 'Fleet Contracts', href: '/control-panel', icon: FileSignature },
    { name: 'Maritime Operations', href: '/demo/maritime', icon: Ship },
    { name: 'Aviation Operations', href: '/demo/aviation', icon: Plane },
    { name: 'Analytics Intelligence', href: '/intelligence', icon: BarChart3 },
    { name: 'Settings', href: '/settings', icon: Settings },
  ];

  const generalNav = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'About Us', href: '/about', icon: Info },
    { name: 'Features', href: '/features', icon: Star },
    { name: 'Pricing', href: '/pricing', icon: CreditCard },
    { name: 'Contact', href: '/contact', icon: Phone },
    { name: 'Help & Support', href: '/contact-us', icon: HelpCircle },
  ];

  const legalNav = [
    { name: 'Terms of Service', href: '/terms-of-service', icon: FileText },
    { name: 'Privacy Policy', href: '/privacy-policy', icon: ShieldCheck },
  ];

  // User Profile Data
  const displayUser = user || null;
  const initials = displayUser?.user_metadata?.full_name
    ? displayUser.user_metadata.full_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
    : displayUser?.email?.substring(0, 2).toUpperCase() || 'U';
  const role = displayUser?.role || 'User';

  const renderNavLinks = (links) => (
    <div className="space-y-1">
      {links.map((link) => {
        const Icon = link.icon;
        const active = isLinkActive(link.href);
        return (
          <Link
            key={link.name}
            to={link.href}
            onClick={closeMenu}
            className={cn(
              "menu-link",
              active ? "menu-link-active" : "menu-link-inactive"
            )}
          >
            <Icon className={cn("w-5 h-5", active ? "text-primary" : "text-muted-foreground")} />
            {link.name}
          </Link>
        );
      })}
    </div>
  );

  return (
    <>
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={toggleMenu}
        aria-label="Open navigation menu"
        className="mr-2 hover:bg-muted/50"
      >
        <Menu className="h-6 w-6" />
      </Button>

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0, backdropFilter: "blur(0px)" }}
              animate={{ opacity: 1, backdropFilter: "blur(4px)" }}
              exit={{ opacity: 0, backdropFilter: "blur(0px)" }}
              transition={{ duration: 0.3 }}
              className="menu-backdrop"
              aria-hidden="true"
            />

            {/* Menu Panel */}
            <motion.div
              ref={menuRef}
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 250 }}
              className="menu-container"
              role="dialog"
              aria-modal="true"
              aria-label="Navigation menu"
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10">
                <Link to="/" onClick={closeMenu} className="flex items-center shrink-0">
                  <img 
                    src="https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/d4c3af1ba833729da85b67b90bdf2c04.png" 
                    alt="Operion Logo" 
                    className="h-7 w-auto"
                  />
                </Link>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={closeMenu}
                  aria-label="Close navigation menu"
                  className="text-muted-foreground hover:text-foreground hover:bg-muted rounded-full"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto py-4 px-4 hide-scrollbar">
                
                {/* User Profile Section (If Signed In) */}
                {displayUser && (
                  <div className="mb-6 p-4 rounded-2xl bg-muted/30 border border-border/50">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-bold text-lg shrink-0 shadow-sm">
                        {initials}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-base font-semibold text-foreground truncate">
                          {displayUser.user_metadata?.full_name || 'Authenticated User'}
                        </p>
                        <p className="text-sm text-muted-foreground truncate">
                          {displayUser.email}
                        </p>
                        <div className="mt-1 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                          {role}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Main Navigation (If Signed In) */}
                {displayUser && (
                  <>
                    <div className="mb-2 px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Platform
                    </div>
                    {renderNavLinks(mainNav)}
                    <div className="menu-section-separator" />
                  </>
                )}

                {/* General Navigation */}
                <div className="mb-2 px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Company
                </div>
                {renderNavLinks(generalNav)}

                {/* Legal Navigation (If Not Signed In) */}
                {!displayUser && (
                  <>
                    <div className="menu-section-separator" />
                    <div className="mb-2 px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      Legal
                    </div>
                    {renderNavLinks(legalNav)}
                  </>
                )}
              </div>

              {/* Footer Actions */}
              <div className="p-4 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                {displayUser ? (
                  <Button 
                    variant="outline" 
                    className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10 hover:border-destructive/20 transition-colors h-12 rounded-xl"
                    onClick={() => {
                      if (onLogout) onLogout();
                      closeMenu();
                    }}
                  >
                    <LogOut className="w-5 h-5 mr-3" />
                    <span className="font-medium">Log Out</span>
                  </Button>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      variant="outline"
                      className="w-full h-12 rounded-xl font-medium"
                      asChild
                      onClick={closeMenu}
                    >
                      <Link to="/login">
                        <LogIn className="w-4 h-4 mr-2" />
                        Log In
                      </Link>
                    </Button>
                    <Button 
                      className="w-full h-12 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 font-medium shadow-md"
                      asChild
                      onClick={closeMenu}
                    >
                      <Link to="/contact-sales">
                        <UserPlus className="w-4 h-4 mr-2" />
                        Sign Up
                      </Link>
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
