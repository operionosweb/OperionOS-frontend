import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { generatePitchNarrative, calculateMetricsSlide, calculateValuation } from '@/lib/investorPresentationHelpers.js';
import AutoMetricsSlide from './AutoMetricsSlide.jsx';
import ValuationSimulator from './ValuationSimulator.jsx';

const InvestorDeckPresentation = ({ operationsData, fleetData, crewData, onExit }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const narrative = generatePitchNarrative(operationsData, fleetData, crewData);
  const metrics = calculateMetricsSlide(operationsData, fleetData);

  const slides = [
    {
      id: 'problem',
      title: 'The Challenge',
      content: (
        <div className="max-w-4xl text-center">
          <p className="text-2xl md:text-3xl lg:text-4xl leading-relaxed text-muted-foreground font-medium">
            {narrative.problem}
          </p>
        </div>
      )
    },
    {
      id: 'solution',
      title: 'The Operion Solution',
      content: (
        <div className="max-w-4xl text-center">
          <p className="text-2xl md:text-3xl lg:text-4xl leading-relaxed text-primary font-medium">
            {narrative.solution}
          </p>
        </div>
      )
    },
    {
      id: 'metrics',
      title: 'Operational Impact',
      content: (
        <div className="w-full max-w-6xl">
          <AutoMetricsSlide operationsData={operationsData} fleetData={fleetData} />
        </div>
      )
    },
    {
      id: 'value',
      title: 'Financial Impact',
      content: (
        <div className="w-full max-w-6xl">
          <ValuationSimulator operationsData={operationsData} fleetData={fleetData} />
        </div>
      )
    },
    {
      id: 'readiness',
      title: 'Investment Readiness',
      content: (
        <div className="flex flex-col items-center justify-center space-y-8">
          <div className="relative flex items-center justify-center w-64 h-64 md:w-80 md:h-80">
            <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="transparent" stroke="currentColor" strokeWidth="8" className="text-muted/30" />
              <motion.circle
                cx="50" cy="50" r="42" fill="transparent" stroke="currentColor" strokeWidth="8" strokeLinecap="round"
                className="text-emerald-500 stroke-emerald-500"
                strokeDasharray={2 * Math.PI * 42}
                initial={{ strokeDashoffset: 2 * Math.PI * 42 }}
                animate={{ strokeDashoffset: (2 * Math.PI * 42) - ((metrics.investmentReadinessScore / 100) * (2 * Math.PI * 42)) }}
                transition={{ duration: 1.5, ease: "easeOut" }}
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="text-7xl md:text-8xl font-black text-foreground tabular-nums tracking-tighter">
                {metrics.investmentReadinessScore}
              </span>
              <span className="text-lg font-medium text-muted-foreground">/ 100</span>
            </div>
          </div>
          <div className="text-center max-w-2xl">
            <h3 className="text-2xl font-bold text-foreground mb-2">Excellent Operational Foundation</h3>
            <p className="text-muted-foreground text-lg">{narrative.scalability}</p>
          </div>
        </div>
      )
    }
  ];

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => Math.min(prev + 1, slides.length - 1));
  }, [slides.length]);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => Math.max(prev - 1, 0));
  }, []);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowRight' || e.key === ' ') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
      if (e.key === 'Escape') onExit();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide, onExit]);

  const slideVariants = {
    enter: (direction) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const [direction, setDirection] = useState(0);

  const handleNext = () => {
    setDirection(1);
    nextSlide();
  };

  const handlePrev = () => {
    setDirection(-1);
    prevSlide();
  };

  return (
    <div className="presentation-mode">
      <button 
        onClick={onExit}
        className="absolute top-6 right-6 z-50 p-3 bg-background/50 hover:bg-background backdrop-blur-md rounded-full border border-border/50 text-foreground transition-all no-print"
      >
        <X className="w-6 h-6" />
      </button>

      <div className="flex-1 relative overflow-hidden">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentSlide}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ x: { type: "spring", stiffness: 300, damping: 30 }, opacity: { duration: 0.2 } }}
            className="presentation-slide absolute inset-0"
          >
            <div className="presentation-content">
              <h2 className="presentation-title text-center">{slides[currentSlide].title}</h2>
              <div className="flex-1 flex items-center justify-center w-full">
                {slides[currentSlide].content}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="presentation-controls no-print">
        <div className="flex items-center gap-4">
          <button 
            onClick={handlePrev}
            disabled={currentSlide === 0}
            className="p-3 rounded-full bg-background border border-border/50 text-foreground disabled:opacity-30 hover:bg-muted transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button 
            onClick={handleNext}
            disabled={currentSlide === slides.length - 1}
            className="p-3 rounded-full bg-background border border-border/50 text-foreground disabled:opacity-30 hover:bg-muted transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
        <div className="text-sm font-medium text-muted-foreground tracking-widest uppercase">
          Slide {currentSlide + 1} of {slides.length}
        </div>
      </div>
    </div>
  );
};

export default InvestorDeckPresentation;