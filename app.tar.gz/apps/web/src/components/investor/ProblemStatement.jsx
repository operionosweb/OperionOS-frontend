
import React from 'react';
import { AlertTriangle, Clock, DollarSign, ShieldAlert } from 'lucide-react';

export default function ProblemStatement() {
  return (
    <section className="space-y-6">
      <div className="mb-8">
        <h3 className="text-2xl font-semibold tracking-tight mb-2">The Industry Challenge</h3>
        <p className="text-muted-foreground max-w-[65ch] leading-relaxed">
          Crew movement operations remain highly fragmented, relying on legacy systems and manual coordination. This creates significant operational friction, escalating costs, and compliance risks across global supply chains.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="flex gap-4">
          <div className="flex-shrink-0 mt-1">
            <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center text-destructive">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div>
            <h4 className="text-lg font-medium text-foreground mb-2">Escalating Operational Costs</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Inefficient routing, last-minute bookings, and lack of consolidated purchasing power lead to a 20-30% premium on standard logistics costs.
            </p>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex-shrink-0 mt-1">
            <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-600">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div>
            <h4 className="text-lg font-medium text-foreground mb-2">Coordination Friction</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Siloed communication between operators, agencies, and crew members results in delays, missed connections, and extensive manual rework.
            </p>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex-shrink-0 mt-1">
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-600">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div>
            <h4 className="text-lg font-medium text-foreground mb-2">Disruption Vulnerability</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Inability to dynamically respond to weather, geopolitical events, or schedule changes causes cascading failures across the network.
            </p>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="flex-shrink-0 mt-1">
            <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center text-red-600">
              <ShieldAlert className="w-5 h-5" />
            </div>
          </div>
          <div>
            <h4 className="text-lg font-medium text-foreground mb-2">Compliance & Fatigue Risks</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Manual tracking of work-rest hours and visa requirements exposes organizations to severe regulatory penalties and safety incidents.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
