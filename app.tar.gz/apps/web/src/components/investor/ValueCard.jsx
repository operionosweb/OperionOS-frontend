
import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';

export default function ValueCard({ label, value, unit, prefix = "", icon: Icon }) {
  return (
    <Card className="shadow-md border-border bg-card overflow-hidden relative group">
      <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity duration-300 pointer-events-none">
        {Icon && <Icon className="w-24 h-24" />}
      </div>
      <CardContent className="p-6 relative z-10">
        <div className="flex items-center gap-3 mb-4">
          {Icon && (
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
              <Icon className="w-5 h-5" />
            </div>
          )}
          <h3 className="font-semibold text-foreground">{label}</h3>
        </div>
        <div className="flex items-baseline gap-1">
          {prefix && <span className="text-2xl font-semibold text-foreground/80">{prefix}</span>}
          <span className="text-4xl font-extrabold tracking-tight text-foreground" style={{ fontVariantNumeric: 'tabular-nums' }}>
            {value}
          </span>
          {unit && <span className="text-base font-medium text-muted-foreground ml-1">{unit}</span>}
        </div>
      </CardContent>
    </Card>
  );
}
