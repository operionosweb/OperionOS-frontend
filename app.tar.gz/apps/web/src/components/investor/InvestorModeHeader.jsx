
import React from 'react';
import { CompanySelector } from '@/components/CompanySelector.jsx';
import { Button } from '@/components/ui/button.jsx';
import { RefreshCw, Download } from 'lucide-react';

export default function InvestorModeHeader({ onRefresh }) {
  return (
    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-6 border-b border-border">
      <div>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground">Investor Mode</h2>
        <p className="text-muted-foreground mt-1">Deterministic performance snapshot and value creation metrics.</p>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <CompanySelector />
        <Button variant="outline" onClick={onRefresh} className="gap-2">
          <RefreshCw className="w-4 h-4" />
          Refresh Snapshot
        </Button>
        <Button variant="secondary" className="gap-2">
          <Download className="w-4 h-4" />
          Export Report
        </Button>
      </div>
    </div>
  );
}
