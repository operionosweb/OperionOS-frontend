
import React from 'react';
import { Layers, Zap, BarChart3, Globe } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';

export default function SolutionSection() {
  return (
    <section className="space-y-8">
      <div>
        <h3 className="text-2xl font-semibold tracking-tight mb-2">The Operion Solution</h3>
        <p className="text-muted-foreground max-w-[65ch] leading-relaxed">
          A unified, deterministic platform that orchestrates complex crew logistics through intelligent automation, real-time visibility, and predictive risk management.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2 bg-secondary text-secondary-foreground border-none shadow-lg">
          <CardContent className="p-8 h-full flex flex-col justify-center">
            <Layers className="w-10 h-10 text-primary mb-6" />
            <h4 className="text-xl font-bold mb-3">Unified Orchestration Engine</h4>
            <p className="text-secondary-foreground/80 leading-relaxed max-w-prose">
              Operion replaces fragmented legacy tools with a single source of truth. By integrating HR, travel, and operational data, the platform automates end-to-end movement lifecycles, ensuring deterministic execution and eliminating manual handoffs.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardContent className="p-6 h-full flex flex-col">
            <Zap className="w-8 h-8 text-primary mb-4" />
            <h4 className="text-lg font-semibold mb-2">Predictive Resolution</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Advanced algorithms detect potential disruptions before they occur, automatically proposing optimized recovery scenarios to minimize downtime and cost.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardContent className="p-6 h-full flex flex-col">
            <BarChart3 className="w-8 h-8 text-primary mb-4" />
            <h4 className="text-lg font-semibold mb-2">Financial Intelligence</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Real-time cost tracking and automated reconciliation provide unprecedented visibility into logistics spend, driving immediate margin improvements.
            </p>
          </CardContent>
        </Card>

        <Card className="md:col-span-2 bg-muted border-none shadow-sm">
          <CardContent className="p-8 h-full flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-background flex items-center justify-center shadow-sm">
              <Globe className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-2">Global Compliance Automation</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Built-in regulatory frameworks automatically validate visas, certifications, and work-rest hours against global maritime and aviation standards, reducing compliance risk to near zero.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
