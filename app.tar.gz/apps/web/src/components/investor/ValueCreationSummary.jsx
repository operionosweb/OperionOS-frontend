
import React from 'react';
import ValueCard from './ValueCard.jsx';
import { TrendingDown, TrendingUp, Activity, ShieldCheck } from 'lucide-react';

export default function ValueCreationSummary({ snapshot }) {
  if (!snapshot) return null;
  const { valueCreation } = snapshot;

  const formatCurrency = (val) => {
    if (val >= 1000000) return `${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `${(val / 1000).toFixed(1)}K`;
    return val.toString();
  };

  return (
    <section className="space-y-6">
      <h3 className="text-xl font-semibold tracking-tight">Value Creation Summary</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ValueCard 
          label="Annual Cost Savings" 
          prefix="$"
          value={formatCurrency(valueCreation.costSavings)} 
          icon={TrendingDown}
        />
        <ValueCard 
          label="Revenue Increase" 
          prefix="$"
          value={formatCurrency(valueCreation.revenueIncrease)} 
          icon={TrendingUp}
        />
        <ValueCard 
          label="Efficiency Gains" 
          value={`+${valueCreation.efficiencyGains}`} 
          unit="%"
          icon={Activity}
        />
        <ValueCard 
          label="Risk Reduction" 
          value={`-${valueCreation.riskReduction}`} 
          unit="%"
          icon={ShieldCheck}
        />
      </div>
    </section>
  );
}
