
import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';

export default function InvestmentReadinessScore({ snapshot }) {
  if (!snapshot) return null;
  const { readiness } = snapshot;

  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (readiness.overall / 100) * circumference;

  return (
    <Card className="border border-gray-200 shadow-sm">
      <CardContent className="p-8 grid grid-cols-1 md:grid-cols-3 gap-12 items-center">
        
        {/* 120px Circular Score */}
        <div className="flex flex-col items-center justify-center col-span-1">
          <div className="relative w-[120px] h-[120px] flex items-center justify-center rounded-full bg-[#3B82F6] text-white shadow-md">
            <svg className="absolute inset-0 w-full h-full transform -rotate-90 pointer-events-none" viewBox="0 0 120 120">
              <circle cx="60" cy="60" r={radius} fill="transparent" stroke="rgba(255,255,255,0.2)" strokeWidth="6" />
              <circle
                cx="60" cy="60" r={radius} fill="transparent" stroke="white" strokeWidth="6"
                strokeDasharray={circumference} strokeDashoffset={strokeDashoffset} strokeLinecap="round"
                className="transition-all duration-1000 ease-out"
              />
            </svg>
            <div className="flex flex-col items-center justify-center z-10">
              <span className="text-[36px] font-bold leading-none tracking-tight">{readiness.overall}</span>
            </div>
          </div>
          <p className="mt-4 text-center text-sm font-semibold text-gray-900 uppercase tracking-wide">Readiness Score</p>
        </div>

        <div className="col-span-1 md:col-span-2 space-y-6">
          {[
            { label: 'Operational Excellence', score: readiness.operational },
            { label: 'Financial Health', score: readiness.financial },
            { label: 'Scalability', score: readiness.scalability },
            { label: 'Market Readiness', score: readiness.market }
          ].map((item) => (
            <div key={item.label} className="space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="font-medium text-gray-700">{item.label}</span>
                <span className="font-bold text-gray-900 tabular-nums">{item.score}/100</span>
              </div>
              <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full bg-[#3B82F6] rounded-full transition-all duration-500 ease-out" style={{ width: `${item.score}%` }} />
              </div>
            </div>
          ))}
        </div>

      </CardContent>
    </Card>
  );
}
