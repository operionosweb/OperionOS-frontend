
import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';

export default function KPICard({ label, value, unit, prefix = "" }) {
  return (
    <Card className="shadow-sm border-border bg-card">
      <CardContent className="p-6 flex flex-col justify-center h-full">
        <p className="text-sm font-medium text-muted-foreground mb-2">{label}</p>
        <div className="flex items-baseline gap-1">
          {prefix && <span className="text-xl font-semibold text-foreground/80">{prefix}</span>}
          <span className="text-3xl font-bold tracking-tight text-foreground" style={{ fontVariantNumeric: 'tabular-nums' }}>
            {value}
          </span>
          {unit && <span className="text-sm font-medium text-muted-foreground ml-1">{unit}</span>}
        </div>
      </CardContent>
    </Card>
  );
}
