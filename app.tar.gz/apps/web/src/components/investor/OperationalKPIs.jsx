
import React from 'react';
import KPICard from './KPICard.jsx';

export default function OperationalKPIs({ snapshot }) {
  if (!snapshot) return null;
  const { kpis } = snapshot;

  return (
    <section className="space-y-6">
      <h3 className="text-xl font-semibold tracking-tight">Operational Performance</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
        <KPICard 
          label="Total Movements" 
          value={kpis.totalMovements.toLocaleString()} 
        />
        <KPICard 
          label="On-Time Delivery Rate" 
          value={kpis.onTimeRate} 
          unit="%" 
        />
        <KPICard 
          label="Cost per Movement" 
          prefix="$"
          value={kpis.costPerMovement.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} 
        />
        <KPICard 
          label="Crew Utilization" 
          value={kpis.crewUtilization} 
          unit="%" 
        />
        <KPICard 
          label="Compliance Score" 
          value={kpis.complianceScore} 
          unit="/ 100" 
        />
        <KPICard 
          label="Revenue per Movement" 
          prefix="$"
          value={kpis.revenuePerMovement.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} 
        />
      </div>
    </section>
  );
}
