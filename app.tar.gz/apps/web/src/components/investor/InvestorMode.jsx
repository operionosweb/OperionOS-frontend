
import React, { useState, useEffect } from 'react';
import { computeSnapshot } from '@/lib/snapshotCalculations.js';
import MetricCard from '@/components/MetricCard.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Activity, Anchor, ShieldCheck, DollarSign, Users, Target } from 'lucide-react';
import InvestmentReadinessScore from './InvestmentReadinessScore.jsx';

export default function InvestorMode({ companyId }) {
  const [snapshot, setSnapshot] = useState(null);
  
  useEffect(() => {
    setSnapshot(computeSnapshot(companyId));
  }, [companyId]);

  if (!snapshot) return null;
  const { kpis } = snapshot;

  return (
    <div className="w-full min-h-screen bg-white">
      {/* Gradient Header */}
      <div className="w-full px-8 py-12 text-white" style={{ background: 'linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)' }}>
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <h1 className="text-4xl font-bold tracking-tight mb-2">Investor Mode</h1>
            <p className="text-white/80 text-lg">Deterministic performance and readiness metrics.</p>
          </div>
          <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
            Export Report
          </Button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-8 py-12 space-y-12">
        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 border-b border-gray-200 pb-12">
          <MetricCard label="On-Time Delivery" value={kpis.onTimeRate} unit="%" icon={Target} />
          <MetricCard label="Cost per Movement" value={`$${kpis.costPerMovement.toFixed(0)}`} icon={DollarSign} />
          <MetricCard label="Crew Utilization" value={kpis.crewUtilization} unit="%" icon={Users} />
          <MetricCard label="Compliance Score" value={kpis.complianceScore} unit="/100" icon={ShieldCheck} />
          <MetricCard label="Revenue per Movement" value={`$${kpis.revenuePerMovement.toFixed(0)}`} icon={Activity} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 border-b border-gray-200 pb-12">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">The Problem</h3>
            <p className="text-gray-600 leading-relaxed">
              Crew movement operations remain highly fragmented, relying on legacy systems and manual coordination. This creates significant operational friction, escalating costs by 20-30%, and exposing organizations to severe compliance risks.
            </p>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">The Solution</h3>
            <p className="text-gray-600 leading-relaxed">
              A unified, deterministic platform that orchestrates complex crew logistics through intelligent automation, real-time visibility, and predictive risk management, driving immediate margin improvements.
            </p>
          </div>
        </div>

        <InvestmentReadinessScore snapshot={snapshot} />
      </div>
    </div>
  );
}
