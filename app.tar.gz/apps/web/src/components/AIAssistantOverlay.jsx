import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, X, Sparkles, Send, Loader2 } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { useOperionOS } from '@/contexts/OperionOSContext.jsx';

const AIAssistantOverlay = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  
  const { activeTab, getActiveLayer, isDemo } = useOperionOS();

  // Context-aware greeting
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const layer = getActiveLayer() === 'DEMO_LAYER' ? 'Simulation' : 'Production';
      setMessages([
        {
          id: 1,
          role: 'ai',
          content: `Operion Intelligence Online. Analyzing ${layer} context for the **${activeTab.toUpperCase()}** view. How can I optimize your operations today?`,
          insights: getContextualInsights(activeTab, isDemo())
        }
      ]);
    }
  }, [isOpen, activeTab, getActiveLayer, isDemo, messages.length]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const getContextualInsights = (tab, demo) => {
    if (!demo) return [];
    switch(tab) {
      case 'overview': return ['Detecting 3 minor schedule deviations', 'Fleet utilization at 82%'];
      case 'crew': return ['2 standbys approaching duty limits', 'Recommend roster swap for Route 7'];
      case 'simulation': return ['ROI projected at 18.4% for current setup'];
      default: return ['All systems nominal'];
    }
  };

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = { id: Date.now(), role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMsg = {
        id: Date.now() + 1,
        role: 'ai',
        content: `I've analyzed the request across the current ${getActiveLayer() === 'DEMO_LAYER' ? 'simulation dataset' : 'live data feed'}. Based on the operational constraints, executing this action is recommended.`
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <>
      <AnimatePresence>
        {!isOpen && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            className="fixed bottom-6 right-6 z-50"
          >
            <Button 
              onClick={() => setIsOpen(true)}
              className="h-14 w-14 rounded-full bg-primary hover:bg-primary/90 shadow-xl flex items-center justify-center p-0"
            >
              <Bot className="w-6 h-6 text-primary-foreground" />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed bottom-6 right-6 z-50 w-full max-w-[380px] origin-bottom-right"
          >
            <Card className="border-border/50 shadow-2xl bg-card overflow-hidden flex flex-col h-[600px] max-h-[80vh]">
              <CardHeader className="py-3 px-4 bg-muted/30 border-b border-border/50 flex flex-row items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-primary/10 rounded-md">
                    <Sparkles className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-sm font-bold">Operion Intelligence</CardTitle>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">
                      Context: {activeTab}
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setIsOpen(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </CardHeader>
              
              <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((msg) => (
                  <div key={msg.id} className={`flex flex-col gap-1.5 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                    <div className={`px-4 py-2.5 rounded-2xl max-w-[85%] text-sm leading-relaxed ${
                      msg.role === 'user' 
                        ? 'bg-primary text-primary-foreground rounded-tr-sm' 
                        : 'bg-muted/50 text-foreground rounded-tl-sm border border-border/50'
                    }`}>
                      {msg.content}
                    </div>
                    {msg.insights && msg.insights.length > 0 && (
                      <div className="flex flex-col gap-1.5 mt-1">
                        {msg.insights.map((insight, idx) => (
                          <Badge key={idx} variant="outline" className="bg-background text-[10px] py-0 border-primary/20 text-primary self-start">
                            {insight}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
                {isTyping && (
                  <div className="flex items-start">
                    <div className="px-4 py-3 rounded-2xl bg-muted/50 rounded-tl-sm border border-border/50">
                      <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </CardContent>

              <CardFooter className="p-3 border-t border-border/50 bg-background shrink-0">
                <form onSubmit={handleSend} className="flex w-full gap-2">
                  <Input 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask Operion..."
                    className="flex-1 bg-muted/30 border-border/50 focus-visible:ring-primary shadow-none"
                  />
                  <Button type="submit" size="icon" disabled={!input.trim() || isTyping} className="shrink-0 bg-primary text-primary-foreground">
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              </CardFooter>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIAssistantOverlay;