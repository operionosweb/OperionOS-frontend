import React from 'react';
import { Helmet } from 'react-helmet';

const SEOHead = ({ title, description, keywords, image, url }) => {
  const defaultImage = "https://horizons-cdn.hostinger.com/97f87c57-3bf4-45e9-95c4-7bfd445a845f/d4c3af1ba833729da85b67b90bdf2c04.png";
  const defaultUrl = "https://operion.com";

  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      {keywords && <meta name="keywords" content={keywords} />}
      
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image || defaultImage} />
      <meta property="og:url" content={url || defaultUrl} />
      <meta property="og:type" content="website" />
      
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image || defaultImage} />
    </Helmet>
  );
};

export default SEOHead;