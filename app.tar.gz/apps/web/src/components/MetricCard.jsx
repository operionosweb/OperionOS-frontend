
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function MetricCard({ label, value, unit, trend, trendValue, icon: Icon, className }) {
  return (
    <Card className={cn("overflow-hidden group", className)}>
      <CardContent className="p-[16px] relative">
        <div className="flex justify-between items-start mb-2">
          <p className="text-[12px] uppercase font-semibold tracking-wider text-gray-500">{label}</p>
          {Icon && <Icon className="w-5 h-5 text-primary opacity-70 group-hover:opacity-100 transition-opacity" />}
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-[24px] font-bold text-gray-900 tabular-nums leading-none tracking-tight">{value}</span>
          {unit && <span className="text-[12px] font-medium text-gray-500">{unit}</span>}
        </div>
        {(trend || trendValue) && (
          <div className="mt-2 flex items-center gap-1">
            {trend === 'up' ? <TrendingUp className="w-3 h-3 text-[#10B981]" /> : trend === 'down' ? <TrendingDown className="w-3 h-3 text-[#EF4444]" /> : null}
            <span className={cn(
              "text-[12px] font-medium",
              trend === 'up' ? "text-[#10B981]" : trend === 'down' ? "text-[#EF4444]" : "text-gray-500"
            )}>
              {trendValue}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
