import React, { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { AlertTriangle, Clock, Activity, Edit2, Save, X, CheckCircle2, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

const EventDetailPanel = ({ event, isOpen, onClose }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(event || {});

  useEffect(() => {
    if (event) setFormData(event);
  }, [event]);

  if (!event) return null;

  const handleSave = () => {
    setIsEditing(false);
    toast.success('Event details updated');
  };

  const handleAction = (action) => {
    toast.success(`${action} initiated`);
    if (action === 'Resolve') onClose();
  };

  const getImpactColor = (impact) => {
    switch(impact) {
      case 'High': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'Medium': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      default: return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto p-0 border-l border-border flex flex-col">
        <div className="bg-muted/30 p-4 md:p-6 border-b border-border relative">
          <div className="absolute top-4 right-12 flex gap-2">
            {!isEditing ? (
              <Button variant="ghost" size="icon" className="touch-target" onClick={() => setIsEditing(true)}>
                <Edit2 className="w-4 h-4" />
              </Button>
            ) : (
              <>
                <Button variant="ghost" size="icon" className="touch-target" onClick={() => setIsEditing(false)}>
                  <X className="w-4 h-4" />
                </Button>
                <Button size="icon" className="touch-target" onClick={handleSave}>
                  <Save className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>

          <div className="flex items-center gap-3 mb-3 pr-12">
            <div className={`p-2 rounded-lg ${formData.impact === 'High' ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}>
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              {isEditing ? (
                <Input 
                  value={formData.type} 
                  onChange={(e) => setFormData({...formData, type: e.target.value})}
                  className="text-xl font-bold h-9 mb-1"
                />
              ) : (
                <SheetTitle className="text-xl font-bold">{formData.type}</SheetTitle>
              )}
              <SheetDescription className="flex items-center gap-1">
                <Clock className="w-3 h-3" /> {formData.date}
              </SheetDescription>
            </div>
          </div>
          <div className="flex gap-2">
            <Badge variant="outline" className={getImpactColor(formData.impact)}>Impact: {formData.impact}</Badge>
            <Badge variant="outline" className={formData.status === 'Resolved' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-muted text-muted-foreground'}>
              {formData.status}
            </Badge>
          </div>
        </div>

        <div className="p-4 md:p-6 flex-1">
          <Tabs defaultValue="overview" className="w-full h-full flex flex-col">
            <div className="overflow-x-auto hide-scrollbar mb-6 -mx-4 px-4 md:mx-0 md:px-0">
              <TabsList className="inline-flex w-max md:grid md:w-full md:grid-cols-4 min-w-full">
                <TabsTrigger value="overview" className="touch-target px-4">Overview</TabsTrigger>
                <TabsTrigger value="timeline" className="touch-target px-4">Timeline</TabsTrigger>
                <TabsTrigger value="impact" className="touch-target px-4">Impact</TabsTrigger>
                <TabsTrigger value="resolution" className="touch-target px-4">Resolution</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="overview" className="space-y-6 focus-visible:outline-none flex-1">
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Description</h3>
                <div className="p-4 bg-card border border-border rounded-xl text-sm leading-relaxed">
                  {formData.description}
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Involved Entities</h3>
                <div className="p-3 bg-card border border-border rounded-lg flex justify-between items-center">
                  <span className="text-sm font-medium">Vessel ID: {formData.vesselId}</span>
                  <Button variant="ghost" size="sm" className="touch-target">View Vessel</Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="timeline" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg">Event Timeline</h3>
              <div className="relative border-l-2 border-muted ml-3 space-y-6 pb-4">
                <div className="relative pl-6">
                  <div className="absolute w-3 h-3 rounded-full -left-[7.5px] top-1.5 ring-4 ring-background bg-primary"></div>
                  <div className="bg-card border border-border rounded-xl p-3">
                    <h4 className="font-semibold text-sm">Event Logged</h4>
                    <p className="text-xs text-muted-foreground">{formData.date}</p>
                  </div>
                </div>
                <div className="relative pl-6">
                  <div className="absolute w-3 h-3 rounded-full -left-[7.5px] top-1.5 ring-4 ring-background bg-muted-foreground"></div>
                  <div className="bg-card border border-border rounded-xl p-3">
                    <h4 className="font-semibold text-sm">Initial Assessment</h4>
                    <p className="text-xs text-muted-foreground">Pending</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="impact" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Activity className="w-5 h-5 text-muted-foreground"/> Operational Impact</h3>
              <div className="p-4 bg-card border border-border rounded-xl">
                <p className="text-sm text-muted-foreground mb-2">Estimated delay to schedule: <span className="font-bold text-foreground">4 Hours</span></p>
                <p className="text-sm text-muted-foreground">Cost implication: <span className="font-bold text-foreground">Minimal</span></p>
              </div>
            </TabsContent>

            <TabsContent value="resolution" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg">Resolution Status</h3>
              {formData.status === 'Resolved' ? (
                <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-600 flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6" />
                  <div>
                    <div className="font-bold">Resolved</div>
                    <div className="text-sm">No further action required.</div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <Button className="w-full touch-target" onClick={() => handleAction('Resolve')}>Mark as Resolved</Button>
                  <Button variant="destructive" className="w-full touch-target" onClick={() => handleAction('Escalate')}>Escalate Issue</Button>
                  <Button variant="outline" className="w-full touch-target" onClick={() => handleAction('Add Note')}><MessageSquare className="w-4 h-4 mr-2"/> Add Note</Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default EventDetailPanel;