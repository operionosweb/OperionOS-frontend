import React from 'react';
import { Calendar, ArrowRight, MapPin, Users } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { portCallsData } from '@/lib/vesselOpsData.js';

const PortOperationsScheduler = ({ onPortClick }) => {
  const getLogisticsColor = (status) => {
    switch(status) {
      case 'Completed': return 'badge-at-sea';
      case 'In Progress': return 'badge-in-port';
      case 'Planned': return 'badge-maintenance';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden mb-8">
      <div className="p-4 md:p-5 border-b border-border flex justify-between items-center">
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" /> Port Operations
        </h2>
        <Button variant="outline" size="sm" className="touch-target">Full Schedule</Button>
      </div>

      <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {portCallsData.map((call) => (
          <Card key={call.id} className="interactive-card" onClick={() => onPortClick(call)}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" />
                  <h3 className="font-bold text-base">{call.port}</h3>
                </div>
                <Badge variant="outline" className={getLogisticsColor(call.logistics)}>{call.logistics}</Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-sm mb-3 bg-muted/30 p-3 rounded-lg">
                <div>
                  <span className="text-xs text-muted-foreground block">Arrival</span>
                  <span className="font-medium">{call.arrival}</span>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground block">Departure</span>
                  <span className="font-medium">{call.departure}</span>
                </div>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-border/50">
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>{call.crewChanges} Changes</span>
                </div>
                <span className="text-primary text-sm font-medium flex items-center">
                  Manage <ArrowRight className="w-4 h-4 ml-1" />
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default PortOperationsScheduler;