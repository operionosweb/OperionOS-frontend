import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { AlertTriangle, Info, AlertCircle, Clock, Ship, Users, Activity, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

const AlertDetailPanel = ({ alert, isOpen, onClose }) => {
  if (!alert) return null;

  const getSeverityConfig = (severity) => {
    switch(severity) {
      case 'Critical': return { color: 'badge-delayed', icon: <AlertTriangle className="w-6 h-6 text-destructive" /> };
      case 'High': return { color: 'badge-maintenance', icon: <AlertCircle className="w-6 h-6 text-amber-600" /> };
      case 'Medium': return { color: 'badge-in-port', icon: <Info className="w-6 h-6 text-blue-600" /> };
      default: return { color: 'bg-muted text-muted-foreground border-border', icon: <Info className="w-6 h-6 text-muted-foreground" /> };
    }
  };

  const config = getSeverityConfig(alert.severity);

  const handleAction = (action) => {
    toast.success(`${action} initiated for this alert.`);
    if (action === 'Resolve') onClose();
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto p-0 border-l border-border flex flex-col">
        <div className="bg-muted/30 p-4 md:p-6 border-b border-border">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-3">
              {config.icon}
              <SheetTitle className="text-xl font-bold">Operational Alert</SheetTitle>
            </div>
            <Badge variant="outline" className={config.color}>{alert.severity}</Badge>
          </div>
          <h2 className="text-lg font-semibold mt-2">{alert.title}</h2>
          <SheetDescription className="text-base mt-2 text-foreground">{alert.description}</SheetDescription>
          <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" /> Detected {alert.time}
          </div>
        </div>

        <div className="p-4 md:p-6 flex-1 space-y-6">
          <div className="space-y-3">
            <h3 className="font-semibold text-lg">Context & Impact</h3>
            <div className="grid grid-cols-1 gap-3">
              <div className="p-4 bg-card border border-border rounded-xl flex items-center gap-4">
                <div className="p-2 bg-primary/10 rounded-lg text-primary"><Ship className="w-5 h-5" /></div>
                <div>
                  <div className="text-sm text-muted-foreground">Related Vessel</div>
                  <div className="font-medium">{alert.vessel}</div>
                </div>
              </div>
              <div className="p-4 bg-card border border-border rounded-xl flex items-center gap-4">
                <div className="p-2 bg-amber-500/10 rounded-lg text-amber-600"><Activity className="w-5 h-5" /></div>
                <div>
                  <div className="text-sm text-muted-foreground">Operational Impact</div>
                  <div className="font-medium">Schedule delay likely</div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-lg">Recommended Actions</h3>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start touch-target" onClick={() => handleAction('Trigger Disruptions Workflow')}>
                Trigger Disruptions Workflow
              </Button>
              <Button variant="outline" className="w-full justify-start touch-target" onClick={() => handleAction('Notify Crew Management')}>
                Notify Crew Management
              </Button>
              <Button variant="outline" className="w-full justify-start touch-target" onClick={() => handleAction('Adjust Planning Schedule')}>
                Adjust Planning Schedule
              </Button>
            </div>
          </div>
        </div>

        <div className="p-4 md:p-6 border-t border-border bg-muted/10 flex flex-col sm:flex-row gap-3 mt-auto">
          <Button className="w-full touch-target" onClick={() => handleAction('Resolve')}>
            <CheckCircle2 className="w-4 h-4 mr-2" /> Mark as Resolved
          </Button>
          <Button variant="ghost" className="w-full sm:w-auto touch-target text-muted-foreground" onClick={onClose}>
            Dismiss
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default AlertDetailPanel;