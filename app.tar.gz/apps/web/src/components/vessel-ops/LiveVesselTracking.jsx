import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Card } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Maximize, ZoomIn, ZoomOut } from 'lucide-react';
import { generateComprehensiveVesselData } from '@/lib/vesselOpsDataGenerator.js';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const createCustomIcon = (status) => {
  let color = '#3b82f6'; // blue for At Sea
  if (status === 'In Port') color = '#10b981'; // green
  if (status === 'Delayed') color = '#ef4444'; // red
  if (status === 'Maintenance') color = '#f59e0b'; // yellow

  return L.divIcon({
    className: 'custom-vessel-marker',
    html: `<div style="background-color: ${color}; width: 14px; height: 14px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.4); transition: transform 0.2s;"></div>`,
    iconSize: [14, 14],
    iconAnchor: [7, 7],
  });
};

const MapControls = () => {
  const map = useMap();
  return (
    <div className="absolute bottom-6 right-6 z-[400] flex flex-col gap-2">
      <Button variant="secondary" size="icon" className="bg-card/90 backdrop-blur shadow-md" onClick={() => map.zoomIn()}>
        <ZoomIn className="w-4 h-4" />
      </Button>
      <Button variant="secondary" size="icon" className="bg-card/90 backdrop-blur shadow-md" onClick={() => map.zoomOut()}>
        <ZoomOut className="w-4 h-4" />
      </Button>
      <Button variant="secondary" size="icon" className="bg-card/90 backdrop-blur shadow-md" onClick={() => map.setView([20, 0], 2)}>
        <Maximize className="w-4 h-4" />
      </Button>
    </div>
  );
};

const LiveVesselTracking = ({ onVesselClick }) => {
  const [isMounted, setIsMounted] = useState(false);
  const [vessels, setVessels] = useState([]);

  useEffect(() => {
    const data = generateComprehensiveVesselData();
    setVessels(data.vessels);
    setIsMounted(true);
  }, []);

  if (!isMounted) return <div className="h-[500px] w-full bg-muted rounded-2xl animate-pulse mb-8"></div>;

  return (
    <Card className="overflow-hidden border-border shadow-sm mb-8 relative z-0 h-[500px] lg:h-[600px]">
      <MapContainer 
        center={[20, 0]} 
        zoom={2} 
        style={{ height: '100%', width: '100%' }} 
        zoomControl={false}
        dragging={!L.Browser.mobile} // Disable 1-finger drag on mobile
        tap={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; OpenStreetMap contributors &copy; CARTO'
        />
        {vessels.map((vessel) => (
          <Marker 
            key={vessel.id} 
            position={vessel.coordinates} 
            icon={createCustomIcon(vessel.status)}
            eventHandlers={{ click: () => onVesselClick(vessel) }}
          >
            <Popup className="custom-popup">
              <div className="p-1 min-w-[180px]">
                <h4 className="font-bold text-sm mb-1">{vessel.name}</h4>
                <p className="text-xs text-muted-foreground mb-1">{vessel.type} • {vessel.status}</p>
                <p className="text-xs mb-2">Dest: {vessel.destination}</p>
                <Button size="sm" className="w-full h-7 text-xs" onClick={(e) => { e.stopPropagation(); onVesselClick(vessel); }}>
                  View Details
                </Button>
              </div>
            </Popup>
          </Marker>
        ))}
        <MapControls />
      </MapContainer>
      
      <div className="absolute top-4 left-4 z-[400] bg-card/90 backdrop-blur-sm p-3 rounded-xl border border-border shadow-sm text-xs space-y-2">
        <div className="font-semibold mb-2">Fleet Status</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-blue-500"></div> At Sea</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-emerald-500"></div> In Port</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-destructive"></div> Delayed</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-amber-500"></div> Maintenance</div>
      </div>
    </Card>
  );
};

export default LiveVesselTracking;