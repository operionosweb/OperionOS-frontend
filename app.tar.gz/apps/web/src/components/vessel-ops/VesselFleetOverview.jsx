import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, MoreHorizontal, MapPin, Navigation } from 'lucide-react';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { fleetData } from '@/lib/vesselOpsData.js';

const VesselFleetOverview = ({ onVesselClick }) => {
  const [search, setSearch] = useState('');

  const filteredFleet = fleetData.filter(v => v.name.toLowerCase().includes(search.toLowerCase()));

  const getStatusColor = (status) => {
    switch(status) {
      case 'At Sea': return 'badge-at-sea';
      case 'In Port': return 'badge-in-port';
      case 'Delayed': return 'badge-delayed';
      case 'Maintenance': return 'badge-maintenance';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden mb-8">
      <div className="p-4 md:p-5 border-b border-border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-xl font-bold text-foreground">Fleet Overview</h2>
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search vessels..." 
            className="pl-9 h-11 sm:h-9 bg-background touch-target"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredFleet.map((vessel, index) => (
          <motion.div
            key={vessel.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: index * 0.05 }}
          >
            <Card className="interactive-card h-full" onClick={() => onVesselClick(vessel)}>
              <CardContent className="p-4 flex flex-col h-full">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-bold text-foreground text-base leading-tight">{vessel.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{vessel.type} • IMO: {vessel.imo}</p>
                  </div>
                  <Badge variant="outline" className={getStatusColor(vessel.status)}>{vessel.status}</Badge>
                </div>
                
                <div className="mt-auto space-y-2 pt-3 border-t border-border/50">
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-muted-foreground shrink-0" />
                    <span className="truncate">{vessel.location.split(' ')[0]}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Navigation className="w-4 h-4 text-muted-foreground shrink-0" />
                    <span className="truncate">To: {vessel.nextPort}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default VesselFleetOverview;