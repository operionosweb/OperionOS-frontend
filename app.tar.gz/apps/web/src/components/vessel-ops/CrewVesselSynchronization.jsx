import React from 'react';
import { Sparkles } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { aiSuggestionsData } from '@/lib/vesselOpsData.js';

const CrewVesselSynchronization = ({ onSuggestionClick }) => {
  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden mb-8">
      <div className="p-4 md:p-5 border-b border-border bg-gradient-to-r from-primary/5 to-transparent">
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" /> AI Synchronization
        </h2>
        <p className="text-sm text-muted-foreground mt-1">Automated recommendations to align crew rotations.</p>
      </div>

      <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {aiSuggestionsData.slice(0, 3).map((suggestion) => (
          <Card key={suggestion.id} className="interactive-card flex flex-col" onClick={() => onSuggestionClick(suggestion)}>
            <CardContent className="p-4 flex flex-col h-full">
              <div className="flex items-start gap-3 mb-3">
                <div className="p-2 bg-primary/10 rounded-lg text-primary shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm leading-tight">{suggestion.title}</h3>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{suggestion.description}</p>
                </div>
              </div>
              
              <div className="mt-auto pt-4 border-t border-border/50 grid grid-cols-3 gap-2 text-center mb-4">
                <div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Cost</div>
                  <div className="text-xs font-bold text-emerald-600">{suggestion.impact.cost}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Efficiency</div>
                  <div className="text-xs font-bold text-blue-600">{suggestion.impact.efficiency}</div>
                </div>
                <div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Risk</div>
                  <div className={`text-xs font-bold ${suggestion.impact.risk === 'High' ? 'text-destructive' : 'text-amber-600'}`}>
                    {suggestion.impact.risk}
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1 text-xs h-9 touch-target" onClick={(e) => { e.stopPropagation(); onSuggestionClick(suggestion); }}>Details</Button>
                <Button size="sm" className="flex-1 text-xs h-9 touch-target" onClick={(e) => { e.stopPropagation(); onSuggestionClick(suggestion); }}>Apply</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CrewVesselSynchronization;