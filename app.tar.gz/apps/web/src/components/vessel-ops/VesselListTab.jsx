import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, MapPin, Navigation, Users } from 'lucide-react';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';

const VesselListTab = ({ vessels, onVesselClick }) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');

  const filteredVessels = vessels.filter(v => {
    const matchesSearch = v.name.toLowerCase().includes(search.toLowerCase()) || v.location.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All' || v.status === statusFilter;
    const matchesType = typeFilter === 'All' || v.type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusColor = (status) => {
    switch(status) {
      case 'At Sea': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'In Port': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'Delayed': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'Maintenance': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 bg-card p-4 rounded-2xl border border-border shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search vessels by name or location..." 
            className="pl-9 h-11 touch-target"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[140px] h-11 touch-target">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Status</SelectItem>
              <SelectItem value="At Sea">At Sea</SelectItem>
              <SelectItem value="In Port">In Port</SelectItem>
              <SelectItem value="Delayed">Delayed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[140px] h-11 touch-target">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Types</SelectItem>
              <SelectItem value="Cargo">Cargo</SelectItem>
              <SelectItem value="Tanker">Tanker</SelectItem>
              <SelectItem value="Cruise">Cruise</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden lg:block bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="font-semibold">Vessel Name</TableHead>
              <TableHead className="font-semibold">Type</TableHead>
              <TableHead className="font-semibold">Location</TableHead>
              <TableHead className="font-semibold">Status</TableHead>
              <TableHead className="font-semibold">Crew</TableHead>
              <TableHead className="font-semibold">Next Port</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredVessels.map((vessel) => (
              <TableRow key={vessel.id} className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => onVesselClick(vessel)}>
                <TableCell className="font-medium text-foreground">{vessel.name}</TableCell>
                <TableCell className="text-muted-foreground">{vessel.type}</TableCell>
                <TableCell className="text-muted-foreground">{vessel.location.split(' (')[0]}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={getStatusColor(vessel.status)}>{vessel.status}</Badge>
                </TableCell>
                <TableCell className="text-muted-foreground">{vessel.crewCount}</TableCell>
                <TableCell className="text-muted-foreground">{vessel.route.split(' → ')[1]}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Mobile/Tablet Cards */}
      <div className="lg:hidden grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredVessels.map((vessel, index) => (
          <motion.div
            key={vessel.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, delay: index * 0.05 }}
          >
            <Card className="interactive-card h-full" onClick={() => onVesselClick(vessel)}>
              <CardContent className="p-4 flex flex-col h-full">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-bold text-foreground text-base leading-tight">{vessel.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{vessel.type} • IMO: {vessel.imo}</p>
                  </div>
                  <Badge variant="outline" className={getStatusColor(vessel.status)}>{vessel.status}</Badge>
                </div>
                
                <div className="mt-auto space-y-2 pt-3 border-t border-border/50">
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-muted-foreground shrink-0" />
                    <span className="truncate">{vessel.location.split(' (')[0]}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Navigation className="w-4 h-4 text-muted-foreground shrink-0" />
                    <span className="truncate">To: {vessel.route.split(' → ')[1]}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-muted-foreground shrink-0" />
                    <span className="truncate">{vessel.crewCount} Crew Onboard</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default VesselListTab;