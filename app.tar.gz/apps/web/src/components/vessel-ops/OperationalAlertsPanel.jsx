import React from 'react';
import { AlertTriangle, Info, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { alertsData } from '@/lib/vesselOpsData.js';

const OperationalAlertsPanel = ({ onAlertClick }) => {
  const getSeverityConfig = (severity) => {
    switch(severity) {
      case 'Critical': return { color: 'badge-delayed', icon: <AlertTriangle className="w-4 h-4 text-destructive" /> };
      case 'High': return { color: 'badge-maintenance', icon: <AlertCircle className="w-4 h-4 text-amber-600" /> };
      case 'Medium': return { color: 'badge-in-port', icon: <Info className="w-4 h-4 text-blue-600" /> };
      default: return { color: 'bg-muted text-muted-foreground border-border', icon: <CheckCircle2 className="w-4 h-4 text-muted-foreground" /> };
    }
  };

  return (
    <Card className="border-border shadow-sm h-full flex flex-col mb-8 lg:mb-0">
      <CardHeader className="pb-3 border-b border-border">
        <CardTitle className="text-lg flex items-center justify-between">
          <span className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-primary" /> Live Alerts
          </span>
          <Badge variant="secondary" className="bg-primary/10 text-primary">{alertsData.length} Active</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 flex-1">
        <ScrollArea className="h-[400px] lg:h-[calc(100vh-300px)]">
          <div className="divide-y divide-border">
            {alertsData.map((alert) => {
              const config = getSeverityConfig(alert.severity);
              return (
                <div 
                  key={alert.id} 
                  className="p-4 hover:bg-muted/50 transition-colors cursor-pointer active:bg-muted"
                  onClick={() => onAlertClick(alert)}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">{config.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-semibold text-sm text-foreground truncate pr-2">{alert.title}</h4>
                        <span className="text-[10px] text-muted-foreground whitespace-nowrap">{alert.time}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{alert.description}</p>
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-5 ${config.color}`}>
                        {alert.severity}
                      </Badge>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default OperationalAlertsPanel;