import React, { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { MapPin, Calendar, Users, Package, Edit2, Save, X, Anchor, Settings } from 'lucide-react';
import { toast } from 'sonner';

const PortDetailPanel = ({ port, isOpen, onClose }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(port || {});

  useEffect(() => {
    if (port) setFormData(port);
  }, [port]);

  if (!port) return null;

  const handleSave = () => {
    setIsEditing(false);
    toast.success('Port details updated successfully');
  };

  const handleAction = (action) => {
    toast.success(`${action} initiated for ${formData.name}`);
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto p-0 border-l border-border flex flex-col">
        <div className="bg-muted/30 p-4 md:p-6 border-b border-border relative">
          <div className="absolute top-4 right-12 flex gap-2">
            {!isEditing ? (
              <Button variant="ghost" size="icon" className="touch-target" onClick={() => setIsEditing(true)}>
                <Edit2 className="w-4 h-4" />
              </Button>
            ) : (
              <>
                <Button variant="ghost" size="icon" className="touch-target" onClick={() => setIsEditing(false)}>
                  <X className="w-4 h-4" />
                </Button>
                <Button size="icon" className="touch-target" onClick={handleSave}>
                  <Save className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>

          <div className="flex items-center gap-3 mb-2 pr-12">
            <div className="p-2 bg-primary/10 rounded-lg text-primary">
              <Anchor className="w-6 h-6" />
            </div>
            <div>
              {isEditing ? (
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="text-xl font-bold h-9 mb-1"
                />
              ) : (
                <SheetTitle className="text-xl font-bold">{formData.name}</SheetTitle>
              )}
              <SheetDescription className="flex items-center gap-1">
                <MapPin className="w-3 h-3" /> {formData.location}
              </SheetDescription>
            </div>
          </div>
        </div>

        <div className="p-4 md:p-6 flex-1">
          <Tabs defaultValue="overview" className="w-full h-full flex flex-col">
            <div className="overflow-x-auto hide-scrollbar mb-6 -mx-4 px-4 md:mx-0 md:px-0">
              <TabsList className="inline-flex w-max md:grid md:w-full md:grid-cols-4 min-w-full">
                <TabsTrigger value="overview" className="touch-target px-4">Overview</TabsTrigger>
                <TabsTrigger value="schedule" className="touch-target px-4">Schedule</TabsTrigger>
                <TabsTrigger value="logistics" className="touch-target px-4">Logistics</TabsTrigger>
                <TabsTrigger value="services" className="touch-target px-4">Services</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="overview" className="space-y-6 focus-visible:outline-none flex-1">
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Port Information</h3>
                <div className="grid grid-cols-1 gap-4">
                  <div className="p-3 bg-card border border-border rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">Coordinates</div>
                    <div className="font-medium text-sm">{formData.coordinates?.join(', ')}</div>
                  </div>
                  <div className="p-3 bg-card border border-border rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1">Status</div>
                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Operational</Badge>
                  </div>
                </div>
              </div>
              <div className="pt-4 flex flex-wrap gap-2">
                <Button variant="outline" className="touch-target flex-1" onClick={() => handleAction('Schedule Maintenance')}>Schedule Maint.</Button>
                <Button variant="outline" className="touch-target flex-1" onClick={() => handleAction('View Full Map')}>View Map</Button>
              </div>
            </TabsContent>

            <TabsContent value="schedule" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Calendar className="w-5 h-5 text-muted-foreground"/> Expected Arrivals</h3>
              <div className="space-y-3">
                {[1, 2].map((i) => (
                  <div key={i} className="p-3 bg-card border border-border rounded-lg flex justify-between items-center">
                    <div>
                      <div className="font-medium text-sm">Vessel {i}</div>
                      <div className="text-xs text-muted-foreground">ETA: Tomorrow, 08:00</div>
                    </div>
                    <Button variant="ghost" size="sm" className="touch-target">Details</Button>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="logistics" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Package className="w-5 h-5 text-muted-foreground"/> Logistics & Crew</h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="p-4 bg-card border border-border rounded-xl text-center">
                  <div className="text-2xl font-bold text-primary mb-1">12</div>
                  <div className="text-xs text-muted-foreground">Crew Changes</div>
                </div>
                <div className="p-4 bg-card border border-border rounded-xl text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-1">4</div>
                  <div className="text-xs text-muted-foreground">Provisions Pending</div>
                </div>
              </div>
              <Button className="w-full touch-target" onClick={() => handleAction('Trigger Logistics')}>Trigger Logistics Workflow</Button>
              <Button variant="outline" className="w-full touch-target" onClick={() => handleAction('Assign Crew Changes')}>Assign Crew Changes</Button>
            </TabsContent>

            <TabsContent value="services" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Settings className="w-5 h-5 text-muted-foreground"/> Available Services</h3>
              <div className="flex flex-wrap gap-2">
                {formData.services?.map((s, i) => (
                  <Badge key={i} variant="secondary" className="px-3 py-1.5 text-sm">{s}</Badge>
                ))}
              </div>
              <h3 className="font-semibold text-lg flex items-center gap-2 mt-6">Facilities</h3>
              <div className="flex flex-wrap gap-2">
                {formData.facilities?.map((f, i) => (
                  <Badge key={i} variant="outline" className="px-3 py-1.5 text-sm">{f}</Badge>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default PortDetailPanel;