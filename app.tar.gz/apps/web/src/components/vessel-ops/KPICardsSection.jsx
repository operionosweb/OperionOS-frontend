import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ArrowDownRight, Ship, Anchor, Navigation, Calendar, Users, AlertTriangle, Download, Filter } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { kpiData } from '@/lib/vesselOpsData.js';

const iconMap = {
  'active': <Ship className="w-5 h-5" />,
  'in-port': <Anchor className="w-5 h-5" />,
  'at-sea': <Navigation className="w-5 h-5" />,
  'port-calls': <Calendar className="w-5 h-5" />,
  'crew': <Users className="w-5 h-5" />,
  'delays': <AlertTriangle className="w-5 h-5" />,
};

const KPICardsSection = () => {
  const [selectedKpi, setSelectedKpi] = useState(null);

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {kpiData.map((kpi, index) => (
          <motion.div
            key={kpi.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.05 }}
          >
            <Card 
              className="interactive-card h-full group"
              onClick={() => setSelectedKpi(kpi)}
            >
              <CardContent className="p-5 flex flex-col justify-between h-full">
                <div className="flex justify-between items-start mb-4">
                  <div className={`p-2 rounded-lg ${kpi.status === 'warning' ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}>
                    {iconMap[kpi.id]}
                  </div>
                  <div className={`flex items-center text-xs font-medium px-2 py-1 rounded-full ${
                    kpi.trend === 'up' && kpi.status !== 'warning' ? 'text-emerald-600 bg-emerald-500/10' : 
                    kpi.trend === 'down' && kpi.status === 'warning' ? 'text-emerald-600 bg-emerald-500/10' :
                    'text-destructive bg-destructive/10'
                  }`}>
                    {kpi.trend === 'up' ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
                    {kpi.change}
                  </div>
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-foreground tabular-nums tracking-tight group-hover:text-primary transition-colors">{kpi.value}</h3>
                  <p className="text-sm text-muted-foreground mt-1 font-medium">{kpi.title}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Dialog open={!!selectedKpi} onOpenChange={() => setSelectedKpi(null)}>
        <DialogContent className="sm:max-w-2xl w-[95vw] rounded-2xl">
          <DialogHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className={`p-2 rounded-lg ${selectedKpi?.status === 'warning' ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}>
                {selectedKpi && iconMap[selectedKpi.id]}
              </div>
              <DialogTitle className="text-2xl">{selectedKpi?.title}</DialogTitle>
            </div>
            <DialogDescription>
              Detailed breakdown and filtered list for {selectedKpi?.title.toLowerCase()}.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4 space-y-4">
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" className="touch-target"><Filter className="w-4 h-4 mr-2" /> Filter</Button>
              <Button variant="outline" size="sm" className="touch-target"><Download className="w-4 h-4 mr-2" /> Export</Button>
            </div>
            
            <div className="bg-muted/30 rounded-xl border border-border p-4 h-[300px] flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <p className="font-medium mb-2">Detailed Data View</p>
                <p className="text-sm">Showing {selectedKpi?.value} records matching this KPI.</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default KPICardsSection;