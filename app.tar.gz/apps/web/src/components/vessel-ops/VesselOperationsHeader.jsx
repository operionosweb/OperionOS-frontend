import React from 'react';
import { Ship, Map, BarChart2, List, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group.jsx';

const VesselOperationsHeader = ({ view, setView, filters, setFilters }) => {
  return (
    <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
      <div>
        <div className="flex items-center gap-3 mb-1">
          <h1 className="text-3xl font-bold text-foreground tracking-tight">Vessel Operations</h1>
          <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-medium text-emerald-600 dark:text-emerald-400">Live</span>
          </div>
        </div>
        <p className="text-muted-foreground">Monitor fleet status, port schedules, and operational alerts.</p>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-3 w-full lg:w-auto">
        <div className="flex items-center gap-2 w-full sm:w-auto bg-card border border-border rounded-lg p-1 shadow-sm">
          <Filter className="w-4 h-4 text-muted-foreground ml-2 hidden sm:block" />
          <Select value={filters.region} onValueChange={(v) => setFilters({ ...filters, region: v })}>
            <SelectTrigger className="w-full sm:w-[140px] border-0 shadow-none focus:ring-0 h-8">
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="north-sea">North Sea</SelectItem>
              <SelectItem value="mediterranean">Mediterranean</SelectItem>
              <SelectItem value="south-china-sea">South China Sea</SelectItem>
              <SelectItem value="baltic-sea">Baltic Sea</SelectItem>
            </SelectContent>
          </Select>
          <div className="w-px h-4 bg-border hidden sm:block"></div>
          <Select value={filters.type} onValueChange={(v) => setFilters({ ...filters, type: v })}>
            <SelectTrigger className="w-full sm:w-[130px] border-0 shadow-none focus:ring-0 h-8">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="cargo">Cargo</SelectItem>
              <SelectItem value="tanker">Tanker</SelectItem>
              <SelectItem value="cruise">Cruise</SelectItem>
            </SelectContent>
          </Select>
          <div className="w-px h-4 bg-border hidden sm:block"></div>
          <Select value={filters.status} onValueChange={(v) => setFilters({ ...filters, status: v })}>
            <SelectTrigger className="w-full sm:w-[130px] border-0 shadow-none focus:ring-0 h-8">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="at-sea">At Sea</SelectItem>
              <SelectItem value="in-port">In Port</SelectItem>
              <SelectItem value="delayed">Delayed</SelectItem>
              <SelectItem value="maintenance">Maintenance</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <ToggleGroup type="single" value={view} onValueChange={(v) => v && setView(v)} className="bg-card border border-border rounded-lg p-1 shadow-sm w-full sm:w-auto justify-start">
          <ToggleGroupItem value="list" aria-label="List View" className="h-8 px-3 data-[state=on]:bg-primary/10 data-[state=on]:text-primary">
            <List className="w-4 h-4 mr-2" /> List
          </ToggleGroupItem>
          <ToggleGroupItem value="map" aria-label="Map View" className="h-8 px-3 data-[state=on]:bg-primary/10 data-[state=on]:text-primary">
            <Map className="w-4 h-4 mr-2" /> Map
          </ToggleGroupItem>
          <ToggleGroupItem value="analytics" aria-label="Analytics View" className="h-8 px-3 data-[state=on]:bg-primary/10 data-[state=on]:text-primary">
            <BarChart2 className="w-4 h-4 mr-2" /> Analytics
          </ToggleGroupItem>
        </ToggleGroup>
      </div>
    </div>
  );
};

export default VesselOperationsHeader;