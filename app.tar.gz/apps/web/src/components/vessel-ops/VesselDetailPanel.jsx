import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { MapPin, Navigation, Clock, Package, Activity, X } from 'lucide-react';

const VesselDetailPanel = ({ vessel, isOpen, onClose }) => {
  if (!vessel) return null;

  const getStatusColor = (status) => {
    switch(status) {
      case 'At Sea': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'In Port': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'Delayed': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'Maintenance': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto p-0 border-l border-border flex flex-col">
        <div className="bg-muted/30 p-6 border-b border-border relative">
          <Button variant="ghost" size="icon" className="absolute top-4 right-4 touch-target" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
          
          <div className="flex flex-col gap-3 pr-8">
            <div className="flex items-center gap-3 flex-wrap">
              <SheetTitle className="text-2xl font-bold">{vessel.name}</SheetTitle>
              <Badge variant="outline" className={getStatusColor(vessel.status)}>{vessel.status}</Badge>
            </div>
            <SheetDescription className="text-base flex items-center gap-2">
              <span className="font-medium text-foreground">{vessel.type}</span>
              <span className="text-muted-foreground">• IMO: {vessel.imo}</span>
            </SheetDescription>
          </div>
        </div>

        <div className="p-6 flex-1 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
              <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1"><MapPin className="w-3 h-3"/> Location</div>
              <div className="font-medium text-sm">{vessel.location}</div>
            </div>
            <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
              <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1"><Navigation className="w-3 h-3"/> Destination</div>
              <div className="font-medium text-sm">{vessel.destination}</div>
            </div>
            <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
              <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1"><Clock className="w-3 h-3"/> ETA</div>
              <div className="font-medium text-sm">{new Date(vessel.eta).toLocaleString()}</div>
            </div>
            <div className="bg-card rounded-xl p-4 border border-border shadow-sm">
              <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1"><Activity className="w-3 h-3"/> Speed</div>
              <div className="font-medium text-sm">{vessel.speed} knots</div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-lg">Operational Details</h3>
            <div className="bg-card border border-border rounded-xl p-4 space-y-3">
              <div className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground flex items-center gap-2"><Package className="w-4 h-4"/> Cargo Type</span>
                <span className="font-medium">{vessel.cargo}</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Crew Onboard</span>
                <span className="font-medium">{vessel.crewCount} Personnel</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Last Update</span>
                <span className="font-medium">{new Date(vessel.lastUpdate).toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <Button className="flex-1 touch-target">Contact Vessel</Button>
            <Button variant="outline" className="flex-1 touch-target">View Full Log</Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default VesselDetailPanel;