import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Sparkles, TrendingUp, DollarSign, AlertTriangle, CheckCircle2, X } from 'lucide-react';
import { toast } from 'sonner';

const SuggestionDetailPanel = ({ suggestion, isOpen, onClose }) => {
  if (!suggestion) return null;

  const handleApply = () => {
    toast.success('Suggestion applied successfully');
    onClose();
  };

  const handleSimulate = () => {
    toast.info('Running simulation... Results will be available shortly.');
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto p-0 border-l border-border flex flex-col">
        <div className="bg-primary/5 p-4 md:p-6 border-b border-border">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-primary/10 rounded-lg text-primary">
              <Sparkles className="w-5 h-5" />
            </div>
            <SheetTitle className="text-xl font-bold">AI Suggestion</SheetTitle>
          </div>
          <h2 className="text-lg font-semibold mt-4">{suggestion.title}</h2>
          <SheetDescription className="text-base mt-2">{suggestion.description}</SheetDescription>
        </div>

        <div className="p-4 md:p-6 flex-1 space-y-6">
          <div className="space-y-3">
            <h3 className="font-semibold text-lg">Projected Impact</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 bg-card border border-border rounded-xl text-center">
                <DollarSign className="w-5 h-5 mx-auto mb-2 text-emerald-600" />
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Cost</div>
                <div className="text-lg font-bold text-emerald-600">{suggestion.impact.cost}</div>
              </div>
              <div className="p-4 bg-card border border-border rounded-xl text-center">
                <TrendingUp className="w-5 h-5 mx-auto mb-2 text-blue-600" />
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Efficiency</div>
                <div className="text-lg font-bold text-blue-600">{suggestion.impact.efficiency}</div>
              </div>
              <div className="p-4 bg-card border border-border rounded-xl text-center">
                <AlertTriangle className={`w-5 h-5 mx-auto mb-2 ${suggestion.impact.risk === 'High' ? 'text-destructive' : 'text-amber-600'}`} />
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Risk</div>
                <div className={`text-lg font-bold ${suggestion.impact.risk === 'High' ? 'text-destructive' : 'text-amber-600'}`}>
                  {suggestion.impact.risk}
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-lg">Affected Entities</h3>
            <div className="p-4 bg-card border border-border rounded-xl space-y-3">
              <div className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Vessels</span>
                <span className="font-medium">1 (MV Ocean Pioneer)</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-border">
                <span className="text-muted-foreground">Crew Members</span>
                <span className="font-medium">12 Personnel</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Ports</span>
                <span className="font-medium">Singapore</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 md:p-6 border-t border-border bg-muted/10 flex flex-col sm:flex-row gap-3 mt-auto">
          <Button className="w-full touch-target" onClick={handleApply}>
            <CheckCircle2 className="w-4 h-4 mr-2" /> Apply Suggestion
          </Button>
          <Button variant="outline" className="w-full touch-target" onClick={handleSimulate}>
            Simulate
          </Button>
          <Button variant="ghost" className="w-full sm:w-auto touch-target text-muted-foreground" onClick={onClose}>
            Dismiss
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default SuggestionDetailPanel;