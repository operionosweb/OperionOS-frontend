import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { generatePorts } from '@/lib/maritimeData.js';
import { MapTouchHandler } from '@/hooks/useMapTouchControl.js';

// Fix Leaflet icon issue with custom divIcon
const createCustomIcon = (status) => {
  let colorClass = 'bg-muted-foreground';
  if (status === 'At Sea') colorClass = 'bg-emerald-500';
  if (status === 'In Port') colorClass = 'bg-blue-500';
  if (status === 'Delayed') colorClass = 'bg-destructive';

  return L.divIcon({
    className: 'custom-leaflet-icon',
    html: `<div class="w-4 h-4 rounded-full border-2 border-white shadow-md ${colorClass}"></div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
    popupAnchor: [0, -8]
  });
};

const portIcon = L.divIcon({
  className: 'custom-port-icon',
  html: `<div class="w-3 h-3 rounded-sm border border-white shadow-sm bg-amber-500"></div>`,
  iconSize: [12, 12],
  iconAnchor: [6, 6],
  popupAnchor: [0, -6]
});

const MapController = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
};

const VesselMapTab = ({ vessels, onVesselClick }) => {
  const [showRoutes, setShowRoutes] = useState(true);
  const [showPorts, setShowPorts] = useState(true);
  const ports = generatePorts();

  return (
    <Card className="map-container border-border shadow-sm overflow-hidden relative w-full rounded-2xl">
      <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2">
        <Button variant="secondary" size="sm" className="shadow-md touch-target" onClick={() => setShowRoutes(!showRoutes)}>
          {showRoutes ? 'Hide Routes' : 'Show Routes'}
        </Button>
        <Button variant="secondary" size="sm" className="shadow-md touch-target" onClick={() => setShowPorts(!showPorts)}>
          {showPorts ? 'Hide Ports' : 'Show Ports'}
        </Button>
      </div>

      <MapContainer 
        center={[30, 0]} 
        zoom={2} 
        style={{ height: '100%', width: '100%', zIndex: 0 }}
        zoomControl={false}
      >
        <MapTouchHandler />
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        
        {showPorts && ports.map(port => (
          <Marker key={port.id} position={port.coordinates} icon={portIcon}>
            <Popup className="custom-popup">
              <div className="font-semibold text-sm">{port.name}</div>
              <div className="text-xs text-muted-foreground">{port.location}</div>
            </Popup>
          </Marker>
        ))}

        {vessels.map(vessel => (
          <React.Fragment key={vessel.id}>
            <Marker 
              position={vessel.coordinates} 
              icon={createCustomIcon(vessel.status)}
              eventHandlers={{
                click: () => onVesselClick(vessel)
              }}
            >
              <Popup className="custom-popup">
                <div className="p-1">
                  <div className="font-bold text-sm mb-1">{vessel.name}</div>
                  <Badge variant="outline" className="text-[10px] mb-2">{vessel.status}</Badge>
                  <div className="text-xs text-muted-foreground">To: {vessel.route.split(' → ')[1]}</div>
                  <Button size="sm" className="w-full mt-2 h-7 text-xs" onClick={() => onVesselClick(vessel)}>View Details</Button>
                </div>
              </Popup>
            </Marker>
            
            {showRoutes && vessel.origin && vessel.destination && (
              <Polyline 
                positions={[vessel.origin, vessel.coordinates, vessel.destination]} 
                color={vessel.status === 'Delayed' ? 'hsl(var(--destructive))' : 'hsl(var(--primary))'} 
                weight={2} 
                opacity={0.5} 
                dashArray="5, 5"
              />
            )}
          </React.Fragment>
        ))}
      </MapContainer>
    </Card>
  );
};

export default VesselMapTab;