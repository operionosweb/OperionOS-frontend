import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Target } from 'lucide-react';
import { calculateInvestmentReadinessScore } from '@/lib/fundraisingModeHelpers.js';

const InvestmentReadinessScore = ({ operationsData }) => {
  const data = calculateInvestmentReadinessScore(operationsData);
  const score = data.score;
  
  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  let colorClass = "text-emerald-500 stroke-emerald-500";
  let bgClass = "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400";
  let interpretation = "Excellent operational foundation";

  if (score < 70) {
    colorClass = "text-red-500 stroke-red-500";
    bgClass = "bg-red-50 dark:bg-red-950/20 text-red-700 dark:text-red-400";
    interpretation = "Requires operational restructuring";
  } else if (score < 85) {
    colorClass = "text-amber-500 stroke-amber-500";
    bgClass = "bg-amber-50 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400";
    interpretation = "Strong potential with minor optimizations";
  }

  return (
    <Card className="border-border shadow-sm bg-card h-full flex flex-col justify-center">
      <CardContent className="p-6 flex flex-col items-center justify-center text-center space-y-6">
        
        <div className="space-y-1">
          <h3 className="text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 text-muted-foreground">
            <Target className="w-4 h-4 text-primary" />
            Investment Readiness
          </h3>
          <p className="text-xs text-muted-foreground">Composite Operational Metric</p>
        </div>

        <div className="relative flex items-center justify-center w-48 h-48">
          {/* Background Track */}
          <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r={radius}
              fill="transparent"
              stroke="currentColor"
              strokeWidth="8"
              className="text-muted/30"
            />
            {/* Animated Progress Ring */}
            <motion.circle
              cx="50"
              cy="50"
              r={radius}
              fill="transparent"
              stroke="currentColor"
              strokeWidth="8"
              strokeLinecap="round"
              className={colorClass}
              strokeDasharray={circumference}
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset }}
              transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
            />
          </svg>
          
          <div className="absolute flex flex-col items-center justify-center space-y-0.5">
            <span className="text-5xl font-black text-foreground tabular-nums tracking-tighter">
              {score}
            </span>
            <span className="text-sm font-medium text-muted-foreground">
              / 100
            </span>
          </div>
        </div>

        <div className={`px-4 py-2 rounded-lg text-sm font-semibold max-w-[200px] leading-snug ${bgClass}`}>
          {interpretation}
        </div>

      </CardContent>
    </Card>
  );
};

export default InvestmentReadinessScore;