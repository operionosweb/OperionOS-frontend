
import React from 'react';
import { useUserRole } from '@/hooks/useUserRole.js';

export default function FeatureGate({ allowedRoles, permission, children, fallback = null }) {
  const { hasRoleAccess, hasPermission } = useUserRole();

  let isAllowed = false;

  if (allowedRoles) {
    isAllowed = hasRoleAccess(allowedRoles);
  } else if (permission) {
    isAllowed = hasPermission(permission);
  } else {
    // If neither is provided, default to allowing (or could default to false)
    isAllowed = true;
  }

  if (!isAllowed) {
    return fallback;
  }

  return <>{children}</>;
}
