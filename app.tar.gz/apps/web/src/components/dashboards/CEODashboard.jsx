
import React from 'react';
import MetricCard from '@/components/MetricCard.jsx';
import { Activity, ShieldCheck, Target, TrendingUp, Users } from 'lucide-react';
import TierGate from '@/components/TierGate.jsx';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';

export default function CEODashboard() {
  return (
    <div className="space-y-6">
      <div className="summary-grid">
        <MetricCard label="Revenue per Movement" value="$8,450" icon={Activity} trend="up" trendValue="+4.2%" />
        <MetricCard label="Compliance Score" value="98/100" icon={ShieldCheck} trend="up" trendValue="Optimal" />
        <MetricCard label="Crew Utilization" value="84%" icon={Users} trend="up" trendValue="+2%" />
        <MetricCard label="On-Time Delivery" value="94.5%" icon={Target} trend="down" trendValue="-1%" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <TierGate feature="investor_mode" requiredTier="Enterprise" featureName="Investor Mode Snapshot">
          <Card>
            <CardHeader><CardTitle>Strategic Value Creation</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                <span className="text-gray-600">Operational Savings (YTD)</span>
                <span className="font-bold text-green-600">$1.24M</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-gray-100">
                <span className="text-gray-600">Avoided Disruption Cost</span>
                <span className="font-bold text-green-600">$480k</span>
              </div>
            </CardContent>
          </Card>
        </TierGate>

        <Card>
          <CardHeader><CardTitle>Global Operations Health</CardTitle></CardHeader>
          <CardContent>
            <div className="h-48 flex items-center justify-center bg-gray-50 border border-dashed border-gray-200 rounded-lg">
              <span className="text-gray-500 font-medium flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" /> Multi-regional Growth Analytics
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
