
import React from 'react';
import MetricCard from '@/components/MetricCard.jsx';
import { Activity, Clock, Navigation, AlertTriangle } from 'lucide-react';
import TierGate from '@/components/TierGate.jsx';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';

export default function ManagerDashboard() {
  return (
    <div className="space-y-6">
      <div className="summary-grid">
        <MetricCard label="Active Movements" value="34" icon={Navigation} />
        <MetricCard label="Pending Approvals" value="12" icon={Clock} trend="up" trendValue="Action needed" />
        <MetricCard label="Alerts" value="3" icon={AlertTriangle} trend="down" trendValue="Resolved" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Operational Tasks</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Approve Rotation Alpha</span>
              <Badge variant="warning">Pending</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Review Port Schedule</span>
              <Badge variant="secondary">Due Today</Badge>
            </div>
          </CardContent>
        </Card>

        <TierGate feature="automated_movements" requiredTier="Professional" featureName="Optimization Suggestions">
          <Card>
            <CardHeader><CardTitle>AI Optimization</CardTitle></CardHeader>
            <CardContent>
              <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                <p className="text-sm text-primary-hover font-medium mb-2">Cost Saving Opportunity</p>
                <p className="text-xs text-gray-600 mb-3">Merging Crew Group A with Group C can save $4,200 on upcoming repositioning.</p>
                <button className="text-xs font-semibold text-primary underline">Apply Suggestion</button>
              </div>
            </CardContent>
          </Card>
        </TierGate>
      </div>
    </div>
  );
}
