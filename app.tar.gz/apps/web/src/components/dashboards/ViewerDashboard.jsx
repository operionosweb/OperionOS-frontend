
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import MetricCard from '@/components/MetricCard.jsx';
import { Ship, Users } from 'lucide-react';

export default function ViewerDashboard() {
  return (
    <div className="space-y-6">
      <div className="summary-grid">
        <MetricCard label="Active Fleet" value="18" icon={Ship} />
        <MetricCard label="Active Crew" value="112" icon={Users} />
      </div>

      <Card>
        <CardHeader><CardTitle>Read-Only Operational View</CardTitle></CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 mb-4">
            You are viewing this dashboard with Viewer permissions. You can monitor live data but cannot execute changes or commands.
          </p>
          <div className="h-32 bg-gray-50 border border-gray-200 rounded-lg flex items-center justify-center">
            <span className="text-gray-400 font-medium">Status Feed OK</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
