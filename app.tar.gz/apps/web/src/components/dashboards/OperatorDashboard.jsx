
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Navigation } from 'lucide-react';

export default function OperatorDashboard() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Navigation className="w-5 h-5 text-primary" /> Active Movements
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reference</TableHead>
                <TableHead>Crew</TableHead>
                <TableHead>Route</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">MOV-8842</TableCell>
                <TableCell>Capt. Jenkins + 4</TableCell>
                <TableCell>LHR → DXB</TableCell>
                <TableCell><Badge variant="success">In Transit</Badge></TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">MOV-8843</TableCell>
                <TableCell>Eng. Smith + 2</TableCell>
                <TableCell>JFK → CDG</TableCell>
                <TableCell><Badge variant="warning">Delayed</Badge></TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader><CardTitle>My Tasks</CardTitle></CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500">No immediate tasks required. Monitoring 2 active movements.</p>
        </CardContent>
      </Card>
    </div>
  );
}
