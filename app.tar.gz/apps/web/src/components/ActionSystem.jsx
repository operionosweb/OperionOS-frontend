
import React, { createContext, useContext, useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { toast } from 'sonner';

const ActionContext = createContext(null);

export const useActionSystem = () => {
  const context = useContext(ActionContext);
  if (!context) throw new Error('useActionSystem must be used within ActionSystemProvider');
  return context;
};

export const ActionSystemProvider = ({ children }) => {
  const [dialogConfig, setDialogConfig] = useState({
    isOpen: false,
    title: '',
    description: '',
    confirmText: 'Confirm',
    cancelText: 'Cancel',
    isDestructive: false,
    onConfirm: null
  });

  const showConfirmationDialog = useCallback((config) => {
    setDialogConfig({
      isOpen: true,
      title: config.title || 'Confirm Action',
      description: config.description || 'Are you sure you want to proceed?',
      confirmText: config.confirmText || 'Confirm',
      cancelText: config.cancelText || 'Cancel',
      isDestructive: config.isDestructive || false,
      onConfirm: config.onConfirm
    });
  }, []);

  const closeDialog = useCallback(() => {
    setDialogConfig(prev => ({ ...prev, isOpen: false }));
  }, []);

  const executeNavigationAction = useCallback((tabId, navigateFn) => {
    if (navigateFn) navigateFn(tabId);
    toast.success(`Navigated to ${tabId}`);
  }, []);

  const executeModalAction = useCallback((modalType, data) => {
    toast(`Opened ${modalType.replace('-', ' ')} modal`);
    // In a real app, this would set state to open a specific complex modal
  }, []);

  const executeStatusChangeAction = useCallback((entityType, entityId, newStatus) => {
    toast.success(`Updated ${entityType} status to ${newStatus}`);
    // State update logic would go here
  }, []);

  const handleConfirm = useCallback(() => {
    if (dialogConfig.onConfirm) {
      dialogConfig.onConfirm();
    }
    closeDialog();
  }, [dialogConfig, closeDialog]);

  return (
    <ActionContext.Provider value={{ 
      executeNavigationAction, 
      executeModalAction, 
      executeStatusChangeAction, 
      showConfirmationDialog 
    }}>
      {children}
      
      <Dialog open={dialogConfig.isOpen} onOpenChange={(open) => !open && closeDialog()}>
        <DialogContent className="sm:max-w-md border-border/50">
          <DialogHeader>
            <DialogTitle>{dialogConfig.title}</DialogTitle>
            <DialogDescription className="pt-2">
              {dialogConfig.description}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-6 flex gap-2 sm:justify-end">
            <Button variant="ghost" onClick={closeDialog}>
              {dialogConfig.cancelText}
            </Button>
            <Button 
              variant={dialogConfig.isDestructive ? "destructive" : "default"} 
              onClick={handleConfirm}
            >
              {dialogConfig.confirmText}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </ActionContext.Provider>
  );
};
