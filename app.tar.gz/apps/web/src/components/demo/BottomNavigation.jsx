import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, AlertTriangle, TrendingUp, Anchor, Plane } from 'lucide-react';

const BottomNavigation = ({ industry = 'maritime' }) => {
  const location = useLocation();

  const maritimeLinks = [
    { path: '/demo/maritime', label: 'Hub', icon: LayoutDashboard },
    { path: '/demo/maritime/vessel-operations', label: 'Vessels', icon: Anchor },
    { path: '/demo/maritime/crew', label: 'Crew', icon: Users },
    { path: '/demo/maritime/disruptions', label: 'Alerts', icon: AlertTriangle },
    { path: '/demo/maritime/roi-savings-tracking', label: 'ROI', icon: TrendingUp },
  ];

  const aviationLinks = [
    { path: '/demo/aviation', label: 'Hub', icon: LayoutDashboard },
    { path: '/demo/aviation/flights', label: 'Flights', icon: Plane },
    { path: '/demo/aviation/crew', label: 'Crew', icon: Users },
    { path: '/demo/aviation/disruptions', label: 'Alerts', icon: AlertTriangle },
    { path: '/aviation-roi-savings', label: 'ROI', icon: TrendingUp },
  ];

  const links = industry === 'aviation' ? aviationLinks : maritimeLinks;

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 pb-safe">
      <div className="flex justify-around items-center h-16 px-2">
        {links.map((link) => {
          const Icon = link.icon;
          const isActive = location.pathname === link.path || (link.path !== `/demo/${industry}` && location.pathname.startsWith(link.path));
          
          return (
            <Link
              key={link.path}
              to={link.path}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${
                isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'fill-primary/20' : ''}`} />
              <span className="text-[10px] font-medium">{link.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};

export default BottomNavigation;