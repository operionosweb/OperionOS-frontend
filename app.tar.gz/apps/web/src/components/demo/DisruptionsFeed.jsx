import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Clock, Filter, ChevronDown } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import DisruptionDetailModal from './aviation/DisruptionDetailModal.jsx';

const DisruptionsFeed = () => {
  const { disruptionsData, selectedDisruption, setSelectedDisruption, markDisruptionRead, openModal } = useDemo();
  
  const [filters, setFilters] = useState({
    severity: 'All',
    region: 'All',
    vessel: 'All',
    type: 'All'
  });

  const [modalDisruption, setModalDisruption] = useState(null);

  const filteredDisruptions = useMemo(() => {
    return disruptionsData.filter(d => {
      if (filters.severity !== 'All' && d.severity !== filters.severity) return false;
      if (filters.region !== 'All' && d.region !== filters.region) return false;
      if (filters.vessel !== 'All' && d.vessel !== filters.vessel) return false;
      if (filters.type !== 'All' && d.type !== filters.type) return false;
      return true;
    });
  }, [disruptionsData, filters]);

  const handleSelect = (disruption) => {
    setSelectedDisruption(disruption);
    markDisruptionRead(disruption.id);
    setModalDisruption(disruption);
  };

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'High': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'Medium': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'Low': return 'bg-primary/10 text-primary border-primary/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <>
      <div className="bg-card border border-border rounded-xl sm:rounded-2xl shadow-sm flex flex-col h-[500px] sm:h-[600px] w-full">
        <div className="p-3 sm:p-4 border-b border-border shrink-0">
          <div className="flex items-center justify-between mb-3 sm:mb-4">
            <h3 className="text-base sm:text-lg font-bold flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-destructive" />
              Live Disruptions Feed
            </h3>
            <Badge variant="secondary" className="text-[10px] sm:text-xs">{filteredDisruptions.length} Active</Badge>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <select 
              className="text-[10px] sm:text-xs bg-muted/50 border border-border rounded-md px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary flex-1 min-w-[100px]"
              value={filters.severity}
              onChange={(e) => setFilters(prev => ({ ...prev, severity: e.target.value }))}
            >
              <option value="All">All Severities</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
            <select 
              className="text-[10px] sm:text-xs bg-muted/50 border border-border rounded-md px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary flex-1 min-w-[100px]"
              value={filters.type}
              onChange={(e) => setFilters(prev => ({ ...prev, type: e.target.value }))}
            >
              <option value="All">All Types</option>
              <option value="Travel">Travel</option>
              <option value="Crew">Crew</option>
              <option value="Port">Port</option>
              <option value="Weather">Weather</option>
            </select>
            <select 
              className="text-[10px] sm:text-xs bg-muted/50 border border-border rounded-md px-2 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary flex-1 min-w-[100px]"
              value={filters.region}
              onChange={(e) => setFilters(prev => ({ ...prev, region: e.target.value }))}
            >
              <option value="All">All Regions</option>
              <option value="Singapore">Singapore</option>
              <option value="Rotterdam">Rotterdam</option>
              <option value="Dubai">Dubai</option>
              <option value="Houston">Houston</option>
            </select>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 sm:p-3 space-y-2 sm:space-y-3 scrollable-y">
          <AnimatePresence>
            {filteredDisruptions.map((disruption) => (
              <motion.div
                key={disruption.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onClick={() => handleSelect(disruption)}
                className={`p-3 sm:p-4 rounded-xl border cursor-pointer transition-all duration-200 ${
                  selectedDisruption?.id === disruption.id 
                    ? 'border-primary bg-primary/5 shadow-md' 
                    : 'border-border bg-card hover:border-primary/50 hover:shadow-sm'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    {!disruption.read && <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-primary animate-pulse" />}
                    <Badge variant="outline" className={`${getSeverityColor(disruption.severity)} text-[10px] sm:text-xs`}>
                      {disruption.severity}
                    </Badge>
                    <span className="text-[10px] sm:text-xs text-muted-foreground font-medium">{disruption.type}</span>
                  </div>
                  <div className="flex items-center text-[10px] sm:text-xs text-muted-foreground shrink-0 ml-2">
                    <Clock className="w-3 h-3 mr-1" />
                    {disruption.time}
                  </div>
                </div>
                <h4 className="font-semibold text-sm sm:text-base mb-1 text-foreground break-words">{disruption.title}</h4>
                <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2 break-words">{disruption.description}</p>
                
                <div className="mt-3 flex justify-end">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-7 text-[10px] sm:text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      setModalDisruption(disruption);
                    }}
                  >
                    View Details
                  </Button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {filteredDisruptions.length === 0 && (
            <div className="text-center py-8 sm:py-12 text-muted-foreground">
              <AlertTriangle className="w-6 h-6 sm:w-8 sm:h-8 mx-auto mb-2 sm:mb-3 opacity-20" />
              <p className="text-xs sm:text-sm">No disruptions match your filters.</p>
            </div>
          )}
        </div>
      </div>

      <DisruptionDetailModal 
        isOpen={!!modalDisruption} 
        onClose={() => setModalDisruption(null)} 
        disruption={modalDisruption} 
      />
    </>
  );
};

export default DisruptionsFeed;