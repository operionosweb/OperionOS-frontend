import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { MapPin, Users, AlertTriangle } from 'lucide-react';
import StatusBadge from './StatusBadge.jsx';
import ProgressBar from './ProgressBar.jsx';

const VesselCard = ({ vessel }) => {
  const getProgressColor = (status) => {
    switch(status) {
      case 'ACTIVE': return 'bg-green-500';
      case 'DELAYED': return 'bg-yellow-500';
      case 'ALERT': return 'bg-red-500';
      default: return 'bg-blue-500';
    }
  };

  return (
    <Card className="p-4 hover:shadow-xl transition-all border-2 border-gray-200 hover:border-primary/50 bg-white">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h4 className="font-bold text-gray-900 flex items-center gap-2">
            {vessel.name}
            {vessel.alert && <AlertTriangle className="w-4 h-4 text-red-600" />}
          </h4>
          <div className="flex items-center gap-1 text-xs text-gray-600 mt-1">
            <MapPin className="w-3 h-3" /> {vessel.location}
          </div>
        </div>
        <StatusBadge status={vessel.status} />
      </div>
      
      <div className="flex items-center gap-4 mb-4 text-sm">
        <div className="flex items-center gap-1.5 text-gray-600">
          <Users className="w-4 h-4" />
          <span className="font-medium text-gray-900">{vessel.crewCount}</span> Crew
        </div>
      </div>

      <ProgressBar 
        value={vessel.progressValue} 
        max={100} 
        label={vessel.progressLabel} 
        colorClass={getProgressColor(vessel.status)}
        showValue={false}
      />
    </Card>
  );
};

export default VesselCard;