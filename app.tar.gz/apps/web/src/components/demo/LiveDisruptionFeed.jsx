import React from 'react';
import { motion } from 'framer-motion';
import { Clock, AlertTriangle, Ship, Users, Settings } from 'lucide-react';

const LiveDisruptionFeed = ({ onSelectIncident }) => {
  const incidents = [
    {
      id: 1,
      vessel: 'Atlantic Sentinel',
      type: 'Port Congestion',
      desc: 'Berth unavailable at Rotterdam. Estimated 14h delay affecting 3 downstream schedules.',
      time: '2m ago',
      severity: 'critical',
      icon: Ship
    },
    {
      id: 2,
      vessel: 'Pacific Voyager',
      type: 'Weather Warning',
      desc: 'Severe storm cell tracking across planned route. Deviation required.',
      time: '14m ago',
      severity: 'warning',
      icon: AlertTriangle
    },
    {
      id: 3,
      vessel: 'CMA CGM Orpheus',
      type: 'Crew Status',
      desc: 'Chief Engineer medical emergency. Immediate replacement needed at next port.',
      time: '1h ago',
      severity: 'critical',
      icon: Users
    },
    {
      id: 4,
      vessel: 'Global Mariner',
      type: 'Engine Malfunction',
      desc: 'Main engine cylinder #4 temperature anomaly. Speed reduced to 12 knots.',
      time: '2h ago',
      severity: 'normal',
      icon: Settings
    }
  ];

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'critical': return 'bg-[hsl(var(--critical))]';
      case 'warning': return 'bg-[hsl(var(--warning))]';
      case 'normal': return 'bg-[hsl(var(--primary))]';
      default: return 'bg-muted';
    }
  };

  const getSeverityBorder = (severity) => {
    switch(severity) {
      case 'critical': return 'border-l-[hsl(var(--critical))]';
      case 'warning': return 'border-l-[hsl(var(--warning))]';
      case 'normal': return 'border-l-[hsl(var(--primary))]';
      default: return 'border-l-muted';
    }
  };

  return (
    <div className="flex flex-col h-full bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
      <div className="p-4 border-b border-border bg-muted/20 flex justify-between items-center shrink-0">
        <h2 className="font-bold text-lg flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-[hsl(var(--critical))] animate-pulse"></div>
          LIVE FEED
        </h2>
        <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-md">4 Active</span>
      </div>
      
      <div className="flex-1 overflow-y-auto p-3 space-y-3 hide-scrollbar">
        {incidents.map((incident, idx) => (
          <motion.div
            key={incident.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            onClick={() => onSelectIncident(incident)}
            className={`relative p-4 rounded-xl border border-border bg-card hover:shadow-md transition-all cursor-pointer border-l-4 ${getSeverityBorder(incident.severity)} group`}
          >
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-2">
                <div className={`p-1.5 rounded-md ${getSeverityColor(incident.severity)}/10`}>
                  <incident.icon className={`w-4 h-4 text-${incident.severity === 'critical' ? '[hsl(var(--critical))]' : incident.severity === 'warning' ? '[hsl(var(--warning))]' : 'primary'}`} />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{incident.type}</span>
              </div>
              <div className="flex items-center text-xs text-muted-foreground font-medium">
                <Clock className="w-3 h-3 mr-1" />
                {incident.time}
              </div>
            </div>
            
            <h3 className="font-bold text-foreground mb-1 group-hover:text-primary transition-colors">{incident.vessel}</h3>
            <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">{incident.desc}</p>
            
            <div className="mt-3 pt-3 border-t border-border/50 flex justify-between items-center">
              <div className="flex -space-x-2">
                <img src="https://i.pravatar.cc/150?u=1" className="w-6 h-6 rounded-full border-2 border-card" alt="Crew" />
                <img src="https://i.pravatar.cc/150?u=2" className="w-6 h-6 rounded-full border-2 border-card" alt="Crew" />
                <div className="w-6 h-6 rounded-full border-2 border-card bg-muted flex items-center justify-center text-[8px] font-bold">+2</div>
              </div>
              <span className="text-xs font-medium text-primary">View Details →</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default LiveDisruptionFeed;