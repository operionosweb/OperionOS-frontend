import React from 'react';
import SummaryMetrics from './SummaryMetrics.jsx';
import ROICalculationLogic from './ROICalculationLogic.jsx';
import SavingsCard from './SavingsCard.jsx';
import AssumptionsPanel from './AssumptionsPanel.jsx';
import { Plane, Building, Timer, Settings, ShieldCheck, FolderSync as CalendarSync } from 'lucide-react';

const ROIDashboard = () => {
  const savingsData = [
    {
      title: "Crew Movements Optimization",
      description: "Consolidated flight bookings and optimized routing for crew changes.",
      icon: Plane,
      perEvent: "€72,000",
      monthly: "€7,200",
      annual: "€864,000",
      rotations: 12,
      contribution: 34,
      colorClass: "text-blue-600",
      bgClass: "bg-blue-500/10",
      assumptions: [
        "15% reduction in average flight costs via group booking algorithms.",
        "Elimination of 80% of premium last-minute fares.",
        "Optimized hub routing reducing layover penalties."
      ]
    },
    {
      title: "Accommodation Reduction",
      description: "Minimized hotel stays through precise vessel ETA alignment.",
      icon: Building,
      perEvent: "€48,000",
      monthly: "€4,800",
      annual: "€576,000",
      rotations: 12,
      contribution: 22,
      colorClass: "text-purple-600",
      bgClass: "bg-purple-500/10",
      assumptions: [
        "Average hotel stay reduced from 2.5 days to 1.1 days per crew member.",
        "Negotiated dynamic rates applied automatically.",
        "Elimination of 'buffer days' through real-time tracking."
      ]
    },
    {
      title: "Idle Time Reduction",
      description: "Decreased non-productive crew time during transit and handovers.",
      icon: Timer,
      perEvent: "€36,000",
      monthly: "€3,600",
      annual: "€432,000",
      rotations: 12,
      contribution: 17,
      colorClass: "text-orange-600",
      bgClass: "bg-orange-500/10",
      assumptions: [
        "Crew utilization rate increased by 12%.",
        "Reduced overlap days where double wages are paid.",
        "Faster port-to-vessel transfer coordination."
      ]
    },
    {
      title: "Operational Efficiency",
      description: "Automated administrative tasks and reduced manual coordination.",
      icon: Settings,
      perEvent: "€24,000",
      monthly: "€2,400",
      annual: "€288,000",
      rotations: 12,
      contribution: 11,
      colorClass: "text-emerald-600",
      bgClass: "bg-emerald-500/10",
      assumptions: [
        "25% reduction in HR and logistics administrative hours.",
        "Automated document verification replacing manual checks.",
        "Centralized communication reducing error-correction time."
      ]
    },
    {
      title: "Compliance & Safety",
      description: "Avoidance of fines and delays due to certification expirations.",
      icon: ShieldCheck,
      perEvent: "€20,000",
      monthly: "€2,000",
      annual: "€240,000",
      rotations: 12,
      contribution: 10,
      colorClass: "text-red-600",
      bgClass: "bg-red-500/10",
      assumptions: [
        "Zero port state control detentions due to crew documentation.",
        "Proactive renewal scheduling avoiding premium rush fees.",
        "Reduced risk of fatigue-related incidents."
      ]
    },
    {
      title: "Scheduling Alignment",
      description: "Optimized rotation planning to maximize contract utilization.",
      icon: CalendarSync,
      perEvent: "€12,000",
      monthly: "€1,200",
      annual: "€144,000",
      rotations: 12,
      contribution: 6,
      colorClass: "text-cyan-600",
      bgClass: "bg-cyan-500/10",
      assumptions: [
        "Contract completion rates improved to 98%.",
        "Reduced early repatriation costs.",
        "Better alignment of senior officer handovers."
      ]
    }
  ];

  return (
    <div className="flex flex-col space-y-8 pb-8">
      <div className="flex flex-col gap-2">
        <h2 className="text-2xl font-bold text-foreground">ROI & Savings Tracking</h2>
        <p className="text-muted-foreground">Comprehensive breakdown of AI-driven cost reductions across fleet operations.</p>
      </div>

      <SummaryMetrics />
      
      <ROICalculationLogic />

      <div className="space-y-4">
        <h3 className="text-xl font-bold text-foreground">Savings by Category</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {savingsData.map((data, index) => (
            <SavingsCard key={index} {...data} />
          ))}
        </div>
      </div>

      <AssumptionsPanel />
    </div>
  );
};

export default ROIDashboard;