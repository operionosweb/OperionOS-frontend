import React, { useState } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';
import { ChevronDown, ChevronUp } from 'lucide-react';
import TimeframeLabel from './TimeframeLabel.jsx';
import { cn } from '@/lib/utils.js';

const SavingsCard = ({ 
  title, 
  description, 
  icon: Icon, 
  perEvent, 
  monthly,
  annual, 
  rotations,
  contribution, 
  assumptions,
  colorClass = "text-primary",
  bgClass = "bg-primary/10"
}) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Card className="flex flex-col overflow-hidden transition-all duration-300 hover:shadow-lg border-border/60 hover:border-border">
      <div className="p-5 flex-1 flex flex-col gap-4">
        <div className="flex justify-between items-start gap-4">
          <div className="flex items-center gap-3">
            <div className={cn("p-2.5 rounded-xl", bgClass, colorClass)}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight text-foreground">{title}</h3>
              <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">{description}</p>
            </div>
          </div>
          <Badge variant="secondary" className="shrink-0 font-mono bg-secondary/50">
            {contribution}%
          </Badge>
        </div>

        <div className="mt-auto pt-2">
          <TimeframeLabel 
            perEvent={perEvent}
            monthly={monthly}
            annual={annual}
            rotations={rotations}
            tooltipText="Calculated based on historical baseline vs AI-optimized routing."
          />
        </div>
      </div>

      <Collapsible open={isOpen} onOpenChange={setIsOpen} className="border-t border-border/50 bg-muted/20">
        <CollapsibleTrigger className="flex w-full items-center justify-between p-3 text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors">
          <span>Optimization Assumptions</span>
          {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </CollapsibleTrigger>
        <CollapsibleContent className="px-4 pb-4 pt-1 text-sm text-muted-foreground animate-in slide-in-from-top-2">
          <div className="space-y-2 border-l-2 border-primary/20 pl-3 ml-1">
            {assumptions.map((assumption, idx) => (
              <p key={idx} className="leading-relaxed">
                <span className="text-foreground font-medium mr-1.5">•</span>
                {assumption}
              </p>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};

export default SavingsCard;