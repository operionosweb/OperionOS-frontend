import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { TrendingUp, TrendingDown, Wallet, BrainCircuit, RotateCcw, Target } from 'lucide-react';
import { cn } from '@/lib/utils.js';

const MetricCard = ({ title, value, subtext, trend, trendUp, icon: Icon, colorClass }) => (
  <Card className="p-5 border-border shadow-sm flex flex-col h-full">
    <div className="flex justify-between items-start mb-4">
      <div className={cn("p-2.5 rounded-xl bg-opacity-10", colorClass.bg, colorClass.text)}>
        <Icon className="w-5 h-5" />
      </div>
      <div className={cn(
        "flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-md",
        trendUp ? "bg-green-500/10 text-green-600" : "bg-red-500/10 text-red-600"
      )}>
        {trendUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
        {trend}%
      </div>
    </div>
    <div className="mt-auto">
      <h4 className="text-sm font-medium text-muted-foreground mb-1">{title}</h4>
      <div className="text-3xl font-extrabold text-foreground tracking-tight">{value}</div>
      <p className="text-xs text-muted-foreground mt-2">{subtext}</p>
    </div>
  </Card>
);

const SummaryMetrics = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <MetricCard 
        title="Total Savings YTD"
        value="€8.4M"
        subtext="Year to Date (12 months)"
        trend="12"
        trendUp={true}
        icon={Wallet}
        colorClass={{ bg: "bg-primary", text: "text-primary" }}
      />
      <MetricCard 
        title="AI-Driven Savings"
        value="€5.9M"
        subtext="70% of total savings"
        trend="18"
        trendUp={true}
        icon={BrainCircuit}
        colorClass={{ bg: "bg-purple-500", text: "text-purple-600" }}
      />
      <MetricCard 
        title="Avg Savings / Rotation"
        value="€180k"
        subtext="47 crew rotations this year"
        trend="8"
        trendUp={true}
        icon={RotateCcw}
        colorClass={{ bg: "bg-blue-500", text: "text-blue-600" }}
      />
      <MetricCard 
        title="Projected Annual"
        value="€10.2M"
        subtext="Based on current optimization rate"
        trend="15"
        trendUp={true}
        icon={Target}
        colorClass={{ bg: "bg-emerald-500", text: "text-emerald-600" }}
      />
    </div>
  );
};

export default SummaryMetrics;