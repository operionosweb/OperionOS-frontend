import React, { useState } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Users, DollarSign, TrendingDown, Calculator, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';

const CalculationStep = ({ icon: Icon, label, value, subtext, isLast }) => (
  <div className="flex items-center gap-4">
    <div className="flex flex-col">
      <div className="flex items-center gap-2 mb-1">
        <div className="p-1.5 rounded-md bg-muted text-muted-foreground">
          <Icon className="w-4 h-4" />
        </div>
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      <span className="text-xl font-bold text-foreground">{value}</span>
      {subtext && <span className="text-xs text-muted-foreground mt-0.5">{subtext}</span>}
    </div>
    {!isLast && (
      <div className="hidden md:flex items-center justify-center px-4 text-border">
        <ArrowRight className="w-5 h-5" />
      </div>
    )}
  </div>
);

const ROICalculationLogic = () => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <Card className="border-border shadow-sm overflow-hidden">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <div className="flex items-center justify-between p-5 bg-card border-b border-border/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 text-primary rounded-lg">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg">ROI Calculation Logic</h3>
              <p className="text-sm text-muted-foreground">Standardized baseline formula for per-event savings</p>
            </div>
          </div>
          <CollapsibleTrigger className="p-2 hover:bg-muted rounded-md transition-colors">
            {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </CollapsibleTrigger>
        </div>
        
        <CollapsibleContent className="p-6 bg-muted/10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 md:gap-2">
            <CalculationStep 
              icon={Users} 
              label="Crew Affected" 
              value="45" 
              subtext="Per rotation event" 
            />
            <CalculationStep 
              icon={DollarSign} 
              label="Avg Cost" 
              value="€2,200" 
              subtext="Per crew member" 
            />
            <CalculationStep 
              icon={Calculator} 
              label="Baseline Cost" 
              value="€99,000" 
              subtext="Total without AI" 
            />
            <CalculationStep 
              icon={TrendingDown} 
              label="Efficiency" 
              value="25%" 
              subtext="AI Optimization Rate" 
            />
            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 flex flex-col">
              <span className="text-xs font-bold uppercase tracking-wider text-primary mb-1">Savings Per Event</span>
              <span className="text-2xl font-extrabold text-primary">€24,750</span>
              <span className="text-xs text-muted-foreground mt-1">Est. 12-15 rotations/yr</span>
            </div>
          </div>
          
          <div className="mt-6 pt-4 border-t border-border/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <p className="text-sm text-muted-foreground max-w-2xl">
              This calculation represents a single standard vessel rotation. Annual savings range from <strong className="text-foreground">€297,000 to €371,250</strong> per vessel depending on operational frequency and market conditions.
            </p>
            <div className="text-xs font-mono bg-background px-3 py-1.5 rounded-md border border-border">
              Formula: (45 × €2,200) × 0.25
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};

export default ROICalculationLogic;