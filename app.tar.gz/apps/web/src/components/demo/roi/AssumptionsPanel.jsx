import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion.jsx';
import { FileText, LineChart, Database, AlertCircle } from 'lucide-react';

const AssumptionsPanel = () => {
  return (
    <Card className="border-border shadow-sm overflow-hidden">
      <div className="p-5 border-b border-border/50 bg-muted/20">
        <h3 className="font-bold text-lg">Methodology & Assumptions</h3>
        <p className="text-sm text-muted-foreground">Transparent breakdown of data sources and variability factors</p>
      </div>
      
      <Accordion type="single" collapsible className="w-full" defaultValue="item-1">
        <AccordionItem value="item-1" className="border-b border-border/50 px-5">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3 text-left">
              <div className="p-1.5 bg-blue-500/10 text-blue-600 rounded-md">
                <FileText className="w-4 h-4" />
              </div>
              <span className="font-semibold">Cost Assumptions</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground pb-4 leading-relaxed">
            <ul className="space-y-2 list-disc pl-5 marker:text-muted">
              <li><strong>Crew Flight Costs:</strong> Estimated at €800–€1,200 per international segment.</li>
              <li><strong>Accommodation:</strong> €120–€180 per night in major port cities (Singapore, Rotterdam, Houston).</li>
              <li><strong>Ground Transfers:</strong> €200–€400 per group transfer event.</li>
              <li><strong>Administrative Overhead:</strong> €200–€300 per crew member for visa, compliance, and booking management.</li>
            </ul>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-2" className="border-b border-border/50 px-5">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3 text-left">
              <div className="p-1.5 bg-green-500/10 text-green-600 rounded-md">
                <LineChart className="w-4 h-4" />
              </div>
              <span className="font-semibold">Optimization Logic</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground pb-4 leading-relaxed">
            <ul className="space-y-2 list-disc pl-5 marker:text-muted">
              <li><strong>Shared Flights:</strong> 15–20% cost reduction by grouping crew on identical flight itineraries.</li>
              <li><strong>Advance Booking:</strong> Reduced last-minute premium fares through predictive scheduling.</li>
              <li><strong>Schedule Alignment:</strong> 20–30% reduction in idle time (hotel days) by aligning flights precisely with vessel ETA.</li>
              <li><strong>Admin Automation:</strong> 25% reduction in manual processing time via automated compliance checks.</li>
            </ul>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-3" className="border-b border-border/50 px-5">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3 text-left">
              <div className="p-1.5 bg-purple-500/10 text-purple-600 rounded-md">
                <Database className="w-4 h-4" />
              </div>
              <span className="font-semibold">Data Basis</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground pb-4 leading-relaxed">
            <p className="mb-2">Calculations are derived from a combination of:</p>
            <ul className="space-y-2 list-disc pl-5 marker:text-muted">
              <li>Aggregated industry averages for maritime logistics (2024-2025).</li>
              <li>Proprietary AI simulations run across 500+ historical vessel rotations.</li>
              <li>2+ years of anonymized operational data from mid-to-large fleet operators.</li>
            </ul>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-4" className="border-none px-5">
          <AccordionTrigger className="hover:no-underline py-4">
            <div className="flex items-center gap-3 text-left">
              <div className="p-1.5 bg-orange-500/10 text-orange-600 rounded-md">
                <AlertCircle className="w-4 h-4" />
              </div>
              <span className="font-semibold">Variability Factors</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground pb-4 leading-relaxed">
            <p>Actual realized savings may fluctuate based on several external factors:</p>
            <ul className="space-y-2 list-disc pl-5 marker:text-muted mt-2">
              <li><strong>Seasonality:</strong> ±10–15% variance during peak travel seasons or holidays.</li>
              <li><strong>Location:</strong> ±5–10% variance depending on port infrastructure and local transport monopolies.</li>
              <li><strong>Vessel Type:</strong> Specialized vessels (e.g., LNG carriers) may require specific crew certifications, limiting routing options.</li>
              <li><strong>Market Conditions:</strong> Global fuel prices and airline capacity constraints.</li>
            </ul>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </Card>
  );
};

export default AssumptionsPanel;