import React from 'react';
import { Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip.jsx';

const TimeframeLabel = ({ perEvent, monthly, annual, rotations, tooltipText }) => {
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground bg-muted/50 p-2 rounded-md border border-border/50">
      <div className="flex items-center gap-1.5">
        <span className="font-semibold text-foreground">Per Event:</span>
        <span>{perEvent}</span>
      </div>
      <span className="text-border hidden sm:inline">|</span>
      <div className="flex items-center gap-1.5">
        <span className="font-semibold text-foreground">Monthly Impact:</span>
        <span>{monthly} <span className="text-[10px] opacity-80">(avg)</span></span>
      </div>
      <span className="text-border hidden sm:inline">|</span>
      <div className="flex items-center gap-1.5">
        <span className="font-semibold text-foreground">Annualized:</span>
        <span className="text-primary font-medium">{annual}</span>
        <span className="text-[10px] opacity-80">({rotations} rotations/yr)</span>
      </div>
      
      {tooltipText && (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Info className="w-3.5 h-3.5 ml-auto text-muted-foreground hover:text-foreground cursor-help transition-colors" />
            </TooltipTrigger>
            <TooltipContent side="top" className="max-w-xs">
              <p>{tooltipText}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      )}
    </div>
  );
};

export default TimeframeLabel;