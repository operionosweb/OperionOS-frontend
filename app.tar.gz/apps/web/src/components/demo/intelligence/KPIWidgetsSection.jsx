import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { ArrowUpRight, ArrowDownRight, Activity, DollarSign, Clock, Users, Plane, AlertTriangle, TrendingUp } from 'lucide-react';
import { useBIState } from '@/contexts/BIStateContext.jsx';
import KPIDetailModal from './KPIDetailModal.jsx';

const KPIWidgetsSection = () => {
  const { kpiMetrics, setSelectedKPI } = useBIState();

  const formatValue = (key, value) => {
    if (key.toLowerCase().includes('cost') || key.toLowerCase().includes('savings')) {
      return `€${value.toLocaleString()}`;
    }
    if (key.toLowerCase().includes('rate') || key.toLowerCase().includes('utilization') || key === 'otp') {
      return `${value}%`;
    }
    return value.toLocaleString();
  };

  const getIcon = (key) => {
    switch(key) {
      case 'otp': return <Activity className="w-5 h-5" />;
      case 'totalCost': case 'costPerFlight': case 'totalSavings': return <DollarSign className="w-5 h-5" />;
      case 'delayMinutes': return <Clock className="w-5 h-5" />;
      case 'crewUtilization': return <Users className="w-5 h-5" />;
      case 'aircraftUtilization': return <Plane className="w-5 h-5" />;
      case 'disruptionRate': return <AlertTriangle className="w-5 h-5" />;
      default: return <TrendingUp className="w-5 h-5" />;
    }
  };

  const getColorClass = (key, trend) => {
    const isGoodUp = ['otp', 'crewUtilization', 'aircraftUtilization', 'totalSavings'].includes(key);
    if (isGoodUp) return trend === 'up' ? 'text-green-600 bg-green-500/10' : 'text-red-600 bg-red-500/10';
    return trend === 'down' ? 'text-green-600 bg-green-500/10' : 'text-red-600 bg-red-500/10';
  };

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(kpiMetrics).map(([key, data]) => (
          <Card 
            key={key} 
            className="cursor-pointer hover:shadow-md transition-all duration-200 hover:-translate-y-1 border-border"
            onClick={() => setSelectedKPI({ key, ...data })}
          >
            <CardContent className="p-5">
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 rounded-lg bg-muted text-muted-foreground">
                  {getIcon(key)}
                </div>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getColorClass(key, data.trend)}`}>
                  {data.trend === 'up' ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {Math.abs(data.change)}%
                </div>
              </div>
              <div>
                <h3 className="text-3xl font-bold tracking-tight mb-1">{formatValue(key, data.value)}</h3>
                <p className="text-sm text-muted-foreground font-medium">{data.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      <KPIDetailModal />
    </>
  );
};

export default KPIWidgetsSection;