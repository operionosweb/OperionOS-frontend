import React, { useState, useMemo } from 'react';
import { Activity, Play, RotateCcw, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { generateForecastData, generateScenarioResults } from '@/lib/biData.js';
import { toast } from 'sonner';

const PredictiveAnalysis = () => {
  const forecastData = useMemo(() => generateForecastData(), []);
  const scenarioResults = useMemo(() => generateScenarioResults(), []);
  
  const [activeScenario, setActiveScenario] = useState(null);
  const [isSimulating, setIsSimulating] = useState(false);
  const [results, setResults] = useState(null);

  const runSimulation = (scenarioKey) => {
    setActiveScenario(scenarioKey);
    setIsSimulating(true);
    setResults(null);
    
    setTimeout(() => {
      setIsSimulating(false);
      setResults(scenarioResults[scenarioKey]);
      toast.success('Simulation complete');
    }, 1500);
  };

  const resetSimulation = () => {
    setActiveScenario(null);
    setResults(null);
  };

  return (
    <div className="space-y-6">
      <div className="scroll-wrapper-x fade-bg -mx-4 px-4 md:mx-0 md:px-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 scroll-container-x">
          {/* Forecast Charts */}
          <Card className="bi-card scroll-item">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Crew Demand Forecast (30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={forecastData.crewDemand} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={10} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} domain={['dataMin - 10', 'dataMax + 10']} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }} />
                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                    <Area type="monotone" dataKey="upper" stroke="none" fill="hsl(var(--chart-1))" fillOpacity={0.1} name="Confidence Interval" />
                    <Area type="monotone" dataKey="lower" stroke="none" fill="hsl(var(--background))" fillOpacity={1} />
                    <Line type="monotone" dataKey="expected" stroke="hsl(var(--chart-1))" strokeWidth={2} dot={false} name="Expected Demand" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="bi-card scroll-item">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Crew Movements Cost Forecast</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={forecastData.travelCost} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={10} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `€${val/1000}k`} />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }} />
                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                    <Area type="monotone" dataKey="upper" stroke="none" fill="hsl(var(--chart-3))" fillOpacity={0.1} name="Confidence Interval" />
                    <Area type="monotone" dataKey="lower" stroke="none" fill="hsl(var(--background))" fillOpacity={1} />
                    <Line type="monotone" dataKey="expected" stroke="hsl(var(--chart-3))" strokeWidth={2} dot={false} name="Expected Cost" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Scenario Simulation Tool */}
      <Card className="bi-card border-primary/20">
        <CardHeader className="pb-4 border-b border-border bg-muted/20">
          <CardTitle className="text-xl flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            Scenario Simulation Engine
          </CardTitle>
          <p className="text-sm text-muted-foreground">Test operational changes against predictive models</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="scroll-wrapper-x fade-card -mx-6 px-6 md:mx-0 md:px-0 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 scroll-container-x">
              <Button 
                variant={activeScenario === 'shortage' ? 'default' : 'outline'} 
                className="h-auto py-4 flex flex-col items-center justify-center gap-2 scroll-item"
                onClick={() => runSimulation('shortage')}
              >
                <span className="font-semibold">Crew Shortage</span>
                <span className="text-xs opacity-70 font-normal">15% reduction</span>
              </Button>
              <Button 
                variant={activeScenario === 'travelCost' ? 'default' : 'outline'} 
                className="h-auto py-4 flex flex-col items-center justify-center gap-2 scroll-item"
                onClick={() => runSimulation('travelCost')}
              >
                <span className="font-semibold">Crew Movements Cost Spike</span>
                <span className="text-xs opacity-70 font-normal">+20% airfare</span>
              </Button>
              <Button 
                variant={activeScenario === 'rotation' ? 'default' : 'outline'} 
                className="h-auto py-4 flex flex-col items-center justify-center gap-2 scroll-item"
                onClick={() => runSimulation('rotation')}
              >
                <span className="font-semibold">Rotation Delay</span>
                <span className="text-xs opacity-70 font-normal">+3 days global</span>
              </Button>
              <Button 
                variant="outline" 
                className="h-auto py-4 flex flex-col items-center justify-center gap-2 border-dashed scroll-item"
                onClick={() => toast.info('Custom scenario builder opening...')}
              >
                <span className="font-semibold">Custom Scenario</span>
                <span className="text-xs opacity-70 font-normal">Configure parameters</span>
              </Button>
            </div>
          </div>

          {isSimulating && (
            <div className="py-12 flex flex-col items-center justify-center text-muted-foreground">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
              <p>Running Monte Carlo simulations...</p>
            </div>
          )}

          {results && !isSimulating && (
            <div className="p-6 rounded-xl bg-muted/30 border border-border animate-in fade-in slide-in-from-bottom-4">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h4 className="font-semibold text-lg mb-1">Simulation Results</h4>
                  <p className="text-sm text-muted-foreground">{results.description}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={resetSimulation}>
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="p-4 rounded-lg bg-background border border-border">
                  <div className="text-sm text-muted-foreground mb-1">Projected Cost Impact</div>
                  <div className={`text-2xl font-bold ${results.cost.includes('+') ? 'text-destructive' : 'text-teal-500'}`}>
                    {results.cost}
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-background border border-border">
                  <div className="text-sm text-muted-foreground mb-1">Efficiency Change</div>
                  <div className={`text-2xl font-bold ${results.efficiency.includes('-') ? 'text-destructive' : 'text-teal-500'}`}>
                    {results.efficiency}
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-background border border-border">
                  <div className="text-sm text-muted-foreground mb-1">Risk Level</div>
                  <div className={`text-2xl font-bold ${
                    results.risk === 'High' ? 'text-destructive' : 
                    results.risk === 'Medium' ? 'text-warning-foreground' : 'text-teal-500'
                  }`}>
                    {results.risk}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3">
                <Button variant="outline">Export Report</Button>
                <Button className="bg-primary text-primary-foreground">Generate Mitigation Plan</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PredictiveAnalysis;