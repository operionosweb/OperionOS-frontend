import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { useBIState } from '@/contexts/BIStateContext.jsx';
import { Users, ShieldAlert, Clock, DollarSign } from 'lucide-react';

const CrewAnalyticsSection = () => {
  const { crewMetrics } = useBIState();

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-3 bg-primary/10 rounded-xl text-primary"><Users className="w-6 h-6"/></div>
            <div>
              <p className="text-sm text-muted-foreground font-medium">Avg Utilization</p>
              <h3 className="text-2xl font-bold">82.4%</h3>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-3 bg-destructive/10 rounded-xl text-destructive"><ShieldAlert className="w-6 h-6"/></div>
            <div>
              <p className="text-sm text-muted-foreground font-medium">High Fatigue Risk</p>
              <h3 className="text-2xl font-bold">12 Crew</h3>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="p-3 bg-amber-500/10 rounded-xl text-amber-600"><Clock className="w-6 h-6"/></div>
            <div>
              <p className="text-sm text-muted-foreground font-medium">Total Overtime</p>
              <h3 className="text-2xl font-bold">450 hrs</h3>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5"/> Crew Performance & Utilization</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-muted/50">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">Crew Member</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Base</th>
                  <th className="px-4 py-3">Utilization</th>
                  <th className="px-4 py-3">Fatigue Risk</th>
                  <th className="px-4 py-3">Cost</th>
                  <th className="px-4 py-3 rounded-tr-lg">Status</th>
                </tr>
              </thead>
              <tbody>
                {crewMetrics.slice(0, 15).map((crew) => (
                  <tr key={crew.id} className="border-b border-border hover:bg-muted/30 transition-colors cursor-pointer">
                    <td className="px-4 py-3 font-medium">{crew.name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{crew.role}</td>
                    <td className="px-4 py-3">{crew.base}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${crew.utilization > 85 ? 'bg-red-500' : crew.utilization < 65 ? 'bg-yellow-500' : 'bg-green-500'}`} 
                            style={{ width: `${crew.utilization}%` }}
                          />
                        </div>
                        <span className="text-xs">{crew.utilization.toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={
                        crew.fatigueRisk > 75 ? 'bg-red-500/10 text-red-600 border-red-500/20' : 
                        crew.fatigueRisk > 50 ? 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20' : 
                        'bg-green-500/10 text-green-600 border-green-500/20'
                      }>
                        {crew.fatigueRisk}%
                      </Badge>
                    </td>
                    <td className="px-4 py-3">€{Math.round(crew.cost).toLocaleString()}</td>
                    <td className="px-4 py-3">
                      {crew.utilization > 90 ? <span className="text-red-600 text-xs font-medium">Over-utilized</span> : 
                       crew.utilization < 60 ? <span className="text-yellow-600 text-xs font-medium">Under-utilized</span> : 
                       <span className="text-green-600 text-xs font-medium">Optimal</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CrewAnalyticsSection;