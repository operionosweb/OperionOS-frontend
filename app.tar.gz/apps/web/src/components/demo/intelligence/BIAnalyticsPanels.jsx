import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useBIState } from '@/contexts/BIStateContext.jsx';
import { formatCurrency, formatPercent } from '@/lib/formatters.js';
import { Activity, Plane, Users, AlertTriangle, DollarSign, Lightbulb, ArrowRight } from 'lucide-react';

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

export const InteractiveChartsSection = () => {
  const { data } = useBIState();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      <Card className="bi-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">On-Time Performance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data.timeSeries} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={5} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} domain={[60, 100]} />
                <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', borderRadius: '8px' }} />
                <Line type="monotone" dataKey="otp" name="OTP %" stroke="hsl(var(--chart-1))" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card className="bi-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Delay Causes Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data.disruptions.distribution} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                  {data.disruptions.distribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', borderRadius: '8px' }} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export const AIInsightsPanelEnhanced = () => {
  const { data } = useBIState();

  const getCategoryColor = (cat) => {
    switch(cat) {
      case 'Efficiency': return 'bg-blue-500/10 text-blue-700 border-blue-500/30';
      case 'Risk': return 'bg-red-500/10 text-red-700 border-red-500/30';
      case 'Performance': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'Cost': return 'bg-orange-500/10 text-orange-700 border-orange-500/30';
      default: return 'bg-slate-500/10 text-slate-700 border-slate-500/30';
    }
  };

  return (
    <Card className="bi-card mb-6 bg-gradient-to-br from-card to-primary/5">
      <CardHeader className="pb-4 border-b border-border/50">
        <CardTitle className="text-xl flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-primary" />
          AI Operational Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {data.insights.slice(0, 8).map((insight) => (
            <div key={insight.id} className="p-5 rounded-xl bg-background border border-border shadow-sm hover:shadow-md transition-all flex flex-col h-full">
              <div className="flex justify-between items-start mb-3">
                <Badge variant="outline" className={getCategoryColor(insight.category)}>{insight.category}</Badge>
                {insight.impact > 0 && (
                  <span className="text-sm font-bold text-green-600">+{formatCurrency(insight.impact)}</span>
                )}
              </div>
              <h4 className="font-bold text-foreground mb-2 leading-tight">{insight.title}</h4>
              <p className="text-sm text-muted-foreground mb-4 flex-1">{insight.description}</p>
              <Button size="sm" className="w-full mt-auto bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground">
                {insight.action}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export const RouteAnalyticsPanel = () => {
  const { data } = useBIState();
  
  return (
    <Card className="bi-card mb-6">
      <CardHeader className="pb-4 border-b border-border">
        <CardTitle className="text-xl flex items-center gap-2">
          <Plane className="w-5 h-5 text-primary" />
          Route Performance Analytics
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground uppercase bg-muted/30 border-b border-border">
              <tr>
                <th className="px-6 py-4 font-medium">Route</th>
                <th className="px-6 py-4 font-medium">Profitability</th>
                <th className="px-6 py-4 font-medium">OTP</th>
                <th className="px-6 py-4 font-medium">Load Factor</th>
                <th className="px-6 py-4 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {data.routes.slice(0, 5).map((route) => (
                <tr key={route.id} className="hover:bg-muted/10 transition-colors">
                  <td className="px-6 py-4 font-bold text-foreground">{route.route}</td>
                  <td className="px-6 py-4 text-green-600 font-medium">{formatCurrency(route.profitability)}</td>
                  <td className="px-6 py-4">
                    <Badge variant="outline" className={route.otp > 85 ? 'bg-green-500/10 text-green-700' : 'bg-yellow-500/10 text-yellow-700'}>
                      {formatPercent(route.otp)}
                    </Badge>
                  </td>
                  <td className="px-6 py-4">{formatPercent(route.loadFactor)}</td>
                  <td className="px-6 py-4 text-right">
                    <Button variant="ghost" size="sm" className="text-primary">Analyze</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export const PredictiveAnalyticsPanel = () => {
  const { data } = useBIState();

  return (
    <Card className="bi-card mb-6">
      <CardHeader className="pb-4 border-b border-border">
        <CardTitle className="text-xl flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" />
          Predictive Forecasts (30 Days)
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="h-[350px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data.predictive.costForecast} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={5} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `€${val/1000}k`} />
              <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', borderRadius: '8px' }} />
              <Legend />
              <Area type="monotone" dataKey="upper" stroke="none" fill="hsl(var(--chart-1))" fillOpacity={0.1} name="Confidence Interval" />
              <Area type="monotone" dataKey="lower" stroke="none" fill="hsl(var(--background))" fillOpacity={1} />
              <Line type="monotone" dataKey="expected" stroke="hsl(var(--chart-1))" strokeWidth={2} dot={false} name="Expected Cost" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export const RealTimeDataStreamPanel = () => {
  return (
    <Card className="bi-card h-full">
      <CardHeader className="pb-4 border-b border-border">
        <CardTitle className="text-lg flex items-center gap-2">
          <div className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
          </div>
          Live Operations Stream
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 overflow-y-auto h-[400px]">
        <div className="divide-y divide-border">
          {[1,2,3,4,5].map((i) => (
            <div key={i} className="p-4 hover:bg-muted/30 transition-colors cursor-pointer">
              <div className="flex justify-between items-start mb-1">
                <Badge variant="outline" className="bg-orange-500/10 text-orange-700 border-orange-500/30">Delay Alert</Badge>
                <span className="text-xs text-muted-foreground">Just now</span>
              </div>
              <h4 className="text-sm font-bold text-foreground mt-2">Flight OP{1000+i} Delayed</h4>
              <p className="text-xs text-muted-foreground mt-1">Estimated 45 min delay due to late incoming aircraft at LHR.</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};