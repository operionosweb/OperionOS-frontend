import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Activity, Pause, Play, Clock, AlertTriangle, Users, Wrench, CloudLightning } from 'lucide-react';
import { useBIState } from '@/contexts/BIStateContext.jsx';
import { motion, AnimatePresence } from 'framer-motion';

const LiveOperationsFeed = () => {
  const { liveFeedData, isLiveFeedPaused, setIsLiveFeedPaused } = useBIState();

  const getIcon = (type) => {
    switch(type) {
      case 'Delay': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'Disruption': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'Crew Change': return <Users className="w-4 h-4 text-blue-500" />;
      case 'Maintenance': return <Wrench className="w-4 h-4 text-orange-500" />;
      case 'Weather Alert': return <CloudLightning className="w-4 h-4 text-purple-500" />;
      default: return <Activity className="w-4 h-4 text-primary" />;
    }
  };

  const formatTime = (isoString) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <Card className="h-full flex flex-col border-border">
      <CardHeader className="pb-3 border-b border-border flex flex-row items-center justify-between">
        <CardTitle className="text-lg flex items-center gap-2">
          <div className="relative flex h-3 w-3">
            {!isLiveFeedPaused && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>}
            <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
          </div>
          Live Operations Feed
        </CardTitle>
        <Button 
          variant="outline" 
          size="sm" 
          className="h-8"
          onClick={() => setIsLiveFeedPaused(!isLiveFeedPaused)}
        >
          {isLiveFeedPaused ? <><Play className="w-4 h-4 mr-1"/> Resume</> : <><Pause className="w-4 h-4 mr-1"/> Pause</>}
        </Button>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-0 relative">
        <div className="absolute inset-0 p-4 space-y-3 overflow-y-auto hide-scrollbar">
          <AnimatePresence initial={false}>
            {liveFeedData.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: -20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="bg-muted/40 border border-border rounded-lg p-3 flex gap-3 items-start hover:bg-muted/60 cursor-pointer transition-colors"
              >
                <div className="mt-0.5 bg-background p-1.5 rounded-md shadow-sm border border-border">
                  {getIcon(item.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-semibold text-sm truncate">{item.type}</span>
                    <span className="text-xs text-muted-foreground whitespace-nowrap ml-2">{formatTime(item.timestamp)}</span>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{item.message}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  );
};

export default LiveOperationsFeed;