import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, TrendingUp, TrendingDown, ArrowRight, Lightbulb } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useDemo } from '@/contexts/DemoStateContext.jsx';

const DetailedKPIPanel = () => {
  const { selectedKPI, isKPIDetailOpen, closeKPIDetail } = useDemo();

  if (!selectedKPI) return null;

  // Generate some dummy detailed data based on the selected KPI
  const historicalData = Array.from({ length: 30 }, (_, i) => ({
    date: `Day ${i + 1}`,
    value: selectedKPI.value.includes('%') 
      ? 80 + Math.random() * 20 
      : 1000 + Math.random() * 500,
    target: selectedKPI.value.includes('%') ? 95 : 1200
  }));

  const breakdownData = [
    { name: 'APAC', value: 45 },
    { name: 'EMEA', value: 30 },
    { name: 'AMER', value: 25 }
  ];

  return (
    <AnimatePresence>
      {isKPIDetailOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeKPIDetail}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
          />
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-x-4 top-[10%] bottom-4 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 md:w-[800px] md:h-[80vh] bg-card border border-border rounded-2xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            <div className="flex items-center justify-between p-6 border-b border-border">
              <div>
                <h2 className="text-2xl font-bold text-foreground">{selectedKPI.name}</h2>
                <p className="text-muted-foreground text-sm mt-1">Detailed 30-day analysis and breakdown</p>
              </div>
              <Button variant="ghost" size="icon" onClick={closeKPIDetail} className="rounded-full">
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Top Stats */}
              <div className="grid grid-cols-3 gap-4">
                <Card className="bg-muted/30 border-border shadow-none">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Current Value</div>
                    <div className="text-3xl font-bold">{selectedKPI.value}</div>
                  </CardContent>
                </Card>
                <Card className="bg-muted/30 border-border shadow-none">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">30-Day Trend</div>
                    <div className={`text-xl font-bold flex items-center gap-1 ${selectedKPI.isPositive ? 'text-teal-500' : 'text-destructive'}`}>
                      {selectedKPI.isPositive ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
                      {selectedKPI.trend}
                    </div>
                  </CardContent>
                </Card>
                <Card className="bg-muted/30 border-border shadow-none">
                  <CardContent className="p-4">
                    <div className="text-sm text-muted-foreground mb-1">Target</div>
                    <div className="text-xl font-bold">{selectedKPI.value.includes('%') ? '95.0%' : 'Optimal'}</div>
                  </CardContent>
                </Card>
              </div>

              {/* Main Chart */}
              <Card className="border-border shadow-sm">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Historical Trend (30 Days)</h3>
                  <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={historicalData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={30} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                          itemStyle={{ color: 'hsl(var(--foreground))' }}
                        />
                        <Legend wrapperStyle={{ fontSize: '12px' }} />
                        <Line type="monotone" dataKey="value" name="Actual" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} activeDot={{ r: 6 }} />
                        <Line type="dashed" dataKey="target" name="Target" stroke="hsl(var(--muted-foreground))" strokeWidth={2} dot={false} strokeDasharray="5 5" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Breakdown Chart */}
                <Card className="border-border shadow-sm">
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4">Regional Breakdown</h3>
                    <div className="h-[200px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={breakdownData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                          <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                          <Tooltip cursor={{ fill: 'hsl(var(--muted)/0.5)' }} contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }} />
                          <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Insights */}
                <Card className="border-border shadow-sm bg-gradient-to-br from-card to-teal-500/5">
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4 flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-teal-500" />
                      AI Insights
                    </h3>
                    <div className="space-y-4">
                      <div className="p-3 rounded-lg bg-background border border-border text-sm">
                        <strong className="block text-foreground mb-1">Anomaly Detected</strong>
                        <span className="text-muted-foreground">Values dropped 12% below average in the EMEA region during the last weekend. Correlates with severe weather events.</span>
                      </div>
                      <div className="p-3 rounded-lg bg-background border border-border text-sm">
                        <strong className="block text-foreground mb-1">Optimization Opportunity</strong>
                        <span className="text-muted-foreground">Adjusting rotation schedules in APAC could improve this metric by an estimated 4.5% next month.</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            <div className="p-4 border-t border-border bg-muted/20 flex justify-end">
              <Button className="gap-2">
                Explore in Data Explorer <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default DetailedKPIPanel;