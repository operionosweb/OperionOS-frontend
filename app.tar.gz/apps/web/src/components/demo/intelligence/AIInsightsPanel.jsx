import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Lightbulb, AlertCircle, TrendingUp, X, CheckCircle2 } from 'lucide-react';
import { useBIState } from '@/contexts/BIStateContext.jsx';
import { toast } from 'sonner';

const AIInsightsPanel = () => {
  const { insights, dismissInsight } = useBIState();

  const handleApply = (id) => {
    toast.success('Optimization applied successfully', {
      description: 'KPIs will update shortly to reflect changes.'
    });
    dismissInsight(id);
  };

  const getIcon = (type) => {
    switch(type) {
      case 'opportunity': return <TrendingUp className="w-5 h-5 text-green-500" />;
      case 'risk': return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'warning': return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      default: return <Lightbulb className="w-5 h-5 text-primary" />;
    }
  };

  return (
    <Card className="h-full flex flex-col border-border">
      <CardHeader className="pb-3 border-b border-border flex flex-row items-center justify-between">
        <CardTitle className="text-lg flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-primary" />
          AI Prescriptive Insights
        </CardTitle>
        <Badge variant="secondary">{insights.length} Active</Badge>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-0">
        <div className="divide-y divide-border">
          {insights.map((insight) => (
            <div key={insight.id} className="p-4 hover:bg-muted/30 transition-colors group">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  {getIcon(insight.type)}
                  <h4 className="font-semibold text-sm">{insight.title}</h4>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => dismissInsight(insight.id)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mb-3">{insight.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs font-medium">
                  <span className={insight.impact > 0 ? 'text-green-600' : 'text-red-600'}>
                    {insight.impact > 0 ? 'Save' : 'Risk'}: €{Math.abs(insight.impact).toLocaleString()}
                  </span>
                  <span className="text-muted-foreground flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> {insight.confidence}% Match
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="h-7 text-xs">Simulate</Button>
                  {insight.type === 'opportunity' && (
                    <Button size="sm" className="h-7 text-xs" onClick={() => handleApply(insight.id)}>Apply</Button>
                  )}
                </div>
              </div>
            </div>
          ))}
          {insights.length === 0 && (
            <div className="p-8 text-center text-muted-foreground">
              <CheckCircle2 className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>All insights addressed. Operations are optimal.</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AIInsightsPanel;