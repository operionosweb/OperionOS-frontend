import React, { useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { generateCrewAnalytics, generateCostAnalytics, generateDisruptionAnalytics, generateComplianceAnalytics } from '@/lib/biData.js';

const COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];

const AnalyticsDashboards = () => {
  const crewData = useMemo(() => generateCrewAnalytics(), []);
  const costData = useMemo(() => generateCostAnalytics(), []);
  const disruptionData = useMemo(() => generateDisruptionAnalytics(), []);
  const complianceData = useMemo(() => generateComplianceAnalytics(), []);

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border p-3 rounded-lg shadow-lg">
          <p className="font-semibold text-sm mb-1">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value.toLocaleString()}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="bi-card">
      <Tabs defaultValue="crew" className="w-full">
        <div className="border-b border-border px-6 py-2 overflow-x-auto hide-scrollbar">
          <TabsList className="bg-transparent h-auto p-0 space-x-6 w-max">
            <TabsTrigger value="crew" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Crew & Utilization</TabsTrigger>
            <TabsTrigger value="cost" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Cost & Spend</TabsTrigger>
            <TabsTrigger value="disruption" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Disruptions</TabsTrigger>
            <TabsTrigger value="compliance" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Compliance</TabsTrigger>
          </TabsList>
        </div>

        <div className="p-6">
          {/* CREW TAB */}
          <TabsContent value="crew" className="mt-0 focus-visible:outline-none">
            <div className="scroll-wrapper-x fade-card -mx-6 px-6 md:mx-0 md:px-0">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 scroll-container-x">
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Utilization Trend (30 Days)</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={crewData.utilization} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={10} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} domain={['dataMin - 5', 'dataMax + 5']} />
                        <Tooltip content={<CustomTooltip />} />
                        <Line type="monotone" dataKey="rate" name="Utilization %" stroke="hsl(var(--chart-1))" strokeWidth={2} dot={false} activeDot={{ r: 6 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Availability vs Demand</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={crewData.availabilityVsDemand} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="role" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip content={<CustomTooltip />} />
                        <Legend wrapperStyle={{ fontSize: '12px' }} />
                        <Bar dataKey="available" name="Available" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="demand" name="Demand" fill="hsl(var(--chart-5))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* COST TAB */}
          <TabsContent value="cost" className="mt-0 focus-visible:outline-none">
            <div className="scroll-wrapper-x fade-card -mx-6 px-6 md:mx-0 md:px-0">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 scroll-container-x">
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Travel Spend (12 Months)</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={costData.travelSpend} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val/1000}k`} />
                        <Tooltip content={<CustomTooltip />} />
                        <Line type="monotone" dataKey="cost" name="Spend" stroke="hsl(var(--chart-3))" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Cost Breakdown</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={costData.costBreakdown} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                          {costData.costBreakdown.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                        <Legend wrapperStyle={{ fontSize: '12px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* DISRUPTION TAB */}
          <TabsContent value="disruption" className="mt-0 focus-visible:outline-none">
            <div className="scroll-wrapper-x fade-card -mx-6 px-6 md:mx-0 md:px-0">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 scroll-container-x">
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Disruption Frequency</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={disruptionData.frequency} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={10} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar dataKey="count" name="Incidents" fill="hsl(var(--chart-4))" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Avg Recovery Time (Hours)</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={disruptionData.recoveryTime} layout="vertical" margin={{ top: 5, right: 5, bottom: 5, left: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                        <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis dataKey="type" type="category" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} width={100} />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar dataKey="hours" name="Hours" fill="hsl(var(--chart-1))" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* COMPLIANCE TAB */}
          <TabsContent value="compliance" className="mt-0 focus-visible:outline-none">
            <div className="scroll-wrapper-x fade-card -mx-6 px-6 md:mx-0 md:px-0">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 scroll-container-x">
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Risk Exposure Trend</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={complianceData.riskExposure} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                        <XAxis dataKey="day" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} minTickGap={10} />
                        <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip content={<CustomTooltip />} />
                        <Line type="monotone" dataKey="riskScore" name="Risk Score" stroke="hsl(var(--chart-5))" strokeWidth={2} dot={false} activeDot={{ r: 6 }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="space-y-2 scroll-item">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Certification Status</h3>
                  <div className="bi-chart-container">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie data={complianceData.certificationStatus} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                          <Cell fill="hsl(var(--chart-2))" />
                          <Cell fill="hsl(var(--chart-4))" />
                          <Cell fill="hsl(var(--chart-3))" />
                          <Cell fill="hsl(var(--chart-5))" />
                        </Pie>
                        <Tooltip content={<CustomTooltip />} />
                        <Legend wrapperStyle={{ fontSize: '12px' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </Card>
  );
};

export default AnalyticsDashboards;