import React from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Search, Filter, Calendar, RefreshCw } from 'lucide-react';
import { useBIState } from '@/contexts/BIStateContext.jsx';

const GlobalFiltersPanel = () => {
  const { filters, updateFilters, resetFilters } = useBIState();

  return (
    <div className="sticky top-0 z-20 bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          
          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto hide-scrollbar pb-1 sm:pb-0">
            <div className="flex bg-muted p-1 rounded-lg shrink-0">
              {['24h', '7d', '30d', '90d'].map(range => (
                <Button 
                  key={range}
                  variant={filters.dateRange === range ? 'default' : 'ghost'}
                  size="sm"
                  className={`h-7 px-3 text-xs ${filters.dateRange === range ? 'shadow-sm' : ''}`}
                  onClick={() => updateFilters({ dateRange: range })}
                >
                  {range}
                </Button>
              ))}
            </div>
            
            <div className="h-6 w-px bg-border mx-1 shrink-0"></div>
            
            <Select defaultValue="all">
              <SelectTrigger className="h-9 w-[130px] text-xs shrink-0">
                <SelectValue placeholder="Airport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Airports</SelectItem>
                <SelectItem value="lhr">LHR - London</SelectItem>
                <SelectItem value="jfk">JFK - New York</SelectItem>
                <SelectItem value="dxb">DXB - Dubai</SelectItem>
              </SelectContent>
            </Select>

            <Select defaultValue="all">
              <SelectTrigger className="h-9 w-[130px] text-xs shrink-0">
                <SelectValue placeholder="Aircraft" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Fleet</SelectItem>
                <SelectItem value="a320">A320 Family</SelectItem>
                <SelectItem value="b777">B777 Fleet</SelectItem>
                <SelectItem value="a350">A350 Fleet</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-[200px]">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search flights, crew..." 
                className="h-9 pl-9 text-xs w-full"
                value={filters.search}
                onChange={(e) => updateFilters({ search: e.target.value })}
              />
            </div>
            <Button variant="outline" size="icon" className="h-9 w-9 shrink-0" onClick={resetFilters} title="Reset Filters">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>

        </div>
      </div>
    </div>
  );
};

export default GlobalFiltersPanel;