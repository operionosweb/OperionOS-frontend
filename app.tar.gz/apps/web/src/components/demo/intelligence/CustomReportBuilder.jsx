import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Checkbox } from '@/components/ui/checkbox.jsx';
import { Label } from '@/components/ui/label.jsx';
import { FileText, Download, Printer, Mail, FileBarChart } from 'lucide-react';
import { toast } from 'sonner';

const CustomReportBuilder = () => {
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      toast.success('Report generated successfully', {
        description: 'Your custom report is ready for download.'
      });
    }, 1500);
  };

  const templates = [
    { title: 'Executive Summary', desc: 'High-level KPIs and financial overview.' },
    { title: 'Operational Performance', desc: 'OTP, delays, and route efficiency.' },
    { title: 'Crew Analytics', desc: 'Utilization, fatigue, and cost breakdown.' },
    { title: 'Disruption Impact', desc: 'Cost and frequency of operational disruptions.' }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {templates.map((t, i) => (
          <Card key={i} className="cursor-pointer hover:border-primary/50 transition-colors group">
            <CardContent className="p-5">
              <FileBarChart className="w-8 h-8 text-muted-foreground group-hover:text-primary mb-3 transition-colors" />
              <h3 className="font-semibold mb-1">{t.title}</h3>
              <p className="text-xs text-muted-foreground">{t.desc}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Custom Report Builder</CardTitle>
          <CardDescription>Select metrics and dimensions to generate a tailored BI report.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <h4 className="font-medium text-sm border-b border-border pb-2">Performance Metrics</h4>
              <div className="space-y-3">
                {['On-Time Performance', 'Delay Minutes', 'Disruption Rate', 'Completion Factor'].map(m => (
                  <div key={m} className="flex items-center space-x-2">
                    <Checkbox id={`m-${m}`} defaultChecked />
                    <Label htmlFor={`m-${m}`} className="text-sm font-normal">{m}</Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <h4 className="font-medium text-sm border-b border-border pb-2">Financial Metrics</h4>
              <div className="space-y-3">
                {['Total Operational Cost', 'Cost per Flight', 'Disruption Costs', 'AI Generated Savings'].map(m => (
                  <div key={m} className="flex items-center space-x-2">
                    <Checkbox id={`f-${m}`} defaultChecked />
                    <Label htmlFor={`f-${m}`} className="text-sm font-normal">{m}</Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <h4 className="font-medium text-sm border-b border-border pb-2">Resource Metrics</h4>
              <div className="space-y-3">
                {['Crew Utilization', 'Aircraft Utilization', 'Fatigue Risk Levels', 'Maintenance Events'].map(m => (
                  <div key={m} className="flex items-center space-x-2">
                    <Checkbox id={`r-${m}`} defaultChecked />
                    <Label htmlFor={`r-${m}`} className="text-sm font-normal">{m}</Label>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-border flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="text-sm text-muted-foreground">
              Report will include data based on current global filters (Last 30 Days).
            </div>
            <div className="flex gap-3 w-full sm:w-auto">
              <Button variant="outline" className="flex-1 sm:flex-none"><Mail className="w-4 h-4 mr-2"/> Schedule</Button>
              <Button 
                className="flex-1 sm:flex-none" 
                onClick={handleGenerate}
                disabled={isGenerating}
              >
                {isGenerating ? 'Generating...' : <><FileText className="w-4 h-4 mr-2"/> Generate Report</>}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomReportBuilder;