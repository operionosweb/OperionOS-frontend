import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { LineChart, Line, ResponsiveContainer, YAxis } from 'recharts';
import { generateKPIData } from '@/lib/biData.js';
import { useDemo } from '@/contexts/DemoStateContext.jsx';

const ExecutiveDashboard = () => {
  const kpiData = useMemo(() => generateKPIData(), []);
  const { openKPIDetail } = useDemo();

  return (
    <div className="scroll-wrapper-x fade-bg -mx-4 px-4 md:mx-0 md:px-0">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6 scroll-container-x">
        {kpiData.map((kpi, index) => (
          <motion.div
            key={kpi.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: index * 0.1 }}
            className="scroll-item"
          >
            <Card 
              className="bi-card cursor-pointer hover:shadow-md hover:border-primary/30 group h-full"
              onClick={() => openKPIDetail(kpi)}
            >
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-1">{kpi.name}</p>
                    <h3 className="text-2xl font-bold text-foreground">{kpi.value}</h3>
                  </div>
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-bold ${
                    kpi.isPositive ? 'bi-trend-positive' : 'bi-trend-negative'
                  }`}>
                    {kpi.isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                    {kpi.trend}
                  </div>
                </div>
                
                <div className="h-[40px] w-full opacity-60 group-hover:opacity-100 transition-opacity">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={kpi.sparkline}>
                      <YAxis domain={['dataMin', 'dataMax']} hide />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke={kpi.isPositive ? "hsl(var(--bi-trend-up))" : "hsl(var(--bi-trend-down))"} 
                        strokeWidth={2} 
                        dot={false} 
                        isAnimationActive={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ExecutiveDashboard;