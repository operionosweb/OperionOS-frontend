import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Zap, ArrowRight, Settings2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { generateRecommendations } from '@/lib/biData.js';

const OptimizationRecommendations = () => {
  const recommendations = useMemo(() => generateRecommendations(), []);

  return (
    <Card className="bi-card h-full flex flex-col">
      <CardHeader className="pb-4 border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="w-5 h-5 text-warning-foreground" />
            Suggested Optimizations
          </CardTitle>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Settings2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0 flex-1 flex flex-col">
        <div className="scroll-wrapper-x fade-card p-4 md:p-0 flex-1">
          <div className="flex flex-col md:divide-y md:divide-border scroll-container-x h-full">
            {recommendations.map((rec, index) => (
              <motion.div
                key={rec.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="scroll-item p-4 md:p-5 hover:bg-muted/30 transition-colors border border-border md:border-0 rounded-xl md:rounded-none flex flex-col h-full"
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-foreground">{rec.title}</h4>
                  <Badge variant="outline" className="bg-teal-500/10 text-teal-700 border-teal-500/20 whitespace-nowrap ml-2">
                    {rec.impact}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-4 flex-1">{rec.description}</p>
                
                <div className="flex flex-wrap items-center justify-between gap-4 mt-auto">
                  <div className="flex gap-3 text-xs">
                    <span className="text-muted-foreground">Efficiency: <strong className="text-foreground">{rec.efficiency}</strong></span>
                    <span className="text-muted-foreground">Risk: <strong className="text-foreground">{rec.risk}</strong></span>
                    <span className="text-muted-foreground">Effort: <strong className="text-foreground">{rec.effort}</strong></span>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="h-8 text-xs">Details</Button>
                    <Button size="sm" className="h-8 text-xs bg-primary text-primary-foreground">Apply</Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        <div className="p-4 border-t border-border mt-auto">
          <Button variant="ghost" className="w-full text-primary group">
            View All Recommendations
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default OptimizationRecommendations;