import React, { useState } from 'react';
import { FileText, Download, Filter, Search, ChevronDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { toast } from 'sonner';

const CustomReports = () => {
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      toast.success('Report generated successfully');
    }, 1500);
  };

  const dummyData = [
    { id: 1, vessel: 'MV Atlantic Star', metric: 'Utilization', value: '94%', status: 'Optimal', date: '2026-03-28' },
    { id: 2, vessel: 'Poseidon Voyager', metric: 'Crew Movements Cost', value: '$52,400', status: 'High', date: '2026-03-28' },
    { id: 3, vessel: 'Northern Star', metric: 'Compliance', value: '100%', status: 'Optimal', date: '2026-03-27' },
    { id: 4, vessel: 'MV Baltic Horizon', metric: 'Disruptions', value: '3', status: 'Warning', date: '2026-03-27' },
    { id: 5, vessel: 'SS Atlantic Explorer', metric: 'Utilization', value: '88%', status: 'Warning', date: '2026-03-26' },
  ];

  return (
    <div className="space-y-6">
      <Card className="bi-card">
        <CardHeader className="pb-4 border-b border-border">
          <CardTitle className="text-xl flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Report Builder
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="scroll-wrapper-x fade-card -mx-6 px-6 md:mx-0 md:px-0">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 scroll-container-x">
              <div className="space-y-2 scroll-item">
                <label className="text-sm font-medium">Data Source</label>
                <Select defaultValue="all">
                  <SelectTrigger><SelectValue placeholder="Select source" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Metrics</SelectItem>
                    <SelectItem value="crew">Crew & Utilization</SelectItem>
                    <SelectItem value="cost">Financial & Cost</SelectItem>
                    <SelectItem value="compliance">Compliance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 scroll-item">
                <label className="text-sm font-medium">Timeframe</label>
                <Select defaultValue="30d">
                  <SelectTrigger><SelectValue placeholder="Select timeframe" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7d">Last 7 Days</SelectItem>
                    <SelectItem value="30d">Last 30 Days</SelectItem>
                    <SelectItem value="90d">Last 90 Days</SelectItem>
                    <SelectItem value="ytd">Year to Date</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 scroll-item">
                <label className="text-sm font-medium">Group By</label>
                <Select defaultValue="vessel">
                  <SelectTrigger><SelectValue placeholder="Select grouping" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="vessel">Vessel</SelectItem>
                    <SelectItem value="region">Region</SelectItem>
                    <SelectItem value="role">Role</SelectItem>
                    <SelectItem value="date">Date</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end scroll-item">
                <Button 
                  className="w-full bg-primary text-primary-foreground" 
                  onClick={handleGenerate}
                  disabled={isGenerating}
                >
                  {isGenerating ? 'Generating...' : 'Generate Report'}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bi-card">
        <CardHeader className="pb-4 border-b border-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <CardTitle className="text-lg">Data Explorer</CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search data..." className="pl-9 h-9" />
            </div>
            <Button variant="outline" size="icon" className="h-9 w-9 shrink-0">
              <Filter className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" className="h-9 gap-2 hidden sm:flex">
              <Download className="w-4 h-4" /> Export CSV
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date <ChevronDown className="w-3 h-3 inline" /></TableHead>
                  <TableHead>Vessel</TableHead>
                  <TableHead>Metric</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dummyData.map((row) => (
                  <TableRow key={row.id} className="cursor-pointer hover:bg-muted/50">
                    <TableCell className="text-muted-foreground">{row.date}</TableCell>
                    <TableCell className="font-medium">{row.vessel}</TableCell>
                    <TableCell>{row.metric}</TableCell>
                    <TableCell>{row.value}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded-md text-xs font-medium ${
                        row.status === 'Optimal' ? 'bg-teal-500/10 text-teal-700' :
                        row.status === 'Warning' ? 'bg-warning/10 text-warning-foreground' :
                        'bg-destructive/10 text-destructive'
                      }`}>
                        {row.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" className="text-primary">View</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="p-4 border-t border-border flex items-center justify-between text-sm text-muted-foreground">
            <span>Showing 1-5 of 248 records</span>
            <div className="flex gap-1">
              <Button variant="outline" size="sm" disabled>Previous</Button>
              <Button variant="outline" size="sm">Next</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomReports;