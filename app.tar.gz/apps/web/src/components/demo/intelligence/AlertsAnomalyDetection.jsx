import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { ShieldAlert, AlertCircle, Info, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { generateAlerts } from '@/lib/biData.js';

const AlertsAnomalyDetection = () => {
  const alerts = useMemo(() => generateAlerts(), []);

  const getSeverityStyles = (severity) => {
    switch(severity) {
      case 'critical': return { icon: <ShieldAlert className="w-5 h-5 text-destructive" />, badge: 'bg-destructive text-destructive-foreground', border: 'border-l-destructive' };
      case 'high': return { icon: <AlertCircle className="w-5 h-5 text-warning-foreground" />, badge: 'bg-warning text-warning-foreground', border: 'border-l-warning' };
      case 'medium': return { icon: <AlertCircle className="w-5 h-5 text-primary" />, badge: 'bg-primary/20 text-primary', border: 'border-l-primary' };
      default: return { icon: <Info className="w-5 h-5 text-muted-foreground" />, badge: 'bg-muted text-muted-foreground', border: 'border-l-muted' };
    }
  };

  return (
    <Card className="bi-card h-full flex flex-col">
      <CardHeader className="pb-4 border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-destructive" />
            Anomaly Detection
          </CardTitle>
          <Badge variant="destructive">2 Critical</Badge>
        </div>
      </CardHeader>
      <CardContent className="p-0 flex-1 flex flex-col">
        <div className="scroll-wrapper-x fade-card p-4 md:p-0 flex-1">
          <div className="flex flex-col md:divide-y md:divide-border scroll-container-x h-full">
            {alerts.map((alert, index) => {
              const styles = getSeverityStyles(alert.severity);
              return (
                <motion.div
                  key={alert.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className={`scroll-item p-4 border-l-4 ${styles.border} hover:bg-muted/30 transition-colors border-y border-r md:border-y-0 md:border-r-0 border-border rounded-r-xl md:rounded-none flex flex-col h-full`}
                >
                  <div className="flex gap-3 flex-1">
                    <div className="mt-1 shrink-0">{styles.icon}</div>
                    <div className="flex-1 min-w-0 flex flex-col">
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="font-semibold text-foreground truncate pr-2">{alert.title}</h4>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">{alert.time}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3 flex-1">{alert.description}</p>
                      <div className="flex items-center justify-between mt-auto">
                        <Badge className={`text-[10px] uppercase tracking-wider ${styles.badge} hover:${styles.badge}`}>
                          {alert.severity}
                        </Badge>
                        <div className="flex gap-2">
                          <Button size="sm" variant="ghost" className="h-7 text-xs">Dismiss</Button>
                          <Button size="sm" variant="outline" className="h-7 text-xs">Investigate</Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
        <div className="p-4 border-t border-border mt-auto">
          <Button variant="ghost" className="w-full text-primary group">
            View Alert History
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AlertsAnomalyDetection;