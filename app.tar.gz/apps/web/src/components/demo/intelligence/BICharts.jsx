import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useBIState } from '@/contexts/BIStateContext.jsx';

const COLORS = ['hsl(var(--primary))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

export const OTPTrendChart = () => {
  const { chartData } = useBIState();
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">On-Time Performance Trend</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData.otpTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
            <XAxis dataKey="date" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} domain={[50, 100]} />
            <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }} />
            <Legend wrapperStyle={{ fontSize: '12px' }} />
            <Line type="monotone" dataKey="overall" name="Overall OTP" stroke="hsl(var(--primary))" strokeWidth={3} dot={false} />
            <Line type="monotone" dataKey="routeA" name="Transatlantic" stroke="hsl(var(--chart-2))" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export const CostPerRouteChart = () => {
  const { chartData } = useBIState();
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Cost per Route</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData.costPerRoute.slice(0, 10)} layout="vertical" margin={{ top: 10, right: 10, left: 20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
            <XAxis type="number" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
            <YAxis dataKey="route" type="category" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }} formatter={(value) => `€${value.toLocaleString()}`} />
            <Bar dataKey="cost" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={20} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export const DelayCausesChart = () => {
  const { chartData } = useBIState();
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Delay Causes Breakdown</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-[300px] flex items-center justify-center">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={chartData.delayCauses} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
              {chartData.delayCauses.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
            </Pie>
            <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }} formatter={(value) => `${value}%`} />
            <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '12px' }} />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export const CostAccumulationChart = () => {
  const { chartData } = useBIState();
  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Cost Accumulation vs Budget</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData.costAccumulation} margin={{ top: 10, right: 10, left: 20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
            <XAxis dataKey="date" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} tickFormatter={(val) => `€${(val/1000000).toFixed(1)}M`} />
            <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }} formatter={(value) => `€${value.toLocaleString()}`} />
            <Legend wrapperStyle={{ fontSize: '12px' }} />
            <Area type="monotone" dataKey="actual" name="Actual Cost" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorActual)" />
            <Line type="monotone" dataKey="budget" name="Budget" stroke="hsl(var(--chart-2))" strokeDasharray="5 5" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
};

export const AirportDelayHeatmap = () => {
  const { chartData } = useBIState();
  const data = chartData.airportHeatmap.slice(0, 8); // Show top 8 for space
  
  const getColor = (val) => {
    if (val < 20) return 'bg-green-500/20';
    if (val < 50) return 'bg-yellow-500/40';
    if (val < 80) return 'bg-orange-500/60';
    return 'bg-red-500/80';
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Airport Delay Heatmap (24h)</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-x-auto">
        <div className="min-w-[600px]">
          <div className="flex mb-2">
            <div className="w-16 shrink-0"></div>
            {Array.from({length: 24}).map((_, i) => (
              <div key={i} className="flex-1 text-center text-[10px] text-muted-foreground">{i}h</div>
            ))}
          </div>
          <div className="space-y-1">
            {data.map((row, idx) => (
              <div key={idx} className="flex items-center h-6">
                <div className="w-16 shrink-0 text-xs font-medium">{row.airport}</div>
                {Array.from({length: 24}).map((_, i) => (
                  <div 
                    key={i} 
                    className={`flex-1 h-full mx-[1px] rounded-sm ${getColor(row[`h${i}`])} transition-opacity hover:opacity-75 cursor-pointer`}
                    title={`${row.airport} at ${i}:00 - ${row[`h${i}`]} delays`}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};