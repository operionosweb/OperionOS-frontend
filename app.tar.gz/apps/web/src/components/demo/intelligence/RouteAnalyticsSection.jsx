import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { useBIState } from '@/contexts/BIStateContext.jsx';
import { Map, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';

const RouteAnalyticsSection = () => {
  const { routeMetrics } = useBIState();

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-primary/10 rounded-lg text-primary"><TrendingUp className="w-5 h-5"/></div>
              <h3 className="font-semibold">Most Profitable Route</h3>
            </div>
            <div className="text-2xl font-bold mb-1">LHR - DXB</div>
            <p className="text-sm text-green-600 font-medium">+€45,200 / flight</p>
          </CardContent>
        </Card>
        <Card className="bg-destructive/5 border-destructive/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-destructive/10 rounded-lg text-destructive"><TrendingDown className="w-5 h-5"/></div>
              <h3 className="font-semibold">Lowest Margin Route</h3>
            </div>
            <div className="text-2xl font-bold mb-1">FRA - MUC</div>
            <p className="text-sm text-red-600 font-medium">-€2,100 / flight</p>
          </CardContent>
        </Card>
        <Card className="bg-amber-500/5 border-amber-500/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-amber-500/10 rounded-lg text-amber-600"><AlertTriangle className="w-5 h-5"/></div>
              <h3 className="font-semibold">Highest Delay Risk</h3>
            </div>
            <div className="text-2xl font-bold mb-1">JFK - LHR</div>
            <p className="text-sm text-amber-600 font-medium">Avg 45 min delay</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Map className="w-5 h-5"/> Route Performance Matrix</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-muted/50">
                <tr>
                  <th className="px-4 py-3 rounded-tl-lg">Route</th>
                  <th className="px-4 py-3">Profitability</th>
                  <th className="px-4 py-3">OTP</th>
                  <th className="px-4 py-3">Load Factor</th>
                  <th className="px-4 py-3">Avg Delay</th>
                  <th className="px-4 py-3 rounded-tr-lg">Status</th>
                </tr>
              </thead>
              <tbody>
                {routeMetrics.map((route) => (
                  <tr key={route.id} className="border-b border-border hover:bg-muted/30 transition-colors cursor-pointer">
                    <td className="px-4 py-3 font-medium">{route.route}</td>
                    <td className={`px-4 py-3 font-medium ${route.profitability > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {route.profitability > 0 ? '+' : ''}€{Math.round(route.profitability).toLocaleString()}
                    </td>
                    <td className="px-4 py-3">{route.otp.toFixed(1)}%</td>
                    <td className="px-4 py-3">{route.loadFactor.toFixed(1)}%</td>
                    <td className="px-4 py-3">{route.avgDelay} min</td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={
                        route.profitability > 10000 ? 'bg-green-500/10 text-green-600 border-green-500/20' : 
                        route.profitability < 0 ? 'bg-red-500/10 text-red-600 border-red-500/20' : 
                        'bg-yellow-500/10 text-yellow-600 border-yellow-500/20'
                      }>
                        {route.profitability > 10000 ? 'Optimal' : route.profitability < 0 ? 'Review' : 'Stable'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RouteAnalyticsSection;