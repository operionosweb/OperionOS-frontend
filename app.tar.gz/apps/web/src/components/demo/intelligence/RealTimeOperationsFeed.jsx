import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Users, AlertTriangle, Plane, Ship, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { generateOperationsFeed } from '@/lib/biData.js';

const RealTimeOperationsFeed = () => {
  const initialFeed = useMemo(() => generateOperationsFeed(), []);
  const [feed, setFeed] = useState(initialFeed);
  const [filter, setFilter] = useState('All');

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newTypes = ['Crew', 'Disruption', 'Crew Movements', 'Rotation'];
      const randomType = newTypes[Math.floor(Math.random() * newTypes.length)];
      
      const newItem = {
        id: Date.now(),
        timestamp: 'Just now',
        type: randomType,
        severity: Math.random() > 0.8 ? 'high' : Math.random() > 0.5 ? 'medium' : 'info',
        title: `Live Update: ${randomType}`,
        description: `Automated system detected a new ${randomType.toLowerCase()} event requiring attention.`
      };

      setFeed(prev => [newItem, ...prev].slice(0, 30)); // Keep last 30 items
    }, 8000); // Every 8 seconds

    return () => clearInterval(interval);
  }, []);

  const filteredFeed = feed.filter(item => filter === 'All' || item.type === filter || (filter === 'Crew Movements' && item.type === 'Travel'));

  const getIcon = (type) => {
    switch(type) {
      case 'Crew': return <Users className="w-4 h-4" />;
      case 'Disruption': return <AlertTriangle className="w-4 h-4" />;
      case 'Travel': 
      case 'Crew Movements': return <Plane className="w-4 h-4" />;
      case 'Rotation': return <Ship className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'high': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'medium': return 'bg-warning/10 text-warning-foreground border-warning/20';
      case 'low': return 'bg-primary/10 text-primary border-primary/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  return (
    <Card className="bi-card h-full flex flex-col">
      <CardHeader className="pb-3 border-b border-border">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <div className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-teal-500"></span>
            </div>
            Live Operations
          </CardTitle>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex gap-2 mt-3 overflow-x-auto hide-scrollbar pb-1">
          {['All', 'Crew', 'Disruption', 'Crew Movements', 'Rotation'].map(f => (
            <Badge 
              key={f} 
              variant={filter === f ? 'default' : 'outline'}
              className="cursor-pointer whitespace-nowrap"
              onClick={() => setFilter(f)}
            >
              {f}
            </Badge>
          ))}
        </div>
      </CardHeader>
      <CardContent className="flex-1 p-0 overflow-y-auto">
        <div className="scroll-wrapper-x fade-card p-4">
          <div className="flex flex-col md:space-y-4 scroll-container-x">
            <AnimatePresence initial={false}>
              {filteredFeed.map((item) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, height: 0, y: -10 }}
                  animate={{ opacity: 1, height: 'auto', y: 0 }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="scroll-item group cursor-pointer"
                >
                  <div className="flex gap-3 p-4 md:p-3 rounded-xl border border-border md:border-transparent hover:border-border hover:bg-muted/30 transition-colors h-full">
                    <div className={`mt-1 p-2 rounded-full shrink-0 h-fit ${getSeverityColor(item.severity)}`}>
                      {getIcon(item.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start mb-1">
                        <h4 className="text-sm font-semibold text-foreground truncate pr-2">{item.title}</h4>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">{item.timestamp}</span>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2 md:line-clamp-2 leading-relaxed">{item.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RealTimeOperationsFeed;