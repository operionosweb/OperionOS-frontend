import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useBIState } from '@/contexts/BIStateContext.jsx';

const KPIDetailModal = () => {
  const { selectedKPI, setSelectedKPI, chartData } = useBIState();

  if (!selectedKPI) return null;

  return (
    <Dialog open={!!selectedKPI} onOpenChange={() => setSelectedKPI(null)}>
      <DialogContent className="sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle className="text-xl">{selectedKPI.label} Details</DialogTitle>
          <DialogDescription>Historical trend and detailed breakdown for the selected period.</DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-muted/50 p-4 rounded-xl border border-border">
            <div className="text-sm text-muted-foreground mb-1">Current Value</div>
            <div className="text-2xl font-bold">{selectedKPI.value.toLocaleString()}</div>
          </div>
          <div className="bg-muted/50 p-4 rounded-xl border border-border">
            <div className="text-sm text-muted-foreground mb-1">Target</div>
            <div className="text-2xl font-bold">{selectedKPI.target.toLocaleString()}</div>
          </div>
          <div className="bg-muted/50 p-4 rounded-xl border border-border">
            <div className="text-sm text-muted-foreground mb-1">Variance</div>
            <div className={`text-2xl font-bold ${selectedKPI.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
              {selectedKPI.change > 0 ? '+' : ''}{selectedKPI.change}%
            </div>
          </div>
        </div>

        <div className="h-[300px] w-full border border-border rounded-xl p-4 bg-card">
          <h4 className="text-sm font-semibold mb-4">30-Day Trend</h4>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData.otpTrend} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
              <YAxis tick={{ fontSize: 12 }} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }} />
              <Line type="monotone" dataKey="overall" stroke="hsl(var(--primary))" strokeWidth={3} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default KPIDetailModal;