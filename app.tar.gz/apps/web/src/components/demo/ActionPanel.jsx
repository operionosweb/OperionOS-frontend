import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Save, Play, Eye, X } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Button } from '@/components/ui/button.jsx';
import { toast } from 'sonner';

const ActionPanel = () => {
  const { selectedRecommendation, setSelectedRecommendation } = useDemo();
  const [isLoading, setIsLoading] = useState(false);

  if (!selectedRecommendation) return null;

  const handleAction = (actionType) => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      if (actionType === 'simulate') toast.info('Simulation complete. View updated metrics.');
      if (actionType === 'apply') {
        toast.success('Solution applied successfully.');
        setSelectedRecommendation(null);
      }
      if (actionType === 'approve') {
        toast.success('Action approved and executed.');
        setSelectedRecommendation(null);
      }
    }, 800);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        className="bg-card border border-border rounded-2xl shadow-xl mt-6 overflow-hidden"
      >
        <div className="p-4 border-b border-border bg-primary/5 flex justify-between items-center">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <Settings className="w-5 h-5 text-primary" />
            Action Details
          </h3>
          <Button variant="ghost" size="icon" onClick={() => setSelectedRecommendation(null)} className="h-8 w-8 rounded-full">
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="p-5 space-y-5">
          <div className="bg-muted/30 p-3 rounded-lg border border-border">
            <p className="text-xs text-muted-foreground uppercase font-bold tracking-wider mb-1">Selected Solution</p>
            <p className="font-medium text-sm">{selectedRecommendation.title}</p>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Reassign Crew Member</label>
              <select className="form-input-base">
                <option>Select crew...</option>
                <option>Maria Lopez (Standby - Houston)</option>
                <option>Ahmed Khan (Resting - Rotterdam)</option>
                <option>John Andersen (Active - Singapore)</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-sm font-medium">New Date</label>
                <input type="date" className="form-input-base" defaultValue="2026-03-30" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">New Time</label>
                <input type="time" className="form-input-base" defaultValue="14:00" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Adjust Rotation Schedule</label>
              <select className="form-input-base">
                <option>Shift rotation forward by 12h</option>
                <option>Cancel current rotation</option>
                <option>Merge with next rotation</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-border grid grid-cols-2 gap-2">
            <Button variant="outline" className="w-full text-xs" onClick={() => handleAction('simulate')} disabled={isLoading}>
              <Play className="w-3 h-3 mr-2" /> Simulate
            </Button>
            <Button variant="outline" className="w-full text-xs" onClick={() => toast.info('Routing details opened')} disabled={isLoading}>
              <Eye className="w-3 h-3 mr-2" /> View Route
            </Button>
            <Button className="w-full text-xs bg-secondary text-secondary-foreground hover:bg-secondary/90" onClick={() => handleAction('apply')} disabled={isLoading}>
              <Save className="w-3 h-3 mr-2" /> Apply
            </Button>
            <Button className="w-full text-xs bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => handleAction('approve')} disabled={isLoading}>
              {isLoading ? 'Processing...' : 'Approve Action'}
            </Button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ActionPanel;