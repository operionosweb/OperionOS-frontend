import React from 'react';

const ProgressBar = ({ value, max = 100, colorClass = 'bg-blue-500', label, showValue = true }) => {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));
  
  return (
    <div className="w-full">
      {(label || showValue) && (
        <div className="flex justify-between items-center mb-1.5 text-xs font-medium">
          {label && <span className="text-gray-600">{label}</span>}
          {showValue && <span className="text-gray-900 font-semibold">{value}{max === 100 ? '%' : `/${max}`}</span>}
        </div>
      )}
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className={`h-full ${colorClass} transition-all duration-500 ease-out rounded-full`} 
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;