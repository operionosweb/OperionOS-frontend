import React from 'react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import ModalWrapper from './ModalWrapper.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { CheckCircle2, AlertTriangle, Briefcase, Plane } from 'lucide-react';
import { toast } from 'sonner';

const CrewProfileModal = () => {
  const { openModals, closeModal, modalData, openModal } = useDemo();
  const isOpen = openModals.has('crew');
  const selectedCrew = modalData['crew'];

  if (!selectedCrew) return null;

  const footer = (
    <>
      <Button variant="outline" onClick={() => openModal('editProfile', selectedCrew)}>Edit Profile</Button>
      <Button variant="outline" onClick={() => toast.info('Exporting profile...')}>Export</Button>
      <Button variant="destructive" onClick={() => toast.error('Delete action requires confirmation')}>Delete</Button>
      <Button className="bg-[hsl(var(--tertiary))] text-secondary hover:bg-[hsl(var(--tertiary))]/90" onClick={() => toast.info('Task assignment opened')}>
        Assign Task
      </Button>
    </>
  );

  return (
    <ModalWrapper 
      isOpen={isOpen} 
      onClose={() => closeModal('crew')} 
      title="Crew Profile" 
      size="lg"
      footer={footer}
    >
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-6 items-start bg-card p-6 rounded-xl border border-border">
          <img src={selectedCrew.avatar} alt={selectedCrew.name} className="w-24 h-24 rounded-2xl object-cover border-2 border-border shadow-sm" />
          <div className="flex-1 w-full">
            <h3 className="text-2xl font-bold">{selectedCrew.name}</h3>
            <p className="text-muted-foreground">{selectedCrew.role}</p>
            <div className="flex items-center gap-3 mt-2">
              <Badge variant="outline" className="font-mono">{selectedCrew.employeeId}</Badge>
              <Badge className={selectedCrew.status === 'ACTIVE' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}>
                {selectedCrew.status}
              </Badge>
            </div>
          </div>
        </div>

        <Tabs defaultValue="personal" className="w-full">
          <TabsList className="w-full justify-start overflow-x-auto hide-scrollbar bg-transparent border-b border-border rounded-none h-auto p-0">
            <TabsTrigger value="personal" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Personal Info</TabsTrigger>
            <TabsTrigger value="certs" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Certifications</TabsTrigger>
            <TabsTrigger value="travel" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Travel History</TabsTrigger>
            <TabsTrigger value="assignments" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Assignments</TabsTrigger>
          </TabsList>
          
          <div className="mt-6">
            <TabsContent value="personal" className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Full Name</label>
                  <input type="text" value={selectedCrew.name} readOnly className="form-input-base bg-muted/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Hub Location</label>
                  <input type="text" value={selectedCrew.hub} readOnly className="form-input-base bg-muted/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Email Address</label>
                  <input type="email" value={`${selectedCrew.name.split(' ')[1].toLowerCase()}@operion.com`} readOnly className="form-input-base bg-muted/50" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">Phone Number</label>
                  <input type="tel" value="+1 (555) 019-2834" readOnly className="form-input-base bg-muted/50" />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="certs" className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 border border-border rounded-xl bg-card">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[hsl(var(--tertiary))]" />
                    <div>
                      <p className="font-medium">ATPL License</p>
                      <p className="text-sm text-muted-foreground">Expires: Oct 24, 2027</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-[hsl(var(--tertiary))]/10 text-[hsl(var(--tertiary))]">Valid</Badge>
                    <Button variant="ghost" size="sm">Edit</Button>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border border-border rounded-xl bg-card">
                  <div className="flex items-center gap-3">
                    {selectedCrew.alert ? <AlertTriangle className="w-5 h-5 text-destructive" /> : <CheckCircle2 className="w-5 h-5 text-[hsl(var(--tertiary))]" />}
                    <div>
                      <p className="font-medium">Class 1 Medical</p>
                      <p className="text-sm text-muted-foreground">Expires: {selectedCrew.alert ? 'In 12 days' : 'Jan 15, 2025'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={selectedCrew.alert ? 'bg-destructive/10 text-destructive' : 'bg-[hsl(var(--tertiary))]/10 text-[hsl(var(--tertiary))]'}>
                      {selectedCrew.alert ? 'Expiring Soon' : 'Valid'}
                    </Badge>
                    <Button variant="ghost" size="sm">Edit</Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="travel" className="space-y-4">
              <div className="relative pl-6 border-l-2 border-border space-y-8 py-4">
                <div className="relative">
                  <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-[hsl(var(--tertiary))] border-4 border-background"></div>
                  <p className="text-xs font-bold text-[hsl(var(--tertiary))] uppercase tracking-wider mb-1">Current</p>
                  <div className="bg-card border border-border p-4 rounded-xl mt-2">
                    <p className="font-bold flex items-center gap-2"><Plane className="w-4 h-4" /> {selectedCrew.voyage.current}</p>
                    <p className="text-sm text-muted-foreground mt-1">Started: 2 hours ago</p>
                  </div>
                </div>
                <div className="relative">
                  <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-muted-foreground border-4 border-background"></div>
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">Previous</p>
                  <div className="bg-card border border-border p-4 rounded-xl mt-2">
                    <p className="font-bold flex items-center gap-2"><Plane className="w-4 h-4" /> {selectedCrew.voyage.previous}</p>
                    <p className="text-sm text-muted-foreground mt-1">Completed: 2 days ago</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="assignments" className="space-y-4">
              <div className="p-4 border border-border rounded-xl bg-card flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <Briefcase className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold">Fleet B787 Rotation</p>
                    <p className="text-sm text-muted-foreground">Starts: Next Monday • Duration: 14 days</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">Edit</Button>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </ModalWrapper>
  );
};

export default CrewProfileModal;