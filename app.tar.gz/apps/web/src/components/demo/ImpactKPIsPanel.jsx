import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertOctagon, BrainCircuit, Users, DollarSign, TrendingUp, CheckCircle2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Checkbox } from '@/components/ui/checkbox.jsx';

const ImpactKPIsPanel = ({ onExecutePivot }) => {
  const [simulate, setSimulate] = useState(true);

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Top Status Card */}
      <div className="bg-card rounded-2xl border border-[hsl(var(--critical))]/30 shadow-sm p-5 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1 h-full bg-[hsl(var(--critical))]"></div>
        
        <div className="flex justify-between items-start mb-4">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[hsl(var(--critical))]/10 text-[hsl(var(--critical))] text-xs font-bold uppercase tracking-wider">
            <AlertOctagon className="w-3.5 h-3.5" />
            Active Incident
          </div>
          <span className="text-xs text-muted-foreground font-medium">ID: INC-8842</span>
        </div>

        <h2 className="text-xl font-bold mb-2">Atlantic Sentinel - Port Congestion</h2>
        
        <div className="bg-muted/40 rounded-xl p-3 border border-border flex items-start gap-3 mt-4">
          <div className="p-2 bg-primary/10 rounded-lg shrink-0">
            <BrainCircuit className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-foreground">Operion AI Root Cause Analysis</h4>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
              Cascading delay originating from Rotterdam berth unavailability. 
              Directly impacts 3 downstream schedules and 24 crew rotations.
            </p>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex -space-x-1.5">
                <img src="https://i.pravatar.cc/150?u=expert1" className="w-5 h-5 rounded-full border border-card" alt="Expert" />
                <img src="https://i.pravatar.cc/150?u=expert2" className="w-5 h-5 rounded-full border border-card" alt="Expert" />
              </div>
              <span className="text-[10px] font-medium text-muted-foreground">2 experts reviewing</span>
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-card rounded-2xl border border-border p-4 shadow-sm">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Users className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Affected Crew</span>
          </div>
          <div className="flex items-end justify-between">
            <span className="text-3xl font-extrabold">24</span>
            <span className="text-xs font-bold text-[hsl(var(--critical))] flex items-center bg-[hsl(var(--critical))]/10 px-1.5 py-0.5 rounded">
              <TrendingUp className="w-3 h-3 mr-1"/> +4
            </span>
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border p-4 shadow-sm">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <DollarSign className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Cost Impact</span>
          </div>
          <div className="flex items-end justify-between">
            <span className="text-2xl font-extrabold">$68.4k</span>
            <span className="text-[10px] font-medium text-muted-foreground mb-1">Estimated</span>
          </div>
        </div>
      </div>

      {/* Risk Bars */}
      <div className="bg-card rounded-2xl border border-border p-5 shadow-sm space-y-5">
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="font-bold text-foreground">Downstream Critical Risk Level</span>
            <span className="font-bold text-[hsl(var(--critical))]">85%</span>
          </div>
          <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }} animate={{ width: '85%' }} transition={{ duration: 1, delay: 0.2 }}
              className="h-full bg-[hsl(var(--critical))]"
            />
          </div>
        </div>
        <div>
          <div className="flex justify-between text-sm mb-2">
            <span className="font-bold text-foreground">Network Moderate Impact Factor</span>
            <span className="font-bold text-[hsl(var(--warning))]">62%</span>
          </div>
          <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }} animate={{ width: '62%' }} transition={{ duration: 1, delay: 0.4 }}
              className="h-full bg-[hsl(var(--warning))]"
            />
          </div>
        </div>
      </div>

      {/* Scenario Comparison */}
      <div className="bg-card rounded-2xl border border-border p-5 shadow-sm flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg">Scenario Comparison</h3>
          <div className="flex items-center space-x-2">
            <Checkbox id="simulate" checked={simulate} onCheckedChange={setSimulate} />
            <label htmlFor="simulate" className="text-xs font-medium cursor-pointer">Simulate</label>
          </div>
        </div>

        <div className="space-y-3 flex-1">
          {/* Status Quo */}
          <div className={`p-4 rounded-xl border transition-all ${!simulate ? 'border-border bg-muted/20' : 'border-border bg-card opacity-60'}`}>
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Status Quo</span>
              <span className="text-xs font-bold text-[hsl(var(--critical))] bg-[hsl(var(--critical))]/10 px-2 py-0.5 rounded">High Risk</span>
            </div>
            <div className="flex justify-between items-end">
              <div>
                <p className="text-sm text-muted-foreground">ETA Delay</p>
                <p className="text-xl font-bold">+72.0h</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Penalty</p>
                <p className="text-xl font-bold">$142k</p>
              </div>
            </div>
          </div>

          {/* AI Optimized */}
          <div className={`p-4 rounded-xl border-2 transition-all relative overflow-hidden ${simulate ? 'border-primary bg-primary/5 shadow-md' : 'border-border bg-card'}`}>
            {simulate && <div className="absolute top-0 left-0 w-full h-1 bg-gradient-ai"></div>}
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-primary flex items-center gap-1">
                <BrainCircuit className="w-3.5 h-3.5" /> AI Optimized
              </span>
              <span className="text-xs font-bold text-[hsl(var(--teal))] bg-[hsl(var(--teal))]/10 px-2 py-0.5 rounded flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Optimal
              </span>
            </div>
            <div className="flex justify-between items-end">
              <div>
                <p className="text-sm text-muted-foreground">ETA Delay</p>
                <p className="text-xl font-bold text-[hsl(var(--teal))]">+28.5h</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Penalty</p>
                <p className="text-xl font-bold text-[hsl(var(--teal))]">$12k</p>
              </div>
            </div>
          </div>
        </div>

        <Button 
          className="w-full mt-4 h-12 text-base font-bold bg-gradient-ai text-white hover:opacity-90 transition-opacity border-0 shadow-lg shadow-primary/20"
          onClick={onExecutePivot}
        >
          Execute AI Pivot <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  );
};

export default ImpactKPIsPanel;