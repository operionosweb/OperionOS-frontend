import React, { useState } from 'react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import ModalWrapper from './ModalWrapper.jsx';
import { Button } from '@/components/ui/button.jsx';
import { toast } from 'sonner';

const EditProfileModal = () => {
  const { openModals, closeModal, modalData } = useDemo();
  const isOpen = openModals.has('editProfile');
  const profileData = modalData['editProfile'] || {};
  
  const [formData, setFormData] = useState({
    name: profileData.name || '',
    email: profileData.email || '',
    phone: profileData.phone || '',
    position: profileData.role || '',
    status: profileData.status || 'ACTIVE'
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (!formData.name) {
      toast.error('Name is required');
      return;
    }
    toast.success('Profile updated successfully');
    closeModal('editProfile');
  };

  const footer = (
    <>
      <Button variant="outline" onClick={() => closeModal('editProfile')}>Cancel</Button>
      <Button variant="outline" onClick={() => setFormData({})}>Reset</Button>
      <Button className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={handleSave}>
        Save Changes
      </Button>
    </>
  );

  return (
    <ModalWrapper 
      isOpen={isOpen} 
      onClose={() => closeModal('editProfile')} 
      title="Edit Profile" 
      size="md"
      footer={footer}
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Full Name <span className="text-destructive">*</span></label>
          <input 
            type="text" 
            name="name"
            value={formData.name} 
            onChange={handleChange}
            className="form-input-base" 
            placeholder="Enter full name"
          />
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Email</label>
            <input 
              type="email" 
              name="email"
              value={formData.email} 
              onChange={handleChange}
              className="form-input-base" 
              placeholder="email@example.com"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Phone</label>
            <input 
              type="tel" 
              name="phone"
              value={formData.phone} 
              onChange={handleChange}
              className="form-input-base" 
              placeholder="+1 (555) 000-0000"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Position</label>
            <select 
              name="position"
              value={formData.position}
              onChange={handleChange}
              className="form-input-base"
            >
              <option value="">Select position...</option>
              <option value="Senior Flight Commander">Senior Flight Commander</option>
              <option value="First Officer">First Officer</option>
              <option value="Engineer">Engineer</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Status</label>
            <select 
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="form-input-base"
            >
              <option value="ACTIVE">Active</option>
              <option value="STANDBY">Standby</option>
              <option value="RESTING">Resting</option>
            </select>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Bio / Notes</label>
          <textarea 
            name="bio"
            className="form-input-base min-h-[100px] resize-y" 
            placeholder="Add any additional notes here..."
          ></textarea>
        </div>
      </div>
    </ModalWrapper>
  );
};

export default EditProfileModal;