import React from 'react';
import { Search, Bell, Settings, ChevronDown, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { useIsMobile } from '@/hooks/use-mobile.jsx';

const DisruptionsHeader = ({ onMenuClick }) => {
  const isMobile = useIsMobile();

  return (
    <header className="sticky top-0 z-40 w-full bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 border-b border-border">
      <div className="flex h-16 items-center px-4 md:px-6 gap-4">
        {isMobile && (
          <Button variant="ghost" size="icon" onClick={onMenuClick} className="shrink-0 touch-target">
            <Menu className="h-5 w-5" />
          </Button>
        )}
        
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg leading-none">O</span>
          </div>
          <span className="font-bold text-lg hidden sm:inline-block tracking-tight">Mission Control</span>
          <span className="text-muted-foreground mx-2 hidden sm:inline-block">/</span>
          <span className="font-semibold text-foreground hidden sm:inline-block">Disruptions Centre</span>
        </div>

        <div className="flex-1 flex items-center justify-end md:justify-between gap-4 ml-auto">
          <div className="hidden md:flex items-center flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="Search vessels, ports..." 
              className="w-full h-10 pl-9 pr-4 rounded-full bg-muted/50 border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary text-sm transition-all"
            />
          </div>

          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            <div className="hidden lg:flex items-center gap-2 mr-2">
              <div className="flex items-center gap-1 px-3 py-1.5 bg-muted/50 border border-border rounded-md text-sm cursor-pointer hover:bg-muted transition-colors">
                <span className="text-muted-foreground">Region:</span>
                <span className="font-medium">APAC</span>
                <ChevronDown className="h-3 w-3 ml-1" />
              </div>
              <div className="flex items-center gap-1 px-3 py-1.5 bg-muted/50 border border-border rounded-md text-sm cursor-pointer hover:bg-muted transition-colors">
                <span className="text-muted-foreground">Severity:</span>
                <span className="font-medium text-[hsl(var(--critical))]">High</span>
                <ChevronDown className="h-3 w-3 ml-1" />
              </div>
            </div>

            <Button variant="ghost" size="icon" className="relative touch-target rounded-full">
              <Bell className="h-5 w-5 text-muted-foreground" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-[hsl(var(--critical))] rounded-full border-2 border-card"></span>
            </Button>
            
            <Button variant="ghost" size="icon" className="hidden sm:flex touch-target rounded-full">
              <Settings className="h-5 w-5 text-muted-foreground" />
            </Button>

            <div className="h-8 w-8 rounded-full bg-gradient-ai p-[2px] cursor-pointer shrink-0">
              <div className="w-full h-full rounded-full border-2 border-card overflow-hidden">
                <img src="https://i.pravatar.cc/150?u=admin" alt="User" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default DisruptionsHeader;