import React, { useState } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import TabNavigation from './TabNavigation.jsx';
import ProgressBar from './ProgressBar.jsx';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';
import ROIDashboard from './roi/ROIDashboard.jsx';

const data = [
  { name: 'Mon', value: 65 },
  { name: 'Tue', value: 72 },
  { name: 'Wed', value: 85 },
  { name: 'Thu', value: 98 }, // Highlighted
  { name: 'Fri', value: 78 },
  { name: 'Sat', value: 60 },
  { name: 'Sun', value: 55 },
];

const AnalyticsDashboard = () => {
  const [activeTab, setActiveTab] = useState('roi'); // Defaulting to ROI to show the new feature
  const [timeframe, setTimeframe] = useState('month');

  return (
    <div className="flex flex-col h-full space-y-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-2">
        <h2 className="text-2xl font-bold text-foreground hidden sm:block">
          {activeTab === 'fleet' ? 'Fleet Analytics' : activeTab === 'roi' ? 'Financial Intelligence' : 'Communications'}
        </h2>
        <TabNavigation 
          tabs={[
            { id: 'fleet', label: 'Fleet Status' },
            { id: 'roi', label: 'ROI Tracker' },
            { id: 'comms', label: 'Communications' }
          ]} 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
      </div>

      {activeTab === 'fleet' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
          {/* Main Chart Area */}
          <div className="lg:col-span-2 flex flex-col space-y-6">
            <Card className="p-6 border-border shadow-sm flex-1">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="font-bold text-lg">Operational Efficiency</h3>
                  <p className="text-sm text-muted-foreground">Aggregated fleet performance across 48 vessels in real-time.</p>
                </div>
                <div className="flex bg-muted rounded-lg p-1">
                  <button 
                    className={`px-3 py-1 text-xs font-bold rounded-md ${timeframe === 'week' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
                    onClick={() => setTimeframe('week')}
                  >
                    WEEK
                  </button>
                  <button 
                    className={`px-3 py-1 text-xs font-bold rounded-md ${timeframe === 'month' ? 'bg-background shadow-sm' : 'text-muted-foreground'}`}
                    onClick={() => setTimeframe('month')}
                  >
                    MONTH
                  </button>
                </div>
              </div>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                    <Tooltip cursor={{ fill: 'hsl(var(--muted))' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                    <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                      {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.value > 90 ? 'hsl(var(--primary))' : 'hsl(var(--primary)/0.3)'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="p-6 border-border shadow-sm">
                <h3 className="font-bold text-lg mb-4">Delay Analytics</h3>
                <div className="space-y-4">
                  <ProgressBar value={58} label="PORT CONGESTION" colorClass="bg-primary" />
                  <ProgressBar value={24} label="WEATHER CONTINGENCY" colorClass="bg-destructive" />
                  <ProgressBar value={18} label="TECHNICAL MAINT." colorClass="bg-[hsl(var(--tertiary))]" />
                </div>
              </Card>
              <Card className="p-6 border-border shadow-sm flex flex-col items-center justify-center text-center">
                <div className="relative w-32 h-32 flex items-center justify-center mb-4">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--muted))" strokeWidth="10" />
                    <circle cx="50" cy="50" r="45" fill="none" stroke="hsl(var(--tertiary))" strokeWidth="10" strokeDasharray="283" strokeDashoffset="5" className="transition-all duration-1000" />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <Activity className="w-6 h-6 text-[hsl(var(--tertiary))] mb-1" />
                    <span className="text-xl font-bold">98.2%</span>
                  </div>
                </div>
                <h4 className="font-bold text-sm">SYSTEM UPTIME</h4>
                <p className="text-xs text-muted-foreground mt-1">Global Sync Active</p>
                <Badge variant="outline" className="mt-2 text-[10px]">LAST UPDATE: 2M AGO</Badge>
              </Card>
            </div>
          </div>

          {/* Right Panel */}
          <div className="hidden lg:flex flex-col space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4 border-border shadow-sm">
                <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Active Crew</p>
                <p className="text-2xl font-bold text-foreground mb-2">1,248</p>
                <div className="flex items-center gap-1 text-xs font-medium text-[hsl(var(--tertiary))]">
                  <TrendingUp className="w-3 h-3" /> +12.4% from last month
                </div>
              </Card>
              <Card className="p-4 border-border shadow-sm">
                <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Cost Per Vessel</p>
                <p className="text-2xl font-bold text-foreground mb-2">$4.2M</p>
                <div className="flex items-center gap-1 text-xs font-medium text-[hsl(var(--tertiary))]">
                  <TrendingDown className="w-3 h-3" /> -3.1% reduction targeted
                </div>
              </Card>
            </div>

            <Card className="p-5 border-border shadow-sm flex-1">
              <h3 className="font-bold text-lg mb-4">Active Fleet Status</h3>
              <div className="space-y-4">
                <div className="p-3 border border-border rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-sm">SS Titan</span>
                    <Badge className="bg-[hsl(var(--tertiary))]/10 text-[hsl(var(--tertiary))] hover:bg-[hsl(var(--tertiary))]/20 border-none">ACTIVE</Badge>
                  </div>
                  <ProgressBar value={85} label="En route Singapore ETA 14h" colorClass="bg-[hsl(var(--tertiary))]" showValue={false} />
                </div>
                <div className="p-3 border border-border rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-sm">MV Aurora</span>
                    <Badge className="bg-destructive/10 text-destructive hover:bg-destructive/20 border-none">ALERT</Badge>
                  </div>
                  <ProgressBar value={30} label="Maintenance Rotterdam +2h Delay" colorClass="bg-destructive" showValue={false} />
                </div>
                <div className="p-3 border border-border rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-sm">Global Mariner</span>
                    <Badge className="bg-[hsl(var(--tertiary))]/10 text-[hsl(var(--tertiary))] hover:bg-[hsl(var(--tertiary))]/20 border-none">ACTIVE</Badge>
                  </div>
                  <ProgressBar value={100} label="Loading Port of LA Full Capacity" colorClass="bg-[hsl(var(--tertiary))]" showValue={false} />
                </div>
              </div>
            </Card>
          </div>
        </div>
      )}

      {activeTab === 'roi' && (
        <ROIDashboard />
      )}

      {activeTab === 'comms' && (
        <div className="flex items-center justify-center h-64 border-2 border-dashed border-border rounded-xl">
          <div className="text-center">
            <h3 className="text-lg font-medium text-foreground">Communications Hub</h3>
            <p className="text-muted-foreground mt-1">Select a vessel to view active communications.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalyticsDashboard;