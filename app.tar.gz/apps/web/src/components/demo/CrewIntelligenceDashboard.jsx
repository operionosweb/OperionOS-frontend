import React, { useState, useEffect } from 'react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Filter, CheckCircle2, AlertTriangle, Clock, MapPin, FileText } from 'lucide-react';
import { toast } from 'sonner';
import CrewCard from './CrewCard.jsx';
import MetricCard from './MetricCard.jsx';

const CrewIntelligenceDashboard = () => {
  // Fix: Use crewList from context instead of undefined crewData
  const { crewList } = useDemo();
  const [selectedCrewLocal, setSelectedCrewLocal] = useState(null);

  // Initialize selected crew when data loads
  useEffect(() => {
    if (crewList && crewList.length > 0 && !selectedCrewLocal) {
      setSelectedCrewLocal(crewList[0]);
    }
  }, [crewList, selectedCrewLocal]);

  const handleCrewClick = (crew) => {
    setSelectedCrewLocal(crew);
    if (window.innerWidth < 1024) {
      toast.success(`Viewing profile for ${crew.name}`);
    }
  };

  const handleAction = (action) => {
    toast.info(`${action} feature coming soon`);
  };

  if (!crewList || crewList.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 border-2 border-dashed border-border rounded-xl">
        <p className="text-muted-foreground">Loading crew data...</p>
      </div>
    );
  }

  // Fallback values for properties that might not exist in the base crew model
  const getCrewDetail = (crew, key, fallback) => {
    if (!crew) return fallback;
    return crew[key] !== undefined ? crew[key] : fallback;
  };

  return (
    <div className="flex flex-col h-full space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Crew Intelligence</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Real-time oversight of global personnel across operational sectors. Compliance health at 98.4%.
          </p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <Button variant="outline" className="flex-1 sm:flex-none gap-2" onClick={() => handleAction('Filters')}>
            <Filter className="w-4 h-4" /> Availability Filters
          </Button>
          <Button className="flex-1 sm:flex-none bg-primary text-primary-foreground hover:bg-primary/90 font-bold">
            Onboard Crew
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
        {/* Left Column: Roster */}
        <div className="lg:col-span-1 flex flex-col space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-lg">Crew Roster</h3>
            <div className="flex gap-2">
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">ACTIVE: {crewList.filter(c => c.status === 'On Assignment').length || 842}</Badge>
              <Badge variant="outline" className="bg-muted text-muted-foreground border-border">STANDBY: {crewList.filter(c => c.status === 'Available').length || 112}</Badge>
            </div>
          </div>
          
          <div className="space-y-3 overflow-y-auto pr-2 hide-scrollbar max-h-[600px]">
            {crewList.map(crew => (
              <CrewCard 
                key={crew.id} 
                crew={crew} 
                isSelected={selectedCrewLocal?.id === crew.id}
                onClick={() => handleCrewClick(crew)}
              />
            ))}
          </div>
        </div>

        {/* Right Column: Profile Detail (Desktop) */}
        <div className="hidden lg:block lg:col-span-2">
          {selectedCrewLocal ? (
            <Card className="h-full p-6 flex flex-col border-border shadow-sm">
              <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-6">
                  <div className="w-24 h-24 rounded-2xl overflow-hidden border-4 border-background shadow-lg bg-muted">
                    <img src={selectedCrewLocal.avatar || `https://i.pravatar.cc/150?u=${selectedCrewLocal.id}`} alt={selectedCrewLocal.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-foreground mb-1">{selectedCrewLocal.name}</h2>
                    <p className="text-lg text-muted-foreground">{selectedCrewLocal.role}</p>
                    <div className="flex items-center gap-3 mt-3">
                      <Badge variant="secondary" className="font-mono">{getCrewDetail(selectedCrewLocal, 'employeeId', `EMP-${selectedCrewLocal.id.split('-')[1] || '1042'}`)}</Badge>
                      <span className="text-sm text-muted-foreground flex items-center gap-1">
                        <MapPin className="w-4 h-4" /> {getCrewDetail(selectedCrewLocal, 'hub', 'Rotterdam Hub')}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => handleAction('Full Profile')}>Full Profile</Button>
                  <Button onClick={() => handleAction('Assign Task')}>Assign Task</Button>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-6 mb-8">
                <div className="bg-muted/50 rounded-xl p-4 border border-border">
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Total Sea Hours</p>
                  <p className="text-2xl font-bold text-foreground">{getCrewDetail(selectedCrewLocal, 'hours', '4,250')}</p>
                </div>
                <div className="bg-muted/50 rounded-xl p-4 border border-border">
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Rank Seniority</p>
                  <p className="text-2xl font-bold text-foreground">{getCrewDetail(selectedCrewLocal, 'rank', 'Senior')}</p>
                </div>
                <div className="bg-muted/50 rounded-xl p-4 border border-border">
                  <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Compliance</p>
                  <p className="text-2xl font-bold text-primary">{getCrewDetail(selectedCrewLocal, 'certs', '100%')}</p>
                </div>
              </div>

              <div className="space-y-6 flex-1">
                <div>
                  <h4 className="font-bold text-lg mb-3 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-primary" /> Certification Status
                  </h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center justify-between p-3 border border-border rounded-lg bg-card">
                      <span className="text-sm font-medium">STCW Basic Safety</span>
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex items-center justify-between p-3 border border-border rounded-lg bg-card">
                      <span className="text-sm font-medium">Medical Certificate</span>
                      {getCrewDetail(selectedCrewLocal, 'alert', false) ? (
                        <AlertTriangle className="w-4 h-4 text-destructive" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-lg mb-3 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" /> Recent Voyage History
                  </h4>
                  <div className="relative pl-6 border-l-2 border-border space-y-6">
                    <div className="relative">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-primary border-4 border-background"></div>
                      <p className="text-xs font-bold text-primary uppercase tracking-wider mb-1">Current Status</p>
                      <p className="text-sm text-foreground font-medium">
                        {selectedCrewLocal.status === 'On Assignment' 
                          ? `Assigned to ${selectedCrewLocal.vessel}` 
                          : selectedCrewLocal.status}
                      </p>
                    </div>
                    <div className="relative">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-muted-foreground border-4 border-background"></div>
                      <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-1">Previous Voyage</p>
                      <p className="text-sm text-foreground font-medium">Rotterdam to Singapore (Completed)</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ) : (
            <div className="h-full flex items-center justify-center border border-dashed border-border rounded-xl">
              <p className="text-muted-foreground">Select a crew member to view details</p>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div onClick={() => handleAction('Rest Compliance')} className="cursor-pointer hover:scale-[1.02] transition-transform">
          <MetricCard label="Rest Compliance" value="94%" trend="up" trendValue="+2.1%" />
        </div>
        <div onClick={() => handleAction('Active Deployments')} className="cursor-pointer hover:scale-[1.02] transition-transform">
          <MetricCard label="Active Deployments" value="1,102" trend="up" trendValue="Optimal" />
        </div>
        <div onClick={() => handleAction('Certs Expiring')} className="cursor-pointer hover:scale-[1.02] transition-transform">
          <MetricCard label="Certs Expiring" value="14" trend="down" trendValue="Attention" trendUpIsGood={false} />
        </div>
        <div onClick={() => handleAction('Availability Index')} className="cursor-pointer hover:scale-[1.02] transition-transform">
          <MetricCard label="Availability Index" value="72.4" trend="up" trendValue="Stable" />
        </div>
      </div>
    </div>
  );
};

export default CrewIntelligenceDashboard;