import React from 'react';
import { motion } from 'framer-motion';
import { TrendingDown, TrendingUp, Users, Clock, DollarSign, ShieldAlert } from 'lucide-react';

const ImpactComparison = () => {
  return (
    <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
      <h3 className="font-bold text-lg mb-4">Impact Analysis</h3>
      
      {/* Triangle Visualization */}
      <div className="relative w-full aspect-square max-w-[240px] mx-auto mb-6">
        <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
          {/* Background Triangle */}
          <polygon points="50,10 90,85 10,85" fill="hsl(var(--muted))" opacity="0.3" stroke="hsl(var(--border))" strokeWidth="1" />
          
          {/* Optimal Zone */}
          <polygon points="50,30 75,75 25,75" fill="hsl(var(--primary))" opacity="0.1" stroke="hsl(var(--primary))" strokeWidth="1" strokeDasharray="2 2" />
          
          {/* Labels */}
          <text x="50" y="2" textAnchor="middle" className="text-[6px] font-bold fill-muted-foreground uppercase tracking-wider">Cost Optimization</text>
          <text x="95" y="92" textAnchor="end" className="text-[6px] font-bold fill-muted-foreground uppercase tracking-wider">Risk Level</text>
          <text x="5" y="92" textAnchor="start" className="text-[6px] font-bold fill-muted-foreground uppercase tracking-wider">Ops Impact</text>
          
          {/* Current State Marker */}
          <motion.g
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, type: 'spring' }}
          >
            <circle cx="45" cy="60" r="3" className="fill-primary" />
            <circle cx="45" cy="60" r="6" className="fill-primary/30 animate-ping" />
            <text x="52" y="62" className="text-[5px] font-bold fill-foreground">Current</text>
          </motion.g>
        </svg>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-muted/30 p-3 rounded-xl border border-border/50">
          <div className="flex items-center gap-2 text-muted-foreground mb-1">
            <Users className="w-3 h-3" />
            <span className="text-xs font-medium">Affected Crew</span>
          </div>
          <div className="flex items-end justify-between">
            <span className="text-xl font-bold">24</span>
            <span className="text-[10px] text-destructive flex items-center"><TrendingUp className="w-3 h-3 mr-0.5"/> +4</span>
          </div>
        </div>
        <div className="bg-muted/30 p-3 rounded-xl border border-border/50">
          <div className="flex items-center gap-2 text-muted-foreground mb-1">
            <Clock className="w-3 h-3" />
            <span className="text-xs font-medium">Est. Delay</span>
          </div>
          <div className="flex items-end justify-between">
            <span className="text-xl font-bold">18h</span>
            <span className="text-[10px] text-[hsl(var(--tertiary))] flex items-center"><TrendingDown className="w-3 h-3 mr-0.5"/> -2h</span>
          </div>
        </div>
        <div className="bg-muted/30 p-3 rounded-xl border border-border/50">
          <div className="flex items-center gap-2 text-muted-foreground mb-1">
            <DollarSign className="w-3 h-3" />
            <span className="text-xs font-medium">Cost Impact</span>
          </div>
          <div className="flex items-end justify-between">
            <span className="text-xl font-bold">$42k</span>
            <span className="text-[10px] text-destructive flex items-center"><TrendingUp className="w-3 h-3 mr-0.5"/> 5%</span>
          </div>
        </div>
        <div className="bg-muted/30 p-3 rounded-xl border border-border/50">
          <div className="flex items-center gap-2 text-muted-foreground mb-1">
            <ShieldAlert className="w-3 h-3" />
            <span className="text-xs font-medium">Compliance Risk</span>
          </div>
          <div className="flex items-end justify-between">
            <span className="text-xl font-bold">8%</span>
            <span className="text-[10px] text-[hsl(var(--tertiary))] flex items-center"><TrendingDown className="w-3 h-3 mr-0.5"/> 2%</span>
          </div>
        </div>
      </div>

      <div className="bg-primary/10 border border-primary/20 p-4 rounded-xl text-center">
        <p className="text-xs text-primary font-bold uppercase tracking-wider mb-1">Total Monthly Projected Savings</p>
        <p className="text-3xl font-extrabold text-primary">$142,850</p>
      </div>
    </div>
  );
};

export default ImpactComparison;