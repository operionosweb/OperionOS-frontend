import React, { useState } from 'react';
import { useIsMobile } from '@/hooks/use-mobile.jsx';
import LeftSidebar from './LeftSidebar.jsx';
import DemoHeader from './DemoHeader.jsx';
import BottomNavigation from './BottomNavigation.jsx';
import DisruptionsFeed from './DisruptionsFeed.jsx';
import RecommendedActions from './RecommendedActions.jsx';
import ImpactComparison from './ImpactComparison.jsx';
import AIAnalysisPanel from './AIAnalysisPanel.jsx';
import ActionPanel from './ActionPanel.jsx';
import ScenarioComparison from './ScenarioComparison.jsx';
import DetailedFleetOptimizations from './DetailedFleetOptimizations.jsx';
import DisruptionDetailModal from './aviation/DisruptionDetailModal.jsx';
import { useDemo } from '@/contexts/DemoStateContext.jsx';

const DisruptionsLayout = () => {
  const [activeSection, setActiveSection] = useState('disruptions');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();
  const { selectedDisruption, selectedRecommendation } = useDemo();

  return (
    <div className="min-h-screen bg-background flex flex-col overflow-hidden">
      <DemoHeader 
        isMobileMenuOpen={isMobileMenuOpen} 
        setIsMobileMenuOpen={setIsMobileMenuOpen} 
      />

      <div className="flex flex-1 overflow-hidden">
        <LeftSidebar 
          activeSection={activeSection} 
          setActiveSection={setActiveSection}
          isMobileMenuOpen={isMobileMenuOpen}
          setIsMobileMenuOpen={setIsMobileMenuOpen}
          isMobile={isMobile}
        />
        
        <main className="flex-1 overflow-y-auto p-3 sm:p-4 md:p-5 lg:p-6 pb-24 lg:pb-8 bg-muted/10 scrollable-y">
          <div className="max-w-[1600px] mx-auto h-full flex flex-col xl:flex-row gap-4 sm:gap-5 md:gap-6">
            
            {/* Main Content Column */}
            <div className="flex-1 space-y-6 sm:space-y-8 min-w-0">
              <div className="mb-4 sm:mb-6">
                <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight text-foreground mb-1 sm:mb-2">AI Decision Engine</h1>
                <p className="text-sm sm:text-base md:text-lg text-muted-foreground">Orchestrating global fleet efficiency in real-time.</p>
              </div>

              <RecommendedActions />
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5 md:gap-6">
                <DisruptionsFeed />
                <div className="hidden lg:block">
                  <ScenarioComparison />
                </div>
              </div>
              
              <div className="block lg:hidden">
                <ScenarioComparison />
              </div>

              <DetailedFleetOptimizations />
            </div>

            {/* Right Panel Column */}
            <div className="w-full xl:w-[400px] shrink-0 space-y-4 sm:space-y-5 md:space-y-6 flex flex-col">
              <ImpactComparison />
              
              {selectedDisruption && (
                <div className="flex-1">
                  <AIAnalysisPanel />
                </div>
              )}
              
              {selectedRecommendation && (
                <div className="shrink-0">
                  <ActionPanel />
                </div>
              )}
            </div>

          </div>
        </main>
      </div>

      <BottomNavigation 
        activeSection={activeSection} 
        setActiveSection={setActiveSection} 
      />

      <DisruptionDetailModal />
    </div>
  );
};

export default DisruptionsLayout;