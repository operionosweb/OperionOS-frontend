import React from 'react';
import { Plus, LayoutDashboard, Globe, BrainCircuit, FileText, History, Activity, LifeBuoy } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const DisruptionsLeftSidebar = () => {
  const navItems = [
    { icon: LayoutDashboard, label: 'Command', active: false },
    { icon: Globe, label: 'Global Map', active: false },
    { icon: BrainCircuit, label: 'Recovery AI', active: true },
    { icon: FileText, label: 'Manifests', active: false },
    { icon: History, label: 'History', active: false },
  ];

  const bottomItems = [
    { icon: Activity, label: 'System Status' },
    { icon: LifeBuoy, label: 'Support' },
  ];

  return (
    <aside className="hidden md:flex flex-col w-64 border-r border-border bg-card h-[calc(100vh-4rem)] sticky top-16 shrink-0">
      <div className="p-4">
        <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm flex items-center justify-center gap-2 h-11 rounded-xl font-medium">
          <Plus className="h-4 w-4" />
          New Incident
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto py-2 px-3 space-y-1 hide-scrollbar">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-3 mt-2">Navigation</div>
        {navItems.map((item, idx) => (
          <button
            key={idx}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
              item.active 
                ? 'bg-primary/10 text-primary' 
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            }`}
          >
            <item.icon className={`h-4 w-4 ${item.active ? 'text-primary' : 'text-muted-foreground'}`} />
            {item.label}
            {item.active && (
              <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary"></div>
            )}
          </button>
        ))}
      </div>

      <div className="p-3 border-t border-border space-y-1">
        {bottomItems.map((item, idx) => (
          <button
            key={idx}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </button>
        ))}
      </div>
    </aside>
  );
};

export default DisruptionsLeftSidebar;