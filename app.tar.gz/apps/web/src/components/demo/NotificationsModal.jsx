import React from 'react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import ModalWrapper from './ModalWrapper.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Bell, AlertTriangle, CheckCircle2, Info } from 'lucide-react';

const NotificationsModal = () => {
  const { openModals, closeModal, notifications, markNotificationRead, clearNotifications } = useDemo();
  const isOpen = openModals.has('notifications');

  const getIcon = (type) => {
    switch (type) {
      case 'Disruption': return <AlertTriangle className="w-5 h-5 text-destructive" />;
      case 'Compliance': return <CheckCircle2 className="w-5 h-5 text-[hsl(var(--tertiary))]" />;
      default: return <Info className="w-5 h-5 text-primary" />;
    }
  };

  const footer = (
    <>
      <Button variant="outline" onClick={clearNotifications} className="text-destructive hover:text-destructive/90">Clear All</Button>
      <Button variant="outline" onClick={() => notifications.forEach(n => markNotificationRead(n.id))}>Mark All as Read</Button>
      <Button onClick={() => closeModal('notifications')}>Close</Button>
    </>
  );

  return (
    <ModalWrapper 
      isOpen={isOpen} 
      onClose={() => closeModal('notifications')} 
      title="Notifications" 
      size="md"
      footer={footer}
    >
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto hide-scrollbar bg-transparent border-b border-border rounded-none h-auto p-0 mb-4">
          <TabsTrigger value="all" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">All</TabsTrigger>
          <TabsTrigger value="disruptions" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Disruptions</TabsTrigger>
          <TabsTrigger value="compliance" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Compliance</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-3">
          {notifications.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Bell className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>You're all caught up!</p>
            </div>
          ) : (
            notifications.map(notif => (
              <div 
                key={notif.id} 
                className={`p-4 border border-border rounded-xl flex gap-4 items-start transition-colors cursor-pointer hover:bg-muted/50 ${!notif.read ? 'bg-primary/5 border-primary/20' : 'bg-card'}`}
                onClick={() => markNotificationRead(notif.id)}
              >
                <div className="mt-1">{getIcon(notif.type)}</div>
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <h4 className="font-bold text-sm">{notif.title}</h4>
                    <span className="text-xs text-muted-foreground">{notif.time}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{notif.message}</p>
                </div>
                {!notif.read && <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>}
              </div>
            ))
          )}
        </TabsContent>
        <TabsContent value="disruptions">
          <p className="text-sm text-muted-foreground p-4 text-center">No disruption alerts.</p>
        </TabsContent>
        <TabsContent value="compliance">
          <p className="text-sm text-muted-foreground p-4 text-center">No compliance alerts.</p>
        </TabsContent>
      </Tabs>
    </ModalWrapper>
  );
};

export default NotificationsModal;