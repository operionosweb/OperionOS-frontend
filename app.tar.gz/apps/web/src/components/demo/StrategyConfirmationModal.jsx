import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Loader2, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const StrategyConfirmationModal = ({ isOpen, onClose, strategyName, onConfirm }) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        onConfirm();
      }, 1500);
    }, 1500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }} 
          animate={{ opacity: 1, scale: 1 }} 
          exit={{ opacity: 0, scale: 0.95 }}
          className="relative w-full max-w-md bg-card border border-border rounded-2xl shadow-2xl p-6 text-center"
        >
          {!isProcessing && !isSuccess && (
            <>
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="w-6 h-6 text-primary" />
              </div>
              <h2 className="text-xl font-bold mb-2">Confirm Strategy Execution</h2>
              <p className="text-sm text-muted-foreground mb-6">
                You are about to execute the <strong className="text-foreground">{strategyName}</strong> strategy. 
                This will automatically update crew manifests and notify affected personnel.
              </p>
              
              <div className="bg-muted/30 rounded-xl p-4 mb-6 text-left space-y-2 border border-border">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Estimated Time Saved:</span>
                  <span className="font-bold text-[hsl(var(--teal))]">8.5 hours</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Net Cost Impact:</span>
                  <span className="font-bold">+$2,400</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Risk Reduction:</span>
                  <span className="font-bold text-[hsl(var(--teal))]">-42%</span>
                </div>
              </div>

              <div className="flex gap-3">
                <Button variant="outline" className="flex-1" onClick={onClose}>Cancel</Button>
                <Button className="flex-1 bg-gradient-ai text-white border-0" onClick={handleConfirm}>
                  Confirm & Execute
                </Button>
              </div>
            </>
          )}

          {isProcessing && (
            <div className="py-8 flex flex-col items-center justify-center">
              <Loader2 className="w-10 h-10 text-primary animate-spin mb-4" />
              <h3 className="text-lg font-bold">Executing Strategy...</h3>
              <p className="text-sm text-muted-foreground mt-2">Re-routing manifests and updating schedules.</p>
            </div>
          )}

          {isSuccess && (
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
              className="py-8 flex flex-col items-center justify-center"
            >
              <div className="w-16 h-16 bg-[hsl(var(--teal))]/10 rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="w-8 h-8 text-[hsl(var(--teal))]" />
              </div>
              <h3 className="text-xl font-bold text-[hsl(var(--teal))]">Strategy Applied</h3>
              <p className="text-sm text-muted-foreground mt-2">All systems updated successfully.</p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default StrategyConfirmationModal;