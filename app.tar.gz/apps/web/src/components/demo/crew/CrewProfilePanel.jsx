import React, { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { User, Award, Clock, Activity, Edit2, Save, X, Phone, Calendar } from 'lucide-react';
import { toast } from 'sonner';

const CrewProfilePanel = ({ crew, isOpen, onClose }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(crew || {});

  useEffect(() => {
    if (crew) setFormData(crew);
  }, [crew]);

  if (!crew) return null;

  const handleSave = () => {
    setIsEditing(false);
    toast.success(`Profile updated for ${formData.name}`);
  };

  const handleAction = (action) => {
    toast.success(`${action} initiated for ${formData.name}`);
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto p-0 border-l border-border flex flex-col">
        <div className="bg-muted/30 p-4 md:p-6 border-b border-border relative">
          <div className="absolute top-4 right-12 flex gap-2">
            {!isEditing ? (
              <Button variant="ghost" size="icon" className="touch-target" onClick={() => setIsEditing(true)}>
                <Edit2 className="w-4 h-4" />
              </Button>
            ) : (
              <>
                <Button variant="ghost" size="icon" className="touch-target" onClick={() => setIsEditing(false)}>
                  <X className="w-4 h-4" />
                </Button>
                <Button size="icon" className="touch-target" onClick={handleSave}>
                  <Save className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>
          
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center text-primary text-2xl font-bold">
              {formData.name.charAt(0)}
            </div>
            <div className="flex-1 pr-12">
              {isEditing ? (
                <Input 
                  value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="text-xl font-bold h-9 mb-1"
                />
              ) : (
                <SheetTitle className="text-xl font-bold">{formData.name}</SheetTitle>
              )}
              <SheetDescription className="text-base">{formData.role}</SheetDescription>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className={formData.certification === 'Valid' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-amber-500/10 text-amber-600 border-amber-500/20'}>
              Cert: {formData.certification}
            </Badge>
            <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">
              Exp: {formData.experience}
            </Badge>
          </div>
        </div>

        <div className="p-4 md:p-6 flex-1">
          <Tabs defaultValue="overview" className="w-full h-full flex flex-col">
            <div className="overflow-x-auto hide-scrollbar mb-6 -mx-4 px-4 md:mx-0 md:px-0">
              <TabsList className="inline-flex w-max md:grid md:w-full md:grid-cols-4 min-w-full">
                <TabsTrigger value="overview" className="touch-target px-4">Overview</TabsTrigger>
                <TabsTrigger value="certs" className="touch-target px-4">Certs</TabsTrigger>
                <TabsTrigger value="travel" className="touch-target px-4">Crew Movements</TabsTrigger>
                <TabsTrigger value="assignments" className="touch-target px-4">History</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="overview" className="space-y-6 focus-visible:outline-none flex-1">
              <div className="space-y-4">
                <h3 className="font-semibold text-lg flex items-center gap-2"><User className="w-5 h-5 text-muted-foreground"/> Personal Details</h3>
                <div className="grid grid-cols-1 gap-4">
                  <div className="p-3 bg-card border border-border rounded-lg">
                    <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1"><Phone className="w-3 h-3"/> Contact</div>
                    {isEditing ? (
                      <Input value={formData.contact} onChange={(e) => setFormData({...formData, contact: e.target.value})} className="h-8 text-sm" />
                    ) : (
                      <div className="font-medium text-sm">{formData.contact}</div>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-card border border-border rounded-lg">
                      <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1"><Calendar className="w-3 h-3"/> Onboard</div>
                      <div className="font-medium text-sm">{formData.onboard}</div>
                    </div>
                    <div className="p-3 bg-card border border-border rounded-lg">
                      <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1"><Calendar className="w-3 h-3"/> Offboard</div>
                      <div className="font-medium text-sm">{formData.offboard}</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap gap-2">
                <Button variant="outline" className="touch-target flex-1 sm:flex-none" onClick={() => handleAction('Reassign')}>Reassign</Button>
                <Button variant="outline" className="touch-target flex-1 sm:flex-none" onClick={() => handleAction('Extend Contract')}>Extend</Button>
                <Button variant="outline" className="touch-target flex-1 sm:flex-none" onClick={() => handleAction('Mark On Leave')}>Leave</Button>
                <Button variant="destructive" className="touch-target flex-1 sm:flex-none" onClick={() => handleAction('Remove Crew')}>Remove</Button>
              </div>
            </TabsContent>

            <TabsContent value="certs" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Award className="w-5 h-5 text-muted-foreground"/> Certifications</h3>
              <div className="space-y-3">
                {['STCW Basic Safety', 'Advanced Firefighting', 'Medical First Aid'].map((cert, i) => (
                  <div key={i} className="p-3 bg-card border border-border rounded-lg flex justify-between items-center">
                    <div>
                      <div className="font-medium text-sm">{cert}</div>
                      <div className="text-xs text-muted-foreground">Expires: 2027-12-01</div>
                    </div>
                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Valid</Badge>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="travel" className="space-y-4 focus-visible:outline-none flex-1">
              {crew.movementItineraries?.length > 0 ? (
                crew.movementItineraries.map(trv => (
                  <div key={trv.id} className="p-3 border border-border rounded-lg">
                    <p className="font-medium">{trv.departure} → {trv.arrival}</p>
                    <p className="text-sm text-muted-foreground">Date: {trv.date} • Status: {trv.status}</p>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground text-center py-4">No upcoming movements.</p>
              )}
            </TabsContent>

            <TabsContent value="assignments" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Clock className="w-5 h-5 text-muted-foreground"/> Assignment History</h3>
              <div className="relative border-l-2 border-muted ml-3 space-y-6 pb-4">
                {['MV Ocean Pioneer', 'MT Nordic Spirit', 'SS Atlantic Wave'].map((v, i) => (
                  <div key={i} className="relative pl-6">
                    <div className="absolute w-3 h-3 rounded-full -left-[7.5px] top-1.5 ring-4 ring-background bg-muted-foreground"></div>
                    <div className="bg-card border border-border rounded-xl p-3">
                      <h4 className="font-semibold text-sm">{v}</h4>
                      <p className="text-xs text-muted-foreground">6 Months • 2024-2025</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="performance" className="space-y-4 focus-visible:outline-none flex-1">
              <h3 className="font-semibold text-lg flex items-center gap-2"><Activity className="w-5 h-5 text-muted-foreground"/> Performance</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-card border border-border rounded-xl text-center">
                  <div className="text-3xl font-bold text-primary mb-1">4.8</div>
                  <div className="text-xs text-muted-foreground">Average Rating</div>
                </div>
                <div className="p-4 bg-card border border-border rounded-xl text-center">
                  <div className="text-3xl font-bold text-emerald-600 mb-1">98%</div>
                  <div className="text-xs text-muted-foreground">Task Completion</div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default CrewProfilePanel;