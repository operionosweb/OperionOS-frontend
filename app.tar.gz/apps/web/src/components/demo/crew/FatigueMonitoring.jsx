import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';

const FatigueMonitoring = ({ fatigueData }) => {
  const getRiskLevel = (score) => {
    if (score <= 40) return { label: 'Low Risk', color: 'bg-emerald-500', badge: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' };
    if (score <= 70) return { label: 'Moderate', color: 'bg-amber-500', badge: 'bg-amber-500/10 text-amber-600 border-amber-500/20' };
    return { label: 'High Risk', color: 'bg-destructive', badge: 'bg-destructive/10 text-destructive border-destructive/20' };
  };

  const sortedData = [...fatigueData].sort((a, b) => b.fatigueScore - a.fatigueScore);

  return (
    <Card className="h-full flex flex-col shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Fatigue Monitoring</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto max-h-[400px] pr-4 space-y-3 custom-scrollbar">
        {sortedData.map(crew => {
          const risk = getRiskLevel(crew.fatigueScore);
          return (
            <div key={crew.id} className="flex flex-col space-y-2 p-3 border border-border rounded-xl bg-card hover:bg-muted/30 transition-colors">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{crew.name}</p>
                  <p className="text-xs text-muted-foreground">{crew.role} • {crew.department}</p>
                </div>
                <Badge variant="outline" className={risk.badge}>{risk.label}</Badge>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-2 flex-1 bg-secondary rounded-full overflow-hidden">
                  <div className={`h-full ${risk.color} transition-all duration-500`} style={{ width: `${crew.fatigueScore}%` }} />
                </div>
                <span className="text-xs font-bold w-8 text-right tabular-nums">{crew.fatigueScore}</span>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

export default FatigueMonitoring;