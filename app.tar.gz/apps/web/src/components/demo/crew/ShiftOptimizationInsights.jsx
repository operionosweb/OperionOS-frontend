import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Lightbulb, ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';

const ShiftOptimizationInsights = ({ fatigueData }) => {
  const generateInsights = () => {
    const insights = [];
    const highRisk = fatigueData.filter(c => c.fatigueScore > 70);
    const lowRisk = fatigueData.filter(c => c.fatigueScore < 40);
    
    if (highRisk.length > 0 && lowRisk.length > 0) {
      insights.push({
        priority: 'High',
        text: `Reassign tasks from ${highRisk[0].name} (${highRisk[0].role}) to ${lowRisk[0].name} to balance workload.`
      });
    }

    const deck = fatigueData.filter(c => c.department === 'Deck');
    const engine = fatigueData.filter(c => c.department === 'Engine');
    const deckAvg = deck.reduce((a, c) => a + c.fatigueScore, 0) / (deck.length || 1);
    const engineAvg = engine.reduce((a, c) => a + c.fatigueScore, 0) / (engine.length || 1);

    if (Math.abs(deckAvg - engineAvg) > 15) {
      const overloaded = deckAvg > engineAvg ? 'Deck' : 'Engine';
      insights.push({
        priority: 'Medium',
        text: `Rebalance ${overloaded} department workload. Average fatigue is significantly higher than other departments.`
      });
    }

    if (highRisk.length > 0) {
      insights.push({
        priority: 'High',
        text: `Reduce shift length for ${highRisk.map(c => c.role).join(', ')} to mitigate safety risks.`
      });
    } else if (lowRisk.length > 0) {
      insights.push({
        priority: 'Low',
        text: `Promote or cross-train ${lowRisk[0].name} for additional responsibilities.`
      });
    }

    if (insights.length < 3) {
       insights.push({ priority: 'Medium', text: 'Optimize watch schedules to align with circadian rhythms.' });
    }

    return insights.slice(0, 3);
  };

  const insights = generateInsights();

  return (
    <Card className="h-full shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Lightbulb className="w-5 h-5 text-primary" />
          Actionable Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {insights.map((insight, idx) => (
          <div key={idx} className="flex items-start gap-3 p-4 bg-muted/40 rounded-xl border border-border hover:bg-muted/60 transition-colors">
            {insight.priority === 'High' ? (
              <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            ) : insight.priority === 'Medium' ? (
              <ArrowRight className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            )}
            <div>
              <div className="mb-1">
                <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                  insight.priority === 'High' ? 'bg-destructive/10 text-destructive border border-destructive/20' : 
                  insight.priority === 'Medium' ? 'bg-amber-500/10 text-amber-600 border border-amber-500/20' : 
                  'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20'
                }`}>
                  {insight.priority} Priority
                </span>
              </div>
              <p className="text-sm text-foreground leading-relaxed">{insight.text}</p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default ShiftOptimizationInsights;