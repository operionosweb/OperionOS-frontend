import React, { useState, useEffect } from 'react';
import CrewAnalyticsDashboard from './CrewAnalyticsDashboard.jsx';
import FatigueMonitoring from './FatigueMonitoring.jsx';
import ShiftOptimizationInsights from './ShiftOptimizationInsights.jsx';

const CrewAnalytics = ({ crewList }) => {
  const [fatigueData, setFatigueData] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    if (!crewList || crewList.length === 0) return;

    setFatigueData(prev => {
      const newData = crewList.map(crew => {
        const existing = prev.find(p => p.id === crew.id && p.status === crew.status && p.role === crew.role);
        if (existing) return existing;

        let base = 50;
        const role = crew.role?.toLowerCase() || '';
        if (role.includes('captain') || role.includes('master')) base = 70;
        else if (role.includes('chief engineer')) base = 65;
        else if (role.includes('officer')) base = 60;
        else base = 50;

        let statusAdj = 0;
        if (crew.status === 'On Duty') statusAdj = 25;
        else if (crew.status === 'Off Duty' || crew.status === 'On Leave') statusAdj = -20;

        const randomVar = Math.floor(Math.random() * 21) - 10;
        let score = base + statusAdj + randomVar;
        score = Math.max(0, Math.min(100, score));

        return { ...crew, fatigueScore: score };
      });
      return newData;
    });
    setLastUpdated(new Date());
  }, [crewList]);

  if (!fatigueData.length) return null;

  return (
    <div className="mt-12 space-y-6 border-t border-border pt-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold tracking-tight">Crew Analytics</h2>
        <div className="text-sm text-muted-foreground bg-muted/50 px-3 py-1.5 rounded-md border border-border w-fit">
          Last analysis: {lastUpdated.toLocaleTimeString()}
        </div>
      </div>
      
      <CrewAnalyticsDashboard fatigueData={fatigueData} />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <FatigueMonitoring fatigueData={fatigueData} />
        <ShiftOptimizationInsights fatigueData={fatigueData} />
      </div>
    </div>
  );
};

export default CrewAnalytics;