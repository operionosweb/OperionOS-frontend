import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Activity, AlertTriangle, Users, UserMinus } from 'lucide-react';

const CrewAnalyticsDashboard = ({ fatigueData }) => {
  const avgFatigue = fatigueData.length ? Math.round(fatigueData.reduce((acc, curr) => acc + curr.fatigueScore, 0) / fatigueData.length) : 0;
  const highRiskCount = fatigueData.filter(c => c.fatigueScore > 70).length;
  const highRiskPct = fatigueData.length ? Math.round((highRiskCount / fatigueData.length) * 100) : 0;
  const onDutyCount = fatigueData.filter(c => c.status === 'On Duty').length;
  const offDutyCount = fatigueData.filter(c => c.status === 'Off Duty' || c.status === 'On Leave').length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Average Fatigue</CardTitle>
          <Activity className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold tabular-nums">{avgFatigue}<span className="text-lg text-muted-foreground font-normal">/100</span></div>
          <p className="text-xs text-muted-foreground mt-1">Across all departments</p>
        </CardContent>
      </Card>
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">High-Risk Crew</CardTitle>
          <AlertTriangle className={`h-4 w-4 ${highRiskPct > 20 ? 'text-destructive' : 'text-amber-500'}`} />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold tabular-nums">{highRiskPct}%</div>
          <p className="text-xs text-muted-foreground mt-1">{highRiskCount} members &gt; 70 score</p>
        </CardContent>
      </Card>
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Total On Duty</CardTitle>
          <Users className="h-4 w-4 text-emerald-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold tabular-nums">{onDutyCount}</div>
          <p className="text-xs text-muted-foreground mt-1">Active shift</p>
        </CardContent>
      </Card>
      <Card className="shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">Total Off Duty</CardTitle>
          <UserMinus className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold tabular-nums">{offDutyCount}</div>
          <p className="text-xs text-muted-foreground mt-1">Resting or on leave</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default CrewAnalyticsDashboard;