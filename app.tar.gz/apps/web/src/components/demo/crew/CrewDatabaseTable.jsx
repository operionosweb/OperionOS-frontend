import React, { useState, useMemo, useEffect } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Search, MoreHorizontal, AlertTriangle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog.jsx';

const initialCrewData = [
  { id: '1', name: 'James Sterling', role: 'Captain', department: 'Deck', nationality: 'UK', status: 'On Duty', certifications: [{status: 'Valid'}, {status: 'Valid'}] },
  { id: '2', name: 'Maria Garcia', role: 'First Officer', department: 'Deck', nationality: 'Spain', status: 'On Duty', certifications: [{status: 'Valid'}] },
  { id: '3', name: 'Lars Knudsen', role: 'Chief Engineer', department: 'Engine', nationality: 'Denmark', status: 'Off Duty', certifications: [{status: 'Valid'}, {status: 'Expired'}] },
  { id: '4', name: 'Chen Wei', role: 'Deck Officer', department: 'Deck', nationality: 'China', status: 'On Duty', certifications: [{status: 'Valid'}] },
  { id: '5', name: 'Aisha Patel', role: 'Electrician', department: 'Engine', nationality: 'India', status: 'On Duty', certifications: [{status: 'Valid'}] },
  { id: '6', name: 'Elena Rossi', role: 'Steward', department: 'Hotel', nationality: 'Italy', status: 'On Duty', certifications: [{status: 'Valid'}] },
  { id: '7', name: 'Michael Chang', role: 'Second Officer', department: 'Deck', nationality: 'Singapore', status: 'Off Duty', certifications: [{status: 'Valid'}] },
  { id: '8', name: 'David Smith', role: 'Bosun', department: 'Deck', nationality: 'USA', status: 'On Duty', certifications: [{status: 'Valid'}] },
  { id: '9', name: 'Ivan Petrov', role: 'Engine Mechanic', department: 'Engine', nationality: 'Russia', status: 'On Duty', certifications: [{status: 'Valid'}] },
  { id: '10', name: 'Sophie Martin', role: 'Chef', department: 'Hotel', nationality: 'France', status: 'On Duty', certifications: [{status: 'Valid'}] },
  { id: '11', name: 'Ahmed Hassan', role: 'Purser', department: 'Hotel', nationality: 'Egypt', status: 'Off Duty', certifications: [{status: 'Valid'}] },
  { id: '12', name: 'Tom Wilson', role: 'Able Seaman', department: 'Deck', nationality: 'Canada', status: 'On Duty', certifications: [{status: 'Valid'}] },
];

const CrewDatabaseTable = ({ onOpenProfile, onCrewChange }) => {
  const [localCrewList, setLocalCrewList] = useState(initialCrewData);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    role: '',
    department: '',
    nationality: '',
    status: 'On Duty'
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (onCrewChange) {
      onCrewChange(localCrewList);
    }
  }, [localCrewList, onCrewChange]);

  const getStatusColor = (status) => {
    switch(status) {
      case 'On Duty':
      case 'Onboard': return 'bg-primary/10 text-primary';
      case 'Available': return 'bg-emerald-500/10 text-emerald-600';
      case 'In Transit': return 'bg-blue-500/10 text-blue-600';
      case 'Off Duty':
      case 'On Leave': return 'bg-amber-500/10 text-amber-600';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const newErrors = {};
    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    if (!formData.role.trim()) newErrors.role = 'Role is required';
    if (!formData.department.trim()) newErrors.department = 'Department is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const newCrew = {
      id: Date.now().toString(),
      name: `${formData.firstName.trim()} ${formData.lastName.trim()}`,
      role: formData.role.trim(),
      department: formData.department.trim(),
      nationality: formData.nationality.trim() || 'Unknown',
      status: formData.status,
      vessel: 'Unassigned',
      certifications: [{ status: 'Valid' }]
    };

    setLocalCrewList(prev => [newCrew, ...prev]);
    
    setFormData({
      firstName: '',
      lastName: '',
      role: '',
      department: '',
      nationality: '',
      status: 'On Duty'
    });
    setErrors({});
    setIsAddModalOpen(false);
  };

  const filteredCrewList = useMemo(() => {
    if (!searchQuery.trim()) return localCrewList;
    const query = searchQuery.toLowerCase();
    return localCrewList.filter(crew => 
      crew.name?.toLowerCase().includes(query) ||
      crew.role?.toLowerCase().includes(query) ||
      crew.department?.toLowerCase().includes(query) ||
      crew.status?.toLowerCase().includes(query)
    );
  }, [localCrewList, searchQuery]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="relative w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search crew..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button>Add Crew Member</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add New Crew Member</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input 
                    id="firstName" 
                    name="firstName" 
                    value={formData.firstName} 
                    onChange={handleInputChange} 
                    className={errors.firstName ? "border-destructive" : ""}
                  />
                  {errors.firstName && <p className="text-xs text-destructive">{errors.firstName}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input 
                    id="lastName" 
                    name="lastName" 
                    value={formData.lastName} 
                    onChange={handleInputChange}
                    className={errors.lastName ? "border-destructive" : ""}
                  />
                  {errors.lastName && <p className="text-xs text-destructive">{errors.lastName}</p>}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="role">Role *</Label>
                  <Input 
                    id="role" 
                    name="role" 
                    placeholder="e.g. Captain, Chef"
                    value={formData.role} 
                    onChange={handleInputChange}
                    className={errors.role ? "border-destructive" : ""}
                  />
                  {errors.role && <p className="text-xs text-destructive">{errors.role}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Department *</Label>
                  <Input 
                    id="department" 
                    name="department" 
                    placeholder="Deck, Engine, Hotel"
                    value={formData.department} 
                    onChange={handleInputChange}
                    className={errors.department ? "border-destructive" : ""}
                  />
                  {errors.department && <p className="text-xs text-destructive">{errors.department}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nationality">Nationality</Label>
                  <Input 
                    id="nationality" 
                    name="nationality" 
                    value={formData.nationality} 
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Initial Status</Label>
                  <select 
                    id="status" 
                    name="status" 
                    value={formData.status} 
                    onChange={handleInputChange}
                    className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="On Duty">On Duty</option>
                    <option value="Off Duty">Off Duty</option>
                    <option value="On Leave">On Leave</option>
                    <option value="In Transit">In Transit</option>
                  </select>
                </div>
              </div>

              <DialogFooter className="pt-4">
                <Button type="button" variant="outline" onClick={() => setIsAddModalOpen(false)}>Cancel</Button>
                <Button type="submit">Save Crew Member</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="border border-border rounded-xl overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Department</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Certifications</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCrewList.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  No crew members found.
                </TableCell>
              </TableRow>
            ) : (
              filteredCrewList.map((crew) => {
                const expiringCerts = crew.certifications?.filter(c => c.status !== 'Valid').length || 0;
                return (
                  <TableRow key={crew.id} className="cursor-pointer hover:bg-muted/50" onClick={() => onOpenProfile && onOpenProfile(crew)}>
                    <TableCell className="font-medium flex items-center gap-3">
                      {crew.avatar ? (
                        <img src={crew.avatar} alt={crew.name || 'Crew'} className="w-8 h-8 rounded-full object-cover" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-medium">
                          {crew.name?.charAt(0) || '?'}
                        </div>
                      )}
                      {crew.name || 'Unknown'}
                    </TableCell>
                    <TableCell>{crew.role || 'N/A'}</TableCell>
                    <TableCell>{crew.department || 'N/A'}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={getStatusColor(crew.status)}>{crew.status || 'Unknown'}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span>{crew.certifications?.length || 0} Total</span>
                        {expiringCerts > 0 && (
                          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" /> {expiringCerts} Issue
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); }}>
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default CrewDatabaseTable;