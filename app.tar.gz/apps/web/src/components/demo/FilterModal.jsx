import React from 'react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import ModalWrapper from './ModalWrapper.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Checkbox } from '@/components/ui/checkbox.jsx';
import { Label } from '@/components/ui/label.jsx';
import { toast } from 'sonner';

const FilterModal = () => {
  const { openModals, closeModal } = useDemo();
  const isOpen = openModals.has('filter');

  const handleApply = () => {
    toast.success('Filters applied');
    closeModal('filter');
  };

  const footer = (
    <>
      <Button variant="outline" onClick={() => closeModal('filter')}>Cancel</Button>
      <Button variant="outline" onClick={() => toast.info('Filters reset')}>Reset</Button>
      <Button className="bg-[hsl(var(--tertiary))] text-secondary hover:bg-[hsl(var(--tertiary))]/90" onClick={handleApply}>
        Apply Filters
      </Button>
    </>
  );

  return (
    <ModalWrapper 
      isOpen={isOpen} 
      onClose={() => closeModal('filter')} 
      title="Availability Filters" 
      size="md"
      footer={footer}
    >
      <div className="space-y-6">
        <div className="space-y-4">
          <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground">Status</h4>
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox id="status-active" defaultChecked />
              <Label htmlFor="status-active">Active</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="status-standby" defaultChecked />
              <Label htmlFor="status-standby">Standby</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="status-resting" />
              <Label htmlFor="status-resting">Resting</Label>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground">Certification Status</h4>
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox id="cert-valid" defaultChecked />
              <Label htmlFor="cert-valid">Valid</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="cert-expiring" defaultChecked />
              <Label htmlFor="cert-expiring">Expiring Soon</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="cert-expired" />
              <Label htmlFor="cert-expired">Expired</Label>
            </div>
          </div>
        </div>
      </div>
    </ModalWrapper>
  );
};

export default FilterModal;