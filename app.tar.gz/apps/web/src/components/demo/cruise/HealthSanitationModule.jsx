import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Wind, ShieldPlus, Activity, AlertTriangle } from 'lucide-react';
import { generateAirQualityData, generateSanitationData } from '@/lib/cruiseShipData.js';

const HealthSanitationModule = () => {
  const airQuality = generateAirQualityData();
  const sanitation = generateSanitationData();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Health & Sanitation</h2>
          <p className="text-muted-foreground">Monitor air quality, infection risks, and cleaning compliance.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Air Quality Section */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2"><Wind className="w-5 h-5" /> Air Quality Monitoring</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 mt-4">
            {airQuality.map((zone, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 border border-border rounded-lg bg-muted/10">
                <div className="w-1/3">
                  <p className="font-medium text-sm">{zone.zone}</p>
                  <p className="text-xs text-muted-foreground">CO2: {zone.co2} ppm</p>
                </div>
                <div className="w-1/3 px-4">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Particulates</span>
                    <span>{zone.particulates} µg/m³</span>
                  </div>
                  <Progress value={(zone.particulates / 50) * 100} className="h-1.5" />
                </div>
                <div className="w-1/4 text-right">
                  <Badge variant={zone.status === 'High' ? 'destructive' : zone.status === 'Medium' ? 'secondary' : 'outline'}>
                    {zone.status} Risk
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Sanitation Compliance */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg flex items-center gap-2"><ShieldPlus className="w-5 h-5" /> Sanitation Compliance</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 mt-4">
            {sanitation.map((area, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 border border-border rounded-lg bg-muted/10">
                <div>
                  <p className="font-medium text-sm">{area.area}</p>
                  <p className="text-xs text-muted-foreground">Last cleaned: {area.lastCleaned}</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-xs font-medium">{area.compliance}% Compliant</p>
                  </div>
                  {area.risk === 'High' && <AlertTriangle className="w-4 h-4 text-orange-500" />}
                  {area.risk === 'Low' && <Activity className="w-4 h-4 text-green-500" />}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default HealthSanitationModule;