import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { ShieldAlert, Users, LifeBuoy, Activity } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { 
  generatePassengerDistribution, 
  generateMusterStations, 
  generateLifeboats 
} from '@/lib/cruiseShipData.js';
import { calculateEvacuationTimeline, generateAIRecommendations } from '@/lib/cruiseSimulationEngine.js';

const PassengerSafetyModule = () => {
  const { passengerCount } = useDemo();
  const [emergencyType, setEmergencyType] = useState('Fire');
  
  const distribution = generatePassengerDistribution(passengerCount);
  const musterStations = generateMusterStations();
  const lifeboats = generateLifeboats();
  const timeline = calculateEvacuationTimeline(emergencyType, passengerCount);
  const recommendations = generateAIRecommendations('safety');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Passenger Safety & Evacuation</h2>
          <p className="text-muted-foreground">Real-time monitoring and predictive emergency modeling.</p>
        </div>
        <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 px-3 py-1">
          <Users className="w-4 h-4 mr-2" /> {passengerCount} Passengers Onboard
        </Badge>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4 max-w-2xl">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="muster">Muster Stations</TabsTrigger>
          <TabsTrigger value="lifeboats">Lifeboats</TabsTrigger>
          <TabsTrigger value="emergency">Emergency Scenarios</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {distribution.map((zone, idx) => (
              <Card key={idx}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">{zone.zone}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{zone.count}</div>
                  <div className="w-full bg-muted rounded-full h-2 mt-3">
                    <div 
                      className={`h-2 rounded-full ${zone.count / zone.capacity > 0.8 ? 'bg-orange-500' : 'bg-primary'}`} 
                      style={{ width: `${Math.min(100, (zone.count / zone.capacity) * 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">Capacity: {zone.capacity}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="muster" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Muster Station Allocation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {musterStations.map((station, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <h4 className="font-semibold">Station {station.id} - {station.location}</h4>
                      <p className="text-sm text-muted-foreground">Assigned: {station.currentAssigned} / {station.capacity}</p>
                    </div>
                    <Badge variant={station.status === 'Optimal' ? 'default' : 'destructive'}>
                      {station.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lifeboats" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><LifeBuoy className="w-5 h-5" /> Port Side</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {lifeboats.filter(lb => lb.side === 'Port').slice(0, 5).map(lb => (
                  <div key={lb.id} className="flex justify-between items-center text-sm p-2 bg-muted/30 rounded">
                    <span className="font-medium">{lb.id}</span>
                    <span>{lb.assigned}/{lb.capacity}</span>
                    <Badge variant={lb.status === 'Ready' ? 'outline' : 'secondary'}>{lb.status}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><LifeBuoy className="w-5 h-5" /> Starboard Side</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {lifeboats.filter(lb => lb.side === 'Starboard').slice(0, 5).map(lb => (
                  <div key={lb.id} className="flex justify-between items-center text-sm p-2 bg-muted/30 rounded">
                    <span className="font-medium">{lb.id}</span>
                    <span>{lb.assigned}/{lb.capacity}</span>
                    <Badge variant={lb.status === 'Ready' ? 'outline' : 'secondary'}>{lb.status}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="emergency" className="mt-6 space-y-6">
          <div className="flex items-center gap-4 bg-muted/30 p-4 rounded-lg border border-border">
            <ShieldAlert className="w-6 h-6 text-orange-500" />
            <div className="flex-1">
              <h3 className="font-semibold">Simulate Emergency Scenario</h3>
              <p className="text-sm text-muted-foreground">Test evacuation timelines based on current passenger distribution.</p>
            </div>
            <Select value={emergencyType} onValueChange={setEmergencyType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Fire">Fire (Deck 5)</SelectItem>
                <SelectItem value="Flooding">Flooding (Engine)</SelectItem>
                <SelectItem value="Evacuation">General Evacuation</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Evacuation Timeline: {emergencyType}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-primary mb-6">{timeline.estimatedTime} <span className="text-lg text-muted-foreground font-normal">minutes est.</span></div>
                <div className="space-y-4">
                  {timeline.phases.map((phase, idx) => (
                    <div key={idx}>
                      <div className="flex justify-between text-sm mb-1">
                        <span>{phase.phase}</span>
                        <span className="font-medium">{phase.duration} min</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: `${(phase.duration / timeline.estimatedTime) * 100}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Activity className="w-5 h-5" /> AI Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {recommendations.map((rec, idx) => (
                    <li key={idx} className="text-sm bg-primary/5 p-3 rounded-lg border border-primary/10 text-foreground leading-relaxed">
                      {rec}
                    </li>
                  ))}
                </ul>
                <Button className="w-full mt-6" variant="outline">Apply Optimizations</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PassengerSafetyModule;