import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { generateDepartmentResources } from '@/lib/cruiseShipData.js';
import { generateAIRecommendations } from '@/lib/cruiseSimulationEngine.js';
import { Users, TrendingUp, ArrowRightLeft } from 'lucide-react';

const CrossDepartmentOperationsModule = () => {
  const departments = generateDepartmentResources();
  const recommendations = generateAIRecommendations('operations');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Cross-Department Operations</h2>
          <p className="text-muted-foreground">Optimize resource allocation between Deck, Engine, and Hotel teams.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Users className="w-5 h-5" /> Department Efficiency</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {departments.map((dept, idx) => (
                <div key={idx} className="flex items-center gap-4">
                  <div className="w-24 font-medium text-sm">{dept.dept}</div>
                  <div className="flex-1">
                    <div className="flex justify-between text-xs text-muted-foreground mb-1">
                      <span>Staff: {dept.staff}</span>
                      <span>Efficiency: {dept.efficiency}%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${dept.efficiency > 90 ? 'bg-green-500' : 'bg-primary'}`} 
                        style={{ width: `${dept.efficiency}%` }} 
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><ArrowRightLeft className="w-5 h-5" /> AI Suggestions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {recommendations.map((rec, idx) => (
              <div key={idx} className="p-3 bg-muted/30 border border-border rounded-lg text-sm leading-relaxed">
                {rec}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CrossDepartmentOperationsModule;