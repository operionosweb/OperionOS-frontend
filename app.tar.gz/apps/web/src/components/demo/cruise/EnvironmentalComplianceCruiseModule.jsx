import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Leaf, Droplets, Plug, BarChart3 } from 'lucide-react';
import { generateWastewaterData } from '@/lib/cruiseShipData.js';
import { calculateESGMetrics } from '@/lib/cruiseSimulationEngine.js';
import { useDemo } from '@/contexts/DemoStateContext.jsx';

const EnvironmentalComplianceCruiseModule = () => {
  const { passengerCount } = useDemo();
  const wastewater = generateWastewaterData();
  const esg = calculateESGMetrics(passengerCount, 45000, 12000); // Mock energy/waste totals

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Cruise Environmental & ESG</h2>
          <p className="text-muted-foreground">Passenger-specific sustainability metrics and port compliance.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* ESG Metrics */}
        <Card className="md:col-span-3 bg-primary/5 border-primary/20">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Emissions per Passenger</p>
                <p className="text-3xl font-bold text-primary">{esg.emissionsPerPassenger} <span className="text-sm font-normal">kg CO2</span></p>
              </div>
              <div className="border-l border-r border-primary/10">
                <p className="text-sm text-muted-foreground mb-1">Energy per Pax-Night</p>
                <p className="text-3xl font-bold text-primary">{esg.energyPerPassengerNight} <span className="text-sm font-normal">kWh</span></p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Waste per Passenger</p>
                <p className="text-3xl font-bold text-primary">{esg.wastePerPassenger} <span className="text-sm font-normal">kg</span></p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Wastewater */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Droplets className="w-5 h-5" /> Wastewater Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium">Black Water Tank</span>
                <span>{wastewater.blackWater.current} / {wastewater.blackWater.capacity} {wastewater.blackWater.unit}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-slate-800 h-2 rounded-full" style={{ width: `${(wastewater.blackWater.current / wastewater.blackWater.capacity) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium">Grey Water Tank</span>
                <span>{wastewater.greyWater.current} / {wastewater.greyWater.capacity} {wastewater.greyWater.unit}</span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div className="bg-slate-400 h-2 rounded-full" style={{ width: `${(wastewater.greyWater.current / wastewater.greyWater.capacity) * 100}%` }} />
              </div>
            </div>
            <div className="p-4 bg-muted/30 rounded-lg flex items-center justify-between">
              <span className="text-sm font-medium">Discharge Status</span>
              {wastewater.dischargeAllowed ? (
                <Badge className="bg-green-500">Allowed</Badge>
              ) : (
                <div className="text-right">
                  <Badge variant="destructive">Restricted Zone</Badge>
                  <p className="text-xs text-muted-foreground mt-1">Next window: {wastewater.nextDischargeWindow}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Shore Power */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Plug className="w-5 h-5" /> Shore Power</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center h-[200px] text-center">
            <div className="w-16 h-16 rounded-full bg-green-500/10 flex items-center justify-center mb-4">
              <Plug className="w-8 h-8 text-green-500" />
            </div>
            <h3 className="font-semibold text-lg mb-1">Ready to Connect</h3>
            <p className="text-sm text-muted-foreground mb-4">Next Port: Rotterdam</p>
            <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50">
              Est. Savings: €{esg.shorePowerSavings}/day
            </Badge>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EnvironmentalComplianceCruiseModule;