import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { generateHotelEnergyData } from '@/lib/cruiseShipData.js';
import { generateAIRecommendations } from '@/lib/cruiseSimulationEngine.js';
import { Zap, ThermometerSun, Droplets, Lightbulb } from 'lucide-react';

const HotelOperationsModule = () => {
  const energyData = generateHotelEnergyData();
  const recommendations = generateAIRecommendations('hotel');

  const occupancyData = [
    { deck: 'Deck 4', occupancy: 85, energy: 400 },
    { deck: 'Deck 5', occupancy: 92, energy: 450 },
    { deck: 'Deck 6', occupancy: 98, energy: 480 },
    { deck: 'Deck 7', occupancy: 75, energy: 350 },
    { deck: 'Deck 8', occupancy: 100, energy: 520 }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Hotel Operations & Energy</h2>
          <p className="text-muted-foreground">Optimize hotel load, HVAC, and passenger comfort systems.</p>
        </div>
      </div>

      <Tabs defaultValue="energy" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md">
          <TabsTrigger value="energy">Energy Breakdown</TabsTrigger>
          <TabsTrigger value="occupancy">Occupancy Analysis</TabsTrigger>
          <TabsTrigger value="recommendations">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="energy" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Hotel Load Distribution</CardTitle>
              </CardHeader>
              <CardContent className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={energyData}
                      cx="50%"
                      cy="50%"
                      innerRadius={80}
                      outerRadius={120}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {energyData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend verticalAlign="bottom" height={36} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="space-y-4">
              <Card>
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="p-3 bg-blue-500/10 rounded-lg text-blue-500"><ThermometerSun className="w-6 h-6" /></div>
                  <div>
                    <p className="text-sm text-muted-foreground">HVAC Load</p>
                    <p className="text-2xl font-bold">4.2 MW</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="p-3 bg-teal-500/10 rounded-lg text-teal-500"><Droplets className="w-6 h-6" /></div>
                  <div>
                    <p className="text-sm text-muted-foreground">Water Production</p>
                    <p className="text-2xl font-bold">1.1 MW</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="p-3 bg-yellow-500/10 rounded-lg text-yellow-500"><Lightbulb className="w-6 h-6" /></div>
                  <div>
                    <p className="text-sm text-muted-foreground">Lighting & Galley</p>
                    <p className="text-2xl font-bold">3.5 MW</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="occupancy" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Occupancy vs Energy Consumption by Deck</CardTitle>
            </CardHeader>
            <CardContent className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={occupancyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="deck" stroke="hsl(var(--muted-foreground))" />
                  <YAxis yAxisId="left" orientation="left" stroke="hsl(var(--primary))" />
                  <YAxis yAxisId="right" orientation="right" stroke="hsl(var(--chart-2))" />
                  <Tooltip cursor={{ fill: 'hsl(var(--muted)/0.5)' }} />
                  <Legend />
                  <Bar yAxisId="left" dataKey="occupancy" name="Occupancy %" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  <Bar yAxisId="right" dataKey="energy" name="Energy (kW)" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Zap className="w-5 h-5 text-yellow-500" /> Optimization Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recommendations.map((rec, idx) => (
                  <div key={idx} className="p-4 border border-border rounded-xl bg-muted/20 hover:bg-muted/40 transition-colors">
                    <p className="text-sm font-medium leading-relaxed">{rec}</p>
                    <div className="mt-4 flex justify-end">
                      <button className="text-xs font-semibold text-primary hover:underline">Apply Setting</button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HotelOperationsModule;