import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Smile, Zap, Euro } from 'lucide-react';
import { generateGuestComfortMetrics } from '@/lib/cruiseShipData.js';
import { calculateEnergyTradeOffs } from '@/lib/cruiseSimulationEngine.js';

const GuestExperienceModule = () => {
  const [comfortLevel, setComfortLevel] = useState(80);
  const metrics = generateGuestComfortMetrics();
  const tradeOffs = calculateEnergyTradeOffs(comfortLevel);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Guest Experience & Comfort</h2>
          <p className="text-muted-foreground">Balance passenger satisfaction with energy efficiency.</p>
        </div>
        <Badge className="bg-green-500 text-white text-lg px-4 py-1">
          {tradeOffs.satisfactionPredicted}% Satisfaction
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Smile className="w-5 h-5" /> Comfort vs Efficiency Engine</CardTitle>
          </CardHeader>
          <CardContent className="space-y-8">
            <div>
              <div className="flex justify-between mb-2 text-sm font-medium">
                <span>Max Efficiency</span>
                <span>Max Comfort</span>
              </div>
              <Slider 
                value={[comfortLevel]} 
                onValueChange={(val) => setComfortLevel(val[0])} 
                max={100} 
                step={1} 
              />
              <p className="text-xs text-muted-foreground mt-2 text-center">Adjusting HVAC and lighting baselines</p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
              <div className="p-4 bg-muted/20 rounded-xl text-center">
                <Zap className="w-6 h-6 mx-auto mb-2 text-yellow-500" />
                <p className="text-sm text-muted-foreground">Energy Index</p>
                <p className="text-2xl font-bold">{tradeOffs.energyIndex}</p>
              </div>
              <div className="p-4 bg-muted/20 rounded-xl text-center">
                <Euro className="w-6 h-6 mx-auto mb-2 text-primary" />
                <p className="text-sm text-muted-foreground">Daily Cost Impact</p>
                <p className={`text-2xl font-bold ${tradeOffs.costImpact > 0 ? 'text-orange-500' : 'text-green-500'}`}>
                  {tradeOffs.costImpact > 0 ? '+' : ''}€{Math.round(tradeOffs.costImpact)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Current Comfort Metrics</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center p-3 border border-border rounded-lg">
              <span className="text-sm font-medium">Temperature Control</span>
              <Badge variant="outline">{metrics.temperatureScore}/100</Badge>
            </div>
            <div className="flex justify-between items-center p-3 border border-border rounded-lg">
              <span className="text-sm font-medium">Acoustic Comfort (Noise)</span>
              <Badge variant="outline">{metrics.noiseScore}/100</Badge>
            </div>
            <div className="flex justify-between items-center p-3 border border-border rounded-lg">
              <span className="text-sm font-medium">Service Speed</span>
              <Badge variant="outline">{metrics.serviceSpeed}/100</Badge>
            </div>
            <div className="flex justify-between items-center p-3 border border-border rounded-lg">
              <span className="text-sm font-medium">Crowd Density</span>
              <Badge variant="outline">{metrics.crowdDensity}/100</Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GuestExperienceModule;