import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, Info } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';

const ScenarioComparison = () => {
  const [selected, setSelected] = useState('A');

  const scenarios = [
    { id: 'A', title: 'Rebook flights', cost: '+$2,300', delay: '-4h', risk: 'Low', recommended: true },
    { id: 'B', title: 'Reassign crew', cost: '+$1,200', delay: '+2h', risk: 'Low', recommended: false },
    { id: 'C', title: 'Delay vessel', cost: '$0', delay: '+6h', risk: 'High', recommended: false },
  ];

  return (
    <div className="space-y-4 mt-8">
      <h2 className="text-xl font-bold tracking-tight">Scenario Comparison</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {scenarios.map((scenario) => (
          <div 
            key={scenario.id}
            className={`relative p-5 rounded-2xl border transition-all cursor-pointer ${
              selected === scenario.id 
                ? 'border-primary bg-primary/5 shadow-md' 
                : 'border-border bg-card hover:border-primary/30'
            }`}
            onClick={() => setSelected(scenario.id)}
          >
            {scenario.recommended && (
              <Badge className="absolute -top-2.5 left-4 bg-[hsl(var(--tertiary))] text-secondary text-[10px] uppercase tracking-wider">
                Recommended
              </Badge>
            )}
            {selected === scenario.id && (
              <div className="absolute top-4 right-4 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                <Check className="w-3 h-3 text-primary-foreground" />
              </div>
            )}
            
            <h3 className="font-bold text-lg mb-4 pr-8">{scenario.title}</h3>
            
            <div className="space-y-2 mb-6">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Cost Impact</span>
                <span className="font-medium">{scenario.cost}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Delay</span>
                <span className="font-medium text-[hsl(var(--tertiary))]">{scenario.delay}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Risk</span>
                <span className={`font-medium ${scenario.risk === 'High' ? 'text-destructive' : ''}`}>{scenario.risk}</span>
              </div>
            </div>
            
            <Button variant="ghost" size="sm" className="w-full text-xs border border-border/50">
              <Info className="w-3 h-3 mr-2" /> View Breakdown
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScenarioComparison;