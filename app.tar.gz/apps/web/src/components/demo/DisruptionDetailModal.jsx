import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, AlertOctagon, BrainCircuit, Users, Clock, DollarSign, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const DisruptionDetailModal = ({ isOpen, onClose, incident, onApplyStrategy }) => {
  if (!isOpen || !incident) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[999] flex items-center justify-center p-4 sm:p-6">
        <motion.div 
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="absolute inset-0 bg-background/80 backdrop-blur-sm"
          onClick={onClose}
        />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }} 
          animate={{ opacity: 1, scale: 1, y: 0 }} 
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-2xl bg-card border border-border rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-5 border-b border-border flex justify-between items-start bg-muted/30">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className={`px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                  incident.severity === 'critical' ? 'bg-[hsl(var(--critical))]/10 text-[hsl(var(--critical))]' :
                  incident.severity === 'warning' ? 'bg-[hsl(var(--warning))]/10 text-[hsl(var(--warning))]' :
                  'bg-primary/10 text-primary'
                }`}>
                  {incident.severity} Severity
                </span>
                <span className="text-xs font-medium text-muted-foreground">{incident.type}</span>
              </div>
              <h2 className="text-2xl font-bold text-foreground">{incident.vessel || incident.name}</h2>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full h-8 w-8 bg-card border border-border shadow-sm">
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6 hide-scrollbar">
            <p className="text-sm text-muted-foreground leading-relaxed">
              {incident.desc}
            </p>

            <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
              <h4 className="text-sm font-bold text-primary flex items-center gap-2 mb-2">
                <BrainCircuit className="w-4 h-4" /> AI Root Cause Analysis
              </h4>
              <p className="text-sm text-foreground leading-relaxed">
                Analysis indicates a 94% probability of cascading delays affecting downstream schedules. 
                Immediate intervention required to prevent SLA penalties.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 border border-border rounded-xl bg-card text-center">
                <Clock className="w-4 h-4 mx-auto mb-1 text-muted-foreground" />
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">ETA Delay</p>
                <p className="text-lg font-bold text-[hsl(var(--critical))]">+14h</p>
              </div>
              <div className="p-3 border border-border rounded-xl bg-card text-center">
                <DollarSign className="w-4 h-4 mx-auto mb-1 text-muted-foreground" />
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Cost Impact</p>
                <p className="text-lg font-bold text-[hsl(var(--critical))]">$42k</p>
              </div>
              <div className="p-3 border border-border rounded-xl bg-card text-center">
                <AlertOctagon className="w-4 h-4 mx-auto mb-1 text-muted-foreground" />
                <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Risk Level</p>
                <p className="text-lg font-bold text-[hsl(var(--critical))]">High</p>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                <Users className="w-4 h-4" /> Affected Crew (8)
              </h4>
              <div className="flex flex-wrap gap-2">
                {[1,2,3,4].map(i => (
                  <div key={i} className="flex items-center gap-2 p-2 border border-border rounded-lg bg-muted/30 pr-4">
                    <img src={`https://i.pravatar.cc/150?u=${i+10}`} className="w-8 h-8 rounded-full border border-border" alt="Crew" />
                    <div>
                      <p className="text-xs font-bold">Crew Member {i}</p>
                      <p className="text-[10px] text-muted-foreground">Engineering</p>
                    </div>
                  </div>
                ))}
                <div className="flex items-center justify-center px-4 border border-dashed border-border rounded-lg bg-muted/10 text-xs font-medium text-muted-foreground">
                  +4 more
                </div>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">Recommended Actions</h4>
              <div className="space-y-3">
                <div className="p-4 border border-primary/30 bg-primary/5 rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <p className="font-bold text-sm">Rebook Travel via Dubai</p>
                    <p className="text-xs text-muted-foreground mt-1">Reduces delay by 8h. Cost: +$2.4k</p>
                  </div>
                  <Button size="sm" className="w-full sm:w-auto bg-primary text-primary-foreground" onClick={() => onApplyStrategy('Rebook Travel')}>
                    Apply Strategy
                  </Button>
                </div>
                <div className="p-4 border border-border bg-card rounded-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <p className="font-bold text-sm">Reassign Standby Crew</p>
                    <p className="text-xs text-muted-foreground mt-1">Zero delay. Cost: +$4.1k</p>
                  </div>
                  <Button size="sm" variant="outline" className="w-full sm:w-auto" onClick={() => onApplyStrategy('Reassign Crew')}>
                    Apply Strategy
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default DisruptionDetailModal;