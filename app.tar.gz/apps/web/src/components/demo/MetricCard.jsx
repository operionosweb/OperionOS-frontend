import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { TrendingUp, TrendingDown } from 'lucide-react';

const MetricCard = ({ label, value, icon: Icon, trend, trendValue, trendUpIsGood = true }) => {
  const isPositiveTrend = trend === 'up';
  const trendColor = isPositiveTrend === trendUpIsGood ? 'text-green-600' : 'text-red-600';
  const TrendIcon = isPositiveTrend ? TrendingUp : TrendingDown;

  return (
    <Card className="p-5 flex flex-col justify-between h-full shadow-md hover:shadow-xl transition-all border-2 border-gray-200 hover:border-primary/50 bg-white">
      <div className="flex justify-between items-start mb-4">
        <div className="p-2 bg-primary/10 rounded-lg">
          {Icon && <Icon className="w-5 h-5 text-primary" />}
        </div>
        {trend && (
          <div className={`flex items-center gap-1 text-xs font-bold ${trendColor}`}>
            <TrendIcon className="w-3 h-3" />
            {trendValue}
          </div>
        )}
      </div>
      <div>
        <h4 className="text-2xl font-bold text-gray-900 mb-1">{value}</h4>
        <p className="text-xs text-gray-600 font-medium uppercase tracking-wider">{label}</p>
      </div>
    </Card>
  );
};

export default MetricCard;