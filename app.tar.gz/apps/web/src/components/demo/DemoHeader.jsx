import React from 'react';
import { Search, Bell, Settings, User, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover.jsx';
import Logo from '@/components/Logo.jsx';
import CruiseModeToggle from '@/components/demo/CruiseModeToggle.jsx';

const DemoHeader = ({ isMobileMenuOpen, setIsMobileMenuOpen }) => {
  const context = useDemo();
  const notifications = context?.notifications || [];
  const markNotificationRead = context?.markNotificationRead;

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleNotificationClick = (notificationId) => {
    if (typeof markNotificationRead === 'function') {
      markNotificationRead(notificationId);
    }
  };

  return (
    <header className="h-16 bg-white border-b-2 border-gray-200 flex items-center justify-between px-4 lg:px-6 relative z-40 shadow-sm">
      <div className="flex items-center gap-3 sm:gap-4">
        <Button 
          variant="ghost" 
          size="icon" 
          className="lg:hidden text-gray-700 hover:text-gray-900 hover:bg-gray-100 relative z-50 min-w-[44px] min-h-[44px]"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </Button>
        
        <div className="block md:hidden">
          <Logo variant="icon" size="md" isClickable={true} />
        </div>
        <div className="hidden md:block">
          <Logo variant="full" size="lg" isClickable={true} />
        </div>
      </div>

      <div className="hidden lg:flex items-center ml-4">
        <CruiseModeToggle />
      </div>

      <div className="flex-1 max-w-md mx-4 hidden md:block lg:ml-8">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
          <input 
            type="text" 
            placeholder="Search fleet personnel, certifications, or status..." 
            className="w-full h-10 bg-gray-100 border-2 border-gray-300 rounded-full pl-10 pr-4 text-sm text-gray-900 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="relative text-gray-700 hover:text-gray-900 hover:bg-gray-100 min-w-[44px] min-h-[44px]">
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-80 p-0 bg-white border-2 border-gray-300 shadow-xl">
            <div className="p-4 border-b-2 border-gray-200 font-bold text-gray-900">Notifications</div>
            <div className="max-h-[300px] overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-4 text-center text-gray-600 text-sm">No notifications</div>
              ) : (
                notifications.map(notif => (
                  <div 
                    key={notif.id} 
                    className={`p-4 border-b border-gray-200 hover:bg-gray-50 cursor-pointer transition-colors ${!notif.read ? 'bg-blue-50' : ''}`}
                    onClick={() => handleNotificationClick(notif.id)}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-semibold text-sm text-gray-900">{notif.title}</span>
                      <span className="text-xs text-gray-600">{notif.time}</span>
                    </div>
                    <p className="text-sm text-gray-700">{notif.message}</p>
                  </div>
                ))
              )}
            </div>
          </PopoverContent>
        </Popover>

        <Button variant="ghost" size="icon" className="hidden sm:flex text-gray-700 hover:text-gray-900 hover:bg-gray-100 min-w-[44px] min-h-[44px]">
          <Settings className="w-5 h-5" />
        </Button>
        
        <div className="hidden sm:flex items-center gap-3 pl-4 border-l-2 border-gray-200">
          <div className="text-right">
            <p className="text-sm font-bold text-gray-900 leading-none">Ops Lead</p>
            <p className="text-xs text-gray-600 mt-1">Terminal 4-B</p>
          </div>
          <Avatar className="w-9 h-9 border-2 border-gray-300 cursor-pointer hover:ring-2 ring-primary transition-all">
            <AvatarImage src="https://i.pravatar.cc/150?u=ops" />
            <AvatarFallback className="bg-blue-100 text-blue-700"><User className="w-4 h-4" /></AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
};

export default DemoHeader;