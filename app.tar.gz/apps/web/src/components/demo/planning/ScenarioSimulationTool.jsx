import React, { useState } from 'react';
import { Activity, Play, RotateCcw, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { toast } from 'sonner';

const ScenarioSimulationTool = () => {
  const [isSimulating, setIsSimulating] = useState(false);
  const [results, setResults] = useState(null);

  const runSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
      setResults({
        costImpact: '+$4,200',
        delay: '3 Days',
        riskLevel: 'Medium',
        before: '12 Apr 2026',
        after: '15 Apr 2026'
      });
      toast.success('Simulation complete');
    }, 1500);
  };

  const resetSimulation = () => {
    setResults(null);
  };

  return (
    <Card className="shadow-sm border-border h-full">
      <CardHeader className="pb-4 border-b border-border">
        <CardTitle className="text-xl flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" />
          Scenario Simulation
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Action Type</label>
            <Select defaultValue="delay">
              <SelectTrigger>
                <SelectValue placeholder="Select action" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="delay">Delay Rotation</SelectItem>
                <SelectItem value="reassign">Reassign Crew</SelectItem>
                <SelectItem value="extend">Extend Contract</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Target Vessel</label>
            <Select defaultValue="v1">
              <SelectTrigger>
                <SelectValue placeholder="Select vessel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="v1">SS Atlantic Explorer</SelectItem>
                <SelectItem value="v2">MV Baltic Horizon</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Duration (Days)</label>
            <Input type="number" defaultValue={3} min={1} />
          </div>
        </div>

        <div className="flex gap-3">
          <Button 
            className="flex-1 bg-primary text-primary-foreground" 
            onClick={runSimulation}
            disabled={isSimulating}
          >
            {isSimulating ? 'Calculating...' : <><Play className="w-4 h-4 mr-2" /> Run Simulation</>}
          </Button>
          <Button variant="outline" size="icon" onClick={resetSimulation}>
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>

        {results && (
          <div className="mt-6 p-4 rounded-xl bg-muted/50 border border-border animate-in fade-in slide-in-from-bottom-4">
            <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-muted-foreground">Simulation Results</h4>
            
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Cost Impact</div>
                <div className="font-semibold text-destructive">{results.costImpact}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Delay</div>
                <div className="font-semibold">{results.delay}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Risk Level</div>
                <div className="font-semibold text-warning-foreground">{results.riskLevel}</div>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-border text-sm">
              <span className="text-muted-foreground">{results.before}</span>
              <ArrowRight className="w-4 h-4 text-muted-foreground" />
              <span className="font-medium">{results.after}</span>
            </div>

            <Button className="w-full mt-4" variant="secondary">Apply Changes</Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ScenarioSimulationTool;