import React from 'react';
import { Users, Search, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { crewMembers } from '@/lib/planningData.js';

const CrewAvailabilityPanel = () => {
  return (
    <Card className="shadow-sm border-border">
      <CardHeader className="pb-4 border-b border-border">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <CardTitle className="text-xl flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Crew Availability
          </CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search personnel..." className="pl-9 h-9" />
            </div>
            <Button variant="outline" size="icon" className="h-9 w-9 shrink-0">
              <Filter className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="hidden md:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Available Date</TableHead>
                <TableHead>Certifications</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {crewMembers.slice(0, 5).map(crew => (
                <TableRow key={crew.id}>
                  <TableCell className="font-medium">{crew.name}</TableCell>
                  <TableCell className="text-muted-foreground">{crew.role}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={
                      crew.status === 'Available' ? 'bg-teal-500/10 text-teal-700' : 
                      crew.status.includes('Risk') || crew.status.includes('Expiring') ? 'bg-destructive/10 text-destructive' : ''
                    }>
                      {crew.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{crew.availableDate}</TableCell>
                  <TableCell>
                    <span className={`text-sm ${crew.certs === 'Valid' ? 'text-teal-600' : 'text-warning-foreground'}`}>
                      {crew.certs}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" className="text-primary">Assign</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {/* Mobile View */}
        <div className="md:hidden p-4 space-y-4">
          {crewMembers.slice(0, 4).map(crew => (
            <div key={crew.id} className="p-4 rounded-xl border border-border bg-card space-y-3 shadow-sm">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-semibold">{crew.name}</div>
                  <div className="text-sm text-muted-foreground">{crew.role}</div>
                </div>
                <Badge variant="secondary" className={
                  crew.status === 'Available' ? 'bg-teal-500/10 text-teal-700' : 
                  crew.status.includes('Risk') || crew.status.includes('Expiring') ? 'bg-destructive/10 text-destructive' : ''
                }>
                  {crew.status}
                </Badge>
              </div>
              <div className="flex items-center justify-between text-sm pt-2 border-t border-border/50">
                <span className="text-muted-foreground">Avail: {crew.availableDate}</span>
                <Button variant="outline" size="sm">Assign</Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CrewAvailabilityPanel;