import React from 'react';
import { motion } from 'framer-motion';
import { Zap, TrendingUp, ShieldCheck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { aiSuggestions } from '@/lib/planningData.js';
import { toast } from 'sonner';

const AIOptimizationSuggestions = () => {
  const handleApply = (title) => {
    toast.success(`Applied: ${title}`, {
      description: 'Optimization plan has been updated successfully.'
    });
  };

  return (
    <Card className="shadow-sm border-border bg-gradient-to-br from-card to-teal-500/5 h-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl flex items-center gap-2">
            <Zap className="w-5 h-5 text-teal-500" />
            AI Rotation Optimizer
          </CardTitle>
          <Badge className="bg-teal-500 hover:bg-teal-600 text-white">EFFICIENCY ENGINE</Badge>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          Sentinel AI has identified opportunities to reduce logistics costs by <strong className="text-foreground">$42,300</strong>.
        </p>
      </CardHeader>
      <CardContent className="space-y-4 mt-4">
        {aiSuggestions.map((suggestion, index) => (
          <motion.div 
            key={suggestion.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-xl bg-background border border-border shadow-sm"
          >
            <div className="flex justify-between items-start mb-2">
              <h4 className="font-semibold text-foreground">{suggestion.title}</h4>
              <Badge variant="outline" className="bg-teal-500/10 text-teal-700 border-teal-500/20">
                Save {suggestion.savings}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-4">{suggestion.description}</p>
            
            <div className="flex items-center gap-4 text-xs text-muted-foreground mb-4">
              <span className="flex items-center gap-1"><TrendingUp className="w-3 h-3 text-teal-500" /> {suggestion.efficiency} efficiency</span>
              <span className="flex items-center gap-1"><ShieldCheck className="w-3 h-3 text-blue-500" /> {suggestion.risk} risk</span>
            </div>

            <div className="flex gap-2">
              <Button size="sm" className="flex-1 bg-teal-600 hover:bg-teal-700 text-white" onClick={() => handleApply(suggestion.title)}>
                Apply
              </Button>
              <Button size="sm" variant="outline" className="flex-1">
                Simulate
              </Button>
            </div>
          </motion.div>
        ))}
      </CardContent>
    </Card>
  );
};

export default AIOptimizationSuggestions;