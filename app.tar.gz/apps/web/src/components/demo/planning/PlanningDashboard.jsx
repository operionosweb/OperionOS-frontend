import React, { useState } from 'react';
import { Calendar, CheckCircle, Ship, AlertTriangle, Plane, Bed, Activity } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { criticalAlerts, complianceMetrics, livePersonnelStatus } from '@/lib/planningData.js';

// Import sub-components
import CrewRotationPlanner from './CrewRotationPlanner.jsx';
import CrewContractTracker from './CrewContractTracker.jsx';
import CrewAvailabilityPanel from './CrewAvailabilityPanel.jsx';
import DemandForecastingChart from './DemandForecastingChart.jsx';
import GapAnalysisPanel from './GapAnalysisPanel.jsx';
import AIOptimizationSuggestions from './AIOptimizationSuggestions.jsx';
import ScenarioSimulationTool from './ScenarioSimulationTool.jsx';

const PlanningDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20 md:pb-0">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">Crew Rotation Management</h1>
          <p className="text-muted-foreground mt-2 text-lg">Coordinating 1,240 active personnel across 42 vessels globally</p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto hide-scrollbar bg-transparent border-b border-border rounded-none h-auto p-0 space-x-6">
          <TabsTrigger value="overview" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Overview</TabsTrigger>
          <TabsTrigger value="planner" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Timeline Planner</TabsTrigger>
          <TabsTrigger value="contracts" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Contracts & Availability</TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 py-3">Forecasting & Simulation</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6 focus-visible:outline-none">
          {/* KPIs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-blue-500/5 border-blue-500/20 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 rounded-xl bg-blue-500/10 text-blue-600">
                  <Calendar className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-foreground">142 Changes Today</h3>
                  <p className="text-sm text-muted-foreground">Active rotations across 8 ports</p>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-teal-500/5 border-teal-500/20 shadow-sm hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-6 flex items-center gap-4">
                <div className="p-3 rounded-xl bg-teal-500/10 text-teal-600">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-foreground">99.8% Global Compliance</h3>
                  <p className="text-sm text-muted-foreground">All mandatory certifications valid</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Alerts & Timeline Preview */}
            <div className="lg:col-span-2 space-y-6">
              <CrewRotationPlanner />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="shadow-sm border-border">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-destructive" />
                        Critical Alerts
                      </h3>
                      <Badge variant="destructive">4 ACTION REQUIRED</Badge>
                    </div>
                    <div className="space-y-3">
                      {criticalAlerts.map(alert => (
                        <div key={alert.id} className={`p-3 rounded-lg bg-muted/30 border border-border ${alert.borderClass} cursor-pointer hover:bg-muted/50 transition-colors`}>
                          <div className="font-semibold text-sm">{alert.person}</div>
                          <div className="text-xs text-muted-foreground mt-1">{alert.issue}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
                
                <GapAnalysisPanel />
              </div>
            </div>

            {/* Right Column: AI & Compliance */}
            <div className="space-y-6">
              <AIOptimizationSuggestions />
              
              <Card className="shadow-sm border-border">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Compliance Status</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>STCW Certifications</span>
                        <span className="font-medium text-teal-600">{complianceMetrics.stcw}%</span>
                      </div>
                      <Progress value={complianceMetrics.stcw} className="h-2 bg-muted" indicatorColor="bg-teal-500" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Medical Clearances</span>
                        <span className="font-medium text-blue-600">{complianceMetrics.medical}%</span>
                      </div>
                      <Progress value={complianceMetrics.medical} className="h-2 bg-muted" indicatorColor="bg-blue-500" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Drug/Alcohol Screening</span>
                        <span className="font-medium text-muted-foreground">{complianceMetrics.drugAlcohol}%</span>
                      </div>
                      <Progress value={complianceMetrics.drugAlcohol} className="h-2 bg-muted" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Live Status Footer */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Plane className="w-5 h-5 text-muted-foreground" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-teal-500 rounded-full"></span>
              </div>
              <div>
                <div className="text-xs text-muted-foreground font-medium tracking-wider">IN TRANSIT</div>
                <div className="font-bold">{livePersonnelStatus.inTransit}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Bed className="w-5 h-5 text-muted-foreground" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full"></span>
              </div>
              <div>
                <div className="text-xs text-muted-foreground font-medium tracking-wider">STANDBY</div>
                <div className="font-bold">{livePersonnelStatus.standby}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Activity className="w-5 h-5 text-muted-foreground" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-destructive rounded-full"></span>
              </div>
              <div>
                <div className="text-xs text-muted-foreground font-medium tracking-wider">QUARANTINE</div>
                <div className="font-bold">{livePersonnelStatus.quarantine}</div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="planner" className="mt-6 h-[600px] focus-visible:outline-none">
          <CrewRotationPlanner />
        </TabsContent>

        <TabsContent value="contracts" className="mt-6 space-y-6 focus-visible:outline-none">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CrewContractTracker />
            <CrewAvailabilityPanel />
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="mt-6 space-y-6 focus-visible:outline-none">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <DemandForecastingChart />
            <ScenarioSimulationTool />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PlanningDashboard;