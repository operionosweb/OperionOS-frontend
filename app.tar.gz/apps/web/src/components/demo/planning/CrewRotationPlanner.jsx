import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, AlertTriangle, User, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';

const CrewRotationPlanner = () => {
  const [activeTab, setActiveTab] = useState('Week');

  const timelineData = [
    {
      id: 'v1',
      vessel: 'MV Atlantic Star',
      assignments: [
        { id: 'a1', name: 'Capt. John Andersen', start: 10, end: 40, color: 'bg-blue-500/20 text-blue-700 border-blue-500/30', conflict: false },
        { id: 'a2', name: 'Capt. David Müller', start: 45, end: 80, color: 'bg-teal-500/20 text-teal-700 border-teal-500/30', conflict: false }
      ]
    },
    {
      id: 'v2',
      vessel: 'MV Ocean Pioneer',
      assignments: [
        { id: 'a3', name: 'CE Maria Lopez', start: 20, end: 60, color: 'bg-blue-500/20 text-blue-700 border-blue-500/30', conflict: false },
        { id: 'a4', name: 'CE Pending', start: 55, end: 90, color: 'bg-red-500/20 text-red-700 border-red-500/30', conflict: true }
      ]
    }
  ];

  return (
    <Card className="shadow-sm border-border flex flex-col h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-4 border-b border-border">
        <CardTitle className="text-xl flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          Operational Timeline
        </CardTitle>
        <div className="flex items-center gap-4">
          <div className="flex gap-1 bg-muted p-1 rounded-lg">
            {['Week', 'Month', 'Year'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
                  activeTab === tab ? 'bg-background shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
          <div className="flex gap-1">
            <Button variant="outline" size="icon" className="h-8 w-8"><ChevronLeft className="w-4 h-4" /></Button>
            <Button variant="outline" size="icon" className="h-8 w-8"><ChevronRight className="w-4 h-4" /></Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 p-0 overflow-x-auto">
        <div className="min-w-[600px] p-6 space-y-6">
          {/* Timeline Header */}
          <div className="flex border-b border-border pb-2 text-sm text-muted-foreground">
            <div className="w-48 font-medium">Vessel</div>
            <div className="flex-1 flex justify-between px-4">
              <span>Mar 01</span>
              <span>Mar 15</span>
              <span>Apr 01</span>
              <span>Apr 15</span>
              <span>May 01</span>
            </div>
          </div>

          {/* Timeline Tracks */}
          {timelineData.map(track => (
            <div key={track.id} className="flex items-center gap-4">
              <div className="w-48 font-semibold text-sm flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary"></div>
                {track.vessel}
              </div>
              <div className="flex-1 planning-timeline-track">
                {track.assignments.map(assignment => (
                  <motion.div
                    key={assignment.id}
                    drag="x"
                    dragConstraints={{ left: 0, right: 0 }}
                    className={`planning-timeline-event border ${assignment.color}`}
                    style={{ left: `${assignment.start}%`, width: `${assignment.end - assignment.start}%` }}
                    whileHover={{ scale: 1.02, zIndex: 10 }}
                    whileDrag={{ scale: 1.05, zIndex: 20, opacity: 0.8 }}
                  >
                    <User className="w-3 h-3 mr-1 shrink-0" />
                    <span className="truncate">{assignment.name}</span>
                    {assignment.conflict && (
                      <AlertTriangle className="w-3 h-3 ml-auto text-destructive shrink-0" />
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CrewRotationPlanner;