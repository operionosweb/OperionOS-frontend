import React from 'react';
import { FileText, Calendar, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';

const CrewContractTracker = () => {
  const contracts = [
    { id: 1, name: 'John Andersen', role: 'Captain', vessel: 'MV Atlantic Star', end: '12 Apr 2026', status: 'Extension Pending', statusColor: 'bg-warning/20 text-warning-foreground' },
    { id: 2, name: 'Maria Lopez', role: 'Chief Engineer', vessel: 'MV Ocean Pioneer', end: '18 Apr 2026', status: 'Confirmed', statusColor: 'bg-teal-500/20 text-teal-700' },
    { id: 3, name: 'Ahmed Khan', role: 'Deck Officer', vessel: 'MV Baltic Horizon', end: '20 Apr 2026', status: 'Not Extended', statusColor: 'bg-destructive/20 text-destructive' }
  ];

  return (
    <Card className="shadow-sm border-border">
      <CardHeader className="pb-4 border-b border-border">
        <CardTitle className="text-xl flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          Contract Tracking
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="hidden md:block">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Crew Member</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Vessel</TableHead>
                <TableHead>Contract End</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contracts.map(contract => (
                <TableRow key={contract.id}>
                  <TableCell className="font-medium">{contract.name}</TableCell>
                  <TableCell className="text-muted-foreground">{contract.role}</TableCell>
                  <TableCell>{contract.vessel}</TableCell>
                  <TableCell>{contract.end}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`border-transparent ${contract.statusColor}`}>
                      {contract.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">Manage</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        
        {/* Mobile View */}
        <div className="md:hidden p-4 space-y-4">
          {contracts.map(contract => (
            <div key={contract.id} className="p-4 rounded-xl border border-border bg-muted/30 space-y-3">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-semibold">{contract.name}</div>
                  <div className="text-sm text-muted-foreground">{contract.role} • {contract.vessel}</div>
                </div>
                <Badge variant="outline" className={`border-transparent ${contract.statusColor}`}>
                  {contract.status}
                </Badge>
              </div>
              <div className="flex items-center justify-between text-sm pt-2 border-t border-border/50">
                <span className="flex items-center gap-1 text-muted-foreground">
                  <Calendar className="w-4 h-4" /> Ends {contract.end}
                </span>
                <Button variant="outline" size="sm">Manage</Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CrewContractTracker;