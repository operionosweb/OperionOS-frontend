import React from 'react';
import { AlertTriangle, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { gapAnalysis } from '@/lib/planningData.js';

const GapAnalysisPanel = () => {
  return (
    <Card className="shadow-sm border-border h-full">
      <CardHeader className="pb-4 border-b border-border">
        <CardTitle className="text-xl flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-warning" />
          Gap Analysis & Risks
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 space-y-4">
        {gapAnalysis.map(gap => (
          <div 
            key={gap.id} 
            className={`p-4 rounded-xl border ${
              gap.severity === 'critical' ? 'border-destructive/30 bg-destructive/5' : 'border-warning/30 bg-warning/5'
            }`}
          >
            <div className="flex justify-between items-start mb-2">
              <h4 className="font-semibold text-foreground">{gap.vessel}</h4>
              <span className={`text-xs font-bold px-2 py-1 rounded-md ${
                gap.severity === 'critical' ? 'bg-destructive/10 text-destructive' : 'bg-warning/10 text-warning-foreground'
              }`}>
                {gap.timeframe}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">{gap.issue}</p>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" variant="outline" className="bg-background">
                Assign Available
              </Button>
              <Button size="sm" variant="outline" className="bg-background">
                Reallocate
              </Button>
            </div>
          </div>
        ))}
        
        <Button variant="ghost" className="w-full text-primary mt-2 group">
          View All Shortages
          <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
        </Button>
      </CardContent>
    </Card>
  );
};

export default GapAnalysisPanel;