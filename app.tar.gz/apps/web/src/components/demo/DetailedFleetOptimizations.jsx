import React from 'react';
import { ArrowRightLeft, Plane, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { toast } from 'sonner';

const DetailedFleetOptimizations = () => {
  const handleApply = (type) => {
    toast.success(`${type} optimization applied successfully.`);
  };

  return (
    <div className="space-y-6 mt-8">
      <h2 className="text-xl font-bold tracking-tight">Detailed Fleet Optimizations</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Crew Swaps */}
        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4" /> Suggested Crew Swaps
          </h3>
          <div className="space-y-3">
            <div className="p-3 border border-border rounded-xl bg-muted/20 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <p className="text-sm font-medium">Alpha Team <span className="text-muted-foreground mx-1">→</span> Gamma Team</p>
                <p className="text-xs text-muted-foreground mt-1">Rotterdam to Houston swap</p>
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <span className="text-sm font-bold text-[hsl(var(--tertiary))]">+$1.8k ROI</span>
                <Button size="sm" onClick={() => handleApply('Crew Swap')} className="flex-1 sm:flex-none">Apply</Button>
              </div>
            </div>
            <div className="p-3 border border-border rounded-xl bg-muted/20 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <p className="text-sm font-medium">Capt. Miller <span className="text-muted-foreground mx-1">→</span> Capt. Davis</p>
                <p className="text-xs text-muted-foreground mt-1">Aligns with rest compliance</p>
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <span className="text-sm font-bold text-[hsl(var(--tertiary))]">Risk -12%</span>
                <Button size="sm" onClick={() => handleApply('Crew Swap')} className="flex-1 sm:flex-none">Apply</Button>
              </div>
            </div>
          </div>
        </div>

        {/* Travel Logic */}
        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
          <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2">
            <Plane className="w-4 h-4" /> Travel Logic Refinement
          </h3>
          <div className="space-y-3">
            <div className="p-3 border border-border rounded-xl bg-muted/20 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <p className="text-sm font-medium">LH432 (Prem. Eco) <span className="text-muted-foreground mx-1">→</span> EK201 (Biz Promo)</p>
                <p className="text-xs text-muted-foreground mt-1">Better rest quality, lower cost</p>
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <span className="text-sm font-bold text-[hsl(var(--tertiary))]">-$400</span>
                <Button size="sm" onClick={() => handleApply('Travel Refinement')} className="flex-1 sm:flex-none">Apply</Button>
              </div>
            </div>
            <div className="p-3 border border-border rounded-xl bg-muted/20 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <p className="text-sm font-medium">Direct Flight <span className="text-muted-foreground mx-1">→</span> 1-Stop via DXB</p>
                <p className="text-xs text-muted-foreground mt-1">Avoids weather delay in FRA</p>
              </div>
              <div className="flex items-center gap-3 w-full sm:w-auto">
                <span className="text-sm font-bold text-[hsl(var(--tertiary))]">Time -4h</span>
                <Button size="sm" onClick={() => handleApply('Travel Refinement')} className="flex-1 sm:flex-none">Apply</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailedFleetOptimizations;