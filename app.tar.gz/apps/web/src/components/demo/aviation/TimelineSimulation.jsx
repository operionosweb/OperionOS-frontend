import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { Slider } from '@/components/ui/slider.jsx';

const TimelineSimulation = () => {
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCurrentTime(prev => {
        if (prev >= 720) {
          setIsPlaying(false);
          return 720;
        }
        return prev + speed;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [isPlaying, speed]);

  const handleReset = () => {
    setCurrentTime(0);
    setIsPlaying(false);
  };

  const formatTime = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900">Timeline Simulation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-600">Current Time:</div>
          <div className="text-2xl font-bold text-gray-900 font-mono">{formatTime(currentTime)}</div>
        </div>
        
        <Slider
          value={[currentTime]}
          onValueChange={(val) => setCurrentTime(val[0])}
          max={720}
          step={1}
          className="w-full"
        />
        
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            <Button size="sm" onClick={() => setIsPlaying(!isPlaying)}>
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button size="sm" variant="outline" onClick={handleReset}>
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="flex gap-2">
            {[1, 2, 4].map(s => (
              <button
                key={s}
                onClick={() => setSpeed(s)}
                className={`px-3 py-1 text-xs rounded-md ${speed === s ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TimelineSimulation;