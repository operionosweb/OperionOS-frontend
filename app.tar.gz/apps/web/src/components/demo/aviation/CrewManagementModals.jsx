import React, { useState, useEffect } from 'react';
import { Users, Calendar, ShieldAlert, Activity, Clock, FileCheck } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const CrewProfileModal = ({ isOpen, onClose, crewMember, onSave }) => {
  const [formData, setFormData] = useState(crewMember || {});
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');

  useEffect(() => {
    if (crewMember) {
      setFormData(crewMember);
      setActiveTab('profile');
    }
  }, [crewMember]);

  if (!crewMember) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    toast.success(successMessage);
    setIsLoading(false);
  };

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    onSave(formData);
    toast.success(`Crew profile for ${formData.name} updated`);
    setIsLoading(false);
    onClose();
  };

  const footerActions = (
    <>
      <Button variant="outline" onClick={() => handleAction('rest', 'Crew member assigned to mandatory rest', { status: 'Rest', fatigueRisk: 0 })}>
        Assign Rest
      </Button>
      <Button variant="outline" onClick={() => toast.info('Schedule view opened')}>
        View Schedule
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={handleSave} disabled={isLoading}>Save Profile</Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title={`Crew Profile: ${formData.name}`}
      icon={Users}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-4xl"
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col gap-4">
        {/* Scrollable Tabs for Mobile */}
        <div className="w-full overflow-x-auto scrollable-x hide-scrollbar pb-1 border-b border-border">
          <TabsList className="flex w-max min-w-full justify-start h-auto p-0 bg-transparent gap-2 sm:gap-6">
            <TabsTrigger 
              value="profile" 
              className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-2 pb-2 pt-1 whitespace-nowrap"
            >
              Profile & Status
            </TabsTrigger>
            <TabsTrigger 
              value="compliance" 
              className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-2 pb-2 pt-1 whitespace-nowrap"
            >
              Compliance & Fatigue
            </TabsTrigger>
            <TabsTrigger 
              value="history" 
              className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-2 pb-2 pt-1 whitespace-nowrap"
            >
              Duty History
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="profile" className="m-0 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={formData.name || ''} onChange={(e) => handleChange('name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Role</Label>
                <Select value={formData.role} onValueChange={(v) => handleChange('role', v)}>
                  <SelectTrigger><SelectValue placeholder="Select role" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Captain">Captain</SelectItem>
                    <SelectItem value="First Officer">First Officer</SelectItem>
                    <SelectItem value="Purser">Purser</SelectItem>
                    <SelectItem value="Flight Attendant">Flight Attendant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Current Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="On-Duty">On-Duty</SelectItem>
                    <SelectItem value="Off-Duty">Off-Duty</SelectItem>
                    <SelectItem value="Rest">Rest</SelectItem>
                    <SelectItem value="Standby">Standby</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Current Location</Label>
                <Input value={formData.location || ''} onChange={(e) => handleChange('location', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Next Available</Label>
                <Input type="datetime-local" value={formData.nextAvailable ? new Date(formData.nextAvailable).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('nextAvailable', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Current Assignment</Label>
                <div className="flex gap-2">
                  <Select defaultValue="none">
                    <SelectTrigger><SelectValue placeholder="Select flight" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Active Assignment</SelectItem>
                      <SelectItem value="OP102">OP102 (LHR-JFK)</SelectItem>
                      <SelectItem value="OP405">OP405 (CDG-DXB)</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="secondary" onClick={() => handleAction('assign', 'Assigned to new flight')}>Assign</Button>
                </div>
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label>Profile Notes</Label>
              <Textarea 
                placeholder="Add notes regarding performance, preferences, or restrictions..." 
                value={formData.notes || ''} 
                onChange={(e) => handleChange('notes', e.target.value)}
                className="min-h-[80px]"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="compliance" className="m-0 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 border border-border rounded-xl bg-muted/10 space-y-6">
              <h4 className="font-semibold flex items-center gap-2"><Activity className="w-4 h-4 text-primary" /> Fatigue & Duty Tracking</h4>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <Label>Duty Hours (Current / Max)</Label>
                  <span className="font-medium">{formData.dutyHours || 0} / {formData.maxDuty || 14}h</span>
                </div>
                <div className="flex gap-2 items-center">
                  <Progress value={((formData.dutyHours || 0) / (formData.maxDuty || 14)) * 100} className="h-2 flex-1" />
                  <Button size="sm" variant="outline" onClick={() => handleAction('updateDuty', 'Duty hours updated')}>Update</Button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <Label>Fatigue Risk Level</Label>
                  <span className={`font-medium ${formData.fatigueRisk > 80 ? 'text-red-500' : formData.fatigueRisk > 50 ? 'text-yellow-500' : 'text-green-500'}`}>
                    {formData.fatigueRisk || 0}%
                  </span>
                </div>
                <Progress 
                  value={formData.fatigueRisk || 0} 
                  className="h-2" 
                  indicatorClassName={formData.fatigueRisk > 80 ? 'bg-red-500' : formData.fatigueRisk > 50 ? 'bg-yellow-500' : 'bg-green-500'} 
                />
              </div>
            </div>

            <div className="p-5 border border-border rounded-xl bg-muted/10 space-y-4">
              <h4 className="font-semibold flex items-center gap-2"><FileCheck className="w-4 h-4 text-primary" /> Certifications & Medical</h4>
              
              <div className="space-y-3">
                {[
                  { name: 'Medical Class 1', expiry: '2026-10-15', status: 'Valid' },
                  { name: 'Type Rating (A350)', expiry: '2026-08-22', status: 'Valid' },
                  { name: 'Line Check', expiry: '2026-04-10', status: 'Expiring Soon' },
                  { name: 'Dangerous Goods', expiry: '2027-01-05', status: 'Valid' }
                ].map((cert, i) => (
                  <div key={i} className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                    <div>
                      <p className="text-sm font-medium">{cert.name}</p>
                      <p className="text-xs text-muted-foreground">Expires: {cert.expiry}</p>
                    </div>
                    <Badge variant={cert.status === 'Valid' ? 'outline' : 'destructive'} className={cert.status === 'Valid' ? 'bg-green-50 text-green-700 border-green-200' : ''}>
                      {cert.status}
                    </Badge>
                  </div>
                ))}
              </div>
              <Button className="w-full" variant="secondary" onClick={() => handleAction('extend', 'Certification extension requested')}>
                Request Extension / Renewal
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history" className="m-0 space-y-4">
          <div className="relative border-l-2 border-muted ml-3 space-y-6 pb-4">
            {[
              { time: 'Yesterday', event: 'Completed OP102 (LHR-JFK)', duration: '7h 45m' },
              { time: '3 days ago', event: 'Completed OP405 (CDG-DXB)', duration: '6h 20m' },
              { time: '5 days ago', event: 'Mandatory Rest Period', duration: '48h' },
              { time: '1 week ago', event: 'Simulator Training (A350)', duration: '4h 00m' }
            ].map((item, i) => (
              <div key={i} className="relative pl-6">
                <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-background border-2 border-primary"></div>
                <p className="text-sm font-medium text-foreground">{item.event}</p>
                <p className="text-xs text-muted-foreground">{item.time} • Duration: {item.duration}</p>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </ModalBase>
  );
};