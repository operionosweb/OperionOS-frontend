import React, { useState, useMemo } from 'react';
import { useAviationFleet } from '@/contexts/AviationFleetContext.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Button } from '@/components/ui/button.jsx';
import { FileText, Edit2, Save, X, Search, Upload, Sparkles } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters.js';
import { calculateMonthsRemaining, generateContracts } from '@/lib/aviationFleetIntelligenceData.js';
import AviationContractDetailModal from './AviationContractDetailModal.jsx';
import AviationFleetDetailModal from './AviationFleetDetailModal.jsx';

const AviationContractsSection = () => {
  const { contracts, aircraft, updateContract, addContract } = useAviationFleet();
  const [searchQuery, setSearchQuery] = useState('');
  const [lessorFilter, setLessorFilter] = useState('All');
  const [riskFilter, setRiskFilter] = useState('All');
  
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  
  const [selectedContract, setSelectedContract] = useState(null);
  const [selectedAircraft, setSelectedAircraft] = useState(null);

  const lessors = useMemo(() => [...new Set(contracts.map(c => c.lessor))], [contracts]);

  const filteredContracts = useMemo(() => {
    return contracts.filter(c => {
      const matchesSearch = c.contractId.toLowerCase().includes(searchQuery.toLowerCase()) || c.aircraftId.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesLessor = lessorFilter === 'All' || c.lessor === lessorFilter;
      const matchesRisk = riskFilter === 'All' || c.riskLevel === riskFilter;
      return matchesSearch && matchesLessor && matchesRisk;
    });
  }, [contracts, searchQuery, lessorFilter, riskFilter]);

  const handleEditClick = (e, c) => {
    e.stopPropagation();
    setEditingId(c.contractId);
    setEditForm({ monthlyPayment: c.monthlyPayment, penaltyClause: c.penaltyClause });
  };

  const handleSaveEdit = (e, id) => {
    e.stopPropagation();
    updateContract(id, {
      monthlyPayment: Number(editForm.monthlyPayment),
      penaltyClause: Number(editForm.penaltyClause)
    });
    setEditingId(null);
  };

  const handleCancelEdit = (e) => {
    e.stopPropagation();
    setEditingId(null);
  };

  const getRiskColor = (risk) => {
    if (risk === 'High') return 'bg-destructive/10 text-destructive border-destructive/20';
    if (risk === 'Medium') return 'bg-warning/10 text-warning border-warning/20';
    return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
  };

  const getExpiryAlert = (endDate) => {
    const months = calculateMonthsRemaining(endDate);
    if (months < 6) return <div className="w-2 h-2 rounded-full bg-destructive animate-pulse" title="Expires < 6 months" />;
    if (months < 12) return <div className="w-2 h-2 rounded-full bg-warning" title="Expires < 12 months" />;
    return null;
  };

  const handleMockUpload = () => {
    // Generate a mock contract for a random aircraft
    const randomAircraft = aircraft[Math.floor(Math.random() * aircraft.length)];
    const newContracts = generateContracts([randomAircraft]);
    if (newContracts.length > 0) {
      const newContract = newContracts[0];
      newContract.contractId = `CNT-NEW-${Math.floor(Math.random() * 1000)}`;
      addContract(newContract);
    }
  };

  const handleViewAircraft = (aircraftId) => {
    const ac = aircraft.find(a => a.aircraftId === aircraftId);
    setSelectedContract(null);
    if (ac) setSelectedAircraft(ac);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Contract Intelligence</h2>
          <p className="text-muted-foreground text-sm">AI-extracted terms and risk analysis for {contracts.length} active leases.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search ID..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-9 text-sm"
            />
          </div>
          <Select value={lessorFilter} onValueChange={setLessorFilter}>
            <SelectTrigger className="w-[130px] h-9 text-sm">
              <SelectValue placeholder="Lessor" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Lessors</SelectItem>
              {lessors.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={riskFilter} onValueChange={setRiskFilter}>
            <SelectTrigger className="w-[120px] h-9 text-sm">
              <SelectValue placeholder="Risk Level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Risks</SelectItem>
              <SelectItem value="High">High Risk</SelectItem>
              <SelectItem value="Medium">Medium Risk</SelectItem>
              <SelectItem value="Low">Low Risk</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleMockUpload} className="h-9 text-sm bg-secondary text-secondary-foreground hover:bg-secondary/90">
            <Upload className="w-4 h-4 mr-2" /> Upload
          </Button>
        </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block bg-card border border-border rounded-xl shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="w-8"></TableHead>
              <TableHead>Contract ID</TableHead>
              <TableHead>Aircraft</TableHead>
              <TableHead>Lessor</TableHead>
              <TableHead>End Date</TableHead>
              <TableHead>Monthly Pmt</TableHead>
              <TableHead>Penalty</TableHead>
              <TableHead>Risk Level</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredContracts.map(c => (
              <TableRow key={c.contractId} className="cursor-pointer hover:bg-muted/30" onClick={() => setSelectedContract(c)}>
                <TableCell>{getExpiryAlert(c.endDate)}</TableCell>
                <TableCell className="font-bold flex items-center gap-2">
                  <FileText className="w-4 h-4 text-muted-foreground" /> {c.contractId}
                </TableCell>
                <TableCell className="text-primary font-medium">{c.aircraftId}</TableCell>
                <TableCell>{c.lessor}</TableCell>
                <TableCell>{c.endDate}</TableCell>
                <TableCell>
                  {editingId === c.contractId ? (
                    <Input 
                      type="number" 
                      value={editForm.monthlyPayment} 
                      onChange={(e) => setEditForm({...editForm, monthlyPayment: e.target.value})}
                      className="h-8 w-28 text-sm"
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <span className="font-medium">{formatCurrency(c.monthlyPayment)}</span>
                  )}
                </TableCell>
                <TableCell>
                  {editingId === c.contractId ? (
                    <Input 
                      type="number" 
                      value={editForm.penaltyClause} 
                      onChange={(e) => setEditForm({...editForm, penaltyClause: e.target.value})}
                      className="h-8 w-28 text-sm"
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <span className="text-destructive font-medium">{formatCurrency(c.penaltyClause)}</span>
                  )}
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={getRiskColor(c.riskLevel)}>{c.riskLevel}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  {editingId === c.contractId ? (
                    <div className="flex items-center justify-end gap-2">
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600" onClick={(e) => handleSaveEdit(e, c.contractId)}><Save className="w-4 h-4" /></Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={handleCancelEdit}><X className="w-4 h-4" /></Button>
                    </div>
                  ) : (
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={(e) => handleEditClick(e, c)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden grid grid-cols-1 gap-4">
        {filteredContracts.map(c => (
          <Card key={c.contractId} className="cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setSelectedContract(c)}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  {getExpiryAlert(c.endDate)}
                  <FileText className="w-4 h-4 text-primary" />
                  <span className="font-bold">{c.contractId}</span>
                </div>
                <Badge variant="outline" className={getRiskColor(c.riskLevel)}>{c.riskLevel}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                <div><span className="text-muted-foreground">Aircraft:</span> {c.aircraftId}</div>
                <div><span className="text-muted-foreground">Lessor:</span> {c.lessor}</div>
                <div><span className="text-muted-foreground">Pmt:</span> {formatCurrency(c.monthlyPayment)}</div>
                <div><span className="text-muted-foreground">Penalty:</span> <span className="text-destructive">{formatCurrency(c.penaltyClause)}</span></div>
              </div>
              <div className="text-xs text-muted-foreground flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-500" /> AI Extracted Terms Available
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <AviationContractDetailModal 
        isOpen={!!selectedContract}
        onClose={() => setSelectedContract(null)}
        contract={selectedContract}
        onUpdate={updateContract}
        onViewAircraft={handleViewAircraft}
      />

      <AviationFleetDetailModal 
        isOpen={!!selectedAircraft} 
        onClose={() => setSelectedAircraft(null)} 
        aircraft={selectedAircraft}
        onViewContract={(id) => {
          const contract = contracts.find(c => c.aircraftId === id);
          setSelectedAircraft(null);
          if (contract) setSelectedContract(contract);
        }}
      />
    </div>
  );
};

export default AviationContractsSection;