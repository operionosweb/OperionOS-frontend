import React, { useState, useEffect } from 'react';
import { Plane, Clock, Users, AlertTriangle, MapPin, FileText, History } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const FlightDetailsModal = ({ isOpen, onClose, flight, onSave }) => {
  const [formData, setFormData] = useState(flight || {});
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('details');

  useEffect(() => {
    if (flight) {
      setFormData(flight);
      setActiveTab('details');
    }
  }, [flight]);

  if (!flight) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    
    toast.success(successMessage);
    setIsLoading(false);
  };

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    onSave(formData);
    toast.success(`Flight ${formData.flightNumber} updated successfully`);
    setIsLoading(false);
    onClose();
  };

  const footerActions = (
    <>
      <Button variant="destructive" onClick={() => handleAction('cancel', 'Flight cancelled successfully', { status: 'Cancelled' })}>
        Cancel Flight
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={handleSave} disabled={isLoading}>Save Changes</Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title={`Flight Details: ${formData.flightNumber}`}
      icon={Plane}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-4xl"
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="details">Operational Details</TabsTrigger>
          <TabsTrigger value="crew">Crew & Passengers</TabsTrigger>
          <TabsTrigger value="history">Flight History</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="On-Time">On-Time</SelectItem>
                    <SelectItem value="Delayed">Delayed</SelectItem>
                    <SelectItem value="Boarding">Boarding</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Route</Label>
                <Input value={formData.route || ''} onChange={(e) => handleChange('route', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Aircraft Type</Label>
                <Input value={formData.aircraft || ''} onChange={(e) => handleChange('aircraft', e.target.value)} />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Departure Time</Label>
                <Input type="datetime-local" value={formData.departure ? new Date(formData.departure).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('departure', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Delay Minutes</Label>
                <div className="flex gap-2">
                  <Input type="number" value={formData.delayMinutes || 0} onChange={(e) => handleChange('delayMinutes', parseInt(e.target.value))} />
                  <Button variant="secondary" onClick={() => handleAction('delay', `Flight delayed by ${formData.delayMinutes} mins`, { status: 'Delayed' })}>Apply Delay</Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Gate</Label>
                <div className="flex gap-2">
                  <Input value={formData.gate || ''} onChange={(e) => handleChange('gate', e.target.value)} />
                  <Button variant="secondary" onClick={() => handleAction('gate', `Gate changed to ${formData.gate}`)}>Change Gate</Button>
                </div>
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label>Operational Notes</Label>
              <Textarea 
                placeholder="Add notes regarding weather, ATC, or technical issues..." 
                value={formData.notes || ''} 
                onChange={(e) => handleChange('notes', e.target.value)}
                className="min-h-[100px]"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="crew" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-4 border border-border rounded-xl bg-muted/20">
              <h4 className="font-semibold flex items-center gap-2 mb-4"><Users className="w-4 h-4 text-primary" /> Assigned Crew ({formData.crewAssigned || 0})</h4>
              <div className="space-y-3">
                {['Captain', 'First Officer', 'Purser', 'Flight Attendant'].map((role, i) => (
                  <div key={i} className="flex justify-between items-center p-2 bg-background rounded-lg border border-border">
                    <div>
                      <p className="text-sm font-medium">{role}</p>
                      <p className="text-xs text-muted-foreground">Assigned</p>
                    </div>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Confirmed</Badge>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-4" variant="outline" onClick={() => handleAction('reassign', 'Crew reassignment initiated')}>
                Reassign Crew
              </Button>
            </div>

            <div className="p-4 border border-border rounded-xl bg-muted/20">
              <h4 className="font-semibold flex items-center gap-2 mb-4"><Users className="w-4 h-4 text-primary" /> Passenger Manifest</h4>
              <div className="space-y-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Total Passengers</Label>
                  <p className="text-3xl font-bold">{formData.passengers || 0}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-background rounded-lg border border-border">
                    <p className="text-xs text-muted-foreground">Business Class</p>
                    <p className="text-lg font-semibold">{Math.floor((formData.passengers || 0) * 0.15)}</p>
                  </div>
                  <div className="p-3 bg-background rounded-lg border border-border">
                    <p className="text-xs text-muted-foreground">Economy Class</p>
                    <p className="text-lg font-semibold">{Math.floor((formData.passengers || 0) * 0.85)}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Badge variant="secondary">2 Wheelchair</Badge>
                  <Badge variant="secondary">1 Unaccompanied Minor</Badge>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <div className="relative border-l-2 border-muted ml-3 space-y-6 pb-4">
            {[
              { time: '10 mins ago', event: 'Status changed to Boarding', user: 'System Auto' },
              { time: '45 mins ago', event: 'Gate assigned: ' + (formData.gate || 'G12'), user: 'Ops Control' },
              { time: '2 hours ago', event: 'Crew check-in completed', user: 'Crew Portal' },
              { time: '4 hours ago', event: 'Flight plan filed', user: 'Dispatch' }
            ].map((item, i) => (
              <div key={i} className="relative pl-6">
                <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-background border-2 border-primary"></div>
                <p className="text-sm font-medium text-foreground">{item.event}</p>
                <p className="text-xs text-muted-foreground">{item.time} • {item.user}</p>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </ModalBase>
  );
};