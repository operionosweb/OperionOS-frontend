import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';

const ModalBase = ({ isOpen, onClose, title, icon: Icon, children, footerActions, isLoading, maxWidth = "max-w-4xl" }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className={`modal-container p-0 border-none ${maxWidth}`}>
        {/* 
          CRITICAL SCROLL STRUCTURE:
          The .modal-body wrapper has overflow-y-auto.
          Header, Content, and Footer are ALL inside this wrapper.
          This ensures they all scroll together naturally, with NO sticky positioning.
        */}
        <div className="modal-body">
          <DialogHeader className="modal-header">
            <DialogTitle className="flex items-center gap-2 text-lg sm:text-xl">
              {Icon && <Icon className="w-5 h-5 text-primary" />}
              {title}
            </DialogTitle>
          </DialogHeader>
          
          <div className="modal-content">
            {children}
          </div>

          {footerActions && (
            <DialogFooter className="modal-footer">
              {footerActions}
            </DialogFooter>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ModalBase;