import React, { useState } from 'react';
import { Calendar, Plane } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const AssignToFlightModal = ({ isOpen, onClose, crewMember }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleAssign = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    toast.success(`${crewMember?.name || 'Crew member'} assigned to flight successfully.`);
    setIsLoading(false);
    onClose();
  };

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title="Assign to Flight"
      icon={Plane}
      maxWidth="max-w-md"
      footerActions={
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <Button variant="outline" onClick={onClose} disabled={isLoading} className="w-full sm:w-auto">Cancel</Button>
          <Button onClick={handleAssign} disabled={isLoading} className="w-full sm:w-auto">Assign Flight</Button>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Select Flight</Label>
          <Select>
            <SelectTrigger><SelectValue placeholder="Select a flight..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="OP102">OP102 (LHR-JFK)</SelectItem>
              <SelectItem value="OP405">OP405 (CDG-DXB)</SelectItem>
              <SelectItem value="OP892">OP892 (FRA-SIN)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Role on Flight</Label>
          <Input value={crewMember?.role || 'Assigned Role'} readOnly className="bg-muted" />
        </div>
      </div>
    </ModalBase>
  );
};

export const RequestTimeOffModal = ({ isOpen, onClose, crewMember }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    toast.success(`Time off request submitted for ${crewMember?.name || 'crew member'}.`);
    setIsLoading(false);
    onClose();
  };

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title="Request Time Off"
      icon={Calendar}
      maxWidth="max-w-md"
      footerActions={
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <Button variant="outline" onClick={onClose} disabled={isLoading} className="w-full sm:w-auto">Cancel</Button>
          <Button onClick={handleSubmit} disabled={isLoading} className="w-full sm:w-auto">Submit Request</Button>
        </div>
      }
    >
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Start Date</Label>
          <Input type="date" />
        </div>
        <div className="space-y-2">
          <Label>End Date</Label>
          <Input type="date" />
        </div>
        <div className="space-y-2">
          <Label>Reason</Label>
          <Select>
            <SelectTrigger><SelectValue placeholder="Select reason..." /></SelectTrigger>
            <SelectContent>
              <SelectItem value="vacation">Annual Leave</SelectItem>
              <SelectItem value="sick">Sick Leave</SelectItem>
              <SelectItem value="personal">Personal Days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </ModalBase>
  );
};