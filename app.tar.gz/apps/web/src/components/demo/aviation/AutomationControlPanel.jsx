import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Switch } from '@/components/ui/switch.jsx';
import { Settings, Zap } from 'lucide-react';

const AutomationControlPanel = ({ automationMode, onModeChange, rules, onToggleRule }) => {
  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Automation Control
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-3 bg-blue-50 border-2 border-blue-200 rounded-lg">
          <div>
            <p className="font-semibold text-blue-900">Automation Mode</p>
            <p className="text-xs text-blue-700">Current: {automationMode}</p>
          </div>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant={automationMode === 'Manual' ? 'default' : 'outline'}
              onClick={() => onModeChange?.('Manual')}
            >
              Manual
            </Button>
            <Button 
              size="sm" 
              variant={automationMode === 'Assisted' ? 'default' : 'outline'}
              onClick={() => onModeChange?.('Assisted')}
            >
              Assisted
            </Button>
            <Button 
              size="sm" 
              variant={automationMode === 'Fully Automated' ? 'default' : 'outline'}
              onClick={() => onModeChange?.('Fully Automated')}
            >
              Automated
            </Button>
          </div>
        </div>

        {automationMode !== 'Manual' && (
          <div className="space-y-3">
            <p className="text-sm font-semibold text-gray-900">Active Rules</p>
            {rules.map((rule, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
                <div className="flex-1">
                  <p className="text-sm font-semibold text-gray-900">{rule.name}</p>
                  <p className="text-xs text-gray-600">{rule.description}</p>
                  {rule.lastTriggered && (
                    <p className="text-xs text-green-600 mt-1">
                      <Zap className="w-3 h-3 inline mr-1" />
                      Last triggered: {new Date(rule.lastTriggered).toLocaleTimeString()}
                    </p>
                  )}
                </div>
                <Switch 
                  checked={rule.enabled} 
                  onCheckedChange={() => onToggleRule?.(rule.id)}
                />
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AutomationControlPanel;