import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Users } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import StandbyCrewCard from './StandbyCrewCard.jsx';
import StandbyCrewDetailModal from './StandbyCrewDetailModal.jsx';
import CrewProfileModal from './CrewProfileModal.jsx';

const StandbyCrewPool = () => {
  const { standbyCrewPool } = useDemo();
  const [selectedCrew, setSelectedCrew] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);

  const handleCardClick = (crew) => {
    setSelectedCrew(crew);
    setDetailModalOpen(true);
  };

  const handleViewFullProfile = (crew) => {
    setDetailModalOpen(false);
    setSelectedCrew(crew);
    setProfileModalOpen(true);
  };

  const handleQuickAssign = (crewId, flightNumber) => {
    console.log(`Assigning crew ${crewId} to flight ${flightNumber}`);
  };

  return (
    <>
      <Card className="bg-white border-2 border-gray-200 shadow-md">
        <CardHeader>
          <CardTitle className="text-gray-900 flex items-center gap-2">
            <Users className="w-5 h-5" />
            Standby Crew Pool
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {standbyCrewPool && standbyCrewPool.map(crew => (
              <StandbyCrewCard 
                key={crew.id} 
                crew={crew} 
                onClick={() => handleCardClick(crew)}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      <StandbyCrewDetailModal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        crew={selectedCrew}
        onViewFullProfile={handleViewFullProfile}
        onQuickAssign={handleQuickAssign}
      />

      <CrewProfileModal
        isOpen={profileModalOpen}
        onClose={() => setProfileModalOpen(true)}
        crew={selectedCrew}
      />
    </>
  );
};

export default StandbyCrewPool;