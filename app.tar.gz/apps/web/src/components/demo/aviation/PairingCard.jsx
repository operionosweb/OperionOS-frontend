import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Users, TrendingUp, DollarSign, AlertTriangle } from 'lucide-react';

const PairingCard = ({ pairing, onClick }) => {
  const getEfficiencyColor = (efficiency) => {
    if (efficiency >= 85) return 'text-green-600';
    if (efficiency >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'Low': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'High': return 'bg-red-500/10 text-red-700 border-red-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  return (
    <Card 
      onClick={onClick}
      className="bg-white border-2 border-gray-200 shadow-md hover:shadow-xl hover:-translate-y-1 hover:border-blue-400 cursor-pointer transition-all duration-200 active:scale-[0.98]"
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-gray-600">AI Pairing Suggestion</p>
              <p className="font-bold text-gray-900">{pairing.flight.flightNumber}</p>
            </div>
          </div>
          <Badge className={`${getRiskColor(pairing.riskFactors)} border-2 font-semibold`}>
            {pairing.riskFactors} Risk
          </Badge>
        </div>

        <div className="space-y-3">
          <div className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-gray-600">Crew Member 1</span>
              <Badge className="bg-blue-500/10 text-blue-700 border-2 border-blue-500/30 text-xs">
                {pairing.crew1.role}
              </Badge>
            </div>
            <p className="font-semibold text-gray-900">{pairing.crew1.name}</p>
          </div>

          <div className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-gray-600">Crew Member 2</span>
              <Badge className="bg-blue-500/10 text-blue-700 border-2 border-blue-500/30 text-xs">
                {pairing.crew2.role}
              </Badge>
            </div>
            <p className="font-semibold text-gray-900">{pairing.crew2.name}</p>
          </div>

          <div className="flex items-center justify-center py-4 bg-gradient-to-r from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-lg">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                <span className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Efficiency</span>
              </div>
              <p className={`text-4xl font-bold ${getEfficiencyColor(pairing.totalEfficiency)}`}>
                {pairing.totalEfficiency}%
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-green-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-600" />
              <span className="text-sm font-semibold text-green-900">Cost Savings</span>
            </div>
            <span className="text-lg font-bold text-green-600">€{pairing.costSavings.toLocaleString()}</span>
          </div>

          <div className="text-xs text-gray-600 line-clamp-2">
            {pairing.recommendationReason}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PairingCard;