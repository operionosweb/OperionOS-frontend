import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { AlertTriangle, Plane, Users, Clock, DollarSign, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';

const DisruptionDetailPanel = ({ disruption, onAddComment }) => {
  const [comment, setComment] = useState('');
  const [liveCost, setLiveCost] = useState(disruption.estimatedCostImpact);

  useEffect(() => {
    if (disruption.status === 'active') {
      const interval = setInterval(() => {
        setLiveCost(prev => prev + Math.floor(Math.random() * 50) + 20);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [disruption.status]);

  const handleAddComment = () => {
    if (comment.trim()) {
      onAddComment?.(disruption.id, comment);
      setComment('');
      toast.success('Comment added');
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Critical': return 'bg-red-500/10 text-red-700 border-red-500/30';
      case 'High': return 'bg-orange-500/10 text-orange-700 border-orange-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'Low': return 'bg-blue-500/10 text-blue-700 border-blue-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-red-600" />
            <div>
              <p>{disruption.subtype}</p>
              <p className="text-sm font-normal text-gray-600">{disruption.airport}</p>
            </div>
          </div>
          <Badge className={`${getSeverityColor(disruption.severity)} border-2 font-semibold`}>
            {disruption.severity}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-red-50 border-2 border-red-200 rounded-lg">
          <p className="text-xs font-semibold text-red-900 uppercase tracking-wider mb-2">Root Cause Analysis</p>
          <p className="text-sm text-red-800">{disruption.rootCauseAnalysis}</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Plane className="w-4 h-4 text-gray-600" />
              <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Affected Flights</p>
            </div>
            <div className="flex flex-wrap gap-1">
              {disruption.affectedFlights.map((flight, idx) => (
                <Badge key={idx} className="bg-blue-500/10 text-blue-700 border-2 border-blue-500/30 text-xs">
                  {flight}
                </Badge>
              ))}
            </div>
          </div>

          <div className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-4 h-4 text-gray-600" />
              <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Affected Crew</p>
            </div>
            <div className="flex flex-wrap gap-1">
              {disruption.affectedCrew.slice(0, 4).map((crew, idx) => (
                <Badge key={idx} className="bg-cyan-500/10 text-cyan-700 border-2 border-cyan-500/30 text-xs">
                  {crew}
                </Badge>
              ))}
              {disruption.affectedCrew.length > 4 && (
                <Badge className="bg-gray-500/10 text-gray-700 border-2 border-gray-500/30 text-xs">
                  +{disruption.affectedCrew.length - 4} more
                </Badge>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg text-center">
            <Clock className="w-5 h-5 text-gray-600 mx-auto mb-1" />
            <p className="text-xs text-gray-600">Time Impact</p>
            <p className="text-lg font-bold text-gray-900">{disruption.timeImpactMinutes}min</p>
          </div>

          <div className="p-3 bg-red-50 border-2 border-red-200 rounded-lg text-center">
            <DollarSign className="w-5 h-5 text-red-600 mx-auto mb-1" />
            <p className="text-xs text-red-600">Live Cost Impact</p>
            <p className="text-lg font-bold text-red-600">€{liveCost.toLocaleString()}</p>
          </div>

          <div className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg text-center">
            <p className="text-xs text-gray-600">Impact Scope</p>
            <p className="text-sm font-bold text-gray-900 capitalize">{disruption.impactScope.replace('-', ' ')}</p>
          </div>
        </div>

        <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
          <p className="text-xs font-semibold text-blue-900 uppercase tracking-wider mb-2">Timeline</p>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-blue-700">Detected:</span>
              <span className="font-semibold text-blue-900">{new Date(disruption.detectedAt).toLocaleTimeString()}</span>
            </div>
            {disruption.escalatedAt && (
              <div className="flex justify-between">
                <span className="text-blue-700">Escalated:</span>
                <span className="font-semibold text-blue-900">{new Date(disruption.escalatedAt).toLocaleTimeString()}</span>
              </div>
            )}
            {disruption.resolvedAt && (
              <div className="flex justify-between">
                <span className="text-blue-700">Resolved:</span>
                <span className="font-semibold text-blue-900">{new Date(disruption.resolvedAt).toLocaleTimeString()}</span>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-gray-600" />
            <p className="text-sm font-semibold text-gray-900">Decision Comments</p>
          </div>
          <Textarea 
            placeholder="Add decision comment or notes..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="min-h-[80px]"
          />
          <Button size="sm" onClick={handleAddComment}>Add Comment</Button>
          
          {disruption.comments && disruption.comments.length > 0 && (
            <div className="space-y-2 mt-3">
              {disruption.comments.map((c) => (
                <div key={c.id} className="p-2 bg-gray-50 border-2 border-gray-200 rounded text-xs">
                  <p className="font-semibold text-gray-900">{c.user}</p>
                  <p className="text-gray-700">{c.text}</p>
                  <p className="text-gray-500 text-xs mt-1">{new Date(c.timestamp).toLocaleString()}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default DisruptionDetailPanel;