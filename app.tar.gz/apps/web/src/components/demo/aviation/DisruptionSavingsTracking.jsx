import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Search, Filter } from 'lucide-react';
import { useAviationROISavings } from '@/contexts/AviationROISavingsContext.jsx';

const DisruptionSavingsTracking = () => {
  const { disruptions, isLoading } = useAviationROISavings();
  const [searchTerm, setSearchTerm] = useState('');

  if (isLoading) return <Card className="h-[400px] animate-pulse bg-muted/20" />;

  const filtered = disruptions.filter(d => 
    d.flight.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.type.toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, 8);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-4">
        <CardTitle className="text-lg">Disruption Savings Log</CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative w-48">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input 
              placeholder="Search flight or type..." 
              className="pl-8 h-9 text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Badge variant="outline" className="h-9 px-3 cursor-pointer hover:bg-muted">
            <Filter className="w-4 h-4 mr-2" /> Filter
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Flight</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>AI Action</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Savings (€)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.map((d) => (
              <TableRow key={d.id} className="cursor-pointer hover:bg-muted/50">
                <TableCell className="font-medium">{d.flight}</TableCell>
                <TableCell>{d.type}</TableCell>
                <TableCell className="text-muted-foreground max-w-[200px] truncate" title={d.aiSolution}>
                  {d.aiSolution}
                </TableCell>
                <TableCell>
                  <Badge variant={d.status === 'Prevented' ? 'default' : 'secondary'} className={d.status === 'Prevented' ? 'bg-green-100 text-green-800 hover:bg-green-200' : ''}>
                    {d.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right font-semibold text-green-600">
                  +€{d.savings.toLocaleString()}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default DisruptionSavingsTracking;