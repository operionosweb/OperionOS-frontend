import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Sparkles, ArrowRight, Zap } from 'lucide-react';
import { useAviationROISavings } from '@/contexts/AviationROISavingsContext.jsx';

const AISavingsEngine = () => {
  const { insights, applyOptimization, simulateSavings, isLoading } = useAviationROISavings();

  if (isLoading) return null;

  const pendingInsights = insights.filter(i => i.status === 'Pending').slice(0, 4);

  return (
    <Card className="border-primary/20 shadow-md">
      <CardHeader className="bg-primary/5 pb-4 border-b border-primary/10">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-primary/20 rounded-lg">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <CardTitle className="text-lg">AI Savings Engine</CardTitle>
            <CardDescription>Proactive optimization recommendations</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-border">
          {pendingInsights.map((insight) => (
            <div key={insight.id} className="p-4 hover:bg-muted/30 transition-colors">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="text-xs font-normal bg-background">
                      {insight.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">Est. {insight.timeToImplement} days to implement</span>
                  </div>
                  <h4 className="font-medium text-foreground">{insight.title}</h4>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-green-600">+€{(insight.estimatedSavings / 1000).toFixed(0)}k</div>
                  <div className="text-xs text-muted-foreground">Potential Savings</div>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button size="sm" onClick={() => applyOptimization(insight.id)} className="w-full sm:w-auto">
                  <Zap className="w-4 h-4 mr-2" /> Apply Now
                </Button>
                <Button size="sm" variant="outline" onClick={() => simulateSavings(insight.id)} className="w-full sm:w-auto">
                  Simulate
                </Button>
              </div>
            </div>
          ))}
        </div>
        <div className="p-4 border-t border-border bg-muted/10 text-center">
          <Button variant="ghost" className="text-primary hover:text-primary/80 w-full">
            View All {insights.length} Recommendations <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AISavingsEngine;