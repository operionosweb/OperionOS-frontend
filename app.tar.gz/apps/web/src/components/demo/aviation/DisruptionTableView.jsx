import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const DisruptionTableView = ({ disruptions, onSelectDisruption }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const totalPages = Math.ceil(disruptions.length / itemsPerPage);
  
  const paginatedDisruptions = disruptions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Critical': return 'bg-red-500/10 text-red-700 border-red-500/30';
      case 'High': return 'bg-orange-500/10 text-orange-700 border-orange-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'Low': return 'bg-blue-500/10 text-blue-700 border-blue-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900">Disruptions Table View</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="border-gray-300">
              <TableHead className="text-gray-700">Type</TableHead>
              <TableHead className="text-gray-700">Severity</TableHead>
              <TableHead className="text-gray-700">Flights</TableHead>
              <TableHead className="text-gray-700">Crew</TableHead>
              <TableHead className="text-gray-700">Time Impact</TableHead>
              <TableHead className="text-gray-700">Cost Impact</TableHead>
              <TableHead className="text-gray-700">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedDisruptions.map(disruption => (
              <TableRow 
                key={disruption.id} 
                className="border-gray-200 hover:bg-blue-50 cursor-pointer"
                onClick={() => onSelectDisruption?.(disruption)}
              >
                <TableCell className="font-medium text-gray-900">{disruption.subtype}</TableCell>
                <TableCell>
                  <Badge className={`${getSeverityColor(disruption.severity)} border-2 font-semibold`}>
                    {disruption.severity}
                  </Badge>
                </TableCell>
                <TableCell className="text-gray-700">{disruption.affectedFlights.length}</TableCell>
                <TableCell className="text-gray-700">{disruption.affectedCrew.length}</TableCell>
                <TableCell className="text-gray-700">{disruption.timeImpactMinutes}min</TableCell>
                <TableCell className="font-mono text-red-600">€{disruption.estimatedCostImpact.toLocaleString()}</TableCell>
                <TableCell>
                  <Badge className={`${
                    disruption.status === 'active' ? 'bg-orange-500/10 text-orange-700 border-orange-500/30' : 'bg-green-500/10 text-green-700 border-green-500/30'
                  } border-2`}>
                    {disruption.status}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        
        <div className="flex items-center justify-between mt-4">
          <p className="text-sm text-gray-600">
            Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, disruptions.length)} of {disruptions.length}
          </p>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DisruptionTableView;