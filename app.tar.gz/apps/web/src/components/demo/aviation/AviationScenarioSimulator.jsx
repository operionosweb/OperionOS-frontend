import React, { useState, useEffect, useMemo } from 'react';
import { useAviationFleet } from '@/contexts/AviationFleetContext.jsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Checkbox } from '@/components/ui/checkbox.jsx';
import { Calculator, Save, RotateCcw, ArrowRight, AlertTriangle, TrendingDown, TrendingUp, Layers, CheckSquare } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters.js';
import { toast } from 'sonner';

const AviationScenarioSimulator = ({ initialAircraftId }) => {
  const { aircraft } = useAviationFleet();
  
  const [selectedIds, setSelectedIds] = useState(initialAircraftId ? [initialAircraftId] : [aircraft[0]?.aircraftId]);
  const [scenarioTemplate, setScenarioTemplate] = useState('Custom'); // Optimize fleet, Reduce cost, Minimize risk
  const [scenarioAction, setScenarioAction] = useState('Extend Lease');
  
  const [inputs, setInputs] = useState({
    discountPercent: 10,
    maintenanceIncreasePercent: 5,
    duration: 24,
    penaltyNegotiationPercent: 80
  });

  const selectedAircraftList = useMemo(() => aircraft.filter(a => selectedIds.includes(a.aircraftId)), [aircraft, selectedIds]);

  const applyTemplate = (template) => {
    setScenarioTemplate(template);
    if (template === 'Optimize fleet') {
      const underutilized = aircraft.filter(a => a.alerts.underutilized).map(a => a.aircraftId);
      setSelectedIds(underutilized.length > 0 ? underutilized : selectedIds);
      setScenarioAction('Return Aircraft');
      setInputs({ ...inputs, penaltyNegotiationPercent: 50 });
    } else if (template === 'Reduce cost') {
      const highCost = aircraft.filter(a => a.alerts.high_cost).map(a => a.aircraftId);
      setSelectedIds(highCost.length > 0 ? highCost : selectedIds);
      setScenarioAction('Extend Lease');
      setInputs({ ...inputs, discountPercent: 20, duration: 60 });
    } else if (template === 'Minimize risk') {
      const highRisk = aircraft.filter(a => a.scenario === 'high-risk').map(a => a.aircraftId);
      setSelectedIds(highRisk.length > 0 ? highRisk : selectedIds);
      setScenarioAction('Return Aircraft');
    }
  };

  const handleSliderChange = (name, value) => {
    setInputs(prev => ({ ...prev, [name]: value[0] }));
  };

  const toggleAircraft = (id) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const metrics = useMemo(() => {
    if (selectedAircraftList.length === 0) return null;

    let currentMonthly = 0;
    let currentTotal = 0;
    let newMonthly = 0;
    let oneTimeCost = 0;
    let newTotal = 0;

    selectedAircraftList.forEach(ac => {
      const baseMonthly = ac.totalMonthlyCost;
      currentMonthly += baseMonthly;
      currentTotal += baseMonthly * inputs.duration;

      if (scenarioAction === 'Extend Lease') {
        const discountedLease = ac.monthlyCost * (1 - inputs.discountPercent / 100);
        const increasedMaint = ac.maintenanceCost * (1 + inputs.maintenanceIncreasePercent / 100);
        newMonthly += (discountedLease + increasedMaint);
        newTotal += (discountedLease + increasedMaint) * inputs.duration;
      } else if (scenarioAction === 'Return Aircraft') {
        // penalty applied
        const assumedPenalty = 500000; // Mock base penalty per aircraft for aggregate
        oneTimeCost += assumedPenalty * (inputs.penaltyNegotiationPercent / 100);
      } else if (scenarioAction === 'Replace Aircraft') {
        newMonthly += ac.monthlyCost * 1.1 + ac.maintenanceCost * 0.8;
        newTotal += newMonthly * inputs.duration;
      }
    });

    if (scenarioAction === 'Return Aircraft') {
      newTotal = oneTimeCost; // Total cost is just the penalty
    } else if (scenarioAction === 'Replace Aircraft') {
      newTotal += oneTimeCost; // Add any transition costs
    }

    return {
      currentMonthly,
      currentTotal,
      newMonthly,
      oneTimeCost,
      newTotal,
      savings: currentTotal - newTotal
    };
  }, [selectedAircraftList, scenarioAction, inputs]);

  const handleSaveScenario = () => {
    if (selectedIds.length === 0) return toast.error('Select at least one aircraft.');
    const scenario = {
      id: Date.now(),
      aircraftIds: selectedIds,
      action: scenarioAction,
      inputs,
      metrics,
      timestamp: new Date().toISOString()
    };
    const saved = JSON.parse(localStorage.getItem('operion_scenarios') || '[]');
    localStorage.setItem('operion_scenarios', JSON.stringify([scenario, ...saved]));
    toast.success('Scenario saved successfully.');
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Advanced Scenario Simulator</h2>
          <p className="text-muted-foreground text-sm">Model multi-aircraft strategies and fleet optimizations.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setSelectedIds([])}><RotateCcw className="w-4 h-4 mr-2" /> Clear All</Button>
          <Button onClick={handleSaveScenario} className="bg-primary text-primary-foreground"><Save className="w-4 h-4 mr-2" /> Save Scenario</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Selection & Templates */}
        <div className="lg:col-span-4 space-y-6">
          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4 border-b border-border/50">
              <CardTitle className="text-lg">Pre-built Strategies</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-2">
              <Button variant={scenarioTemplate === 'Optimize fleet' ? 'default' : 'outline'} className="w-full justify-start" onClick={() => applyTemplate('Optimize fleet')}>
                <Layers className="w-4 h-4 mr-2" /> Optimize Underutilized Fleet
              </Button>
              <Button variant={scenarioTemplate === 'Reduce cost' ? 'default' : 'outline'} className="w-full justify-start" onClick={() => applyTemplate('Reduce cost')}>
                <TrendingDown className="w-4 h-4 mr-2" /> Cost Reduction Drive
              </Button>
              <Button variant={scenarioTemplate === 'Minimize risk' ? 'default' : 'outline'} className="w-full justify-start" onClick={() => applyTemplate('Minimize risk')}>
                <AlertTriangle className="w-4 h-4 mr-2" /> High-Risk Mitigation
              </Button>
            </CardContent>
          </Card>

          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4 border-b border-border/50 flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Target Aircraft ({selectedIds.length})</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setSelectedIds(aircraft.map(a => a.aircraftId))}>
                <CheckSquare className="w-4 h-4" />
              </Button>
            </CardHeader>
            <CardContent className="pt-4 max-h-[300px] overflow-y-auto space-y-1 pr-2 custom-scrollbar">
              {aircraft.map(a => (
                <div key={a.aircraftId} className="flex items-center space-x-2 p-2 hover:bg-muted/50 rounded-md">
                  <Checkbox id={`ac-${a.aircraftId}`} checked={selectedIds.includes(a.aircraftId)} onCheckedChange={() => toggleAircraft(a.aircraftId)} />
                  <label htmlFor={`ac-${a.aircraftId}`} className="text-sm font-medium leading-none cursor-pointer flex-1 flex justify-between">
                    <span>{a.aircraftId}</span>
                    <span className="text-muted-foreground text-xs">{a.aircraftType}</span>
                  </label>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Parameters & Results */}
        <div className="lg:col-span-8 space-y-6">
          <Card className="border-border shadow-sm">
            <CardHeader className="pb-4 border-b border-border/50">
              <CardTitle className="text-lg flex items-center gap-2"><Calculator className="w-5 h-5 text-primary" /> Parameters</CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Action</label>
                  <Select value={scenarioAction} onValueChange={setScenarioAction}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Extend Lease">Extend Lease</SelectItem>
                      <SelectItem value="Return Aircraft">Return Aircraft (Early)</SelectItem>
                      <SelectItem value="Replace Aircraft">Replace Aircraft</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-3 pt-1">
                  <div className="flex justify-between">
                    <label className="text-sm font-medium">Evaluation Period</label>
                    <span className="text-sm font-bold text-primary">{inputs.duration} months</span>
                  </div>
                  <Slider min={6} max={120} step={6} value={[inputs.duration]} onValueChange={(v) => handleSliderChange('duration', v)} />
                </div>

                {scenarioAction === 'Extend Lease' && (
                  <>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <label className="text-sm font-medium">Target Lease Discount</label>
                        <span className="text-sm font-bold text-emerald-600">-{inputs.discountPercent}%</span>
                      </div>
                      <Slider min={0} max={30} step={1} value={[inputs.discountPercent]} onValueChange={(v) => handleSliderChange('discountPercent', v)} />
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <label className="text-sm font-medium">Est. Maintenance Increase</label>
                        <span className="text-sm font-bold text-destructive">+{inputs.maintenanceIncreasePercent}%</span>
                      </div>
                      <Slider min={0} max={20} step={1} value={[inputs.maintenanceIncreasePercent]} onValueChange={(v) => handleSliderChange('maintenanceIncreasePercent', v)} />
                    </div>
                  </>
                )}

                {(scenarioAction === 'Return Aircraft' || scenarioAction === 'Replace Aircraft') && (
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <label className="text-sm font-medium">Penalty Negotiation</label>
                      <span className="text-sm font-bold text-destructive">{inputs.penaltyNegotiationPercent}% of base</span>
                    </div>
                    <Slider min={10} max={100} step={5} value={[inputs.penaltyNegotiationPercent]} onValueChange={(v) => handleSliderChange('penaltyNegotiationPercent', v)} />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {metrics && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-muted/30 border-border shadow-sm relative overflow-hidden">
                <CardHeader>
                  <CardTitle className="text-lg text-muted-foreground">Current Baseline</CardTitle>
                  <CardDescription>Status Quo over {inputs.duration} months</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-xs text-muted-foreground uppercase">Aggregated Monthly Cost</p>
                    <p className="text-2xl font-bold">{formatCurrency(metrics.currentMonthly)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground uppercase">Total Period Cost</p>
                    <p className="text-xl font-semibold">{formatCurrency(metrics.currentTotal)}</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-card border-primary/30 shadow-md relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5"><ArrowRight className="w-24 h-24" /></div>
                <CardHeader>
                  <CardTitle className="text-lg text-primary">Simulated Outcome</CardTitle>
                  <CardDescription>Impact of {scenarioAction}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 relative z-10">
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-xs text-primary/70 uppercase">New Monthly Rate</p>
                      <p className="text-2xl font-bold text-foreground">{formatCurrency(metrics.newMonthly)}</p>
                    </div>
                    {metrics.oneTimeCost > 0 && (
                      <div className="text-right">
                        <p className="text-xs text-destructive uppercase">One-Time Cost (Penalty)</p>
                        <p className="text-lg font-bold text-destructive">{formatCurrency(metrics.oneTimeCost)}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="pt-4 border-t border-border flex justify-between items-center">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase">Total Period Cost</p>
                      <p className="text-xl font-semibold">{formatCurrency(metrics.newTotal)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground uppercase mb-1">Net Savings</p>
                      <Badge variant={metrics.savings > 0 ? "default" : "destructive"} className={metrics.savings > 0 ? "bg-emerald-500 hover:bg-emerald-600" : ""}>
                        {metrics.savings > 0 ? '+' : ''}{formatCurrency(metrics.savings)}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AviationScenarioSimulator;