import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { AlertTriangle, TrendingUp } from 'lucide-react';

const PredictiveDisruptionEngine = ({ predictions, onApplyPreventive }) => {
  const getRiskColor = (score) => {
    if (score >= 80) return 'bg-red-500/10 text-red-700 border-red-500/30';
    if (score >= 60) return 'bg-orange-500/10 text-orange-700 border-orange-500/30';
    if (score >= 40) return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
    return 'bg-blue-500/10 text-blue-700 border-blue-500/30';
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Predictive Disruption Engine
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {predictions.map((prediction, idx) => (
          <div key={idx} className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-600" />
                <p className="font-semibold text-gray-900 text-sm">{prediction.description}</p>
              </div>
              <Badge className={`${getRiskColor(prediction.riskScore)} border-2 font-semibold text-xs`}>
                {prediction.riskScore}%
              </Badge>
            </div>
            <div className="space-y-1 mb-3">
              <p className="text-xs text-gray-600 font-semibold">Preventive Suggestions:</p>
              <ul className="list-disc list-inside text-xs text-gray-700 space-y-1">
                {prediction.suggestions.map((suggestion, sidx) => (
                  <li key={sidx}>{suggestion}</li>
                ))}
              </ul>
            </div>
            <div className="flex items-center justify-between">
              <div className="text-xs text-gray-600">
                Affected: {prediction.affectedFlights.length} flights, {prediction.affectedCrew.length} crew
              </div>
              <Button size="sm" variant="outline" onClick={() => onApplyPreventive?.(prediction)}>
                Apply Preventive
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default PredictiveDisruptionEngine;