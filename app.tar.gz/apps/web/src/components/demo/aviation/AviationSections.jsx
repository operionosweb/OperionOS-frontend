import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { TrendingUp, ArrowRight, DollarSign, Activity, Plane, Users, Briefcase, AlertTriangle, ShieldCheck, MessageSquare, Wrench, Bell } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';

import DisruptionManagementPanel from './DisruptionManagementPanel.jsx';
import FlightOperationsSection from './FlightOperationsSection.jsx';
import CrewManagementSection from './CrewManagementSection.jsx';
import { BookingDetailModal } from './TravelLogisticsModals.jsx';
import { FinancialDetailModal } from './FinancialControlModals.jsx';
import { NotificationDetailModal } from './NotificationsCenterModals.jsx';
import { ComplianceDetailModal } from './ComplianceSafetyModals.jsx';
import { MessageDetailModal } from './CommunicationHubModals.jsx';
import { AircraftDetailModal } from './AircraftMaintenanceModals.jsx';

import AviationFleetOverview from './AviationFleetOverview.jsx';
import AviationContractsSection from './AviationContractsSection.jsx';
import AviationFinancialDashboard from './AviationFinancialDashboard.jsx';
import AviationScenarioSimulator from './AviationScenarioSimulator.jsx';

export const MissionControlDashboard = () => {
  return (
    <div className="p-3 sm:p-4 md:p-6 animate-in fade-in w-full">
      <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">Mission Control</h2>
      <p className="text-sm sm:text-base text-slate-600 mb-6 sm:mb-8">Overview dashboard is currently focused on Disruption Management.</p>
      <DisruptionManagementPanel />
    </div>
  );
};

export { 
  FlightOperationsSection, 
  CrewManagementSection,
  AviationFleetOverview,
  AviationContractsSection,
  AviationFinancialDashboard,
  AviationScenarioSimulator
};

export const DisruptionManagementSection = () => <DisruptionManagementPanel />;

export const CrewTravelLogisticsSection = () => {
  const { travelBookings, updateBooking } = useDemo();
  const [selectedBooking, setSelectedBooking] = useState(null);

  return (
    <div className="p-3 sm:p-4 md:p-6 animate-in fade-in space-y-4 sm:space-y-6 w-full">
      <h2 className="text-xl sm:text-2xl font-bold">Crew Movements & Logistics</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6">
        {travelBookings.slice(0, 12).map(booking => (
          <Card key={booking.id} className="cursor-pointer hover:shadow-md hover:-translate-y-1 transition-all border-border w-full h-auto" onClick={() => setSelectedBooking(booking)}>
            <CardContent className="p-4 sm:p-5 md:p-6">
              <div className="flex justify-between items-start mb-2 gap-2">
                <h3 className="font-bold text-sm sm:text-base break-words">{booking.crewName}</h3>
                <Badge variant={booking.status === 'Confirmed' ? 'default' : 'secondary'} className="shrink-0 text-[10px] sm:text-xs">{booking.status}</Badge>
              </div>
              <p className="text-xs sm:text-sm text-muted-foreground mb-2 break-words">{booking.hotel} - {booking.destination}</p>
              <div className="flex justify-between text-xs sm:text-sm font-medium">
                <span>{new Date(booking.checkIn).toLocaleDateString()}</span>
                <span>€{booking.cost}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      <BookingDetailModal isOpen={!!selectedBooking} onClose={() => setSelectedBooking(null)} booking={selectedBooking} onSave={updateBooking} />
    </div>
  );
};

export const FinancialControlSection = () => {
  const { financials, updateFinancial } = useDemo();
  const [selectedFinancial, setSelectedFinancial] = useState(null);

  return (
    <div className="p-3 sm:p-4 md:p-6 animate-in fade-in space-y-4 sm:space-y-6 w-full">
      <h2 className="text-xl sm:text-2xl font-bold">Financial Control</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-5 md:gap-6 mb-4 sm:mb-6">
        <Card className="w-full h-auto"><CardHeader className="p-4 sm:p-5"><CardTitle className="text-xs sm:text-sm">Daily Burn Rate</CardTitle></CardHeader><CardContent className="p-4 sm:p-5 pt-0"><div className="text-xl sm:text-2xl font-bold">€1.2M</div></CardContent></Card>
        <Card className="w-full h-auto"><CardHeader className="p-4 sm:p-5"><CardTitle className="text-xs sm:text-sm">Budget Variance</CardTitle></CardHeader><CardContent className="p-4 sm:p-5 pt-0"><div className="text-xl sm:text-2xl font-bold text-green-600">-4.2%</div></CardContent></Card>
        <Card className="w-full h-auto"><CardHeader className="p-4 sm:p-5"><CardTitle className="text-xs sm:text-sm">Pending Approvals</CardTitle></CardHeader><CardContent className="p-4 sm:p-5 pt-0"><div className="text-xl sm:text-2xl font-bold">14</div></CardContent></Card>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5 md:gap-6">
        {financials.slice(0, 8).map(fin => (
          <Card key={fin.id} className="cursor-pointer hover:shadow-md hover:-translate-y-1 transition-all border-border w-full h-auto" onClick={() => setSelectedFinancial(fin)}>
            <CardContent className="p-4 sm:p-5 flex justify-between items-center gap-3">
              <div className="min-w-0 flex-1">
                <h4 className="font-medium text-sm sm:text-base truncate">{fin.description}</h4>
                <p className="text-xs sm:text-sm text-muted-foreground truncate">{fin.category}</p>
              </div>
              <div className="text-right shrink-0">
                <div className="font-bold text-sm sm:text-base">€{fin.amount.toLocaleString()}</div>
                <Badge variant={fin.status === 'Approved' ? 'outline' : 'secondary'} className={`text-[10px] sm:text-xs ${fin.status === 'Approved' ? 'bg-green-50 text-green-700 border-green-200' : ''}`}>
                  {fin.status}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      <FinancialDetailModal isOpen={!!selectedFinancial} onClose={() => setSelectedFinancial(null)} financialItem={selectedFinancial} onSave={updateFinancial} />
    </div>
  );
};

export const NotificationsCenterSection = () => {
  const { notifications, updateNotification } = useDemo();
  const [selectedNotification, setSelectedNotification] = useState(null);

  return (
    <div className="p-3 sm:p-4 md:p-6 animate-in fade-in space-y-4 sm:space-y-6 w-full">
      <h2 className="text-xl sm:text-2xl font-bold">Notifications Center</h2>
      <div className="space-y-3 sm:space-y-4">
        {notifications.slice(0, 10).map(notif => (
          <Card key={notif.id} className="cursor-pointer hover:bg-muted/50 transition-colors border-border w-full h-auto" onClick={() => setSelectedNotification(notif)}>
            <CardContent className="p-3 sm:p-4 flex items-start gap-3 sm:gap-4">
              <Bell className={`w-4 h-4 sm:w-5 sm:h-5 mt-1 shrink-0 ${notif.severity === 'Critical' ? 'text-red-500' : notif.severity === 'High' ? 'text-orange-500' : 'text-blue-500'}`} />
              <div className="flex-1 min-w-0">
                <div className="flex justify-between gap-2">
                  <h4 className="font-medium text-sm sm:text-base truncate">{notif.title}</h4>
                  <span className="text-[10px] sm:text-xs text-muted-foreground shrink-0">{new Date(notif.timestamp).toLocaleTimeString()}</span>
                </div>
                <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2 break-words">{notif.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      <NotificationDetailModal isOpen={!!selectedNotification} onClose={() => setSelectedNotification(null)} notification={selectedNotification} onSave={updateNotification} />
    </div>
  );
};

export const ComplianceSafetySection = () => {
  const { complianceItems, updateCompliance } = useDemo();
  const [selectedCompliance, setSelectedCompliance] = useState(null);

  return (
    <div className="p-3 sm:p-4 md:p-6 animate-in fade-in space-y-4 sm:space-y-6 w-full">
      <h2 className="text-xl sm:text-2xl font-bold">Compliance & Safety</h2>
      <Card className="mb-4 sm:mb-6 w-full h-auto">
        <CardHeader className="p-4 sm:p-5"><CardTitle className="text-base sm:text-lg">Safety Score</CardTitle></CardHeader>
        <CardContent className="p-4 sm:p-5 pt-0">
          <div className="text-3xl sm:text-4xl font-bold text-green-600 mb-1 sm:mb-2">98.5/100</div>
          <p className="text-xs sm:text-sm text-muted-foreground">All operations are currently within regulatory compliance limits.</p>
        </CardContent>
      </Card>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
        {complianceItems.slice(0, 8).map(item => (
          <Card key={item.id} className="cursor-pointer hover:shadow-md hover:-translate-y-1 transition-all border-border w-full h-auto" onClick={() => setSelectedCompliance(item)}>
            <CardContent className="p-4 sm:p-5">
              <div className="flex justify-between mb-1 sm:mb-2 gap-2">
                <h4 className="font-medium text-sm sm:text-base truncate">{item.title}</h4>
                <Badge variant={item.status === 'Compliant' ? 'outline' : 'secondary'} className={`shrink-0 text-[10px] sm:text-xs ${item.status === 'Compliant' ? 'bg-green-50 text-green-700 border-green-200' : ''}`}>
                  {item.status}
                </Badge>
              </div>
              <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2 break-words">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <ComplianceDetailModal isOpen={!!selectedCompliance} onClose={() => setSelectedCompliance(null)} complianceItem={selectedCompliance} onSave={updateCompliance} />
    </div>
  );
};

export const CommunicationHubSection = () => {
  const { messages, updateMessage } = useDemo();
  const [selectedMessage, setSelectedMessage] = useState(null);

  return (
    <div className="p-3 sm:p-4 md:p-6 animate-in fade-in space-y-4 sm:space-y-6 w-full">
      <h2 className="text-xl sm:text-2xl font-bold">Communication Hub</h2>
      <div className="space-y-2 sm:space-y-3">
        {messages.slice(0, 10).map(msg => (
          <Card key={msg.id} className="cursor-pointer hover:bg-muted/50 transition-colors border-border w-full h-auto" onClick={() => setSelectedMessage(msg)}>
            <CardContent className="p-3 sm:p-4 flex justify-between items-center gap-3">
              <div className="min-w-0 flex-1">
                <h4 className="font-medium text-sm sm:text-base truncate">{msg.subject}</h4>
                <p className="text-xs sm:text-sm text-muted-foreground truncate">From: {msg.from} • To: {msg.to}</p>
              </div>
              <Badge variant={msg.status === 'Delivered' ? 'default' : 'secondary'} className="shrink-0 text-[10px] sm:text-xs">{msg.status}</Badge>
            </CardContent>
          </Card>
        ))}
      </div>
      <MessageDetailModal isOpen={!!selectedMessage} onClose={() => setSelectedMessage(null)} message={selectedMessage} onSave={updateMessage} />
    </div>
  );
};

export const AircraftMaintenanceSection = () => {
  const { aircraft, updateAircraft } = useDemo();
  const [selectedAircraft, setSelectedAircraft] = useState(null);

  return (
    <div className="p-3 sm:p-4 md:p-6 animate-in fade-in space-y-4 sm:space-y-6 w-full">
      <h2 className="text-xl sm:text-2xl font-bold">Aircraft & Maintenance</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-5 md:gap-6 mb-4 sm:mb-6">
        <Card className="w-full h-auto"><CardHeader className="p-4 sm:p-5"><CardTitle className="text-sm sm:text-base">Fleet Status</CardTitle></CardHeader><CardContent className="p-4 sm:p-5 pt-0"><div className="text-xl sm:text-2xl font-bold">124 Active / 4 Maintenance</div></CardContent></Card>
        <Card className="w-full h-auto"><CardHeader className="p-4 sm:p-5"><CardTitle className="text-sm sm:text-base">Next A-Check</CardTitle></CardHeader><CardContent className="p-4 sm:p-5 pt-0"><div className="text-xl sm:text-2xl font-bold">G-OP42 (Tomorrow)</div></CardContent></Card>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
        {aircraft.slice(0, 12).map(ac => (
          <Card key={ac.id} className="cursor-pointer hover:shadow-md hover:-translate-y-1 transition-all border-border w-full h-auto" onClick={() => setSelectedAircraft(ac)}>
            <CardContent className="p-4 sm:p-5">
              <div className="flex justify-between mb-1 sm:mb-2 gap-2">
                <h4 className="font-bold text-sm sm:text-base truncate">{ac.registration}</h4>
                <Badge variant={ac.status === 'Operational' ? 'default' : 'destructive'} className="shrink-0 text-[10px] sm:text-xs">{ac.status}</Badge>
              </div>
              <p className="text-xs sm:text-sm text-muted-foreground truncate">{ac.type} • {ac.flightHours} hrs</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <AircraftDetailModal isOpen={!!selectedAircraft} onClose={() => setSelectedAircraft(null)} aircraft={selectedAircraft} onSave={updateAircraft} />
    </div>
  );
};