import React, { useState, useEffect } from 'react';
import { TrendingUp, DollarSign, PieChart, AlertTriangle, FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const FinancialDetailModal = ({ isOpen, onClose, financialItem, onSave }) => {
  const [formData, setFormData] = useState(financialItem || {});
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('details');

  useEffect(() => {
    if (financialItem) {
      setFormData(financialItem);
      setActiveTab('details');
    }
  }, [financialItem]);

  if (!financialItem) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    toast.success(successMessage);
    setIsLoading(false);
    if (actionName === 'approve' || actionName === 'reject') onClose();
  };

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    onSave(formData);
    toast.success(`Financial record updated`);
    setIsLoading(false);
    onClose();
  };

  const variance = ((formData.amount || 0) / (formData.budget || 1)) * 100;
  const isOverBudget = variance > 100;

  const footerActions = (
    <>
      {formData.status === 'Pending' && (
        <>
          <Button variant="destructive" onClick={() => handleAction('reject', 'Expense rejected', { status: 'Rejected' })}>Reject</Button>
          <Button className="bg-green-600 hover:bg-green-700" onClick={() => handleAction('approve', 'Expense approved', { status: 'Approved' })}>Approve</Button>
        </>
      )}
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={handleSave} disabled={isLoading}>Save Changes</Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title={`Financial Details: ${formData.description}`}
      icon={DollarSign}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-4xl"
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="details">Budget & Variance</TabsTrigger>
          <TabsTrigger value="breakdown">Cost Breakdown</TabsTrigger>
          <TabsTrigger value="history">Approval History</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="p-4 border border-border rounded-xl bg-card shadow-sm">
              <p className="text-sm text-muted-foreground mb-1">Current Amount</p>
              <p className="text-2xl font-bold">€{(formData.amount || 0).toLocaleString()}</p>
            </div>
            <div className="p-4 border border-border rounded-xl bg-card shadow-sm">
              <p className="text-sm text-muted-foreground mb-1">Budget Limit</p>
              <p className="text-2xl font-bold">€{(formData.budget || 0).toLocaleString()}</p>
            </div>
            <div className={`p-4 border rounded-xl shadow-sm ${isOverBudget ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
              <p className={`text-sm mb-1 ${isOverBudget ? 'text-red-600' : 'text-green-600'}`}>Variance</p>
              <p className={`text-2xl font-bold ${isOverBudget ? 'text-red-700' : 'text-green-700'}`}>
                {variance.toFixed(1)}%
              </p>
            </div>
          </div>

          <div className="space-y-2 mb-6">
            <div className="flex justify-between text-sm">
              <Label>Budget Utilization</Label>
              <span className="font-medium">{variance.toFixed(1)}%</span>
            </div>
            <Progress value={Math.min(variance, 100)} className="h-3" indicatorClassName={isOverBudget ? 'bg-red-500' : 'bg-primary'} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={formData.category} onValueChange={(v) => handleChange('category', v)}>
                  <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Operational">Operational</SelectItem>
                    <SelectItem value="Crew">Crew</SelectItem>
                    <SelectItem value="Maintenance">Maintenance</SelectItem>
                    <SelectItem value="Fuel">Fuel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Update Amount (€)</Label>
                <Input type="number" value={formData.amount || 0} onChange={(e) => handleChange('amount', parseInt(e.target.value))} />
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Approved">Approved</SelectItem>
                    <SelectItem value="Rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Update Budget Limit (€)</Label>
                <Input type="number" value={formData.budget || 0} onChange={(e) => handleChange('budget', parseInt(e.target.value))} />
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label>Financial Notes & Justification</Label>
              <Textarea 
                placeholder="Provide justification for expenses or budget changes..." 
                value={formData.notes || ''} 
                onChange={(e) => handleChange('notes', e.target.value)}
                className="min-h-[80px]"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="breakdown" className="space-y-6">
          <div className="p-6 border border-border rounded-xl bg-muted/10 flex flex-col items-center justify-center min-h-[300px]">
            <PieChart className="w-16 h-16 text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-foreground mb-2">Detailed Cost Breakdown</h3>
            <p className="text-sm text-muted-foreground text-center max-w-md mb-6">
              Visual breakdown of sub-categories within this financial item.
            </p>
            <div className="w-full max-w-md space-y-3">
              <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                <span className="text-sm font-medium">Direct Costs</span>
                <span className="text-sm font-bold">€{(formData.amount * 0.6).toFixed(0)}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                <span className="text-sm font-medium">Indirect Costs</span>
                <span className="text-sm font-bold">€{(formData.amount * 0.3).toFixed(0)}</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                <span className="text-sm font-medium">Taxes & Fees</span>
                <span className="text-sm font-bold">€{(formData.amount * 0.1).toFixed(0)}</span>
              </div>
            </div>
            <Button className="mt-6" variant="outline" onClick={() => handleAction('export', 'Report exported successfully')}>
              <Download className="w-4 h-4 mr-2" /> Export Full Report
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <div className="relative border-l-2 border-muted ml-3 space-y-6 pb-4">
            {[
              { time: 'Today, 09:45', event: 'Expense submitted for approval', user: 'Finance System' },
              { time: 'Yesterday', event: 'Budget limit updated', user: 'Admin User' },
              { time: 'Last Week', event: 'Initial budget allocated', user: 'System Auto' }
            ].map((item, i) => (
              <div key={i} className="relative pl-6">
                <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-background border-2 border-primary"></div>
                <p className="text-sm font-medium text-foreground">{item.event}</p>
                <p className="text-xs text-muted-foreground">{item.time} • {item.user}</p>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </ModalBase>
  );
};