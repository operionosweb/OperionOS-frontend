import React from 'react';
import { motion } from 'framer-motion';
import { Clock, AlertCircle, CheckCircle2, Zap, MessageSquare } from 'lucide-react';
import { Badge } from '@/components/ui/badge.jsx';

const DisruptionTimelineView = ({ disruption }) => {
  if (!disruption) return null;

  // Generate mock timeline events based on disruption data
  const events = [
    {
      id: 1,
      time: new Date(Date.now() - 120 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      title: 'Anomaly Detected',
      description: `AI system flagged potential ${disruption.type} issue at ${disruption.airport || 'hub'}.`,
      type: 'alert',
      icon: AlertCircle,
      color: 'text-orange-500',
      bgColor: 'bg-orange-500/10'
    },
    {
      id: 2,
      time: new Date(Date.now() - 115 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      title: 'Disruption Confirmed',
      description: `${disruption.subtype} confirmed. Severity assessed as ${disruption.severity}.`,
      type: 'critical',
      icon: AlertCircle,
      color: 'text-destructive',
      bgColor: 'bg-destructive/10'
    },
    {
      id: 3,
      time: new Date(Date.now() - 110 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      title: 'Impact Analysis Complete',
      description: `Cascade impact calculated: ${disruption.affectedFlights?.length || 0} flights and ${disruption.affectedCrew?.length || 0} crew members affected.`,
      type: 'info',
      icon: Zap,
      color: 'text-blue-500',
      bgColor: 'bg-blue-500/10'
    },
    {
      id: 4,
      time: new Date(Date.now() - 105 * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      title: 'AI Solutions Generated',
      description: `Generated ${disruption.solutions?.length || 3} recovery scenarios.`,
      type: 'success',
      icon: CheckCircle2,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10'
    }
  ];

  if (disruption.status === 'Resolved') {
    events.push({
      id: 5,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      title: 'Solution Applied',
      description: 'Recovery scenario executed successfully. Operations normalizing.',
      type: 'success',
      icon: CheckCircle2,
      color: 'text-green-500',
      bgColor: 'bg-green-500/10'
    });
  } else {
    events.push({
      id: 5,
      time: 'Now',
      title: 'Awaiting Action',
      description: 'Pending operator decision on recovery scenarios.',
      type: 'pending',
      icon: Clock,
      color: 'text-muted-foreground',
      bgColor: 'bg-muted'
    });
  }

  return (
    <div className="p-4 sm:p-6">
      <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:ml-[8.5rem] md:before:translate-x-0 before:h-full before:w-0.5 before:bg-border">
        {events.map((event, index) => {
          const Icon = event.icon;
          return (
            <motion.div 
              key={event.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
            >
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-card shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-sm z-10 bg-card">
                <div className={`w-full h-full rounded-full flex items-center justify-center ${event.bgColor}`}>
                  <Icon className={`w-4 h-4 ${event.color}`} />
                </div>
              </div>
              
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-border bg-card shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-bold text-foreground">{event.title}</h5>
                  <Badge variant="outline" className="text-xs font-mono bg-muted/50">{event.time}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{event.description}</p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default DisruptionTimelineView;