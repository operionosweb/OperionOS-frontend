import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { toast } from 'sonner';
import { Briefcase } from 'lucide-react';

const BookingModal = ({ isOpen, onClose, booking, onSave }) => {
  const [formData, setFormData] = useState(booking || {});

  useEffect(() => {
    if (booking) setFormData(booking);
  }, [booking]);

  if (!booking) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(formData);
    toast.success(`Movement for ${formData.crewName} updated`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Briefcase className="w-5 h-5 text-primary" />
            Movement Plan Details
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Crew Member</Label>
              <Input value={formData.crewName || ''} onChange={(e) => handleChange('crewName', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Destination</Label>
              <Input value={formData.destination || ''} onChange={(e) => handleChange('destination', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Hotel</Label>
              <Input value={formData.hotel || ''} onChange={(e) => handleChange('hotel', e.target.value)} />
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Confirmed">Confirmed</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Accommodation Start Date</Label>
              <Input type="datetime-local" value={formData.checkIn ? new Date(formData.checkIn).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('checkIn', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Cost (€)</Label>
              <Input type="number" value={formData.cost || 0} onChange={(e) => handleChange('cost', parseInt(e.target.value))} />
            </div>
          </div>

          <div className="col-span-1 md:col-span-2 space-y-2">
            <Label>Special Requirements & Notes</Label>
            <Textarea 
              placeholder="Add notes regarding transport, visa, or room preferences..." 
              value={formData.notes || ''} 
              onChange={(e) => handleChange('notes', e.target.value)}
              className="min-h-[80px]"
            />
          </div>
        </div>

        <DialogFooter className="flex flex-wrap gap-2 sm:justify-between">
          <Button variant="outline" onClick={() => toast.info('Transport Arranged')}>Arrange Transport</Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Close</Button>
            <Button onClick={handleSave}>Adjust Movement</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BookingModal;