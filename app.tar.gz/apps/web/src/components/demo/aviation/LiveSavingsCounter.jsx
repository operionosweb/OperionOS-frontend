import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip.jsx';
import { Info } from 'lucide-react';

const LiveSavingsCounter = () => {
  const [savings, setSavings] = useState(45280);
  const [increment, setIncrement] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      const jump = Math.floor(Math.random() * 150) + 50;
      setIncrement(jump);
      setSavings(prev => prev + jump);
      
      setTimeout(() => setIncrement(0), 1000);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-gradient-to-br from-primary to-blue-700 text-primary-foreground border-none shadow-lg overflow-hidden relative">
      <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
      <CardContent className="p-6 relative z-10">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-primary-foreground/80 font-medium flex items-center gap-2">
            Live Savings Today
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="w-4 h-4 cursor-help opacity-70 hover:opacity-100 transition-opacity" />
                </TooltipTrigger>
                <TooltipContent className="bg-white text-gray-900 p-3 rounded-lg shadow-xl border border-gray-200">
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between gap-4"><span className="text-gray-500">Crew Optimization:</span> <span className="font-medium">€{Math.floor(savings * 0.4).toLocaleString()}</span></div>
                    <div className="flex justify-between gap-4"><span className="text-gray-500">Delay Reduction:</span> <span className="font-medium">€{Math.floor(savings * 0.35).toLocaleString()}</span></div>
                    <div className="flex justify-between gap-4"><span className="text-gray-500">Disruption Prevention:</span> <span className="font-medium">€{Math.floor(savings * 0.25).toLocaleString()}</span></div>
                  </div>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </h3>
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
            </span>
            <span className="text-xs font-medium text-green-100 uppercase tracking-wider">Live</span>
          </div>
        </div>
        
        <div className="flex items-baseline gap-3">
          <div className="text-4xl md:text-5xl font-bold tracking-tight tabular-nums">
            €{savings.toLocaleString()}
          </div>
          <AnimatePresence>
            {increment > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10, scale: 0.8 }}
                animate={{ opacity: 1, y: -10, scale: 1 }}
                exit={{ opacity: 0, y: -20 }}
                className="text-green-300 font-semibold text-lg"
              >
                +€{increment}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  );
};

export default LiveSavingsCounter;