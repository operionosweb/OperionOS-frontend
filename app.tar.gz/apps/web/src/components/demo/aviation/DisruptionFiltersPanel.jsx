import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Checkbox } from '@/components/ui/checkbox.jsx';
import { Filter, Table, Map, Clock } from 'lucide-react';

const DisruptionFiltersPanel = ({ filters, onFilterChange, viewMode, onViewModeChange }) => {
  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Filter className="w-5 h-5" />
          Filters & View
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-sm font-semibold text-gray-900 mb-2">Severity</p>
          <div className="space-y-2">
            {['Critical', 'High', 'Medium', 'Low'].map(severity => (
              <div key={severity} className="flex items-center gap-2">
                <Checkbox 
                  id={`severity-${severity}`}
                  checked={filters.severity.includes(severity)}
                  onCheckedChange={(checked) => {
                    const newSeverity = checked 
                      ? [...filters.severity, severity]
                      : filters.severity.filter(s => s !== severity);
                    onFilterChange?.({ ...filters, severity: newSeverity });
                  }}
                />
                <label htmlFor={`severity-${severity}`} className="text-sm text-gray-700">
                  {severity}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div>
          <p className="text-sm font-semibold text-gray-900 mb-2">Status</p>
          <div className="space-y-2">
            {['active', 'resolved'].map(status => (
              <div key={status} className="flex items-center gap-2">
                <Checkbox 
                  id={`status-${status}`}
                  checked={filters.status.includes(status)}
                  onCheckedChange={(checked) => {
                    const newStatus = checked 
                      ? [...filters.status, status]
                      : filters.status.filter(s => s !== status);
                    onFilterChange?.({ ...filters, status: newStatus });
                  }}
                />
                <label htmlFor={`status-${status}`} className="text-sm text-gray-700 capitalize">
                  {status}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t-2 border-gray-200">
          <p className="text-sm font-semibold text-gray-900 mb-2">View Mode</p>
          <div className="flex gap-2">
            <Button 
              size="sm" 
              variant={viewMode === 'table' ? 'default' : 'outline'}
              onClick={() => onViewModeChange?.('table')}
            >
              <Table className="w-4 h-4 mr-1" />
              Table
            </Button>
            <Button 
              size="sm" 
              variant={viewMode === 'map' ? 'default' : 'outline'}
              onClick={() => onViewModeChange?.('map')}
            >
              <Map className="w-4 h-4 mr-1" />
              Map
            </Button>
            <Button 
              size="sm" 
              variant={viewMode === 'timeline' ? 'default' : 'outline'}
              onClick={() => onViewModeChange?.('timeline')}
            >
              <Clock className="w-4 h-4 mr-1" />
              Timeline
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DisruptionFiltersPanel;