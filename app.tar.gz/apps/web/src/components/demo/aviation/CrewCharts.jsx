import React from 'react';
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';

const COLORS = ['hsl(var(--primary))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))'];

export const CrewPerformanceCharts = ({ performance }) => {
  const trendData = [
    { month: 'Jan', otp: performance.onTime - 2, efficiency: performance.efficiencyScore - 1 },
    { month: 'Feb', otp: performance.onTime - 1, efficiency: performance.efficiencyScore + 2 },
    { month: 'Mar', otp: performance.onTime + 1, efficiency: performance.efficiencyScore - 2 },
    { month: 'Apr', otp: performance.onTime, efficiency: performance.efficiencyScore },
    { month: 'May', otp: performance.onTime + 2, efficiency: performance.efficiencyScore + 1 },
    { month: 'Jun', otp: performance.onTime, efficiency: performance.efficiencyScore },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full h-auto">
      <Card className="flex flex-col h-auto">
        <CardHeader>
          <CardTitle className="text-sm font-medium">6-Month Performance Trend</CardTitle>
        </CardHeader>
        <CardContent className="min-h-[300px] w-full flex-1">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} domain={['dataMin - 5', 'dataMax + 5']} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                itemStyle={{ color: 'hsl(var(--foreground))' }}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Line type="monotone" dataKey="otp" name="On-Time %" stroke="hsl(var(--primary))" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
              <Line type="monotone" dataKey="efficiency" name="Efficiency Score" stroke="hsl(var(--chart-2))" strokeWidth={3} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="flex flex-col h-auto">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Delay Involvement vs Peer Average</CardTitle>
        </CardHeader>
        <CardContent className="min-h-[300px] w-full flex-1">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={[{ name: 'Weather', crew: 2, peer: 3 }, { name: 'ATC', crew: 4, peer: 4 }, { name: 'Technical', crew: 1, peer: 2 }, { name: 'Operational', crew: performance.delayInvolvement, peer: 5 }]} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                cursor={{ fill: 'hsl(var(--muted)/0.5)' }}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Bar dataKey="crew" name="This Crew Member" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="peer" name="Peer Average" fill="hsl(var(--muted))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

export const CrewCostCharts = ({ costProfile }) => {
  const breakdownData = [
    { name: 'Base Salary', value: costProfile.monthlyTotal * 0.6 },
    { name: 'Flight Pay', value: costProfile.monthlyTotal * 0.25 },
    { name: 'Per Diem', value: costProfile.monthlyTotal * 0.1 },
    { name: 'Hotel/Travel', value: costProfile.monthlyTotal * 0.05 },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full h-auto">
      <Card className="flex flex-col h-auto">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Monthly Cost Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="min-h-[300px] w-full flex-1 flex items-center justify-center">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={breakdownData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {breakdownData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => `€${value.toFixed(0)}`}
                contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="flex flex-col h-auto">
        <CardHeader>
          <CardTitle className="text-sm font-medium">Cost Efficiency Metrics</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-6 pt-4 flex-1">
          <div className="w-full">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Cost per Duty Hour</span>
              <span className="font-bold">€{costProfile.costPerDutyHour}</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-primary h-2 rounded-full" style={{ width: '65%' }}></div>
            </div>
            <p className="text-xs text-muted-foreground mt-1">12% below base average</p>
          </div>
          
          <div className="w-full">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-muted-foreground">Average Hotel Cost</span>
              <span className="font-bold">€{costProfile.hotelAverage}/night</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="bg-chart-2 h-2 rounded-full" style={{ width: '80%' }}></div>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Within policy limits</p>
          </div>

          <div className="p-4 bg-primary/5 border border-primary/20 rounded-xl mt-auto">
            <h4 className="text-sm font-semibold text-primary mb-1">AI Cost Insight</h4>
            <p className="text-sm text-muted-foreground">Optimizing pairings for this crew member could reduce monthly layover costs by approximately €450.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};