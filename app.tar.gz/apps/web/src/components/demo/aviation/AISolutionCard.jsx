import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Sparkles, Clock, DollarSign, TrendingUp, CheckCircle } from 'lucide-react';

const AISolutionCard = ({ solution, onApply, onSimulate, onCompare }) => {
  const getRiskColor = (risk) => {
    switch (risk) {
      case 'Low': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'High': return 'bg-red-500/10 text-red-700 border-red-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md hover:shadow-lg transition-all duration-200">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-gray-900 text-sm">{solution.actionSummary}</p>
            </div>
          </div>
          {solution.isRecommended && (
            <Badge className="bg-green-500/10 text-green-700 border-2 border-green-500/30 font-semibold text-xs">
              Recommended
            </Badge>
          )}
        </div>

        <div className="space-y-2 mb-4">
          <div className="text-xs text-gray-600">
            <p className="font-semibold mb-1">Implementation Steps:</p>
            <ol className="list-decimal list-inside space-y-1">
              {solution.stepsInvolved.map((step, idx) => (
                <li key={idx} className="text-gray-700">{step}</li>
              ))}
            </ol>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4 text-xs">
          <div className="p-2 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center gap-1 text-gray-600 mb-1">
              <Clock className="w-3 h-3" />
              <span>Time to Implement</span>
            </div>
            <p className="font-bold text-gray-900">{solution.timeToImplementMinutes}min</p>
          </div>

          <div className="p-2 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center gap-1 text-gray-600 mb-1">
              <DollarSign className="w-3 h-3" />
              <span>Cost Impact</span>
            </div>
            <p className={`font-bold ${solution.costImpact < 0 ? 'text-green-600' : 'text-red-600'}`}>
              {solution.costImpact < 0 ? '-' : ''}€{Math.abs(solution.costImpact).toLocaleString()}
            </p>
          </div>

          <div className="p-2 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center gap-1 text-gray-600 mb-1">
              <TrendingUp className="w-3 h-3" />
              <span>Delays Avoided</span>
            </div>
            <p className="font-bold text-green-600">{solution.operationalImpact.delaysAvoided}min</p>
          </div>

          <div className="p-2 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center gap-1 text-gray-600 mb-1">
              <CheckCircle className="w-3 h-3" />
              <span>Confidence</span>
            </div>
            <p className="font-bold text-blue-600">{solution.confidenceScore}%</p>
          </div>
        </div>

        <div className="flex items-center justify-between mb-4">
          <span className="text-xs text-gray-600">Risk Level:</span>
          <Badge className={`${getRiskColor(solution.riskLevel)} border-2 font-semibold text-xs`}>
            {solution.riskLevel}
          </Badge>
        </div>

        <div className="flex gap-2">
          <Button size="sm" onClick={() => onApply?.(solution)} className="flex-1">
            Apply Solution
          </Button>
          <Button size="sm" variant="outline" onClick={() => onSimulate?.(solution)}>
            Simulate
          </Button>
          <Button size="sm" variant="outline" onClick={() => onCompare?.(solution)}>
            Compare
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AISolutionCard;