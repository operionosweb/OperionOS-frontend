import React, { useState, useEffect } from 'react';
import { Wrench, Plane, Calendar, AlertTriangle, Settings, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const AircraftDetailModal = ({ isOpen, onClose, aircraft, onSave }) => {
  const [formData, setFormData] = useState(aircraft || {});
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('details');

  useEffect(() => {
    if (aircraft) {
      setFormData(aircraft);
      setActiveTab('details');
    }
  }, [aircraft]);

  if (!aircraft) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    toast.success(successMessage);
    setIsLoading(false);
  };

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    onSave(formData);
    toast.success(`Aircraft ${formData.registration} updated`);
    setIsLoading(false);
    onClose();
  };

  const footerActions = (
    <>
      <Button variant="outline" onClick={() => handleAction('schedule', 'Maintenance scheduled', { status: 'Maintenance' })}>
        <Calendar className="w-4 h-4 mr-2" /> Schedule Maintenance
      </Button>
      <Button variant="outline" onClick={() => handleAction('report', 'Inspection report generated')}>
        <FileText className="w-4 h-4 mr-2" /> Generate Report
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={handleSave} disabled={isLoading}>Save Changes</Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title={`Aircraft Details: ${formData.registration}`}
      icon={Wrench}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-4xl"
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="details">Aircraft Profile</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance & Tech</TabsTrigger>
          <TabsTrigger value="utilization">Utilization Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Registration</Label>
                <Input value={formData.registration || ''} onChange={(e) => handleChange('registration', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Aircraft Type</Label>
                <Input value={formData.type || ''} onChange={(e) => handleChange('type', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Operational">Operational</SelectItem>
                    <SelectItem value="Maintenance">Maintenance</SelectItem>
                    <SelectItem value="Grounded">Grounded</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Current Location</Label>
                <Input value={formData.location || 'LHR'} onChange={(e) => handleChange('location', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Total Flight Hours</Label>
                <Input type="number" value={formData.flightHours || 0} onChange={(e) => handleChange('flightHours', parseInt(e.target.value))} />
              </div>
              <div className="space-y-2">
                <Label>Next Scheduled Maintenance</Label>
                <Input type="datetime-local" value={formData.nextMaintenance ? new Date(formData.nextMaintenance).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('nextMaintenance', e.target.value)} />
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label>General Notes</Label>
              <Textarea 
                placeholder="Add notes regarding configuration, special equipment..." 
                value={formData.notes || ''} 
                onChange={(e) => handleChange('notes', e.target.value)}
                className="min-h-[80px]"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 border border-border rounded-xl bg-muted/10 space-y-4">
              <h4 className="font-semibold flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-primary" /> Active Technical Issues</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">Cabin APU Fault</p>
                    <p className="text-xs text-muted-foreground">Reported 2 days ago</p>
                  </div>
                  <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Deferred</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">Nav Light Inop</p>
                    <p className="text-xs text-muted-foreground">Reported today</p>
                  </div>
                  <Badge variant="destructive">Open</Badge>
                </div>
              </div>
              <Button className="w-full" variant="secondary" onClick={() => toast.info('Log issue modal opened')}>
                Log New Issue
              </Button>
            </div>

            <div className="p-5 border border-border rounded-xl bg-muted/10 space-y-4">
              <h4 className="font-semibold flex items-center gap-2"><Settings className="w-4 h-4 text-primary" /> Maintenance Schedule</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">A-Check</p>
                    <p className="text-xs text-muted-foreground">Due: {new Date(formData.nextMaintenance).toLocaleDateString()}</p>
                  </div>
                  <Badge variant="secondary">Scheduled</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">C-Check</p>
                    <p className="text-xs text-muted-foreground">Due: in 8 months</p>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="utilization" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <Label>Daily Utilization Target</Label>
                  <span className="font-medium">{formData.utilization || 85}%</span>
                </div>
                <Progress value={formData.utilization || 85} className="h-3" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <Label>Fuel Efficiency Score</Label>
                  <span className="font-medium text-green-600">92%</span>
                </div>
                <Progress value={92} className="h-3" indicatorClassName="bg-green-500" />
              </div>
            </div>
            
            <div className="p-6 border border-border rounded-xl bg-primary/5 flex flex-col justify-center items-center text-center">
              <Plane className="w-12 h-12 text-primary mb-4 opacity-80" />
              <h4 className="text-sm font-medium text-muted-foreground mb-2 uppercase tracking-wider">Fleet Performance Rank</h4>
              <div className="text-4xl font-bold text-foreground">Top 15%</div>
              <p className="text-sm text-muted-foreground mt-2">Based on reliability and utilization metrics</p>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </ModalBase>
  );
};