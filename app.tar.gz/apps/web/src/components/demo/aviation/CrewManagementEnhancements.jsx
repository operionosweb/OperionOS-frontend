import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Search, Filter, Users, Zap, AlertTriangle } from 'lucide-react';

export const CrewFiltersPanel = ({ searchQuery, setSearchQuery, roleFilter, setRoleFilter, baseFilter, setBaseFilter }) => {
  return (
    <Card className="mb-6 border-border shadow-sm">
      <CardContent className="p-4 flex flex-col md:flex-row gap-4 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search crew by name or ID..." 
            className="pl-9 w-full"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-full md:w-[160px]">
              <SelectValue placeholder="All Roles" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="Captain">Captain</SelectItem>
              <SelectItem value="First Officer">First Officer</SelectItem>
              <SelectItem value="Purser">Purser</SelectItem>
              <SelectItem value="Flight Attendant">Flight Attendant</SelectItem>
            </SelectContent>
          </Select>
          <Select value={baseFilter} onValueChange={setBaseFilter}>
            <SelectTrigger className="w-full md:w-[140px]">
              <SelectValue placeholder="All Bases" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Bases</SelectItem>
              <SelectItem value="LHR">LHR</SelectItem>
              <SelectItem value="JFK">JFK</SelectItem>
              <SelectItem value="DXB">DXB</SelectItem>
              <SelectItem value="BCN">BCN</SelectItem>
              <SelectItem value="FRA">FRA</SelectItem>
              <SelectItem value="AMS">AMS</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" className="shrink-0">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export const StandbyPoolWidget = ({ standbyCrew, onCrewClick }) => {
  return (
    <Card className="h-full border-border shadow-sm flex flex-col">
      <CardHeader className="pb-3 border-b border-border bg-muted/10">
        <CardTitle className="text-sm font-bold flex items-center gap-2">
          <Users className="w-4 h-4 text-primary" /> Standby Pool
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 flex-1 overflow-y-auto max-h-[400px] hide-scrollbar">
        <div className="divide-y divide-border">
          {standbyCrew.slice(0, 5).map(crew => (
            <div key={crew.id} className="p-3 hover:bg-muted/50 transition-colors flex items-center justify-between cursor-pointer" onClick={() => onCrewClick(crew)}>
              <div className="flex items-center gap-3">
                <img src={crew.avatar} alt={crew.name} className="w-8 h-8 rounded-full object-cover" />
                <div>
                  <p className="text-sm font-bold">{crew.name}</p>
                  <p className="text-xs text-muted-foreground">{crew.role} • {crew.base}</p>
                </div>
              </div>
              <Button size="sm" variant="secondary" className="h-7 text-xs">Assign</Button>
            </div>
          ))}
          {standbyCrew.length === 0 && (
            <div className="p-6 text-center text-muted-foreground text-sm">No crew currently on standby.</div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export const AIPairingWidget = () => {
  return (
    <Card className="h-full border-border shadow-sm flex flex-col bg-primary/5 border-primary/20">
      <CardHeader className="pb-3 border-b border-primary/10">
        <CardTitle className="text-sm font-bold flex items-center gap-2 text-primary">
          <Zap className="w-4 h-4" /> AI Pairing Suggestions
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 space-y-4">
        <div className="p-3 bg-card rounded-xl border border-border shadow-sm">
          <div className="flex justify-between items-start mb-2">
            <Badge className="bg-green-500 hover:bg-green-600">98% Match</Badge>
            <span className="text-xs text-muted-foreground">Flight OP102</span>
          </div>
          <p className="text-sm font-medium mb-1">Capt. M. Chen + FO R. Patel</p>
          <p className="text-xs text-muted-foreground mb-3">Optimal fatigue balance and high historical OTP together.</p>
          <Button size="sm" className="w-full h-7 text-xs">Apply Pairing</Button>
        </div>
        <div className="p-3 bg-card rounded-xl border border-border shadow-sm">
          <div className="flex justify-between items-start mb-2">
            <Badge className="bg-green-500 hover:bg-green-600">94% Match</Badge>
            <span className="text-xs text-muted-foreground">Flight OP405</span>
          </div>
          <p className="text-sm font-medium mb-1">Capt. L. Torres + FO K. Asante</p>
          <p className="text-xs text-muted-foreground mb-3">Minimizes layover costs by €320.</p>
          <Button size="sm" variant="outline" className="w-full h-7 text-xs">Review</Button>
        </div>
      </CardContent>
    </Card>
  );
};