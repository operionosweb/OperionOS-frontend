import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Clock, AlertTriangle, MapPin, Lightbulb } from 'lucide-react';

const OperationalTools = ({ flight }) => {
  if (!flight) return null;

  return (
    <div className="space-y-4">
      <Card className="bg-white border-2 border-gray-200">
        <CardHeader>
          <CardTitle className="text-sm text-gray-900">Aircraft Rotation Tracking</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-gray-700">
          <div className="flex justify-between">
            <span>Previous Flight:</span>
            <span className="font-semibold">{flight.previousFlight}</span>
          </div>
          <div className="flex justify-between">
            <span>Current Flight:</span>
            <span className="font-semibold text-blue-600">{flight.flightNumber}</span>
          </div>
          <div className="flex justify-between">
            <span>Next Flight:</span>
            <span className="font-semibold">{flight.nextFlight}</span>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white border-2 border-gray-200">
        <CardHeader>
          <CardTitle className="text-sm text-gray-900 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Turnaround Countdown
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-gray-900 font-mono">{flight.turnaroundTime} min</div>
          <p className="text-xs text-gray-600 mt-1">Remaining until next departure</p>
        </CardContent>
      </Card>

      <Card className="bg-white border-2 border-gray-200">
        <CardHeader>
          <CardTitle className="text-sm text-gray-900">Slot & Gate Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-700">Slot Risk:</span>
            <Badge className={
              flight.slotRisk === 'Safe' ? 'badge-on-time' : 
              flight.slotRisk === 'At-Risk' ? 'badge-delayed' : 'badge-critical'
            }>
              {flight.slotRisk}
            </Badge>
          </div>
          {flight.gateConflict && (
            <div className="flex items-center gap-2 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-700">
              <AlertTriangle className="w-4 h-4" />
              Gate conflict detected at {flight.gate}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-white border-2 border-gray-200">
        <CardHeader>
          <CardTitle className="text-sm text-gray-900 flex items-center gap-2">
            <Lightbulb className="w-4 h-4" />
            AI Alternative Routes
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="p-2 bg-blue-50 border border-blue-200 rounded text-xs">
            <p className="font-semibold text-blue-900">Route via FRA</p>
            <p className="text-blue-700">+15 min, -€2,400 cost</p>
          </div>
          <div className="p-2 bg-blue-50 border border-blue-200 rounded text-xs">
            <p className="font-semibold text-blue-900">Route via AMS</p>
            <p className="text-blue-700">+22 min, -€1,800 cost</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OperationalTools;