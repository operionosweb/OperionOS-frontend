import React, { useState, useEffect } from 'react';
import { BarChart3, Download, Filter, RefreshCw, Share2, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const KPIDetailModal = ({ isOpen, onClose, kpiData }) => {
  const [isLoading, setIsLoading] = useState(false);

  if (!kpiData) return null;

  const handleAction = async (actionName, successMessage) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    toast.success(successMessage);
    setIsLoading(false);
  };

  const footerActions = (
    <>
      <Button variant="outline" onClick={() => handleAction('export', 'Data exported to CSV')}>
        <Download className="w-4 h-4 mr-2" /> Export Data
      </Button>
      <Button variant="outline" onClick={() => handleAction('share', 'Report shared with team')}>
        <Share2 className="w-4 h-4 mr-2" /> Share
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={() => handleAction('simulate', 'Simulation engine started')} disabled={isLoading}>
        <Zap className="w-4 h-4 mr-2" /> Run Simulation
      </Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title={`KPI Analysis: ${kpiData.title || 'Metric'}`}
      icon={BarChart3}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-4xl"
    >
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="overview">Overview & Trends</TabsTrigger>
          <TabsTrigger value="breakdown">Detailed Breakdown</TabsTrigger>
          <TabsTrigger value="filters">Data Filters</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 border border-border rounded-xl bg-primary/5 flex flex-col justify-center items-center text-center col-span-1 md:col-span-3">
              <h4 className="text-sm font-medium text-muted-foreground mb-2 uppercase tracking-wider">Current Value</h4>
              <div className="text-5xl font-bold text-primary">{kpiData.value || 'N/A'}</div>
              <p className="text-sm text-green-600 mt-2 font-medium">+12.4% vs previous period</p>
            </div>
          </div>
          <div className="p-6 border border-border rounded-xl bg-card h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">Interactive Chart Visualization Placeholder</p>
          </div>
        </TabsContent>

        <TabsContent value="breakdown" className="space-y-6">
          <div className="p-6 border border-border rounded-xl bg-card h-[400px] flex items-center justify-center">
            <p className="text-muted-foreground">Data Table Breakdown Placeholder</p>
          </div>
        </TabsContent>

        <TabsContent value="filters" className="space-y-6">
          <div className="p-6 border border-border rounded-xl bg-muted/10 space-y-4">
            <h4 className="font-semibold flex items-center gap-2"><Filter className="w-4 h-4 text-primary" /> Apply Custom Filters</h4>
            <p className="text-sm text-muted-foreground">Adjust parameters to recalculate this KPI.</p>
            <div className="grid grid-cols-2 gap-4 pt-4">
              <Button variant="outline" className="w-full justify-start">Date Range: Last 30 Days</Button>
              <Button variant="outline" className="w-full justify-start">Region: Global</Button>
              <Button variant="outline" className="w-full justify-start">Fleet: All Aircraft</Button>
              <Button variant="outline" className="w-full justify-start">Crew Type: All</Button>
            </div>
            <Button className="w-full mt-4" onClick={() => handleAction('refresh', 'Data refreshed with new filters')}>
              <RefreshCw className="w-4 h-4 mr-2" /> Apply Filters
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </ModalBase>
  );
};