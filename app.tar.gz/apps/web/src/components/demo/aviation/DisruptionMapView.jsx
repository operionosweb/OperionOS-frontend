import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { MapPin } from 'lucide-react';

const DisruptionMapView = ({ disruptions, onSelectDisruption }) => {
  const airportPositions = {
    'BCN': { x: 45, y: 48 },
    'LHR': { x: 42, y: 42 },
    'JFK': { x: 25, y: 45 },
    'DXB': { x: 65, y: 55 },
    'SIN': { x: 75, y: 65 },
    'FRA': { x: 48, y: 42 },
    'AMS': { x: 46, y: 40 },
    'CDG': { x: 44, y: 43 },
    'MAD': { x: 40, y: 50 },
    'MUC': { x: 50, y: 43 }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Critical': return '#ef4444';
      case 'High': return '#f97316';
      case 'Medium': return '#eab308';
      case 'Low': return '#3b82f6';
      default: return '#6b7280';
    }
  };

  const getSeveritySize = (severity) => {
    switch (severity) {
      case 'Critical': return 24;
      case 'High': return 20;
      case 'Medium': return 16;
      case 'Low': return 12;
      default: return 12;
    }
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900">Disruptions Map View</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative w-full h-[500px] bg-gray-100 border-2 border-gray-300 rounded-lg overflow-hidden">
          <svg className="w-full h-full">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            
            {disruptions.map((disruption, idx) => {
              const pos = airportPositions[disruption.airport] || { x: 50, y: 50 };
              const color = getSeverityColor(disruption.severity);
              const size = getSeveritySize(disruption.severity);
              
              return (
                <g 
                  key={idx} 
                  onClick={() => onSelectDisruption?.(disruption)}
                  className="cursor-pointer hover:opacity-80 transition-opacity"
                >
                  <circle
                    cx={`${pos.x}%`}
                    cy={`${pos.y}%`}
                    r={size}
                    fill={color}
                    opacity="0.3"
                  />
                  <circle
                    cx={`${pos.x}%`}
                    cy={`${pos.y}%`}
                    r={size / 2}
                    fill={color}
                  />
                  <text
                    x={`${pos.x}%`}
                    y={`${pos.y - 2}%`}
                    textAnchor="middle"
                    className="text-xs font-bold fill-gray-900"
                  >
                    {disruption.airport}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
        
        <div className="mt-4 flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-red-500"></div>
            <span className="text-gray-700">Critical</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-orange-500"></div>
            <span className="text-gray-700">High</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-yellow-500"></div>
            <span className="text-gray-700">Medium</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-blue-500"></div>
            <span className="text-gray-700">Low</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DisruptionMapView;