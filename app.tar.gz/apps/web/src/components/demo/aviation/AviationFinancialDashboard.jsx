import React, { useState, useMemo } from 'react';
import { useAviationFleet } from '@/contexts/AviationFleetContext.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, CartesianGrid } from 'recharts';
import { DollarSign, TrendingUp, Activity, Settings } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters.js';

const CHART_COLORS = ['hsl(var(--primary))', 'hsl(var(--teal))', 'hsl(var(--warning))', 'hsl(var(--destructive))'];

const AviationFinancialDashboard = () => {
  const { aircraft } = useAviationFleet();
  const [typeFilter, setTypeFilter] = useState('All');
  const [leaseFilter, setLeaseFilter] = useState('All');
  const [maintPercent, setMaintPercent] = useState(8);

  const filteredAircraft = useMemo(() => {
    return aircraft.filter(a => {
      const matchesType = typeFilter === 'All' || a.aircraftType === typeFilter;
      const matchesLease = leaseFilter === 'All' || a.leaseType === leaseFilter;
      return matchesType && matchesLease;
    }).map(a => ({
      ...a,
      calculatedMaint: Math.round(a.monthlyCost * (maintPercent / 100)),
      totalCost: a.monthlyCost + Math.round(a.monthlyCost * (maintPercent / 100))
    }));
  }, [aircraft, typeFilter, leaseFilter, maintPercent]);

  const kpis = useMemo(() => {
    const totalMonthly = filteredAircraft.reduce((sum, a) => sum + a.totalCost, 0);
    const totalYearly = totalMonthly * 12;
    const avgCost = filteredAircraft.length ? totalMonthly / filteredAircraft.length : 0;
    return { totalMonthly, totalYearly, avgCost };
  }, [filteredAircraft]);

  const barChartData = useMemo(() => {
    return [...filteredAircraft]
      .sort((a, b) => b.totalCost - a.totalCost)
      .slice(0, 15)
      .map(a => ({
        name: a.aircraftId,
        Lease: a.monthlyCost,
        Maintenance: a.calculatedMaint
      }));
  }, [filteredAircraft]);

  const pieChartData = useMemo(() => {
    const grouped = filteredAircraft.reduce((acc, a) => {
      acc[a.aircraftType] = (acc[a.aircraftType] || 0) + a.totalCost;
      return acc;
    }, {});
    return Object.entries(grouped).map(([name, value]) => ({ name, value }));
  }, [filteredAircraft]);

  const top10 = useMemo(() => {
    return [...filteredAircraft].sort((a, b) => b.totalCost - a.totalCost).slice(0, 10);
  }, [filteredAircraft]);

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Financial Dashboard</h2>
          <p className="text-muted-foreground text-sm">Real-time cost analysis and projections.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <div className="flex items-center gap-2 bg-muted/50 px-3 py-1.5 rounded-lg border border-border">
            <Settings className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium">Maint. %</span>
            <Input 
              type="number" 
              value={maintPercent} 
              onChange={(e) => setMaintPercent(Number(e.target.value))}
              className="w-16 h-7 text-xs"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[120px] h-9 text-sm">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Types</SelectItem>
              <SelectItem value="B737">B737</SelectItem>
              <SelectItem value="B787">B787</SelectItem>
              <SelectItem value="A320">A320</SelectItem>
              <SelectItem value="E195">E195</SelectItem>
            </SelectContent>
          </Select>
          <Select value={leaseFilter} onValueChange={setLeaseFilter}>
            <SelectTrigger className="w-[130px] h-9 text-sm">
              <SelectValue placeholder="Lease Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Leases</SelectItem>
              <SelectItem value="Operating">Operating</SelectItem>
              <SelectItem value="Finance">Finance</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-card border-border shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <DollarSign className="w-5 h-5" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">Total Monthly Cost</p>
            </div>
            <p className="text-3xl font-bold">{formatCurrency(kpis.totalMonthly)}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-600">
                <TrendingUp className="w-5 h-5" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">Yearly Projection</p>
            </div>
            <p className="text-3xl font-bold">{formatCurrency(kpis.totalYearly)}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                <Activity className="w-5 h-5" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">Avg Cost per Aircraft</p>
            </div>
            <p className="text-3xl font-bold">{formatCurrency(kpis.avgCost)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 bg-card border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Cost per Aircraft (Top 15)</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barChartData} margin={{ top: 10, right: 10, left: 20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} angle={-45} textAnchor="end" />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `€${(val/1000).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                  formatter={(value) => formatCurrency(value)}
                />
                <Bar dataKey="Lease" stackId="a" fill="hsl(var(--primary))" radius={[0, 0, 4, 4]} />
                <Bar dataKey="Maintenance" stackId="a" fill="hsl(var(--teal))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-base">Cost by Aircraft Type</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                  formatter={(value) => formatCurrency(value)}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap justify-center gap-3 mt-2">
              {pieChartData.map((entry, index) => (
                <div key={entry.name} className="flex items-center gap-1 text-xs">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }} />
                  <span>{entry.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top 10 Table */}
      <Card className="bg-card border-border shadow-sm">
        <CardHeader>
          <CardTitle className="text-base">Top 10 Most Expensive Aircraft</CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow>
                <TableHead>Aircraft ID</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Lease Type</TableHead>
                <TableHead className="text-right">Monthly Lease</TableHead>
                <TableHead className="text-right">Est. Maintenance</TableHead>
                <TableHead className="text-right">Total Cost</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {top10.map(a => (
                <TableRow key={a.aircraftId}>
                  <TableCell className="font-bold">{a.aircraftId}</TableCell>
                  <TableCell>{a.aircraftType}</TableCell>
                  <TableCell>{a.leaseType}</TableCell>
                  <TableCell className="text-right">{formatCurrency(a.monthlyCost)}</TableCell>
                  <TableCell className="text-right text-muted-foreground">{formatCurrency(a.calculatedMaint)}</TableCell>
                  <TableCell className="text-right font-bold text-primary">{formatCurrency(a.totalCost)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default AviationFinancialDashboard;