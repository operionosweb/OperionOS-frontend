import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline, useMap } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Plane, AlertTriangle, Cloud, Wind, Eye } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { airportLocations, generateWeatherData, generateAirportCongestion } from '@/lib/aviationDemoData.js';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet default marker icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const FlightMarker = ({ flight }) => {
  const planeIcon = L.divIcon({
    className: 'custom-plane-icon',
    html: `<div style="color: ${flight.status === 'Critical' ? '#ef4444' : flight.status === 'Delayed' ? '#f59e0b' : '#3b82f6'}; font-size: 20px;">✈️</div>`,
    iconSize: [20, 20]
  });

  return (
    <Marker position={[flight.currentLat, flight.currentLng]} icon={planeIcon}>
      <Popup>
        <div className="text-sm">
          <p className="font-bold">{flight.flightNumber}</p>
          <p>{flight.route}</p>
          <p>Progress: {flight.progress.toFixed(0)}%</p>
          <Badge className={flight.status === 'On Time' ? 'badge-on-time' : 'badge-delayed'}>{flight.status}</Badge>
        </div>
      </Popup>
    </Marker>
  );
};

const DisruptionZone = ({ disruption }) => {
  const color = disruption.severity === 'Critical' ? '#ef4444' : disruption.severity === 'Warning' ? '#f59e0b' : '#3b82f6';
  return (
    <Circle
      center={[disruption.lat, disruption.lng]}
      radius={disruption.radius * 1000}
      pathOptions={{ color, fillColor: color, fillOpacity: 0.2 }}
    >
      <Popup>
        <div className="text-sm">
          <p className="font-bold">{disruption.type}</p>
          <p>Location: {disruption.location}</p>
          <p>Severity: {disruption.severity}</p>
          <p>Cost Impact: €{disruption.costImpact.toLocaleString()}</p>
        </div>
      </Popup>
    </Circle>
  );
};

const GlobalOperationsMap = () => {
  const { aviationFlights, aviationDisruptions } = useDemo();
  const [weatherData, setWeatherData] = useState([]);
  const [congestionData, setCongestionData] = useState([]);
  const [showWeather, setShowWeather] = useState(true);
  const [showDisruptions, setShowDisruptions] = useState(true);
  const [showFlights, setShowFlights] = useState(true);

  useEffect(() => {
    setWeatherData(generateWeatherData());
    setCongestionData(generateAirportCongestion());
  }, []);

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-gray-900">Global Operations Map</CardTitle>
        <div className="flex gap-2">
          <button onClick={() => setShowFlights(!showFlights)} className={`px-3 py-1 text-xs rounded-md ${showFlights ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
            Flights
          </button>
          <button onClick={() => setShowDisruptions(!showDisruptions)} className={`px-3 py-1 text-xs rounded-md ${showDisruptions ? 'bg-red-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
            Disruptions
          </button>
          <button onClick={() => setShowWeather(!showWeather)} className={`px-3 py-1 text-xs rounded-md ${showWeather ? 'bg-yellow-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
            Weather
          </button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[500px] rounded-lg overflow-hidden border-2 border-gray-300">
          <MapContainer center={[40, 10]} zoom={3} style={{ height: '100%', width: '100%' }}>
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            />
            
            {showFlights && aviationFlights.filter(f => f.currentLat && f.currentLng).map(flight => (
              <FlightMarker key={flight.id} flight={flight} />
            ))}
            
            {showDisruptions && aviationDisruptions.filter(d => d.lat && d.lng).map(disruption => (
              <DisruptionZone key={disruption.id} disruption={disruption} />
            ))}
            
            {airportLocations.map(airport => {
              const congestion = congestionData.find(c => c.code === airport.code);
              return (
                <Marker key={airport.code} position={[airport.lat, airport.lng]}>
                  <Popup>
                    <div className="text-sm">
                      <p className="font-bold">{airport.name} ({airport.code})</p>
                      {congestion && (
                        <>
                          <p>Congestion: {congestion.congestion}%</p>
                          <p>Delays: {congestion.delays}</p>
                        </>
                      )}
                    </div>
                  </Popup>
                </Marker>
              );
            })}
          </MapContainer>
        </div>
        
        <div className="mt-4 flex gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-gray-700">On Time</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <span className="text-gray-700">Delayed</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <span className="text-gray-700">Critical</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default GlobalOperationsMap;