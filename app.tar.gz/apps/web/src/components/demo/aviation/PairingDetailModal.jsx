import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { TrendingUp, DollarSign, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';

const PairingDetailModal = ({ isOpen, onClose, pairing, onViewCrewProfile, onViewFlightDetails }) => {
  const [customizing, setCustomizing] = useState(false);
  const [customPairing, setCustomPairing] = useState(pairing || {});

  if (!pairing) return null;

  const getProgressColor = (value) => {
    if (value >= 80) return 'bg-green-500';
    if (value >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getConfidenceColor = (confidence) => {
    switch (confidence) {
      case 'High': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'Low': return 'bg-red-500/10 text-red-700 border-red-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  const handleAccept = () => {
    toast.success('Pairing accepted successfully');
    onClose();
  };

  const handleReject = () => {
    toast.success('Pairing rejected');
    onClose();
  };

  const handleSaveCustom = () => {
    toast.success('Custom pairing saved successfully');
    setCustomizing(false);
  };

  const efficiencyComponents = [
    { label: 'Crew Compatibility', value: pairing.efficiencyBreakdown.crewCompatibility, description: 'Based on previous flight history and working relationship' },
    { label: 'Aircraft Certification Match', value: pairing.efficiencyBreakdown.certificationMatch, description: 'Both crew members certified for required aircraft type' },
    { label: 'Rest Period Adequacy', value: pairing.efficiencyBreakdown.restAdequacy, description: 'Sufficient rest time between flights' },
    { label: 'Cost Optimization', value: pairing.efficiencyBreakdown.costOptimization, description: 'Minimizes operational costs and overtime' },
    { label: 'Schedule Alignment', value: pairing.efficiencyBreakdown.scheduleAlignment, description: 'Optimal fit with existing crew schedules' },
    { label: 'Fatigue Risk Mitigation', value: pairing.efficiencyBreakdown.fatigueRiskMitigation, description: 'Low fatigue risk based on FRMS analysis' },
    { label: 'Geographic Proximity', value: pairing.efficiencyBreakdown.geographicProximity, description: 'Crew members located near departure airport' },
    { label: 'Previous Pairing History', value: pairing.efficiencyBreakdown.pairingHistory, description: 'Successful previous pairings recorded' }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-gray-900 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p>AI Pairing Suggestion</p>
                <p className="text-sm font-normal text-gray-600">Flight {pairing.flight.flightNumber}</p>
              </div>
            </div>
            <Badge className={`${getConfidenceColor(pairing.confidence)} border-2 font-semibold`}>
              {pairing.confidence} Confidence
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
              <p className="text-xs text-blue-600 font-semibold uppercase tracking-wider mb-2">Crew Member 1</p>
              <p className="font-bold text-gray-900 mb-1">{pairing.crew1.name}</p>
              <p className="text-sm text-gray-600 mb-2">{pairing.crew1.role}</p>
              <Button size="sm" variant="outline" onClick={() => onViewCrewProfile?.(pairing.crew1)}>
                View Profile
              </Button>
            </div>

            <div className="p-4 bg-cyan-50 border-2 border-cyan-200 rounded-lg">
              <p className="text-xs text-cyan-600 font-semibold uppercase tracking-wider mb-2">Crew Member 2</p>
              <p className="font-bold text-gray-900 mb-1">{pairing.crew2.name}</p>
              <p className="text-sm text-gray-600 mb-2">{pairing.crew2.role}</p>
              <Button size="sm" variant="outline" onClick={() => onViewCrewProfile?.(pairing.crew2)}>
                View Profile
              </Button>
            </div>
          </div>

          <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <span className="font-semibold text-green-900">Estimated Cost Savings</span>
              </div>
              <span className="text-2xl font-bold text-green-600">€{pairing.costSavings.toLocaleString()}</span>
            </div>
            <p className="text-xs text-green-700">
              Compared to average pairing cost. Benchmark comparison: {pairing.benchmarkComparison > 0 ? '+' : ''}{pairing.benchmarkComparison}% vs industry average
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Efficiency Breakdown
            </h3>
            <div className="space-y-3">
              {efficiencyComponents.map((component, idx) => (
                <div key={idx} className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold text-gray-900">{component.label}</span>
                    <span className={`text-lg font-bold ${component.value >= 80 ? 'text-green-600' : component.value >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
                      {component.value}%
                    </span>
                  </div>
                  <Progress value={component.value} className="h-2 mb-2" indicatorClassName={getProgressColor(component.value)} />
                  <p className="text-xs text-gray-600">{component.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-blue-900">Total Weighted Efficiency</span>
              <span className="text-3xl font-bold text-blue-600">{pairing.totalEfficiency}%</span>
            </div>
            <p className="text-sm text-blue-700">{pairing.recommendationReason}</p>
          </div>

          {customizing && (
            <div className="p-4 bg-yellow-50 border-2 border-yellow-200 rounded-lg space-y-3">
              <h4 className="font-semibold text-yellow-900">Customize Pairing</h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider block mb-1">
                    Crew Member 1
                  </label>
                  <Select defaultValue={pairing.crew1.id}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={pairing.crew1.id}>{pairing.crew1.name}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider block mb-1">
                    Crew Member 2
                  </label>
                  <Select defaultValue={pairing.crew2.id}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={pairing.crew2.id}>{pairing.crew2.name}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex flex-wrap gap-2">
          {!customizing ? (
            <>
              <Button variant="outline" onClick={() => onViewFlightDetails?.(pairing.flight)}>
                View Flight Details
              </Button>
              <Button variant="outline" onClick={() => setCustomizing(true)}>
                Customize Pairing
              </Button>
              <Button variant="outline" onClick={handleReject}>
                <XCircle className="w-4 h-4 mr-2" />
                Reject
              </Button>
              <Button onClick={handleAccept}>
                <CheckCircle className="w-4 h-4 mr-2" />
                Accept Pairing
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setCustomizing(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveCustom}>
                Save Custom Pairing
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default PairingDetailModal;