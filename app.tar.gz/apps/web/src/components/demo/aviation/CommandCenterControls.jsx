import React, { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Switch } from '@/components/ui/switch.jsx';
import { Zap, AlertCircle, Bot, Pause } from 'lucide-react';
import { toast } from 'sonner';
import { useDemo } from '@/contexts/DemoStateContext.jsx';

const CommandCenterControls = () => {
  const { crisisMode, setCrisisMode, autoRecovery, setAutoRecovery, scheduleFreeze, setScheduleFreeze } = useDemo();
  const [showOptimizeModal, setShowOptimizeModal] = useState(false);
  const [optimizing, setOptimizing] = useState(false);

  const handleGlobalOptimize = () => {
    setOptimizing(true);
    setTimeout(() => {
      setOptimizing(false);
      setShowOptimizeModal(true);
      toast.success('Global optimization complete');
    }, 2000);
  };

  const handleCrisisModeToggle = () => {
    setCrisisMode(!crisisMode);
    toast.success(crisisMode ? 'Crisis mode deactivated' : 'Crisis mode activated - showing critical disruptions only');
  };

  return (
    <div className="flex flex-wrap gap-3">
      <Button 
        onClick={handleGlobalOptimize} 
        disabled={optimizing}
        className="bg-blue-600 hover:bg-blue-700 text-white"
      >
        <Zap className="w-4 h-4 mr-2" />
        {optimizing ? 'Optimizing...' : 'Global Optimize'}
      </Button>
      
      <Button 
        onClick={handleCrisisModeToggle}
        variant={crisisMode ? 'destructive' : 'outline'}
      >
        <AlertCircle className="w-4 h-4 mr-2" />
        Crisis Mode {crisisMode ? 'ON' : 'OFF'}
      </Button>
      
      <div className="flex items-center gap-2 px-4 py-2 border-2 border-gray-300 rounded-md bg-white">
        <Bot className="w-4 h-4 text-gray-700" />
        <span className="text-sm font-medium text-gray-900">Auto-Recovery</span>
        <Switch checked={autoRecovery} onCheckedChange={setAutoRecovery} />
      </div>
      
      <div className="flex items-center gap-2 px-4 py-2 border-2 border-gray-300 rounded-md bg-white">
        <Pause className="w-4 h-4 text-gray-700" />
        <span className="text-sm font-medium text-gray-900">Freeze Schedule</span>
        <Switch checked={scheduleFreeze} onCheckedChange={setScheduleFreeze} />
      </div>

      <Dialog open={showOptimizeModal} onOpenChange={setShowOptimizeModal}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Global Optimization Summary</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-4 text-sm text-gray-700">
            <p>✅ Rebalanced 12 crew assignments for optimal coverage</p>
            <p>✅ Identified 3 aircraft swaps to reduce turnaround time</p>
            <p>✅ Optimized 8 flight routes to avoid weather disruptions</p>
            <p>✅ Estimated cost savings: €47,200</p>
            <p>✅ Improved on-time performance by 4.2%</p>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowOptimizeModal(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CommandCenterControls;