import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { CheckCircle, TrendingUp, TrendingDown, Users, Clock } from 'lucide-react';

const ScenarioSimulatorPanel = ({ solutions, onApplyBest }) => {
  const [selectedScenarios, setSelectedScenarios] = useState([0]);

  const toggleScenario = (index) => {
    setSelectedScenarios(prev => 
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  const selectedSolutions = solutions.filter((_, idx) => selectedScenarios.includes(idx));

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900">Scenario Comparison</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2 mb-4">
          {solutions.map((solution, idx) => (
            <Button
              key={idx}
              size="sm"
              variant={selectedScenarios.includes(idx) ? 'default' : 'outline'}
              onClick={() => toggleScenario(idx)}
            >
              Scenario {idx + 1}
            </Button>
          ))}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-gray-300">
                <th className="text-left p-2 text-gray-700">Metric</th>
                {selectedSolutions.map((_, idx) => (
                  <th key={idx} className="text-center p-2 text-gray-700">Scenario {selectedScenarios[idx] + 1}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-gray-200">
                <td className="p-2 text-gray-700 font-semibold">Cost Impact</td>
                {selectedSolutions.map((sol, idx) => (
                  <td key={idx} className="text-center p-2">
                    <span className={`font-bold ${sol.costImpact < 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {sol.costImpact < 0 ? '-' : ''}€{Math.abs(sol.costImpact).toLocaleString()}
                    </span>
                  </td>
                ))}
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-2 text-gray-700 font-semibold">Delays Avoided</td>
                {selectedSolutions.map((sol, idx) => (
                  <td key={idx} className="text-center p-2">
                    <span className="font-bold text-green-600">{sol.operationalImpact.delaysAvoided}min</span>
                  </td>
                ))}
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-2 text-gray-700 font-semibold">Implementation Time</td>
                {selectedSolutions.map((sol, idx) => (
                  <td key={idx} className="text-center p-2">
                    <span className="font-bold text-gray-900">{sol.timeToImplementMinutes}min</span>
                  </td>
                ))}
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-2 text-gray-700 font-semibold">Risk Level</td>
                {selectedSolutions.map((sol, idx) => (
                  <td key={idx} className="text-center p-2">
                    <Badge className={`${
                      sol.riskLevel === 'Low' ? 'bg-green-500/10 text-green-700 border-green-500/30' :
                      sol.riskLevel === 'Medium' ? 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30' :
                      'bg-red-500/10 text-red-700 border-red-500/30'
                    } border-2`}>
                      {sol.riskLevel}
                    </Badge>
                  </td>
                ))}
              </tr>
              <tr className="border-b border-gray-200">
                <td className="p-2 text-gray-700 font-semibold">Confidence Score</td>
                {selectedSolutions.map((sol, idx) => (
                  <td key={idx} className="text-center p-2">
                    <span className="font-bold text-blue-600">{sol.confidenceScore}%</span>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>

        <div className="flex justify-end">
          <Button onClick={() => onApplyBest?.(selectedSolutions[0])}>
            <CheckCircle className="w-4 h-4 mr-2" />
            Apply Best Scenario
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScenarioSimulatorPanel;