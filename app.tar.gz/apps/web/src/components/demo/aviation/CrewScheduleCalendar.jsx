import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Calendar as CalendarIcon, Clock, MapPin, Plane } from 'lucide-react';

const CrewScheduleCalendar = ({ crewMember }) => {
  // Generate a mock 30-day schedule
  const days = Array.from({ length: 30 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() + i - 5); // Start 5 days ago
    
    let type = 'Rest';
    let details = null;
    
    const rand = Math.random();
    if (rand < 0.5) {
      type = 'Flight';
      details = { flight: `OP${Math.floor(Math.random() * 9000 + 100)}`, route: `${crewMember.base}-${['JFK', 'DXB', 'SIN', 'LAX'][Math.floor(Math.random() * 4)]}` };
    } else if (rand < 0.7) {
      type = 'Standby';
    } else if (rand < 0.8) {
      type = 'Leave';
    }

    return { date, type, details };
  });

  const getTypeColor = (type) => {
    switch(type) {
      case 'Flight': return 'bg-primary/10 text-primary border-primary/20';
      case 'Rest': return 'bg-green-500/10 text-green-700 border-green-500/20';
      case 'Standby': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/20';
      case 'Leave': return 'bg-slate-500/10 text-slate-700 border-slate-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="flex flex-col gap-6 w-full h-auto">
      <Card className="h-auto flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-bold flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-primary" /> 30-Day Roster
          </CardTitle>
          <div className="flex gap-2 text-xs">
            <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-primary"></div> Flight</span>
            <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-green-500"></div> Rest</span>
            <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-yellow-500"></div> Standby</span>
          </div>
        </CardHeader>
        <CardContent className="flex-1">
          <div className="grid grid-cols-7 gap-2 text-center mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
              <div key={d} className="text-xs font-medium text-muted-foreground py-1">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-2">
            {/* Offset for visual realism */}
            {Array.from({ length: days[0].date.getDay() }).map((_, i) => (
              <div key={`empty-${i}`} className="aspect-square rounded-lg bg-muted/30 border border-transparent"></div>
            ))}
            
            {days.map((day, i) => {
              const isToday = day.date.toDateString() === new Date().toDateString();
              return (
                <div 
                  key={i} 
                  className={`aspect-square rounded-lg border p-1 flex flex-col items-center justify-center relative transition-colors hover:border-primary/50 cursor-pointer
                    ${getTypeColor(day.type)}
                    ${isToday ? 'ring-2 ring-primary ring-offset-2 ring-offset-background' : ''}
                  `}
                >
                  <span className="text-sm font-bold">{day.date.getDate()}</span>
                  {day.details && (
                    <span className="text-[10px] font-medium truncate w-full px-1 mt-1 opacity-80">
                      {day.details.route.split('-')[1]}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full h-auto">
        <Card className="flex flex-col h-auto">
          <CardHeader>
            <CardTitle className="text-sm font-medium">Upcoming Duties</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4 flex-1">
            {days.filter(d => d.date >= new Date() && d.type === 'Flight').slice(0, 4).map((duty, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-border bg-card hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg text-primary">
                    <Plane className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-sm">{duty.details.flight}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {duty.details.route}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium">{duty.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</p>
                  <Badge variant="outline" className="mt-1 text-[10px]">Confirmed</Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="flex flex-col h-auto">
          <CardHeader>
            <CardTitle className="text-sm font-medium">Recent History</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4 flex-1">
            {days.filter(d => d.date < new Date() && d.type === 'Flight').reverse().slice(0, 4).map((duty, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-border bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-muted rounded-lg text-muted-foreground">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-bold text-sm text-foreground">{duty.details.flight}</p>
                    <p className="text-xs text-muted-foreground">{duty.details.route}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">{duty.date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</p>
                  <span className="text-xs text-green-600 font-medium">Completed</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CrewScheduleCalendar;