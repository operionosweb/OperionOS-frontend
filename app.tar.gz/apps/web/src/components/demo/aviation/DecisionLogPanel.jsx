import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { FileText, User, Clock, CheckCircle } from 'lucide-react';

const DecisionLogPanel = ({ decisions }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'pending': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'rejected': return 'bg-red-500/10 text-red-700 border-red-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Decision Log
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {decisions.map((decision, idx) => (
          <div key={idx} className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-gray-600" />
                <p className="font-semibold text-gray-900 text-sm">{decision.user}</p>
              </div>
              <Badge className={`${getStatusColor(decision.status)} border-2 font-semibold text-xs`}>
                {decision.status}
              </Badge>
            </div>
            <p className="text-sm text-gray-700 mb-2">{decision.action}</p>
            <div className="flex items-center justify-between text-xs text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{new Date(decision.timestamp).toLocaleString()}</span>
              </div>
              {decision.result && (
                <div className="flex items-center gap-1 text-green-600">
                  <CheckCircle className="w-3 h-3" />
                  <span>{decision.result}</span>
                </div>
              )}
            </div>
            {decision.comment && (
              <p className="text-xs text-gray-600 mt-2 italic">"{decision.comment}"</p>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default DecisionLogPanel;