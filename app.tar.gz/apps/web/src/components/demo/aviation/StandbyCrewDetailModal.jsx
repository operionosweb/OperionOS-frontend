import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { User, MapPin, Award, Calendar, DollarSign } from 'lucide-react';
import { toast } from 'sonner';

const StandbyCrewDetailModal = ({ isOpen, onClose, crew, onViewFullProfile, onQuickAssign }) => {
  const [editedCrew, setEditedCrew] = useState(crew || {});
  const [selectedFlight, setSelectedFlight] = useState('');

  if (!crew) return null;

  const getRiskColor = (riskLevel) => {
    switch (riskLevel) {
      case 'Low': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'High': return 'bg-red-500/10 text-red-700 border-red-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  const handleSave = () => {
    toast.success('Crew details updated successfully');
    onClose();
  };

  const handleQuickAssign = () => {
    if (!selectedFlight) {
      toast.error('Please select a flight');
      return;
    }
    onQuickAssign?.(crew.id, selectedFlight);
    toast.success(`${crew.name} assigned to ${selectedFlight}`);
    onClose();
  };

  const handleMarkUnavailable = () => {
    toast.success(`${crew.name} marked as unavailable`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-gray-900 flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <User className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p>{crew.name}</p>
              <p className="text-sm font-normal text-gray-600">{crew.role}</p>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</label>
              <Select 
                value={editedCrew.status} 
                onValueChange={(val) => setEditedCrew({...editedCrew, status: val})}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Standby">Standby</SelectItem>
                  <SelectItem value="Available">Available</SelectItem>
                  <SelectItem value="On Rest">On Rest</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Base Airport</label>
              <Input value={crew.base} disabled className="mt-1 bg-gray-50" />
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Current Location</label>
              <Input 
                value={editedCrew.currentLocation} 
                onChange={(e) => setEditedCrew({...editedCrew, currentLocation: e.target.value})}
                className="mt-1"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Availability Hours</label>
              <Input 
                type="number"
                value={editedCrew.availabilityHours} 
                onChange={(e) => setEditedCrew({...editedCrew, availabilityHours: parseInt(e.target.value)})}
                className="mt-1"
              />
            </div>
          </div>

          <div className="p-4 bg-gray-50 border-2 border-gray-200 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-gray-900">FRMS Score</span>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold text-gray-900">{crew.frmsScore}</span>
                <Badge className={`${getRiskColor(crew.riskLevel)} border-2 font-semibold`}>
                  {crew.riskLevel} Risk
                </Badge>
              </div>
            </div>
            <p className="text-xs text-gray-600">
              {crew.riskLevel === 'Low' && 'Crew member is well-rested and ready for assignment'}
              {crew.riskLevel === 'Medium' && 'Monitor fatigue levels before next assignment'}
              {crew.riskLevel === 'High' && 'Recommend extended rest period before next flight'}
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <Award className="w-4 h-4 text-gray-600" />
              <span className="font-semibold text-gray-900">Certifications:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {crew.certifications.map((cert, idx) => (
                <Badge key={idx} className="bg-blue-500/10 text-blue-700 border-2 border-blue-500/30">
                  {cert.type} - {cert.status}
                </Badge>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gray-600" />
              <div>
                <p className="text-xs text-gray-600">Last Flight</p>
                <p className="font-semibold text-gray-900">{crew.lastFlightDate}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-gray-600" />
              <div>
                <p className="text-xs text-gray-600">Cost per Hour</p>
                <p className="font-semibold text-gray-900">€{crew.costPerHour}</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
            <label className="text-xs font-semibold text-blue-900 uppercase tracking-wider block mb-2">
              Quick Assign to Flight
            </label>
            <Select value={selectedFlight} onValueChange={setSelectedFlight}>
              <SelectTrigger>
                <SelectValue placeholder="Select flight..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="IB342">IB342 - BCN to LHR</SelectItem>
                <SelectItem value="LH567">LH567 - FRA to JFK</SelectItem>
                <SelectItem value="EK891">EK891 - DXB to SIN</SelectItem>
                <SelectItem value="BA234">BA234 - LHR to CDG</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={handleQuickAssign}>
            Quick Assign
          </Button>
          <Button variant="outline" onClick={() => onViewFullProfile?.(crew)}>
            View Full Profile
          </Button>
          <Button variant="outline" onClick={handleMarkUnavailable}>
            Mark Unavailable
          </Button>
          <Button onClick={handleSave}>
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default StandbyCrewDetailModal;