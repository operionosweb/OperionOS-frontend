import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Lightbulb } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import PairingCard from './PairingCard.jsx';
import PairingDetailModal from './PairingDetailModal.jsx';
import CrewProfileModal from './CrewProfileModal.jsx';
import FlightDetailsModal from './FlightDetailsModal.jsx';

const PairingRecommendations = () => {
  const { crewPairingSuggestions } = useDemo();
  const [selectedPairing, setSelectedPairing] = useState(null);
  const [pairingModalOpen, setPairingModalOpen] = useState(false);
  const [crewProfileModalOpen, setCrewProfileModalOpen] = useState(false);
  const [flightModalOpen, setFlightModalOpen] = useState(false);
  const [selectedCrew, setSelectedCrew] = useState(null);
  const [selectedFlight, setSelectedFlight] = useState(null);

  const handleCardClick = (pairing) => {
    setSelectedPairing(pairing);
    setPairingModalOpen(true);
  };

  const handleViewCrewProfile = (crew) => {
    setPairingModalOpen(false);
    setSelectedCrew(crew);
    setCrewProfileModalOpen(true);
  };

  const handleViewFlightDetails = (flight) => {
    setPairingModalOpen(false);
    setSelectedFlight(flight);
    setFlightModalOpen(true);
  };

  return (
    <>
      <Card className="bg-white border-2 border-gray-200 shadow-md">
        <CardHeader>
          <CardTitle className="text-gray-900 flex items-center gap-2">
            <Lightbulb className="w-5 h-5" />
            AI Pairing Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {crewPairingSuggestions && crewPairingSuggestions.map(pairing => (
              <PairingCard 
                key={pairing.id} 
                pairing={pairing} 
                onClick={() => handleCardClick(pairing)}
              />
            ))}
          </div>
        </CardContent>
      </Card>

      <PairingDetailModal
        isOpen={pairingModalOpen}
        onClose={() => setPairingModalOpen(false)}
        pairing={selectedPairing}
        onViewCrewProfile={handleViewCrewProfile}
        onViewFlightDetails={handleViewFlightDetails}
      />

      <CrewProfileModal
        isOpen={crewProfileModalOpen}
        onClose={() => setCrewProfileModalOpen(false)}
        crew={selectedCrew}
      />

      <FlightDetailsModal
        isOpen={flightModalOpen}
        onClose={() => setFlightModalOpen(false)}
        flight={selectedFlight}
      />
    </>
  );
};

export default PairingRecommendations;