import React, { useState } from 'react';
import { useAviationFleet } from '@/contexts/AviationFleetContext.jsx';
import { AlertTriangle, Clock, TrendingDown, DollarSign, X, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button.jsx';

const DecisionAlertsSystem = () => {
  const { allAlerts } = useAviationFleet();
  const navigate = useNavigate();
  const [dismissed, setDismissed] = useState([]);

  const activeAlerts = allAlerts.filter(a => !dismissed.includes(a.id)).slice(0, 3); // Show top 3

  if (activeAlerts.length === 0) return null;

  const getAlertIcon = (type) => {
    switch(type) {
      case 'lease_expiring_soon': return <Clock className="w-4 h-4" />;
      case 'underutilized': return <TrendingDown className="w-4 h-4" />;
      case 'high_cost': return <DollarSign className="w-4 h-4" />;
      case 'high_risk': return <AlertTriangle className="w-4 h-4" />;
      default: return <AlertTriangle className="w-4 h-4" />;
    }
  };

  const getAlertColor = (severity) => {
    return severity === 'high' ? 'bg-destructive/10 text-destructive border-destructive/20' : 'bg-warning/10 text-warning border-warning/20';
  };

  return (
    <div className="flex flex-col gap-2 mb-6">
      <AnimatePresence>
        {activeAlerts.map(alert => (
          <motion.div 
            key={alert.id}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, height: 0, marginBottom: 0 }}
            className={`flex items-center justify-between p-3 rounded-lg border ${getAlertColor(alert.severity)}`}
          >
            <div className="flex items-center gap-3">
              <div className="p-1.5 rounded-md bg-background/50">
                {getAlertIcon(alert.type)}
              </div>
              <div>
                <span className="font-semibold text-sm">{alert.title}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 text-xs hover:bg-background/20"
                onClick={() => navigate(`/demo/aviation/aircraft/${alert.relatedId}`)}
              >
                View <ChevronRight className="w-3 h-3 ml-1" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 hover:bg-background/20"
                onClick={() => setDismissed([...dismissed, alert.id])}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

export default DecisionAlertsSystem;