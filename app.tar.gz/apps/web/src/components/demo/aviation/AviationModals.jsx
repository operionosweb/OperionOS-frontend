import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { toast } from 'sonner';

export const EditFlightModal = ({ isOpen, onClose, flight, onSave, onDelete }) => {
  const [formData, setFormData] = useState(flight || {});
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (flight) setFormData(flight); }, [flight]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.flightNumber || !formData.route) {
      toast.error('Please fill in all required fields');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      onSave(formData.id, formData);
      setLoading(false);
      onClose();
    }, 500);
  };

  if (!flight) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-white">
        <DialogHeader>
          <DialogTitle className="text-gray-900">Edit Flight {flight.flightNumber}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Flight Number</label>
            <Input value={formData.flightNumber || ''} onChange={e => setFormData({...formData, flightNumber: e.target.value})} required className="bg-white text-gray-900" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Route</label>
            <Input value={formData.route || ''} onChange={e => setFormData({...formData, route: e.target.value})} required className="bg-white text-gray-900" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Status</label>
            <Select value={formData.status} onValueChange={v => setFormData({...formData, status: v})}>
              <SelectTrigger className="bg-white text-gray-900"><SelectValue placeholder="Select status" /></SelectTrigger>
              <SelectContent className="bg-white">
                <SelectItem value="On Time">On Time</SelectItem>
                <SelectItem value="Delayed">Delayed</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="flex justify-between sm:justify-between mt-6">
            <Button type="button" variant="destructive" onClick={() => { onDelete(flight.id); onClose(); }}>Delete</Button>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={loading}>{loading ? 'Saving...' : 'Save Changes'}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export const EditCrewModal = ({ isOpen, onClose, crew, onSave, onDelete }) => {
  const [formData, setFormData] = useState(crew || {});
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (crew) setFormData(crew); }, [crew]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      onSave(formData.id, formData);
      setLoading(false);
      onClose();
    }, 500);
  };

  if (!crew) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-white">
        <DialogHeader>
          <DialogTitle className="text-gray-900">Edit Crew Member</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Name</label>
            <Input value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} required className="bg-white text-gray-900" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Role</label>
            <Input value={formData.role || ''} onChange={e => setFormData({...formData, role: e.target.value})} required className="bg-white text-gray-900" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Status</label>
            <Select value={formData.status} onValueChange={v => setFormData({...formData, status: v})}>
              <SelectTrigger className="bg-white text-gray-900"><SelectValue placeholder="Select status" /></SelectTrigger>
              <SelectContent className="bg-white">
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Standby">Standby</SelectItem>
                <SelectItem value="Rest">Rest</SelectItem>
                <SelectItem value="Training">Training</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="flex justify-between sm:justify-between mt-6">
            <Button type="button" variant="destructive" onClick={() => { onDelete(crew.id); onClose(); }}>Delete</Button>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={loading}>{loading ? 'Saving...' : 'Save Changes'}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export const EditDisruptionModal = ({ isOpen, onClose, disruption, onSave, onResolve }) => {
  const [formData, setFormData] = useState(disruption || {});
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (disruption) setFormData(disruption); }, [disruption]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      onSave(formData.id, formData);
      setLoading(false);
      onClose();
    }, 500);
  };

  if (!disruption) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-white">
        <DialogHeader>
          <DialogTitle className="text-gray-900">Manage Disruption</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Type</label>
            <Input value={formData.type || ''} onChange={e => setFormData({...formData, type: e.target.value})} required className="bg-white text-gray-900" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-900">Severity</label>
            <Select value={formData.severity} onValueChange={v => setFormData({...formData, severity: v})}>
              <SelectTrigger className="bg-white text-gray-900"><SelectValue placeholder="Select severity" /></SelectTrigger>
              <SelectContent className="bg-white">
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="Warning">Warning</SelectItem>
                <SelectItem value="Info">Info</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter className="flex justify-between sm:justify-between mt-6">
            <Button type="button" variant="secondary" onClick={() => { onResolve(disruption.id); onClose(); }}>AI Auto-Resolve</Button>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={loading}>{loading ? 'Saving...' : 'Save Changes'}</Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};