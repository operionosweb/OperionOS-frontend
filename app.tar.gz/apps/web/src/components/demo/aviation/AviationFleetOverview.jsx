import React, { useState, useMemo } from 'react';
import { useAviationFleet } from '@/contexts/AviationFleetContext.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Plane, Edit2, Save, X, Search } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters.js';
import { calculateMonthsRemaining } from '@/lib/aviationFleetIntelligenceData.js';
import AviationFleetDetailModal from './AviationFleetDetailModal.jsx';
import AviationContractDetailModal from './AviationContractDetailModal.jsx';

const AviationFleetOverview = ({ onRunScenario }) => {
  const { aircraft, contracts, updateAircraft } = useAviationFleet();
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  
  const [selectedAircraft, setSelectedAircraft] = useState(null);
  const [selectedContract, setSelectedContract] = useState(null);

  const filteredAircraft = useMemo(() => {
    return aircraft.filter(a => {
      const matchesSearch = a.aircraftId.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = typeFilter === 'All' || a.aircraftType === typeFilter;
      const matchesStatus = statusFilter === 'All' || a.status === statusFilter;
      return matchesSearch && matchesType && matchesStatus;
    });
  }, [aircraft, searchQuery, typeFilter, statusFilter]);

  const handleEditClick = (e, a) => {
    e.stopPropagation();
    setEditingId(a.aircraftId);
    setEditForm({ monthlyCost: a.monthlyCost, utilization: a.utilization });
  };

  const handleSaveEdit = (e, id) => {
    e.stopPropagation();
    updateAircraft(id, {
      monthlyCost: Number(editForm.monthlyCost),
      utilization: Number(editForm.utilization)
    });
    setEditingId(null);
  };

  const handleCancelEdit = (e) => {
    e.stopPropagation();
    setEditingId(null);
  };

  const getStatusColor = (endDate) => {
    const months = calculateMonthsRemaining(endDate);
    if (months < 6) return 'bg-destructive/10 text-destructive border-destructive/20';
    if (months < 12) return 'bg-warning/10 text-warning border-warning/20';
    return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
  };

  const handleViewContract = (aircraftId) => {
    const contract = contracts.find(c => c.aircraftId === aircraftId);
    setSelectedAircraft(null);
    if (contract) setSelectedContract(contract);
  };

  const handleViewAircraft = (aircraftId) => {
    const ac = aircraft.find(a => a.aircraftId === aircraftId);
    setSelectedContract(null);
    if (ac) setSelectedAircraft(ac);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Fleet Overview</h2>
          <p className="text-muted-foreground text-sm">Manage {aircraft.length} active aircraft leases and utilization.</p>
        </div>
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search ID..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-9 text-sm"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[120px] h-9 text-sm">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Types</SelectItem>
              <SelectItem value="B737">B737</SelectItem>
              <SelectItem value="B787">B787</SelectItem>
              <SelectItem value="A320">A320</SelectItem>
              <SelectItem value="E195">E195</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px] h-9 text-sm">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Status</SelectItem>
              <SelectItem value="Active">Active</SelectItem>
              <SelectItem value="Near Return">Near Return</SelectItem>
              <SelectItem value="Critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block bg-card border border-border rounded-xl shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead>Aircraft ID</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Lease Type</TableHead>
              <TableHead>Monthly Cost</TableHead>
              <TableHead>Utilization</TableHead>
              <TableHead>Lease End</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAircraft.map(a => (
              <TableRow key={a.aircraftId} className="cursor-pointer hover:bg-muted/30" onClick={() => setSelectedAircraft(a)}>
                <TableCell className="font-bold flex items-center gap-2">
                  <Plane className="w-4 h-4 text-muted-foreground" /> {a.aircraftId}
                </TableCell>
                <TableCell>{a.aircraftType}</TableCell>
                <TableCell>{a.leaseType}</TableCell>
                <TableCell>
                  {editingId === a.aircraftId ? (
                    <Input 
                      type="number" 
                      value={editForm.monthlyCost} 
                      onChange={(e) => setEditForm({...editForm, monthlyCost: e.target.value})}
                      className="h-8 w-28 text-sm"
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <span className="font-medium">{formatCurrency(a.monthlyCost)}</span>
                  )}
                </TableCell>
                <TableCell>
                  {editingId === a.aircraftId ? (
                    <Input 
                      type="number" 
                      value={editForm.utilization} 
                      onChange={(e) => setEditForm({...editForm, utilization: e.target.value})}
                      className="h-8 w-20 text-sm"
                      onClick={(e) => e.stopPropagation()}
                    />
                  ) : (
                    <span>{a.utilization}%</span>
                  )}
                </TableCell>
                <TableCell>{a.leaseEndDate}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={getStatusColor(a.leaseEndDate)}>{a.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  {editingId === a.aircraftId ? (
                    <div className="flex items-center justify-end gap-2">
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600" onClick={(e) => handleSaveEdit(e, a.aircraftId)}><Save className="w-4 h-4" /></Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={handleCancelEdit}><X className="w-4 h-4" /></Button>
                    </div>
                  ) : (
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={(e) => handleEditClick(e, a)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden grid grid-cols-1 gap-4">
        {filteredAircraft.map(a => (
          <Card key={a.aircraftId} className="cursor-pointer hover:border-primary/50 transition-colors" onClick={() => setSelectedAircraft(a)}>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <Plane className="w-4 h-4 text-primary" />
                  <span className="font-bold">{a.aircraftId}</span>
                </div>
                <Badge variant="outline" className={getStatusColor(a.leaseEndDate)}>{a.status}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm mb-3">
                <div><span className="text-muted-foreground">Type:</span> {a.aircraftType}</div>
                <div><span className="text-muted-foreground">Lease:</span> {a.leaseType}</div>
                <div><span className="text-muted-foreground">Cost:</span> {formatCurrency(a.monthlyCost)}</div>
                <div><span className="text-muted-foreground">Util:</span> {a.utilization}%</div>
              </div>
              <div className="text-xs text-muted-foreground">Ends: {a.leaseEndDate}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <AviationFleetDetailModal 
        isOpen={!!selectedAircraft} 
        onClose={() => setSelectedAircraft(null)} 
        aircraft={selectedAircraft}
        onUpdate={updateAircraft}
        onViewContract={handleViewContract}
        onRunScenario={(id) => { setSelectedAircraft(null); onRunScenario(id); }}
      />

      <AviationContractDetailModal 
        isOpen={!!selectedContract}
        onClose={() => setSelectedContract(null)}
        contract={selectedContract}
        onViewAircraft={handleViewAircraft}
      />
    </div>
  );
};

export default AviationFleetOverview;