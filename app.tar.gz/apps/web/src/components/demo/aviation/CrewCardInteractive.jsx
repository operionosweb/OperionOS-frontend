import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { MapPin, Plane } from 'lucide-react';

const CrewCardInteractive = ({ member, onClick }) => {
  const getStatusColor = (status) => {
    switch(status) {
      case 'On-Duty': return 'crew-status-on-duty';
      case 'Rest': return 'crew-status-rest';
      case 'Standby': return 'crew-status-standby';
      case 'Leave': return 'crew-status-leave';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card 
      className="hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer border-border h-full flex flex-col group overflow-hidden"
      onClick={() => onClick(member)}
    >
      <CardContent className="p-0 flex flex-col h-full">
        <div className="p-5 flex items-start gap-4 border-b border-border/50 bg-muted/10 group-hover:bg-primary/5 transition-colors">
          <img 
            src={member.avatar} 
            alt={member.name} 
            className="w-14 h-14 rounded-xl object-cover border border-border shadow-sm"
          />
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start mb-1">
              <h3 className="font-bold text-foreground truncate pr-2">{member.name}</h3>
              <Badge variant="outline" className={`${getStatusColor(member.status)} shrink-0 text-[10px] px-1.5 py-0`}>
                {member.status}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground font-medium">{member.role} • {member.base}</p>
          </div>
        </div>
        
        <div className="p-5 space-y-4 flex-1 flex flex-col">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <MapPin className="w-3.5 h-3.5" />
              <span className="truncate">{member.location}</span>
            </div>
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Plane className="w-3.5 h-3.5" />
              <span className="truncate">{member.nextFlight || 'No Flight'}</span>
            </div>
          </div>

          <div className="mt-auto space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">Duty Hours</span>
                <span className="font-medium">{member.dutyHours} / {member.maxDuty}h</span>
              </div>
              <Progress value={(member.dutyHours / member.maxDuty) * 100} className="h-1.5" />
            </div>
            
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">Fatigue Risk</span>
                <span className={`font-medium ${member.fatigueRisk > 70 ? 'text-red-500' : member.fatigueRisk > 40 ? 'text-yellow-500' : 'text-green-500'}`}>
                  {member.fatigueRisk}%
                </span>
              </div>
              <Progress 
                value={member.fatigueRisk} 
                className="h-1.5" 
                indicatorClassName={member.fatigueRisk > 70 ? 'bg-red-500' : member.fatigueRisk > 40 ? 'bg-yellow-500' : 'bg-green-500'} 
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CrewCardInteractive;