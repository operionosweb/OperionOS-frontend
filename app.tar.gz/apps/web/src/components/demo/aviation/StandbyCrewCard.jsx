import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { User, MapPin, Award } from 'lucide-react';

const StandbyCrewCard = ({ crew, onClick }) => {
  const getRiskColor = (riskLevel) => {
    switch (riskLevel) {
      case 'Low': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'High': return 'bg-red-500/10 text-red-700 border-red-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Available': return 'bg-green-500/10 text-green-700 border-green-500/30';
      case 'Standby': return 'bg-blue-500/10 text-blue-700 border-blue-500/30';
      case 'On Rest': return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  return (
    <Card 
      onClick={onClick}
      className="bg-white border-2 border-gray-200 shadow-md hover:shadow-xl hover:-translate-y-1 hover:border-blue-400 cursor-pointer transition-all duration-200 active:scale-[0.98]"
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <User className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="font-bold text-gray-900">{crew.name}</p>
              <p className="text-xs text-gray-600">{crew.role}</p>
            </div>
          </div>
          <Badge className={`${getStatusColor(crew.status)} border-2 font-semibold`}>
            {crew.status}
          </Badge>
        </div>

        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              Base:
            </span>
            <span className="font-semibold text-gray-900">{crew.base}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-600">FRMS Score:</span>
            <div className="flex items-center gap-2">
              <span className="font-bold text-gray-900">{crew.frmsScore}</span>
              <Badge className={`${getRiskColor(crew.riskLevel)} border-2 text-xs`}>
                {crew.riskLevel}
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-600">Available:</span>
            <span className="font-semibold text-gray-900">{crew.availabilityHours}h</span>
          </div>

          <div className="pt-2 border-t-2 border-gray-200">
            <div className="flex items-center gap-1 text-gray-600 mb-1">
              <Award className="w-3 h-3" />
              <span className="text-xs">Certifications:</span>
            </div>
            <div className="flex flex-wrap gap-1">
              {crew.certifications.map((cert, idx) => (
                <Badge key={idx} className="bg-blue-500/10 text-blue-700 border-2 border-blue-500/30 text-xs">
                  {cert.type}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StandbyCrewCard;