import React, { useState, useEffect } from 'react';
import { Bell, AlertTriangle, Clock, CheckCircle, Archive, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const NotificationDetailModal = ({ isOpen, onClose, notification, onSave }) => {
  const [formData, setFormData] = useState(notification || {});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (notification) {
      setFormData(notification);
    }
  }, [notification]);

  if (!notification) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    toast.success(successMessage);
    setIsLoading(false);
    if (actionName === 'archive' || actionName === 'read') onClose();
  };

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'High': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const footerActions = (
    <>
      <Button variant="outline" onClick={() => handleAction('snooze', 'Notification snoozed for 1 hour')}>
        <Clock className="w-4 h-4 mr-2" /> Snooze
      </Button>
      <Button variant="outline" onClick={() => handleAction('archive', 'Notification archived', { status: 'Archived' })}>
        <Archive className="w-4 h-4 mr-2" /> Archive
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={() => handleAction('read', 'Marked as read', { status: 'Read' })} disabled={isLoading}>
        <CheckCircle className="w-4 h-4 mr-2" /> Mark as Read
      </Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title="Notification Details"
      icon={Bell}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-2xl"
    >
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4 p-4 border border-border rounded-xl bg-muted/10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className={getSeverityColor(formData.severity)}>{formData.severity}</Badge>
              <Badge variant="secondary">{formData.type}</Badge>
              <span className="text-xs text-muted-foreground">{new Date(formData.timestamp).toLocaleString()}</span>
            </div>
            <h3 className="text-lg font-bold text-foreground">{formData.title}</h3>
          </div>
        </div>

        <div className="p-4 border border-border rounded-xl bg-card">
          <h4 className="text-sm font-semibold text-foreground mb-2">Message Content</h4>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {formData.description}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label>Update Priority</Label>
            <Select value={formData.severity} onValueChange={(v) => handleChange('severity', v)}>
              <SelectTrigger><SelectValue placeholder="Select priority" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Related Items</Label>
            <Button variant="secondary" className="w-full justify-start" onClick={() => toast.info('Opening related flight details...')}>
              View Related Flight OP102
            </Button>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Resolution Notes</Label>
          <Textarea 
            placeholder="Add notes regarding how this alert was handled..." 
            value={formData.notes || ''} 
            onChange={(e) => handleChange('notes', e.target.value)}
            className="min-h-[100px]"
          />
        </div>
      </div>
    </ModalBase>
  );
};