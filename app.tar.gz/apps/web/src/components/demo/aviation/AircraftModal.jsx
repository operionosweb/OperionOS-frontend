import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { toast } from 'sonner';
import { Wrench } from 'lucide-react';

const AircraftModal = ({ isOpen, onClose, aircraft, onSave }) => {
  const [formData, setFormData] = useState(aircraft || {});

  useEffect(() => {
    if (aircraft) setFormData(aircraft);
  }, [aircraft]);

  if (!aircraft) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(formData);
    toast.success(`Aircraft ${formData.registration} updated`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Wrench className="w-5 h-5 text-primary" />
            Aircraft Profile: {formData.registration}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Registration</Label>
              <Input value={formData.registration || ''} disabled className="bg-muted" />
            </div>
            <div className="space-y-2">
              <Label>Type</Label>
              <Input value={formData.type || ''} onChange={(e) => handleChange('type', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Operational">Operational</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Grounded">Grounded</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Flight Hours</Label>
              <Input type="number" value={formData.flightHours || 0} onChange={(e) => handleChange('flightHours', parseInt(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label>Next Maintenance</Label>
              <Input type="datetime-local" value={formData.nextMaintenance ? new Date(formData.nextMaintenance).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('nextMaintenance', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Utilization (%)</Label>
              <Input type="number" value={formData.utilization || 0} onChange={(e) => handleChange('utilization', parseInt(e.target.value))} />
            </div>
          </div>

          <div className="col-span-1 md:col-span-2 space-y-2">
            <Label>Technical Issues & Notes</Label>
            <Textarea 
              placeholder="Log any technical issues or maintenance notes..." 
              value={formData.notes || ''} 
              onChange={(e) => handleChange('notes', e.target.value)}
              className="min-h-[100px]"
            />
          </div>
        </div>

        <DialogFooter className="flex flex-wrap gap-2 sm:justify-between">
          <Button variant="outline" onClick={() => toast.info('Maintenance Scheduled')}>Schedule Maintenance</Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Close</Button>
            <Button onClick={handleSave}>Update Aircraft</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AircraftModal;