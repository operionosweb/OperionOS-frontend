import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Switch } from '@/components/ui/switch.jsx';
import { Label } from '@/components/ui/label.jsx';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const data = [
  { name: 'Total Cost (€M)', before: 45.2, after: 32.8 },
  { name: 'Delay Mins (k)', before: 125, after: 45 },
  { name: 'Disruptions', before: 850, after: 320 },
];

const BeforeAfterComparison = () => {
  const [showPercentage, setShowPercentage] = useState(false);

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg">Impact Analysis</CardTitle>
        <div className="flex items-center space-x-2">
          <Switch 
            id="view-toggle" 
            checked={showPercentage} 
            onCheckedChange={setShowPercentage} 
          />
          <Label htmlFor="view-toggle" className="text-xs text-muted-foreground">Show % Improvement</Label>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[250px] w-full mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b7280' }} />
              <Tooltip 
                cursor={{ fill: '#f3f4f6' }}
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Legend iconType="circle" wrapperStyle={{ fontSize: '12px' }} />
              <Bar dataKey="before" name="Without Operion" fill="#94a3b8" radius={[4, 4, 0, 0]} maxBarSize={40} />
              <Bar dataKey="after" name="With Operion" fill="#2563eb" radius={[4, 4, 0, 0]} maxBarSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

export default BeforeAfterComparison;