import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Plane } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import FlightDetailsModal from './FlightDetailsModal.jsx';

const FlightOperationsSection = () => {
  const { flights, updateFlight } = useDemo();
  const [selectedFlight, setSelectedFlight] = useState(null);

  const getStatusColor = (status) => {
    switch(status) {
      case 'On-Time': return 'bg-green-100 text-green-800';
      case 'Delayed': return 'bg-yellow-100 text-yellow-800';
      case 'Boarding': return 'bg-orange-100 text-orange-800';
      case 'Cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="flex-auto-height gap-4 sm:gap-5 md:gap-6 animate-in fade-in w-full">
      <div className="flex justify-between items-center">
        <h2 className="text-xl sm:text-2xl font-bold text-foreground">Flight Operations</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-5 md:gap-6 w-full">
        <Card className="h-auto w-full">
          <CardHeader className="pb-2 p-4 sm:p-5"><CardTitle className="text-xs sm:text-sm text-muted-foreground">Active Flights</CardTitle></CardHeader>
          <CardContent className="p-4 sm:p-5 pt-0"><div className="text-2xl sm:text-3xl font-bold">{flights.length}</div></CardContent>
        </Card>
        <Card className="h-auto w-full">
          <CardHeader className="pb-2 p-4 sm:p-5"><CardTitle className="text-xs sm:text-sm text-muted-foreground">Delayed</CardTitle></CardHeader>
          <CardContent className="p-4 sm:p-5 pt-0"><div className="text-2xl sm:text-3xl font-bold text-yellow-600">{flights.filter(f => f.status === 'Delayed').length}</div></CardContent>
        </Card>
        <Card className="h-auto w-full">
          <CardHeader className="pb-2 p-4 sm:p-5"><CardTitle className="text-xs sm:text-sm text-muted-foreground">On-Time Performance</CardTitle></CardHeader>
          <CardContent className="p-4 sm:p-5 pt-0"><div className="text-2xl sm:text-3xl font-bold text-green-600">84%</div></CardContent>
        </Card>
      </div>

      <Card className="h-auto w-full">
        <CardHeader className="p-4 sm:p-5">
          <CardTitle className="text-base sm:text-lg">Live Flight Board</CardTitle>
        </CardHeader>
        <CardContent className="p-0 sm:p-2 md:p-4 overflow-x-auto scrollable-x">
          <Table className="min-w-[600px]">
            <TableHeader>
              <TableRow>
                <TableHead className="text-xs sm:text-sm">Flight</TableHead>
                <TableHead className="text-xs sm:text-sm">Route</TableHead>
                <TableHead className="text-xs sm:text-sm">Aircraft</TableHead>
                <TableHead className="text-xs sm:text-sm">Departure</TableHead>
                <TableHead className="text-xs sm:text-sm">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {flights.slice(0, 15).map(flight => (
                <TableRow 
                  key={flight.id} 
                  className="cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => setSelectedFlight(flight)}
                >
                  <TableCell className="font-medium flex items-center gap-2 text-xs sm:text-sm">
                    <Plane className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground shrink-0" /> {flight.flightNumber}
                  </TableCell>
                  <TableCell className="text-xs sm:text-sm">{flight.route}</TableCell>
                  <TableCell className="text-xs sm:text-sm">{flight.aircraft}</TableCell>
                  <TableCell className="text-xs sm:text-sm">{new Date(flight.departure).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`text-[10px] sm:text-xs ${getStatusColor(flight.status)}`}>{flight.status}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <FlightDetailsModal 
        isOpen={!!selectedFlight} 
        onClose={() => setSelectedFlight(null)} 
        flight={selectedFlight} 
        onSave={updateFlight} 
      />
    </div>
  );
};

export default FlightOperationsSection;