import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { TrendingUp, TrendingDown, DollarSign, AlertTriangle, Users, Plane } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';

const KPIWidget = ({ label, value, unit, trend, trendValue, icon: Icon, color }) => {
  const isPositive = trend === 'up';
  const TrendIcon = isPositive ? TrendingUp : TrendingDown;
  
  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md hover:shadow-lg transition-all">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className={`p-2 rounded-lg ${color}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div className={`flex items-center gap-1 text-xs font-bold ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            <TrendIcon className="w-3 h-3" />
            {trendValue}
          </div>
        </div>
        <div>
          <p className="text-2xl font-bold text-gray-900">{value}{unit}</p>
          <p className="text-xs text-gray-600 font-medium uppercase tracking-wider mt-1">{label}</p>
        </div>
        <div className="mt-3 h-8 flex items-end gap-0.5">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className={`flex-1 ${color} rounded-sm`} style={{ height: `${Math.random() * 100}%` }}></div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

const AdvancedKPIWidgets = () => {
  const { aviationFlights, aviationCrew, aviationDisruptions } = useDemo();
  const [onTimePerf, setOnTimePerf] = useState(87.3);
  const [costBurnRate, setCostBurnRate] = useState(1247);
  const [crewRisk, setCrewRisk] = useState(12);
  const [aircraftUtil, setAircraftUtil] = useState(78.5);

  useEffect(() => {
    const interval = setInterval(() => {
      setOnTimePerf(prev => Math.max(70, Math.min(95, prev + (Math.random() - 0.5) * 2)));
      setCostBurnRate(prev => Math.max(1000, Math.min(1500, prev + (Math.random() - 0.5) * 50)));
      setCrewRisk(prev => Math.max(5, Math.min(20, prev + Math.floor((Math.random() - 0.5) * 3))));
      setAircraftUtil(prev => Math.max(60, Math.min(90, prev + (Math.random() - 0.5) * 2)));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const activeDisruptions = aviationDisruptions.filter(d => d.status !== 'Resolved');
  const criticalCount = activeDisruptions.filter(d => d.severity === 'Critical').length;
  const warningCount = activeDisruptions.filter(d => d.severity === 'Warning').length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
      <KPIWidget
        label="On-Time Performance"
        value={onTimePerf.toFixed(1)}
        unit="%"
        trend="up"
        trendValue="+2.3%"
        icon={Plane}
        color="bg-green-500/10 text-green-600"
      />
      <KPIWidget
        label="Cost Burn Rate"
        value={`€${costBurnRate}`}
        unit="/min"
        trend="down"
        trendValue="-5.2%"
        icon={DollarSign}
        color="bg-yellow-500/10 text-yellow-600"
      />
      <Card className="bg-white border-2 border-gray-200 shadow-md">
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="p-2 rounded-lg bg-red-500/10 text-red-600">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold text-gray-900">{activeDisruptions.length}</p>
            <p className="text-xs text-gray-600 font-medium uppercase tracking-wider mt-1">Active Disruptions</p>
          </div>
          <div className="mt-3 flex gap-2 text-xs">
            <span className="px-2 py-1 bg-red-500/10 text-red-700 rounded font-semibold">Critical: {criticalCount}</span>
            <span className="px-2 py-1 bg-yellow-500/10 text-yellow-700 rounded font-semibold">Warning: {warningCount}</span>
          </div>
        </CardContent>
      </Card>
      <KPIWidget
        label="Crew Legality Risk"
        value={crewRisk}
        unit=" at-risk"
        trend="down"
        trendValue="-3"
        icon={Users}
        color="bg-blue-500/10 text-blue-600"
      />
      <KPIWidget
        label="Aircraft Utilization"
        value={aircraftUtil.toFixed(1)}
        unit="%"
        trend="up"
        trendValue="+1.8%"
        icon={Plane}
        color="bg-cyan-500/10 text-cyan-600"
      />
    </div>
  );
};

export default AdvancedKPIWidgets;