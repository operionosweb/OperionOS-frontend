import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { 
  User, Calendar, ShieldAlert, Award, TrendingUp, 
  DollarSign, Zap, FileText, MapPin, Mail, Phone, Clock, AlertTriangle
} from 'lucide-react';
import { toast } from 'sonner';

import { CrewPerformanceCharts, CrewCostCharts } from './CrewCharts.jsx';
import CrewScheduleCalendar from './CrewScheduleCalendar.jsx';
import { AssignToFlightModal, RequestTimeOffModal } from './CrewActionModals.jsx';

const CrewProfileModal = ({ isOpen, onClose, crewMember }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [assignModalOpen, setAssignModalOpen] = useState(false);
  const [timeOffModalOpen, setTimeOffModalOpen] = useState(false);

  if (!crewMember) return null;

  const getStatusColor = (status) => {
    switch(status) {
      case 'On-Duty': return 'crew-status-on-duty';
      case 'Rest': return 'crew-status-rest';
      case 'Standby': return 'crew-status-standby';
      case 'Leave': return 'crew-status-leave';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const handleQuickAction = (action) => {
    if (action === 'standby') {
      toast.success(`${crewMember.name} moved to Standby pool.`);
    } else if (action === 'remove') {
      toast.success(`${crewMember.name} removed from current assignment.`);
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="modal-container max-w-6xl p-0 border-none sm:rounded-xl">
          <div className="modal-body">
            {/* Minimal Header for Title and Close Button */}
            <DialogHeader className="modal-header">
              <DialogTitle className="text-lg sm:text-xl font-bold">Crew Profile</DialogTitle>
            </DialogHeader>

            {/* Scrollable Content Area */}
            <div className="modal-content">
              
              {/* Profile Header - Scrolls naturally with content */}
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 bg-card p-4 rounded-xl border border-border">
                <div className="flex items-center gap-3 sm:gap-4">
                  <img src={crewMember.avatar} alt={crewMember.name} className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover border-2 border-border shadow-sm shrink-0" />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 sm:gap-3 mb-1 flex-wrap">
                      <h2 className="text-xl sm:text-2xl font-bold text-foreground truncate">{crewMember.name}</h2>
                      <Badge variant="outline" className={getStatusColor(crewMember.status)}>{crewMember.status}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground font-medium break-words">
                      {crewMember.role} • Base: {crewMember.base} • ID: {crewMember.id}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <Button variant="outline" size="sm" className="text-xs sm:text-sm flex-1 sm:flex-none" onClick={() => setAssignModalOpen(true)}>Assign Flight</Button>
                  <Button variant="outline" size="sm" className="text-xs sm:text-sm flex-1 sm:flex-none" onClick={() => handleQuickAction('standby')}>Send to Standby</Button>
                  <Button variant="outline" size="sm" className="text-xs sm:text-sm flex-1 sm:flex-none" onClick={() => setTimeOffModalOpen(true)}>Request Time Off</Button>
                </div>
              </div>

              {/* Tabs Navigation */}
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col gap-4">
                <div className="w-full overflow-x-auto scrollable-x hide-scrollbar pb-1 border-b border-border">
                  <TabsList className="flex w-max min-w-full justify-start h-auto p-0 bg-transparent gap-2 sm:gap-6">
                    {[
                      { id: 'overview', icon: User, label: 'Overview' },
                      { id: 'schedule', icon: Calendar, label: 'Schedule' },
                      { id: 'duty', icon: ShieldAlert, label: 'Duty & Legality' },
                      { id: 'certs', icon: Award, label: 'Certifications' },
                      { id: 'performance', icon: TrendingUp, label: 'Performance' },
                      { id: 'cost', icon: DollarSign, label: 'Cost Profile' },
                      { id: 'ai', icon: Zap, label: 'AI Insights' },
                      { id: 'docs', icon: FileText, label: 'Documents' },
                    ].map(tab => (
                      <TabsTrigger 
                        key={tab.id} 
                        value={tab.id}
                        className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-2 pb-2 pt-1 text-xs sm:text-sm text-muted-foreground data-[state=active]:text-foreground whitespace-nowrap min-w-max"
                      >
                        <tab.icon className="w-3 h-3 sm:w-4 sm:h-4 mr-1.5 sm:mr-2" /> {tab.label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </div>

                {/* Tab Contents */}
                <div className="w-full h-auto">
                  {/* 1. OVERVIEW */}
                  <TabsContent value="overview" className="m-0 flex flex-col gap-4 sm:gap-5 md:gap-6 animate-in fade-in h-auto">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5 md:gap-6">
                      <div className="col-span-1 md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                        <div className="p-3 sm:p-4 border border-border rounded-xl bg-card">
                          <p className="text-xs sm:text-sm text-muted-foreground mb-1 flex items-center gap-2"><MapPin className="w-3 h-3 sm:w-4 sm:h-4" /> Current Location</p>
                          <p className="text-base sm:text-lg font-bold break-words">{crewMember.location}</p>
                        </div>
                        <div className="p-3 sm:p-4 border border-border rounded-xl bg-card">
                          <p className="text-xs sm:text-sm text-muted-foreground mb-1 flex items-center gap-2"><Clock className="w-3 h-3 sm:w-4 sm:h-4" /> Next Flight</p>
                          <p className="text-base sm:text-lg font-bold break-words">{crewMember.nextFlight || 'None Assigned'}</p>
                          {crewMember.nextFlight && <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">{new Date(crewMember.nextFlightTime).toLocaleString()}</p>}
                        </div>
                        <div className="p-3 sm:p-4 border border-border rounded-xl bg-card">
                          <p className="text-xs sm:text-sm text-muted-foreground mb-1">Total Flight Hours</p>
                          <p className="text-base sm:text-lg font-bold">{crewMember.flightHours.toLocaleString()} hrs</p>
                        </div>
                        <div className="p-3 sm:p-4 border border-border rounded-xl bg-card">
                          <p className="text-xs sm:text-sm text-muted-foreground mb-1">Years of Service</p>
                          <p className="text-base sm:text-lg font-bold">{crewMember.yearsOfService} Years</p>
                        </div>
                      </div>
                      
                      <div className="col-span-1 flex flex-col gap-3 sm:gap-4">
                        <div className="p-4 sm:p-5 border border-border rounded-xl bg-card">
                          <h3 className="font-bold mb-3 sm:mb-4 text-sm sm:text-base">Contact Information</h3>
                          <div className="flex flex-col gap-2 sm:gap-3">
                            <div className="flex items-center gap-2 sm:gap-3 text-xs sm:text-sm">
                              <Mail className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground shrink-0" />
                              <span className="text-foreground break-all">{crewMember.email}</span>
                            </div>
                            <div className="flex items-center gap-2 sm:gap-3 text-xs sm:text-sm">
                              <Phone className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground shrink-0" />
                              <span className="text-foreground break-words">{crewMember.phone}</span>
                            </div>
                          </div>
                          <Button variant="secondary" className="w-full mt-4 sm:mt-6 text-xs sm:text-sm">Edit Profile</Button>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  {/* 2. SCHEDULE */}
                  <TabsContent value="schedule" className="m-0 flex flex-col gap-3 sm:gap-4 animate-in fade-in h-auto">
                    <CrewScheduleCalendar crewMember={crewMember} />
                  </TabsContent>

                  {/* 3. DUTY & LEGALITY */}
                  <TabsContent value="duty" className="m-0 flex flex-col gap-4 sm:gap-5 md:gap-6 animate-in fade-in h-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5 md:gap-6">
                      <div className="p-4 sm:p-5 md:p-6 border border-border rounded-xl bg-card flex flex-col gap-4 sm:gap-5 md:gap-6">
                        <h3 className="font-bold text-base sm:text-lg flex items-center gap-2"><ShieldAlert className="w-4 h-4 sm:w-5 sm:h-5 text-primary" /> Duty Hours Tracking</h3>
                        
                        <div className="flex flex-col gap-1.5 sm:gap-2">
                          <div className="flex justify-between text-xs sm:text-sm">
                            <span className="text-muted-foreground">Monthly Duty (Max 100h)</span>
                            <span className="font-bold">{crewMember.dutyHours}h / 100h</span>
                          </div>
                          <Progress value={(crewMember.dutyHours / 100) * 100} className="h-1.5 sm:h-2" indicatorClassName={crewMember.dutyHours > 90 ? 'bg-red-500' : 'bg-primary'} />
                        </div>

                        <div className="flex flex-col gap-1.5 sm:gap-2">
                          <div className="flex justify-between text-xs sm:text-sm">
                            <span className="text-muted-foreground">Weekly Flight Time (Max 32h)</span>
                            <span className="font-bold">24h / 32h</span>
                          </div>
                          <Progress value={(24 / 32) * 100} className="h-1.5 sm:h-2" indicatorClassName="bg-yellow-500" />
                        </div>

                        <div className="flex flex-col gap-1.5 sm:gap-2">
                          <div className="flex justify-between text-xs sm:text-sm">
                            <span className="text-muted-foreground">Minimum Rest Period</span>
                            <span className="font-bold text-green-600">Cleared (14h elapsed)</span>
                          </div>
                          <Progress value={100} className="h-1.5 sm:h-2" indicatorClassName="bg-green-500" />
                        </div>
                      </div>

                      <div className="p-4 sm:p-5 md:p-6 border border-border rounded-xl bg-card flex flex-col gap-3 sm:gap-4">
                        <h3 className="font-bold text-base sm:text-lg flex items-center gap-2"><AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-orange-500" /> Fatigue Risk Management</h3>
                        <div className="flex items-center justify-between p-3 sm:p-4 bg-muted/30 rounded-lg border border-border">
                          <div>
                            <p className="text-xs sm:text-sm text-muted-foreground">Current Risk Score</p>
                            <p className={`text-2xl sm:text-3xl font-bold ${crewMember.fatigueRisk > 70 ? 'text-red-500' : crewMember.fatigueRisk > 40 ? 'text-yellow-500' : 'text-green-500'}`}>
                              {crewMember.fatigueRisk}/100
                            </p>
                          </div>
                          <Badge variant="outline" className={crewMember.fatigueRisk > 70 ? 'border-red-500 text-red-500' : 'border-green-500 text-green-500'}>
                            {crewMember.fatigueRisk > 70 ? 'High Risk' : 'Optimal'}
                          </Badge>
                        </div>
                        <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                          Based on recent sector lengths, time zone crossings, and rest periods, the AI model predicts fatigue levels will remain within acceptable limits for the next 48 hours.
                        </p>
                      </div>
                    </div>
                  </TabsContent>

                  {/* 4. CERTIFICATIONS */}
                  <TabsContent value="certs" className="m-0 flex flex-col gap-4 sm:gap-5 md:gap-6 animate-in fade-in h-auto">
                    <div className="flex justify-between items-center mb-2 sm:mb-4">
                      <h3 className="font-bold text-base sm:text-lg">Active Certifications</h3>
                      <Button variant="outline" size="sm" className="text-xs sm:text-sm">Add Certification</Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                      {crewMember.certifications.map((cert, i) => (
                        <div key={i} className="flex items-center justify-between p-3 sm:p-4 border border-border rounded-xl bg-card hover:shadow-sm transition-all">
                          <div className="min-w-0 flex-1 pr-2">
                            <h4 className="font-bold text-sm sm:text-base text-foreground truncate">{cert.name}</h4>
                            <p className="text-xs sm:text-sm text-muted-foreground">Expires: {new Date(cert.expiry).toLocaleDateString()}</p>
                          </div>
                          <Badge variant={cert.status === 'Valid' ? 'outline' : 'destructive'} className={`shrink-0 text-[10px] sm:text-xs ${cert.status === 'Valid' ? 'bg-green-50 text-green-700 border-green-200' : ''}`}>
                            {cert.status}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  {/* 5. PERFORMANCE */}
                  <TabsContent value="performance" className="m-0 flex flex-col gap-3 sm:gap-4 animate-in fade-in h-auto">
                    <CrewPerformanceCharts performance={crewMember.performance} />
                  </TabsContent>

                  {/* 6. COST PROFILE */}
                  <TabsContent value="cost" className="m-0 flex flex-col gap-3 sm:gap-4 animate-in fade-in h-auto">
                    <CrewCostCharts costProfile={crewMember.costProfile} />
                  </TabsContent>

                  {/* 7. AI INSIGHTS */}
                  <TabsContent value="ai" className="m-0 flex flex-col gap-3 sm:gap-4 animate-in fade-in h-auto">
                    {crewMember.aiInsights.map((insight, i) => (
                      <div key={i} className="p-4 sm:p-5 border border-primary/20 rounded-xl bg-primary/5 flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4">
                        <div className="flex items-start gap-3 sm:gap-4">
                          <div className="p-1.5 sm:p-2 bg-primary/10 rounded-lg text-primary shrink-0 mt-0.5 sm:mt-1">
                            <Zap className="w-4 h-4 sm:w-5 sm:h-5" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <h4 className="font-bold text-sm sm:text-base text-foreground">{insight.type} Insight</h4>
                              <Badge variant="secondary" className="text-[10px] sm:text-xs">{insight.confidence}% Confidence</Badge>
                            </div>
                            <p className="text-xs sm:text-sm text-muted-foreground">{insight.message}</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2 shrink-0 w-full md:w-auto">
                          <Button variant="outline" size="sm" className="flex-1 md:flex-none text-xs sm:text-sm">View Details</Button>
                          <Button size="sm" className="flex-1 md:flex-none text-xs sm:text-sm">Apply</Button>
                        </div>
                      </div>
                    ))}
                  </TabsContent>

                  {/* 8. DOCUMENTS */}
                  <TabsContent value="docs" className="m-0 flex flex-col gap-3 sm:gap-4 animate-in fade-in h-auto">
                    <div className="flex justify-between items-center mb-2 sm:mb-4">
                      <h3 className="font-bold text-base sm:text-lg">Compliance Documents</h3>
                      <Button variant="outline" size="sm" className="text-xs sm:text-sm">Upload Document</Button>
                    </div>
                    <div className="flex flex-col gap-2 sm:gap-3">
                      {['Employment Contract.pdf', 'Background Check 2025.pdf', 'Training Certificate A350.pdf'].map((doc, i) => (
                        <div key={i} className="flex items-center justify-between p-3 sm:p-4 border border-border rounded-xl bg-card hover:bg-muted/50 transition-colors cursor-pointer">
                          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1 pr-2">
                            <FileText className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground shrink-0" />
                            <span className="font-medium text-xs sm:text-sm truncate">{doc}</span>
                          </div>
                          <Button variant="ghost" size="sm" className="shrink-0 text-xs sm:text-sm">Download</Button>
                        </div>
                      ))}
                    </div>
                  </TabsContent>
                </div>
              </Tabs>
            </div>
            
            {/* Footer Section */}
            <div className="modal-footer">
              <Button variant="outline" className="w-full sm:w-auto" onClick={onClose}>Close Profile</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AssignToFlightModal isOpen={assignModalOpen} onClose={() => setAssignModalOpen(false)} crewMember={crewMember} />
      <RequestTimeOffModal isOpen={timeOffModalOpen} onClose={() => setTimeOffModalOpen(false)} crewMember={crewMember} />
    </>
  );
};

export default CrewProfileModal;