import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { toast } from 'sonner';
import { MessageSquare } from 'lucide-react';

const MessageDetailModal = ({ isOpen, onClose, message, onSave }) => {
  const [formData, setFormData] = useState(message || {});

  useEffect(() => {
    if (message) setFormData(message);
  }, [message]);

  if (!message) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(formData);
    toast.success(`Message updated`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <MessageSquare className="w-5 h-5 text-primary" />
            Message Details
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 gap-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>From</Label>
              <Input value={formData.from || ''} disabled className="bg-muted" />
            </div>
            <div className="space-y-2">
              <Label>To</Label>
              <Input value={formData.to || ''} onChange={(e) => handleChange('to', e.target.value)} />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>Subject</Label>
            <Input value={formData.subject || ''} onChange={(e) => handleChange('subject', e.target.value)} />
          </div>

          <div className="space-y-2">
            <Label>Message Body</Label>
            <Textarea 
              value={formData.body || ''} 
              onChange={(e) => handleChange('body', e.target.value)}
              className="min-h-[150px]"
            />
          </div>
        </div>

        <DialogFooter className="flex flex-wrap gap-2 sm:justify-between">
          <Button variant="outline" onClick={() => toast.info('Reply Sent')}>Reply</Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Close</Button>
            <Button onClick={handleSave}>Save Draft</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MessageDetailModal;