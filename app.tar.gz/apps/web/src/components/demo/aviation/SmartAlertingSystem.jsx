import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Bell, AlertTriangle } from 'lucide-react';

const SmartAlertingSystem = ({ alerts, onTakeAction }) => {
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'Critical': return 'bg-red-500/10 text-red-700 border-red-500/30';
      case 'High': return 'bg-orange-500/10 text-orange-700 border-orange-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'Low': return 'bg-blue-500/10 text-blue-700 border-blue-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  return (
    <Card className="bg-white border-2 border-gray-200 shadow-md">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Bell className="w-5 h-5" />
          Smart Alerting System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {alerts.map((alert, idx) => (
          <div key={idx} className={`p-3 border-2 rounded-lg ${
            alert.priority === 'Critical' ? 'bg-red-50 border-red-200' :
            alert.priority === 'High' ? 'bg-orange-50 border-orange-200' :
            'bg-gray-50 border-gray-200'
          }`}>
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className={`w-4 h-4 ${
                  alert.priority === 'Critical' ? 'text-red-600' :
                  alert.priority === 'High' ? 'text-orange-600' :
                  'text-gray-600'
                }`} />
                <p className="font-semibold text-gray-900 text-sm">{alert.message}</p>
              </div>
              <Badge className={`${getPriorityColor(alert.priority)} border-2 font-semibold text-xs`}>
                {alert.priority}
              </Badge>
            </div>
            <p className="text-xs text-gray-700 mb-2">Suggested: {alert.suggestedAction}</p>
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-600">Escalation: {alert.escalationStatus}</span>
              <Button size="sm" onClick={() => onTakeAction?.(alert)}>
                Take Action
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

export default SmartAlertingSystem;