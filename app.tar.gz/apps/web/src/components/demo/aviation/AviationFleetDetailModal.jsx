import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Plane, Calendar, DollarSign, Activity, FileText, Edit2, Save, X, Calculator, Wrench } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters.js';
import { calculateMonthsRemaining } from '@/lib/aviationFleetIntelligenceData.js';
import { useNavigate } from 'react-router-dom';

const AviationFleetDetailModal = ({ isOpen, onClose, aircraft, onUpdate, onViewContract, onRunScenario }) => {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({});

  if (!aircraft) return null;

  const handleEditToggle = () => {
    if (isEditing) {
      setIsEditing(false);
    } else {
      setEditForm({
        monthlyCost: aircraft.monthlyCost,
        utilization: aircraft.utilization,
        leaseEndDate: aircraft.leaseEndDate
      });
      setIsEditing(true);
    }
  };

  const handleSave = () => {
    onUpdate(aircraft.aircraftId, {
      monthlyCost: Number(editForm.monthlyCost),
      utilization: Number(editForm.utilization),
      leaseEndDate: editForm.leaseEndDate
    });
    setIsEditing(false);
  };

  const monthsRemaining = calculateMonthsRemaining(aircraft.leaseEndDate);
  const statusColor = monthsRemaining < 6 ? 'bg-destructive/10 text-destructive border-destructive/20' : 
                      monthsRemaining < 12 ? 'bg-warning/10 text-warning border-warning/20' : 
                      'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-card">
        <div className="bg-muted/30 p-6 border-b border-border flex justify-between items-start">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              <Plane className="w-5 h-5" />
            </div>
            <div>
              <DialogTitle className="text-2xl font-bold">{aircraft.aircraftId}</DialogTitle>
              <DialogDescription className="text-sm font-medium">{aircraft.aircraftType} • {aircraft.leaseType} Lease</DialogDescription>
            </div>
          </div>
          <Badge variant="outline" className={statusColor}>{aircraft.status}</Badge>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <DollarSign className="w-3 h-3" /> Monthly Cost
              </label>
              {isEditing ? (
                <Input 
                  type="number" 
                  value={editForm.monthlyCost} 
                  onChange={(e) => setEditForm({...editForm, monthlyCost: e.target.value})}
                  className="h-8 text-sm"
                />
              ) : (
                <p className="text-lg font-bold">{formatCurrency(aircraft.monthlyCost)}</p>
              )}
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <Activity className="w-3 h-3" /> Utilization
              </label>
              {isEditing ? (
                <div className="flex items-center gap-2">
                  <Input 
                    type="number" 
                    value={editForm.utilization} 
                    onChange={(e) => setEditForm({...editForm, utilization: e.target.value})}
                    className="h-8 text-sm w-20"
                  />
                  <span className="text-sm">%</span>
                </div>
              ) : (
                <p className="text-lg font-bold">{aircraft.utilization}%</p>
              )}
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <Calendar className="w-3 h-3" /> Lease End Date
              </label>
              {isEditing ? (
                <Input 
                  type="date" 
                  value={editForm.leaseEndDate} 
                  onChange={(e) => setEditForm({...editForm, leaseEndDate: e.target.value})}
                  className="h-8 text-sm"
                />
              ) : (
                <p className="text-lg font-bold">{aircraft.leaseEndDate}</p>
              )}
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <Wrench className="w-3 h-3" /> Est. Maintenance
              </label>
              <p className="text-lg font-bold text-muted-foreground">{formatCurrency(aircraft.maintenanceCost)}</p>
            </div>
          </div>

          <div className="bg-primary/5 border border-primary/10 rounded-xl p-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-foreground">Total Monthly Liability</p>
              <p className="text-xs text-muted-foreground">Lease + Maintenance</p>
            </div>
            <p className="text-xl font-extrabold text-primary">{formatCurrency(aircraft.monthlyCost + aircraft.maintenanceCost)}</p>
          </div>

          <div className="flex flex-wrap gap-3 pt-4 border-t border-border">
            {isEditing ? (
              <>
                <Button onClick={handleSave} className="flex-1"><Save className="w-4 h-4 mr-2" /> Save Changes</Button>
                <Button variant="outline" onClick={handleEditToggle} className="flex-1"><X className="w-4 h-4 mr-2" /> Cancel</Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={handleEditToggle} className="flex-1"><Edit2 className="w-4 h-4 mr-2" /> Edit Details</Button>
                <Button variant="outline" onClick={() => onViewContract(aircraft.aircraftId)} className="flex-1"><FileText className="w-4 h-4 mr-2" /> View Contract</Button>
                <Button onClick={() => onRunScenario(aircraft.aircraftId)} className="flex-1 bg-primary text-primary-foreground"><Calculator className="w-4 h-4 mr-2" /> Run Scenario</Button>
                <Button variant="secondary" onClick={() => navigate(`/demo/aviation/aircraft/${aircraft.aircraftId}`)} className="w-full mt-2">View Full Page</Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AviationFleetDetailModal;