import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { toast } from 'sonner';
import { TrendingUp } from 'lucide-react';

const FinancialModal = ({ isOpen, onClose, financial, onSave }) => {
  const [formData, setFormData] = useState(financial || {});

  useEffect(() => {
    if (financial) setFormData(financial);
  }, [financial]);

  if (!financial) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(formData);
    toast.success(`Financial record updated`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <TrendingUp className="w-5 h-5 text-primary" />
            Financial Details
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Category</Label>
              <Input value={formData.category || ''} onChange={(e) => handleChange('category', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input value={formData.description || ''} onChange={(e) => handleChange('description', e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Amount (€)</Label>
              <Input type="number" value={formData.amount || 0} onChange={(e) => handleChange('amount', parseInt(e.target.value))} />
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Budget Allocated (€)</Label>
              <Input type="number" value={formData.budget || 0} onChange={(e) => handleChange('budget', parseInt(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label>Date</Label>
              <Input type="datetime-local" value={formData.date ? new Date(formData.date).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('date', e.target.value)} />
            </div>
          </div>

          <div className="col-span-1 md:col-span-2 space-y-2">
            <Label>Notes & Justification</Label>
            <Textarea 
              placeholder="Add financial notes..." 
              value={formData.notes || ''} 
              onChange={(e) => handleChange('notes', e.target.value)}
              className="min-h-[80px]"
            />
          </div>
        </div>

        <DialogFooter className="flex flex-wrap gap-2 sm:justify-between">
          <Button variant="outline" onClick={() => toast.info('Receipt Downloaded')}>Download Receipt</Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Close</Button>
            <Button onClick={handleSave}>Update Record</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FinancialModal;