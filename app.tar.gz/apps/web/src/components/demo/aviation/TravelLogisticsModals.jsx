import React, { useState, useEffect } from 'react';
import { Briefcase, MapPin, Calendar, CreditCard, FileText, Car } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const BookingDetailModal = ({ isOpen, onClose, booking, onSave }) => {
  const [formData, setFormData] = useState(booking || {});
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('details');

  useEffect(() => {
    if (booking) {
      setFormData(booking);
      setActiveTab('details');
    }
  }, [booking]);

  if (!booking) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    toast.success(successMessage);
    setIsLoading(false);
  };

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    onSave(formData);
    toast.success(`Movement for ${formData.crewName} updated`);
    setIsLoading(false);
    onClose();
  };

  const footerActions = (
    <>
      <Button variant="destructive" onClick={() => handleAction('cancel', 'Movement cancelled', { status: 'Cancelled' })}>
        Cancel Movement
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={handleSave} disabled={isLoading}>Save Changes</Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title={`Movement Plan: ${formData.crewName}`}
      icon={Briefcase}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-4xl"
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="details">Movement Details</TabsTrigger>
          <TabsTrigger value="logistics">Ground & Visa</TabsTrigger>
          <TabsTrigger value="financials">Per Diem & Costs</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Crew Member</Label>
                <Input value={formData.crewName || ''} onChange={(e) => handleChange('crewName', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Destination</Label>
                <Input value={formData.destination || ''} onChange={(e) => handleChange('destination', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Hotel</Label>
                <Select value={formData.hotel} onValueChange={(v) => handleChange('hotel', v)}>
                  <SelectTrigger><SelectValue placeholder="Select hotel" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Grand Plaza">Grand Plaza</SelectItem>
                    <SelectItem value="Airport Transit Hotel">Airport Transit Hotel</SelectItem>
                    <SelectItem value="City Center Suites">City Center Suites</SelectItem>
                    <SelectItem value="Marriott Airport">Marriott Airport</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Confirmed">Confirmed</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Accommodation Start Date</Label>
                <Input type="datetime-local" value={formData.checkIn ? new Date(formData.checkIn).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('checkIn', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Accommodation End Date</Label>
                <Input type="datetime-local" value={formData.checkOut ? new Date(formData.checkOut).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('checkOut', e.target.value)} />
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label>Special Requirements & Notes</Label>
              <Textarea 
                placeholder="Add notes regarding room preferences, dietary requirements..." 
                value={formData.notes || ''} 
                onChange={(e) => handleChange('notes', e.target.value)}
                className="min-h-[80px]"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="logistics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 border border-border rounded-xl bg-muted/10 space-y-4">
              <h4 className="font-semibold flex items-center gap-2"><Car className="w-4 h-4 text-primary" /> Ground Transportation</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">Airport to Hotel</p>
                    <p className="text-xs text-muted-foreground">Scheduled: 14:30 Local</p>
                  </div>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Confirmed</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">Hotel to Airport</p>
                    <p className="text-xs text-muted-foreground">Pending Schedule</p>
                  </div>
                  <Badge variant="secondary">Pending</Badge>
                </div>
              </div>
              <Button className="w-full" variant="secondary" onClick={() => handleAction('transport', 'Ground transport requested')}>
                Request Additional Transport
              </Button>
            </div>

            <div className="p-5 border border-border rounded-xl bg-muted/10 space-y-4">
              <h4 className="font-semibold flex items-center gap-2"><FileText className="w-4 h-4 text-primary" /> Visa & Documentation</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">Entry Visa ({formData.destination})</p>
                    <p className="text-xs text-muted-foreground">Multiple Entry</p>
                  </div>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Valid</Badge>
                </div>
                <div className="flex justify-between items-center p-3 bg-background rounded-lg border border-border">
                  <div>
                    <p className="text-sm font-medium">Health Declaration</p>
                    <p className="text-xs text-muted-foreground">Required 24h prior</p>
                  </div>
                  <Badge variant="destructive">Missing</Badge>
                </div>
              </div>
              <Button className="w-full" variant="secondary" onClick={() => handleAction('visa', 'Visa check initiated')}>
                Verify Documentation
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="financials" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Hotel Cost (€)</Label>
                <Input type="number" value={formData.cost || 0} onChange={(e) => handleChange('cost', parseInt(e.target.value))} />
              </div>
              <div className="space-y-2">
                <Label>Transport Cost (€)</Label>
                <Input type="number" value={formData.transportCost || 45} onChange={(e) => handleChange('transportCost', parseInt(e.target.value))} />
              </div>
              <div className="space-y-2">
                <Label>Per Diem Rate (€/day)</Label>
                <div className="flex gap-2">
                  <Input type="number" value={formData.perDiemRate || 85} onChange={(e) => handleChange('perDiemRate', parseInt(e.target.value))} />
                  <Button variant="secondary" onClick={() => handleAction('perdiem', 'Per diem recalculated')}>Calculate</Button>
                </div>
              </div>
            </div>
            
            <div className="p-6 border border-border rounded-xl bg-primary/5 flex flex-col justify-center">
              <h4 className="text-sm font-medium text-muted-foreground mb-4 uppercase tracking-wider text-center">Total Estimated Cost</h4>
              <div className="text-center">
                <div className="text-5xl font-bold text-primary mb-2">
                  €{(formData.cost || 0) + (formData.transportCost || 45) + ((formData.perDiemRate || 85) * 2)}
                </div>
                <p className="text-sm text-muted-foreground">Includes 2 days per diem</p>
              </div>
              <Button className="mt-6 w-full" variant="outline" onClick={() => handleAction('expense', 'Expense report generated')}>
                Generate Expense Report
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </ModalBase>
  );
};