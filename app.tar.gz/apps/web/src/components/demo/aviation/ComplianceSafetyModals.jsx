import React, { useState, useEffect } from 'react';
import { ShieldCheck, FileCheck, AlertTriangle, Calendar, Upload, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const ComplianceDetailModal = ({ isOpen, onClose, complianceItem, onSave }) => {
  const [formData, setFormData] = useState(complianceItem || {});
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('details');

  useEffect(() => {
    if (complianceItem) {
      setFormData(complianceItem);
      setActiveTab('details');
    }
  }, [complianceItem]);

  if (!complianceItem) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    toast.success(successMessage);
    setIsLoading(false);
  };

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    onSave(formData);
    toast.success(`Compliance record updated`);
    setIsLoading(false);
    onClose();
  };

  const footerActions = (
    <>
      <Button variant="outline" onClick={() => handleAction('upload', 'Upload dialog opened')}>
        <Upload className="w-4 h-4 mr-2" /> Upload Docs
      </Button>
      <Button variant="outline" onClick={() => handleAction('report', 'Compliance report generated')}>
        <FileText className="w-4 h-4 mr-2" /> Generate Report
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      <Button onClick={handleSave} disabled={isLoading}>Save Changes</Button>
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title={`Compliance Record: ${formData.title}`}
      icon={ShieldCheck}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-3xl"
    >
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="details">Audit Details</TabsTrigger>
          <TabsTrigger value="actions">Corrective Actions</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Record Title</Label>
                <Input value={formData.title || ''} onChange={(e) => handleChange('title', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={formData.type} onValueChange={(v) => handleChange('type', v)}>
                  <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Audit">Audit</SelectItem>
                    <SelectItem value="Inspection">Inspection</SelectItem>
                    <SelectItem value="Certification">Certification</SelectItem>
                    <SelectItem value="Violation">Violation</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Severity / Priority</Label>
                <Select value={formData.severity} onValueChange={(v) => handleChange('severity', v)}>
                  <SelectTrigger><SelectValue placeholder="Select severity" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Critical">Critical</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Open">Open</SelectItem>
                    <SelectItem value="In-Progress">In-Progress</SelectItem>
                    <SelectItem value="Compliant">Compliant</SelectItem>
                    <SelectItem value="Non-Compliant">Non-Compliant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Due Date</Label>
                <Input type="datetime-local" value={formData.dueDate ? new Date(formData.dueDate).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('dueDate', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Assigned Auditor</Label>
                <Input value={formData.auditor || 'System Auto-Check'} onChange={(e) => handleChange('auditor', e.target.value)} />
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label>Description & Findings</Label>
              <Textarea 
                placeholder="Detailed description of the compliance requirement or audit findings..." 
                value={formData.description || ''} 
                onChange={(e) => handleChange('description', e.target.value)}
                className="min-h-[100px]"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="actions" className="space-y-6">
          <div className="p-5 border border-border rounded-xl bg-muted/10 space-y-4">
            <h4 className="font-semibold flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-primary" /> Corrective Action Plan</h4>
            <Textarea 
              placeholder="Outline the steps required to achieve compliance..." 
              value={formData.correctiveActions || ''} 
              onChange={(e) => handleChange('correctiveActions', e.target.value)}
              className="min-h-[120px]"
            />
            <div className="flex justify-end">
              <Button onClick={() => handleAction('markCompliant', 'Status updated to Compliant', { status: 'Compliant' })}>
                Mark as Compliant
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="font-semibold text-sm">Action History</h4>
            <div className="relative border-l-2 border-muted ml-3 space-y-6 pb-4">
              {[
                { time: 'Today', event: 'Corrective action plan drafted', user: 'Safety Officer' },
                { time: '2 days ago', event: 'Initial finding recorded', user: 'System Auto-Check' }
              ].map((item, i) => (
                <div key={i} className="relative pl-6">
                  <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-background border-2 border-primary"></div>
                  <p className="text-sm font-medium text-foreground">{item.event}</p>
                  <p className="text-xs text-muted-foreground">{item.time} • {item.user}</p>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </ModalBase>
  );
};