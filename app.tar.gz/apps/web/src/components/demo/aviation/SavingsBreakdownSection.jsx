import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { useAviationROISavings } from '@/contexts/AviationROISavingsContext.jsx';
import { Users, Clock, ShieldAlert, Briefcase, Plane } from 'lucide-react';

const BreakdownItem = ({ title, icon: Icon, amount, percentage, colorClass }) => (
  <div className="group cursor-pointer p-3 rounded-lg hover:bg-muted/50 transition-colors">
    <div className="flex justify-between items-center mb-2">
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-md ${colorClass} bg-opacity-10`}>
          <Icon className={`w-4 h-4 ${colorClass.replace('bg-', 'text-').replace('/10', '')}`} />
        </div>
        <span className="font-medium text-sm text-foreground">{title}</span>
      </div>
      <div className="text-right">
        <div className="font-bold text-sm">€{(amount / 1000000).toFixed(2)}M</div>
        <div className="text-xs text-muted-foreground">{percentage}% of total</div>
      </div>
    </div>
    <Progress value={percentage} className="h-1.5" indicatorClassName={colorClass.replace('bg-', 'bg-').replace('/10', '')} />
  </div>
);

const SavingsBreakdownSection = () => {
  const { kpis, isLoading } = useAviationROISavings();

  if (isLoading || !kpis) return null;

  const total = kpis.totalSavings;
  const breakdown = [
    { title: 'Crew Cost Optimization', icon: Users, amount: total * 0.35, colorClass: 'bg-blue-500' },
    { title: 'Reduced Delay Costs', icon: Clock, amount: total * 0.25, colorClass: 'bg-indigo-500' },
    { title: 'Disruption Impact Reduction', icon: ShieldAlert, amount: total * 0.20, colorClass: 'bg-violet-500' },
    { title: 'Travel & Logistics Savings', icon: Briefcase, amount: total * 0.12, colorClass: 'bg-purple-500' },
    { title: 'Aircraft Utilization', icon: Plane, amount: total * 0.08, colorClass: 'bg-fuchsia-500' },
  ];

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-lg">Savings Breakdown</CardTitle>
      </CardHeader>
      <CardContent className="space-y-1">
        {breakdown.map((item, idx) => (
          <BreakdownItem 
            key={idx}
            title={item.title}
            icon={item.icon}
            amount={item.amount}
            percentage={Math.round((item.amount / total) * 100)}
            colorClass={item.colorClass}
          />
        ))}
      </CardContent>
    </Card>
  );
};

export default SavingsBreakdownSection;