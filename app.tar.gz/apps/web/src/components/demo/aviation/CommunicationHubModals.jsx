import React, { useState, useEffect } from 'react';
import { MessageSquare, Send, Reply, Forward, Archive, Trash2, Paperclip } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';
import ModalBase from './ModalBase.jsx';

export const MessageDetailModal = ({ isOpen, onClose, message, onSave }) => {
  const [formData, setFormData] = useState(message || {});
  const [isLoading, setIsLoading] = useState(false);
  const [isReplying, setIsReplying] = useState(false);
  const [replyText, setReplyText] = useState('');

  useEffect(() => {
    if (message) {
      setFormData(message);
      setIsReplying(false);
      setReplyText('');
    }
  }, [message]);

  if (!message) return null;

  const handleAction = async (actionName, successMessage, updateData = {}) => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 600));
    const newData = { ...formData, ...updateData };
    setFormData(newData);
    onSave(newData);
    toast.success(successMessage);
    setIsLoading(false);
    if (actionName === 'archive' || actionName === 'delete') onClose();
  };

  const handleSendReply = async () => {
    if (!replyText.trim()) return;
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    toast.success('Reply sent successfully');
    setIsReplying(false);
    setReplyText('');
    setIsLoading(false);
  };

  const footerActions = (
    <>
      <Button variant="destructive" onClick={() => handleAction('delete', 'Message deleted', { status: 'Deleted' })}>
        <Trash2 className="w-4 h-4 mr-2" /> Delete
      </Button>
      <Button variant="outline" onClick={() => handleAction('archive', 'Message archived', { status: 'Archived' })}>
        <Archive className="w-4 h-4 mr-2" /> Archive
      </Button>
      <div className="flex-1"></div>
      <Button variant="outline" onClick={onClose} disabled={isLoading}>Close</Button>
      {!isReplying && (
        <Button onClick={() => setIsReplying(true)} disabled={isLoading}>
          <Reply className="w-4 h-4 mr-2" /> Reply
        </Button>
      )}
    </>
  );

  return (
    <ModalBase
      isOpen={isOpen}
      onClose={onClose}
      title="Message Details"
      icon={MessageSquare}
      footerActions={footerActions}
      isLoading={isLoading}
      maxWidth="max-w-2xl"
    >
      <div className="space-y-6">
        <div className="p-4 border border-border rounded-xl bg-muted/10 space-y-3">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-bold text-foreground">{formData.subject}</h3>
            <Badge variant={formData.status === 'Delivered' ? 'default' : 'secondary'}>{formData.status}</Badge>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><span className="text-muted-foreground">From:</span> <span className="font-medium">{formData.from}</span></div>
            <div><span className="text-muted-foreground">Date:</span> <span>{new Date(formData.timestamp).toLocaleString()}</span></div>
            <div className="col-span-2"><span className="text-muted-foreground">To:</span> <span className="font-medium">{formData.to}</span></div>
          </div>
        </div>

        <div className="p-5 border border-border rounded-xl bg-card min-h-[150px]">
          <p className="text-sm text-foreground whitespace-pre-wrap leading-relaxed">
            {formData.body}
          </p>
        </div>

        {isReplying && (
          <div className="p-4 border border-primary/20 rounded-xl bg-primary/5 space-y-4 animate-in fade-in slide-in-from-top-4">
            <Label>Compose Reply</Label>
            <Textarea 
              placeholder="Type your message here..." 
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              className="min-h-[120px] bg-background"
            />
            <div className="flex justify-between items-center">
              <Button variant="ghost" size="sm" onClick={() => toast.info('Attachment dialog opened')}>
                <Paperclip className="w-4 h-4 mr-2" /> Attach File
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setIsReplying(false)}>Cancel</Button>
                <Button size="sm" onClick={handleSendReply}><Send className="w-4 h-4 mr-2" /> Send</Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ModalBase>
  );
};