import React from 'react';
import { motion } from 'framer-motion';
import { Plane, Users, AlertTriangle, ArrowRight, Clock, DollarSign } from 'lucide-react';
import { Badge } from '@/components/ui/badge.jsx';

const CascadeImpactVisualization = ({ disruption }) => {
  if (!disruption) return null;

  const affectedFlights = disruption.affectedFlights || [];
  const affectedCrew = disruption.affectedCrew || [];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl border border-border bg-muted/20 flex flex-col items-center justify-center text-center">
          <Plane className="w-8 h-8 text-blue-500 mb-2" />
          <p className="text-2xl font-bold text-foreground">{affectedFlights.length}</p>
          <p className="text-sm text-muted-foreground">Flights Affected</p>
        </div>
        <div className="p-4 rounded-xl border border-border bg-muted/20 flex flex-col items-center justify-center text-center">
          <Users className="w-8 h-8 text-orange-500 mb-2" />
          <p className="text-2xl font-bold text-foreground">{affectedCrew.length}</p>
          <p className="text-sm text-muted-foreground">Crew Impacted</p>
        </div>
        <div className="p-4 rounded-xl border border-border bg-muted/20 flex flex-col items-center justify-center text-center">
          <DollarSign className="w-8 h-8 text-red-500 mb-2" />
          <p className="text-2xl font-bold text-foreground">€{disruption.costImpact?.toLocaleString() || 0}</p>
          <p className="text-sm text-muted-foreground">Est. Cost Impact</p>
        </div>
      </div>

      <div className="relative p-6 rounded-xl border border-border bg-card overflow-hidden">
        <h4 className="font-semibold text-lg mb-6 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-destructive" />
          Impact Propagation Tree
        </h4>
        
        <div className="space-y-8 relative before:absolute before:inset-0 before:ml-6 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-destructive before:via-orange-400 before:to-transparent">
          
          {/* Root Cause */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
          >
            <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-card bg-destructive text-destructive-foreground shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-sm z-10">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-destructive/30 bg-destructive/5 shadow-sm">
              <div className="flex items-center justify-between mb-1">
                <Badge variant="destructive">Root Cause</Badge>
                <span className="text-xs text-muted-foreground font-medium">{disruption.type}</span>
              </div>
              <h5 className="font-bold text-foreground">{disruption.title || disruption.subtype}</h5>
              <p className="text-sm text-muted-foreground mt-1">{disruption.description || disruption.rootCauseAnalysis}</p>
            </div>
          </motion.div>

          {/* Level 1: Flights */}
          {affectedFlights.slice(0, 3).map((flight, idx) => (
            <motion.div 
              key={flight}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + (idx * 0.1) }}
              className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group"
            >
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-card bg-orange-500 text-white shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-sm z-10">
                <Plane className="w-4 h-4" />
              </div>
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-border bg-card shadow-sm hover:border-orange-500/50 transition-colors cursor-pointer">
                <div className="flex items-center justify-between mb-1">
                  <Badge variant="outline" className="bg-orange-500/10 text-orange-700 border-orange-500/30">Delayed</Badge>
                  <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3"/> +{Math.floor(Math.random() * 60) + 30}m</span>
                </div>
                <h5 className="font-bold text-foreground">Flight {flight}</h5>
                <p className="text-sm text-muted-foreground mt-1">Awaiting aircraft rotation from {disruption.airport || 'origin'}.</p>
              </div>
            </motion.div>
          ))}

          {/* Level 2: Crew */}
          {affectedCrew.slice(0, 2).map((crew, idx) => (
            <motion.div 
              key={crew}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + (idx * 0.1) }}
              className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group"
            >
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-card bg-yellow-500 text-white shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-sm z-10">
                <Users className="w-4 h-4" />
              </div>
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-border bg-card shadow-sm hover:border-yellow-500/50 transition-colors cursor-pointer">
                <div className="flex items-center justify-between mb-1">
                  <Badge variant="outline" className="bg-yellow-500/10 text-yellow-700 border-yellow-500/30">Legality Risk</Badge>
                </div>
                <h5 className="font-bold text-foreground">Crew {crew}</h5>
                <p className="text-sm text-muted-foreground mt-1">Approaching maximum duty hours due to upstream delay.</p>
              </div>
            </motion.div>
          ))}

          {affectedFlights.length > 3 && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="relative flex items-center justify-center"
            >
              <Badge variant="secondary" className="z-10 bg-muted text-muted-foreground">
                + {affectedFlights.length - 3} more flights impacted downstream
              </Badge>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CascadeImpactVisualization;