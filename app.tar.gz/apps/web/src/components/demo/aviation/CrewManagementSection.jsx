import React, { useState, useMemo, useEffect } from 'react';
import { generateCrewData } from '@/lib/crewManagementData.js';
import CrewCardInteractive from './CrewCardInteractive.jsx';
import CrewProfileModal from './CrewProfileModal.jsx';
import { CrewFiltersPanel, StandbyPoolWidget, AIPairingWidget } from './CrewManagementEnhancements.jsx';

const CrewManagementSection = () => {
  // Initialize rich crew data once
  const [crewData, setCrewData] = useState([]);
  const [selectedCrew, setSelectedCrew] = useState(null);
  
  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [baseFilter, setBaseFilter] = useState('all');

  useEffect(() => {
    // Generate 35 realistic crew members on mount
    setCrewData(generateCrewData(35));
  }, []);

  // Filter logic
  const filteredCrew = useMemo(() => {
    return crewData.filter(member => {
      const matchesSearch = member.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            member.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRole = roleFilter === 'all' || member.role === roleFilter;
      const matchesBase = baseFilter === 'all' || member.base === baseFilter;
      return matchesSearch && matchesRole && matchesBase;
    });
  }, [crewData, searchQuery, roleFilter, baseFilter]);

  const standbyCrew = useMemo(() => crewData.filter(c => c.status === 'Standby'), [crewData]);

  return (
    <div className="flex-auto-height gap-6 animate-in fade-in w-full">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-2">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Crew Intelligence & Management</h2>
          <p className="text-muted-foreground text-sm mt-1">Manage rosters, track fatigue, and optimize pairings globally.</p>
        </div>
      </div>

      {/* Top Enhancements Row */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 w-full">
        <div className="lg:col-span-3 w-full">
          <CrewFiltersPanel 
            searchQuery={searchQuery} setSearchQuery={setSearchQuery}
            roleFilter={roleFilter} setRoleFilter={setRoleFilter}
            baseFilter={baseFilter} setBaseFilter={setBaseFilter}
          />
          
          {/* Crew Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 w-full">
            {filteredCrew.map(member => (
              <CrewCardInteractive 
                key={member.id} 
                member={member} 
                onClick={setSelectedCrew} 
              />
            ))}
            {filteredCrew.length === 0 && (
              <div className="col-span-full py-12 text-center text-muted-foreground bg-muted/10 rounded-xl border border-dashed border-border">
                No crew members match the current filters.
              </div>
            )}
          </div>
        </div>

        {/* Right Sidebar Widgets */}
        <div className="space-y-6 flex flex-col w-full">
          <div className="flex-1 min-h-[300px] w-full">
            <StandbyPoolWidget standbyCrew={standbyCrew} onCrewClick={setSelectedCrew} />
          </div>
          <div className="flex-1 min-h-[300px] w-full">
            <AIPairingWidget />
          </div>
        </div>
      </div>

      {/* Full Profile Modal */}
      <CrewProfileModal 
        isOpen={!!selectedCrew} 
        onClose={() => setSelectedCrew(null)} 
        crewMember={selectedCrew} 
      />
    </div>
  );
};

export default CrewManagementSection;