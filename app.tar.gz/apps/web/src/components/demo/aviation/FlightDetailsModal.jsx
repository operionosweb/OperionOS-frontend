import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { toast } from 'sonner';
import { Plane } from 'lucide-react';

const FlightDetailsModal = ({ isOpen, onClose, flight, onSave }) => {
  const [formData, setFormData] = useState(flight || {});

  useEffect(() => {
    if (flight) setFormData(flight);
  }, [flight]);

  if (!flight) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(formData);
    toast.success(`Flight ${formData.flightNumber} updated successfully`);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-full sm:w-[95%] md:w-[90%] lg:w-[80%] max-w-3xl max-h-[85vh] sm:max-h-[85vh] md:max-h-[90vh] p-0 flex flex-col bg-background border-border rounded-xl sm:rounded-2xl overflow-hidden">
        <DialogHeader className="p-3 sm:p-4 md:p-5 border-b border-border bg-muted/30 sticky top-0 z-20 shrink-0">
          <DialogTitle className="flex items-center gap-2 text-lg sm:text-xl">
            <Plane className="w-5 h-5 text-primary" />
            Flight Details: {formData.flightNumber}
          </DialogTitle>
        </DialogHeader>
        
        <div className="p-3 sm:p-4 md:p-5 overflow-y-auto flex-1 scrollable-y">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5 md:gap-6">
            <div className="space-y-3 sm:space-y-4">
              <div className="space-y-2">
                <Label>Flight Number</Label>
                <Input value={formData.flightNumber || ''} onChange={(e) => handleChange('flightNumber', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Route</Label>
                <Input value={formData.route || ''} onChange={(e) => handleChange('route', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Aircraft Type</Label>
                <Input value={formData.aircraft || ''} onChange={(e) => handleChange('aircraft', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={formData.status} onValueChange={(v) => handleChange('status', v)}>
                  <SelectTrigger><SelectValue placeholder="Select status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="On-Time">On-Time</SelectItem>
                    <SelectItem value="Delayed">Delayed</SelectItem>
                    <SelectItem value="Boarding">Boarding</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-3 sm:space-y-4">
              <div className="space-y-2">
                <Label>Departure Time</Label>
                <Input type="datetime-local" value={formData.departure ? new Date(formData.departure).toISOString().slice(0,16) : ''} onChange={(e) => handleChange('departure', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Delay Minutes</Label>
                <Input type="number" value={formData.delayMinutes || 0} onChange={(e) => handleChange('delayMinutes', parseInt(e.target.value))} />
              </div>
              <div className="space-y-2">
                <Label>Gate</Label>
                <Input value={formData.gate || ''} onChange={(e) => handleChange('gate', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Passengers</Label>
                <Input type="number" value={formData.passengers || 0} onChange={(e) => handleChange('passengers', parseInt(e.target.value))} />
              </div>
            </div>

            <div className="col-span-1 md:col-span-2 space-y-2">
              <Label>Operational Notes</Label>
              <Textarea 
                placeholder="Add notes regarding weather, ATC, or crew..." 
                value={formData.notes || ''} 
                onChange={(e) => handleChange('notes', e.target.value)}
                className="min-h-[100px]"
              />
            </div>
          </div>
        </div>

        <DialogFooter className="p-3 sm:p-4 md:p-5 border-t border-border bg-muted/30 sticky bottom-0 z-20 shrink-0 flex flex-col-reverse sm:flex-row justify-between gap-2 sm:gap-3">
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 w-full sm:w-auto">
            <Button variant="destructive" className="w-full sm:w-auto" onClick={() => { toast.error('Flight Cancelled'); onClose(); }}>Cancel Flight</Button>
            <Button variant="outline" className="w-full sm:w-auto" onClick={() => toast.info('Crew Reassignment Modal Opened')}>Reassign Crew</Button>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 w-full sm:w-auto">
            <Button variant="outline" className="w-full sm:w-auto" onClick={onClose}>Close</Button>
            <Button className="w-full sm:w-auto" onClick={handleSave}>Update Flight</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FlightDetailsModal;