import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { FileText, Calendar, DollarSign, AlertTriangle, Download, Edit2, Save, X, Plane, Sparkles } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters.js';
import { calculateMonthsRemaining } from '@/lib/aviationFleetIntelligenceData.js';
import { toast } from 'sonner';

const AviationContractDetailModal = ({ isOpen, onClose, contract, onUpdate, onViewAircraft }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({});

  if (!contract) return null;

  const handleEditToggle = () => {
    if (isEditing) {
      setIsEditing(false);
    } else {
      setEditForm({
        monthlyPayment: contract.monthlyPayment,
        keyTerms: contract.keyTerms,
        penaltyClause: contract.penaltyClause
      });
      setIsEditing(true);
    }
  };

  const handleSave = () => {
    onUpdate(contract.contractId, {
      monthlyPayment: Number(editForm.monthlyPayment),
      keyTerms: editForm.keyTerms,
      penaltyClause: Number(editForm.penaltyClause)
    });
    setIsEditing(false);
  };

  const handleFlagRisk = () => {
    const newRisk = contract.riskLevel === 'High' ? 'Medium' : 'High';
    onUpdate(contract.contractId, { riskLevel: newRisk });
    toast.info(`Risk level updated to ${newRisk}`);
  };

  const handleDownload = () => {
    toast.success('Contract PDF downloaded successfully.');
  };

  const monthsRemaining = calculateMonthsRemaining(contract.endDate);
  const riskColor = contract.riskLevel === 'High' ? 'bg-destructive/10 text-destructive border-destructive/20' : 
                    contract.riskLevel === 'Medium' ? 'bg-warning/10 text-warning border-warning/20' : 
                    'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[650px] p-0 overflow-hidden bg-card">
        <div className="bg-muted/30 p-6 border-b border-border flex justify-between items-start">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center text-secondary">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <DialogTitle className="text-2xl font-bold">{contract.contractId}</DialogTitle>
                <DialogDescription className="text-sm font-medium">Lessor: {contract.lessor}</DialogDescription>
              </div>
            </div>
          </div>
          <Badge variant="outline" className={riskColor}>{contract.riskLevel} Risk</Badge>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <Plane className="w-3 h-3" /> Linked Aircraft
              </label>
              <p className="text-lg font-bold text-primary cursor-pointer hover:underline" onClick={() => onViewAircraft(contract.aircraftId)}>
                {contract.aircraftId}
              </p>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <Calendar className="w-3 h-3" /> Duration
              </label>
              <p className="text-sm font-bold">{contract.startDate} to {contract.endDate}</p>
              <p className="text-xs text-muted-foreground">{monthsRemaining} months remaining</p>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <DollarSign className="w-3 h-3" /> Monthly Payment
              </label>
              {isEditing ? (
                <Input 
                  type="number" 
                  value={editForm.monthlyPayment} 
                  onChange={(e) => setEditForm({...editForm, monthlyPayment: e.target.value})}
                  className="h-8 text-sm"
                />
              ) : (
                <p className="text-lg font-bold">{formatCurrency(contract.monthlyPayment)}</p>
              )}
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Penalty Clause
              </label>
              {isEditing ? (
                <Input 
                  type="number" 
                  value={editForm.penaltyClause} 
                  onChange={(e) => setEditForm({...editForm, penaltyClause: e.target.value})}
                  className="h-8 text-sm"
                />
              ) : (
                <p className="text-lg font-bold text-destructive">{formatCurrency(contract.penaltyClause)}</p>
              )}
            </div>
          </div>

          <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 relative overflow-hidden">
            <div className="absolute top-2 right-2 flex items-center gap-1 text-amber-600 text-[10px] font-bold uppercase tracking-wider bg-amber-500/10 px-2 py-1 rounded-md">
              <Sparkles className="w-3 h-3" /> AI Extracted
            </div>
            <label className="text-xs font-semibold text-amber-700/70 dark:text-amber-400/70 uppercase tracking-wider mb-2 block">
              Key Terms & Conditions
            </label>
            {isEditing ? (
              <Textarea 
                value={editForm.keyTerms} 
                onChange={(e) => setEditForm({...editForm, keyTerms: e.target.value})}
                className="text-sm min-h-[80px]"
              />
            ) : (
              <p className="text-sm text-foreground leading-relaxed">{contract.keyTerms}</p>
            )}
          </div>

          <div className="flex flex-wrap gap-3 pt-4 border-t border-border">
            {isEditing ? (
              <>
                <Button onClick={handleSave} className="flex-1"><Save className="w-4 h-4 mr-2" /> Save Changes</Button>
                <Button variant="outline" onClick={handleEditToggle} className="flex-1"><X className="w-4 h-4 mr-2" /> Cancel</Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={handleEditToggle} className="flex-1"><Edit2 className="w-4 h-4 mr-2" /> Edit</Button>
                <Button variant="outline" onClick={handleDownload} className="flex-1"><Download className="w-4 h-4 mr-2" /> Download</Button>
                <Button variant="outline" onClick={handleFlagRisk} className="flex-1 text-warning hover:text-warning hover:bg-warning/10 border-warning/20"><AlertTriangle className="w-4 h-4 mr-2" /> Flag Risk</Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AviationContractDetailModal;