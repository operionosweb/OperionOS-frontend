import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Plane, Users, Clock, DollarSign, MapPin } from 'lucide-react';
import OperationalTools from './OperationalTools.jsx';

const FlightProfileModal = ({ isOpen, onClose, flight }) => {
  if (!flight) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-gray-900 flex items-center gap-3">
            <Plane className="w-6 h-6 text-blue-600" />
            Flight {flight.flightNumber} - {flight.route}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-gray-200">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="crew">Crew</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="costs">Costs</TabsTrigger>
            <TabsTrigger value="routing">Routing</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Aircraft:</span>
                  <span className="font-semibold text-gray-900">{flight.aircraft}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Registration:</span>
                  <span className="font-semibold text-gray-900">{flight.registration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <Badge className={flight.status === 'On Time' ? 'badge-on-time' : 'badge-delayed'}>{flight.status}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Passenger Load:</span>
                  <span className="font-semibold text-gray-900">{flight.passengerLoad}%</span>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Gate:</span>
                  <span className="font-semibold text-gray-900">{flight.gate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Terminal:</span>
                  <span className="font-semibold text-gray-900">{flight.terminal}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Fuel:</span>
                  <span className="font-semibold text-gray-900">{flight.fuel} kg</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Cost Impact:</span>
                  <span className="font-semibold text-gray-900">€{flight.costImpact.toLocaleString()}</span>
                </div>
              </div>
            </div>
            <OperationalTools flight={flight} />
          </TabsContent>

          <TabsContent value="crew" className="space-y-3 mt-4">
            {flight.crew && flight.crew.map((member, idx) => (
              <div key={idx} className="p-3 bg-gray-50 border-2 border-gray-200 rounded-lg flex items-center justify-between hover:bg-gray-100 cursor-pointer transition-colors">
                <div>
                  <p className="font-semibold text-gray-900">{member.name}</p>
                  <p className="text-xs text-gray-600">{member.role}</p>
                </div>
                <Button size="sm" variant="outline">View Profile</Button>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="timeline" className="space-y-3 mt-4">
            {flight.timeline && flight.timeline.map((event, idx) => (
              <div key={idx} className="flex items-center gap-4 p-3 bg-gray-50 border-2 border-gray-200 rounded-lg">
                <Clock className="w-5 h-5 text-gray-600" />
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">{event.event}</p>
                  <p className="text-xs text-gray-600">Scheduled: {event.scheduled} | Actual: {event.actual || 'Pending'}</p>
                </div>
                <Badge className={event.status === 'Complete' ? 'badge-on-time' : event.status === 'Delayed' ? 'badge-delayed' : 'badge-info'}>
                  {event.status}
                </Badge>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="costs" className="space-y-3 mt-4">
            <div className="p-4 bg-gray-50 border-2 border-gray-200 rounded-lg space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Fuel Cost:</span>
                <span className="font-semibold text-gray-900">€{(flight.fuel * 0.8).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Crew Cost:</span>
                <span className="font-semibold text-gray-900">€{(flight.crew?.length * 450 || 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Delay Cost:</span>
                <span className="font-semibold text-gray-900">€{flight.costImpact.toLocaleString()}</span>
              </div>
              <div className="flex justify-between border-t-2 border-gray-300 pt-2 mt-2">
                <span className="font-bold text-gray-900">Total Cost:</span>
                <span className="font-bold text-gray-900">€{(flight.fuel * 0.8 + (flight.crew?.length * 450 || 0) + flight.costImpact).toLocaleString()}</span>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="routing" className="space-y-3 mt-4">
            <div className="p-4 bg-gray-50 border-2 border-gray-200 rounded-lg">
              <p className="text-sm text-gray-700 mb-2">Current Route: {flight.route}</p>
              <p className="text-xs text-gray-600">Distance: {Math.floor(Math.random() * 2000) + 500} km</p>
              <p className="text-xs text-gray-600">Flight Time: {Math.floor(Math.random() * 180) + 60} min</p>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex gap-2 mt-4 flex-wrap">
          <Button size="sm" variant="outline">Swap Aircraft</Button>
          <Button size="sm" variant="outline">Swap Crew</Button>
          <Button size="sm" variant="outline">Delay/Expedite</Button>
          <Button size="sm" variant="destructive">Cancel</Button>
          <Button size="sm" variant="outline">Re-route</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default FlightProfileModal;