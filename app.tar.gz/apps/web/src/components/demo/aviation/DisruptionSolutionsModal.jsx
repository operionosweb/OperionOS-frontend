import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, CheckCircle2, AlertTriangle, Clock, DollarSign, Activity, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';

const DisruptionSolutionsModal = ({ isOpen, onClose, disruption, onApplySolution }) => {
  if (!isOpen || !disruption) return null;

  const solutions = disruption.solutions || [];

  const handleApply = (solution) => {
    if (onApplySolution) {
      onApplySolution(disruption.id, solution);
    } else {
      toast.success(`Applied solution: ${solution.actionSummary}`);
    }
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="modal-backdrop">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-header">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-foreground">AI Recovery Solutions</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Generated for {disruption.subtype} at {disruption.airport || 'Hub'}
                </p>
              </div>
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-muted">
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="modal-body bg-muted/10">
              {solutions.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Activity className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>No AI solutions available for this disruption yet.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {solutions.map((sol, idx) => (
                    <motion.div 
                      key={sol.id || idx}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className={`flex flex-col rounded-2xl border-2 transition-all bg-card overflow-hidden ${
                        sol.isRecommended 
                          ? 'border-primary shadow-lg shadow-primary/10' 
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      {sol.isRecommended && (
                        <div className="bg-primary text-primary-foreground text-xs font-bold uppercase tracking-wider py-1.5 px-4 text-center flex items-center justify-center gap-2">
                          <CheckCircle2 className="w-4 h-4" /> Recommended Strategy
                        </div>
                      )}
                      
                      <div className="p-5 sm:p-6 flex-1 flex flex-col">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="text-lg font-bold text-foreground leading-tight">{sol.actionSummary}</h3>
                          <Badge variant="outline" className={
                            sol.riskLevel === 'Low' ? 'bg-green-500/10 text-green-700 border-green-500/30' :
                            sol.riskLevel === 'Medium' ? 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30' :
                            'bg-red-500/10 text-red-700 border-red-500/30'
                          }>
                            {sol.riskLevel} Risk
                          </Badge>
                        </div>

                        <p className="text-sm text-muted-foreground mb-6">{sol.operationalImpact}</p>

                        <div className="grid grid-cols-2 gap-4 mb-6">
                          <div className="p-3 rounded-xl bg-muted/50 border border-border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-1">
                              <Clock className="w-4 h-4" />
                              <span className="text-xs font-medium uppercase tracking-wider">Time to Execute</span>
                            </div>
                            <p className="text-lg font-bold text-foreground">{sol.timeToImplement} mins</p>
                          </div>
                          <div className="p-3 rounded-xl bg-muted/50 border border-border">
                            <div className="flex items-center gap-2 text-muted-foreground mb-1">
                              <DollarSign className="w-4 h-4" />
                              <span className="text-xs font-medium uppercase tracking-wider">Net Impact</span>
                            </div>
                            <p className={`text-lg font-bold ${sol.costImpact < 0 ? 'text-green-600' : 'text-destructive'}`}>
                              {sol.costImpact < 0 ? '-' : '+'}€{Math.abs(sol.costImpact).toLocaleString()}
                            </p>
                          </div>
                        </div>

                        <div className="mb-6 flex-1">
                          <h4 className="text-sm font-semibold text-foreground mb-3">Execution Steps:</h4>
                          <ul className="space-y-2">
                            {sol.steps?.map((step, sIdx) => (
                              <li key={sIdx} className="flex items-start gap-2 text-sm text-muted-foreground">
                                <span className="flex items-center justify-center w-5 h-5 rounded-full bg-primary/10 text-primary text-xs font-bold shrink-0 mt-0.5">
                                  {sIdx + 1}
                                </span>
                                <span>{step}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-3 mt-auto pt-4 border-t border-border">
                          <Button 
                            className={`flex-1 ${sol.isRecommended ? 'bg-primary hover:bg-primary/90' : ''}`}
                            variant={sol.isRecommended ? 'default' : 'outline'}
                            onClick={() => handleApply(sol)}
                          >
                            Apply Solution
                          </Button>
                          <Button variant="secondary" className="flex-1">
                            Simulate
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default DisruptionSolutionsModal;