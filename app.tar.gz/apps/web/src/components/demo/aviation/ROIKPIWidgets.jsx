import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, DollarSign, Clock, Users, ShieldAlert, Activity, Target, Zap } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { useAviationROISavings } from '@/contexts/AviationROISavingsContext.jsx';
import { Skeleton } from '@/components/ui/skeleton.jsx';

const formatCurrency = (value) => {
  if (value >= 1000000) return `€${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `€${(value / 1000).toFixed(1)}k`;
  return `€${value}`;
};

const KPICard = ({ title, value, trend, icon: Icon, isCurrency = true, suffix = '', delay = 0 }) => {
  const isPositive = trend > 0;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
    >
      <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-primary/10 rounded-lg text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
              <Icon className="w-5 h-5" />
            </div>
            <div className={`flex items-center text-sm font-medium ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
              {isPositive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
              {Math.abs(trend)}%
            </div>
          </div>
          <h3 className="text-muted-foreground text-sm font-medium mb-1">{title}</h3>
          <div className="text-2xl font-bold text-foreground">
            {isCurrency ? formatCurrency(value) : value}{suffix}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const ROIKPIWidgets = () => {
  const { kpis, isLoading } = useAviationROISavings();

  if (isLoading || !kpis) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 7 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <KPICard title="Total Savings Generated" value={kpis.totalSavings} trend={kpis.trends.totalSavings} icon={DollarSign} delay={0.1} />
      <KPICard title="Monthly Savings" value={kpis.monthlySavings} trend={kpis.trends.monthlySavings} icon={Activity} delay={0.2} />
      <KPICard title="Cost Avoided (Disruptions)" value={kpis.costAvoided} trend={kpis.trends.costAvoided} icon={ShieldAlert} delay={0.3} />
      <KPICard title="Crew Optimization Savings" value={kpis.crewOptimization} trend={kpis.trends.crewOptimization} icon={Users} delay={0.4} />
      <KPICard title="Operational Efficiency Gain" value={kpis.operationalEfficiency} trend={kpis.trends.operationalEfficiency} icon={Zap} isCurrency={false} suffix="%" delay={0.5} />
      <KPICard title="Return on Investment" value={kpis.roi} trend={kpis.trends.roi} icon={Target} isCurrency={false} suffix="%" delay={0.6} />
      <KPICard title="Payback Period" value={kpis.paybackPeriod} trend={kpis.trends.paybackPeriod} icon={Clock} isCurrency={false} suffix=" mo" delay={0.7} />
    </div>
  );
};

export default ROIKPIWidgets;