import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import { useAviationROISavings } from '@/contexts/AviationROISavingsContext.jsx';
import { Calculator, Save, RefreshCw } from 'lucide-react';

const InteractiveROICalculator = () => {
  const { calcInputs, updateROICalculatorInputs, saveScenario, isLoading } = useAviationROISavings();
  const [localInputs, setLocalInputs] = useState(calcInputs || {});
  const [results, setResults] = useState({ monthly: 0, annual: 0, roi: 0 });

  useEffect(() => {
    if (calcInputs) setLocalInputs(calcInputs);
  }, [calcInputs]);

  useEffect(() => {
    if (!localInputs.fleetSize) return;
    // Simple mock calculation logic
    const baseCost = localInputs.dailyFlights * localInputs.avgDelayCost * 30;
    const disruptionCost = baseCost * (localInputs.disruptionRate / 100);
    const crewInefficiency = localInputs.crewMembers * 500 * ((100 - localInputs.crewUtilization) / 100);
    
    const monthlySavings = (disruptionCost * 0.4) + (crewInefficiency * 0.6);
    const annualSavings = monthlySavings * 12;
    const roi = ((annualSavings - 250000) / 250000) * 100; // Assuming 250k platform cost

    setResults({
      monthly: monthlySavings,
      annual: annualSavings,
      roi: roi > 0 ? roi : 0
    });
  }, [localInputs]);

  if (isLoading || !localInputs.fleetSize) return null;

  const handleSliderChange = (key, val) => {
    setLocalInputs(prev => ({ ...prev, [key]: val[0] }));
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-primary" /> ROI Calculator
            </CardTitle>
            <CardDescription>Simulate savings based on your operational metrics</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setLocalInputs(calcInputs)}>
              <RefreshCw className="w-4 h-4 mr-2" /> Reset
            </Button>
            <Button size="sm" onClick={() => saveScenario('Custom Simulation')}>
              <Save className="w-4 h-4 mr-2" /> Save
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-3">
              <div className="flex justify-between">
                <Label>Fleet Size</Label>
                <span className="text-sm font-medium">{localInputs.fleetSize} aircraft</span>
              </div>
              <Slider 
                value={[localInputs.fleetSize]} 
                min={10} max={500} step={5}
                onValueChange={(v) => handleSliderChange('fleetSize', v)} 
              />
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <Label>Daily Flights</Label>
                <span className="text-sm font-medium">{localInputs.dailyFlights}</span>
              </div>
              <Slider 
                value={[localInputs.dailyFlights]} 
                min={50} max={2000} step={10}
                onValueChange={(v) => handleSliderChange('dailyFlights', v)} 
              />
            </div>

            <div className="space-y-3">
              <div className="flex justify-between">
                <Label>Disruption Rate (%)</Label>
                <span className="text-sm font-medium">{localInputs.disruptionRate}%</span>
              </div>
              <Slider 
                value={[localInputs.disruptionRate]} 
                min={1} max={15} step={0.1}
                onValueChange={(v) => handleSliderChange('disruptionRate', v)} 
              />
            </div>
          </div>

          <div className="bg-muted/30 rounded-xl p-6 flex flex-col justify-center border border-border">
            <h4 className="text-sm font-medium text-muted-foreground mb-6 uppercase tracking-wider text-center">Projected Impact</h4>
            
            <div className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-1">
                  €{(results.annual / 1000000).toFixed(2)}M
                </div>
                <div className="text-sm text-muted-foreground">Estimated Annual Savings</div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                <div className="text-center">
                  <div className="text-2xl font-bold text-foreground">
                    €{(results.monthly / 1000).toFixed(0)}k
                  </div>
                  <div className="text-xs text-muted-foreground">Monthly Savings</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {results.roi.toFixed(0)}%
                  </div>
                  <div className="text-xs text-muted-foreground">Projected ROI</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InteractiveROICalculator;