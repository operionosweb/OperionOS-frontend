import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, AlertTriangle, Clock, DollarSign, Plane, Users, Save, MessageSquare, Activity, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { toast } from 'sonner';
import CascadeImpactVisualization from './CascadeImpactVisualization.jsx';
import DisruptionTimelineView from './DisruptionTimelineView.jsx';
import DisruptionSolutionsModal from './DisruptionSolutionsModal.jsx';

const DisruptionDetailModal = ({ isOpen, onClose, disruption, onSave }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [showSolutions, setShowSolutions] = useState(false);
  const [comment, setComment] = useState('');
  const [commentsList, setCommentsList] = useState([]);

  useEffect(() => {
    if (disruption) {
      setEditedData({ ...disruption });
      setCommentsList([
        { id: 1, author: 'System', text: 'Disruption automatically detected by AI engine.', time: '10 mins ago' }
      ]);
      setActiveTab('overview');
      setIsEditing(false);
    }
  }, [disruption, isOpen]);

  if (!isOpen || !disruption || !editedData) return null;

  const handleSave = () => {
    setIsEditing(false);
    if (onSave) onSave(editedData);
    toast.success('Disruption details updated successfully.');
  };

  const handleAddComment = () => {
    if (!comment.trim()) return;
    setCommentsList([{ id: Date.now(), author: 'Current User', text: comment, time: 'Just now' }, ...commentsList]);
    setComment('');
    toast.success('Comment added.');
  };

  const getSeverityClass = (severity) => {
    switch(severity) {
      case 'Critical': return 'severity-critical';
      case 'High': return 'severity-high';
      case 'Medium': return 'severity-medium';
      default: return 'severity-low';
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="modal-backdrop" onClick={onClose}>
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="modal-container max-w-5xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="modal-body">
              {/* Header */}
              <div className="modal-header">
                <div className="flex-1 w-full">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    {isEditing ? (
                      <select 
                        className="text-sm border border-input rounded-md px-2 py-1 bg-background"
                        value={editedData.severity}
                        onChange={(e) => setEditedData({...editedData, severity: e.target.value})}
                      >
                        <option value="Critical">Critical</option>
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                      </select>
                    ) : (
                      <Badge className={`${getSeverityClass(editedData.severity)} border`}>{editedData.severity}</Badge>
                    )}
                    <Badge variant="outline" className="bg-background">{editedData.type}</Badge>
                    <Badge variant={editedData.status === 'Active' ? 'destructive' : 'secondary'}>
                      {editedData.status}
                    </Badge>
                  </div>
                  
                  {isEditing ? (
                    <Input 
                      value={editedData.subtype || editedData.title || ''} 
                      onChange={(e) => setEditedData({...editedData, subtype: e.target.value})}
                      className="text-xl font-bold mt-2"
                    />
                  ) : (
                    <h2 className="text-xl sm:text-2xl font-bold text-foreground">
                      {editedData.subtype || editedData.title} at {editedData.airport || editedData.region}
                    </h2>
                  )}
                </div>
                
                <div className="flex items-center gap-2 self-end sm:self-start">
                  {isEditing ? (
                    <>
                      <Button variant="outline" onClick={() => setIsEditing(false)}>Cancel</Button>
                      <Button onClick={handleSave} className="gap-2"><Save className="w-4 h-4"/> Save</Button>
                    </>
                  ) : (
                    <>
                      <Button variant="outline" onClick={() => setIsEditing(true)}>Edit</Button>
                      <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-muted">
                        <X className="w-5 h-5" />
                      </Button>
                    </>
                  )}
                </div>
              </div>

              {/* Body */}
              <div className="modal-content p-0 sm:p-0">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full flex flex-col h-full">
                  <div className="px-4 sm:px-6 pt-4 border-b border-border bg-muted/10">
                    <TabsList className="w-full justify-start h-auto p-0 bg-transparent gap-6 overflow-x-auto hide-scrollbar">
                      <TabsTrigger value="overview" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3">Overview</TabsTrigger>
                      <TabsTrigger value="cascade" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3">Cascade Impact</TabsTrigger>
                      <TabsTrigger value="timeline" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3">Timeline</TabsTrigger>
                      <TabsTrigger value="comments" className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-0 pb-3">Comments ({commentsList.length})</TabsTrigger>
                    </TabsList>
                  </div>

                  <div className="p-4 sm:p-6 flex-1">
                    <TabsContent value="overview" className="mt-0 space-y-6">
                      {/* Key Metrics */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                        <div className="p-4 rounded-xl border border-border bg-card shadow-sm">
                          <div className="flex items-center gap-2 text-muted-foreground mb-2">
                            <Clock className="w-4 h-4" />
                            <span className="text-xs font-medium uppercase tracking-wider">Time Impact</span>
                          </div>
                          {isEditing ? (
                            <Input 
                              type="number" 
                              value={editedData.timeImpact || 0} 
                              onChange={(e) => setEditedData({...editedData, timeImpact: parseInt(e.target.value)})}
                            />
                          ) : (
                            <p className="text-xl font-bold text-foreground">{editedData.timeImpact || editedData.time || 0} mins</p>
                          )}
                        </div>
                        <div className="p-4 rounded-xl border border-border bg-card shadow-sm">
                          <div className="flex items-center gap-2 text-muted-foreground mb-2">
                            <DollarSign className="w-4 h-4" />
                            <span className="text-xs font-medium uppercase tracking-wider">Cost Impact</span>
                          </div>
                          {isEditing ? (
                            <Input 
                              type="number" 
                              value={editedData.costImpact || 0} 
                              onChange={(e) => setEditedData({...editedData, costImpact: parseInt(e.target.value)})}
                            />
                          ) : (
                            <p className="text-xl font-bold text-destructive">€{(editedData.costImpact || 0).toLocaleString()}</p>
                          )}
                        </div>
                        <div className="p-4 rounded-xl border border-border bg-card shadow-sm">
                          <div className="flex items-center gap-2 text-muted-foreground mb-2">
                            <Plane className="w-4 h-4" />
                            <span className="text-xs font-medium uppercase tracking-wider">Flights</span>
                          </div>
                          <p className="text-xl font-bold text-foreground">{editedData.affectedFlights?.length || 1}</p>
                        </div>
                        <div className="p-4 rounded-xl border border-border bg-card shadow-sm">
                          <div className="flex items-center gap-2 text-muted-foreground mb-2">
                            <Users className="w-4 h-4" />
                            <span className="text-xs font-medium uppercase tracking-wider">Crew</span>
                          </div>
                          <p className="text-xl font-bold text-foreground">{editedData.affectedCrew?.length || 0}</p>
                        </div>
                      </div>

                      {/* Root Cause */}
                      <div className="p-5 rounded-xl border border-border bg-muted/20">
                        <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                          <Activity className="w-5 h-5 text-primary" />
                          Root Cause Analysis
                        </h3>
                        {isEditing ? (
                          <Textarea 
                            value={editedData.rootCauseAnalysis || editedData.description || ''} 
                            onChange={(e) => setEditedData({...editedData, rootCauseAnalysis: e.target.value})}
                            rows={4}
                          />
                        ) : (
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {editedData.rootCauseAnalysis || editedData.description || 'No detailed analysis available.'}
                          </p>
                        )}
                      </div>

                      {/* Affected Resources */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-semibold text-sm text-foreground mb-3 uppercase tracking-wider">Affected Flights</h4>
                          <div className="flex flex-wrap gap-2">
                            {(editedData.affectedFlights || []).map(f => (
                              <Badge key={f} variant="secondary" className="bg-muted hover:bg-muted/80 cursor-pointer px-3 py-1.5">
                                <Plane className="w-3 h-3 mr-2" /> {f}
                              </Badge>
                            ))}
                            {(!editedData.affectedFlights || editedData.affectedFlights.length === 0) && (
                              <span className="text-sm text-muted-foreground">None specified</span>
                            )}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-sm text-foreground mb-3 uppercase tracking-wider">Affected Crew</h4>
                          <div className="flex flex-wrap gap-2">
                            {(editedData.affectedCrew || []).map(c => (
                              <Badge key={c} variant="secondary" className="bg-muted hover:bg-muted/80 cursor-pointer px-3 py-1.5">
                                <Users className="w-3 h-3 mr-2" /> {c}
                              </Badge>
                            ))}
                            {(!editedData.affectedCrew || editedData.affectedCrew.length === 0) && (
                              <span className="text-sm text-muted-foreground">None specified</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="cascade" className="mt-0">
                      <CascadeImpactVisualization disruption={editedData} />
                    </TabsContent>

                    <TabsContent value="timeline" className="mt-0">
                      <DisruptionTimelineView disruption={editedData} />
                    </TabsContent>

                    <TabsContent value="comments" className="mt-0 space-y-6">
                      <div className="flex gap-3">
                        <Textarea 
                          placeholder="Add a comment or update..." 
                          value={comment}
                          onChange={(e) => setComment(e.target.value)}
                          className="min-h-[80px]"
                        />
                        <Button onClick={handleAddComment} className="self-end">Post</Button>
                      </div>
                      <div className="space-y-4">
                        {commentsList.map(c => (
                          <div key={c.id} className="p-4 rounded-xl border border-border bg-card">
                            <div className="flex justify-between items-start mb-2">
                              <span className="font-semibold text-sm text-foreground">{c.author}</span>
                              <span className="text-xs text-muted-foreground">{c.time}</span>
                            </div>
                            <p className="text-sm text-muted-foreground">{c.text}</p>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  </div>
                </Tabs>
              </div>

              {/* Footer Actions */}
              <div className="modal-footer">
                <Button variant="outline" onClick={onClose} className="w-full sm:w-auto">Close</Button>
                <Button 
                  variant="destructive" 
                  className="w-full sm:w-auto"
                  onClick={() => {
                    toast.success('Disruption escalated to critical response team.');
                    onClose();
                  }}
                >
                  Escalate
                </Button>
                <Button 
                  className="w-full sm:w-auto bg-primary hover:bg-primary/90 gap-2"
                  onClick={() => setShowSolutions(true)}
                >
                  <Activity className="w-4 h-4" /> View AI Solutions
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
      
      <DisruptionSolutionsModal 
        isOpen={showSolutions} 
        onClose={() => setShowSolutions(false)} 
        disruption={editedData}
        onApplySolution={(id, sol) => {
          setShowSolutions(false);
          onClose();
          toast.success(`Applied solution: ${sol.actionSummary}`);
        }}
      />
    </AnimatePresence>
  );
};

export default DisruptionDetailModal;