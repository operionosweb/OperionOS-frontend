import React from 'react';
import { useAviationFleet } from '@/contexts/AviationFleetContext.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Clock, AlertTriangle, TrendingDown, Percent, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const DecisionInsightsPanel = () => {
  const { insights } = useAviationFleet();
  const navigate = useNavigate();

  if (!insights.avgUtilization) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <Card className="bg-card hover:bg-muted/50 transition-colors cursor-pointer border-border" onClick={() => navigate('/demo/aviation/fleet')}>
        <CardContent className="p-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Expiring &lt; 6mo</p>
            <p className="text-2xl font-bold text-destructive">{insights.nearingLeaseEnd}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center text-destructive">
            <Clock className="w-5 h-5" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card hover:bg-muted/50 transition-colors cursor-pointer border-border" onClick={() => navigate('/demo/aviation/contracts')}>
        <CardContent className="p-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Avg Risk Score</p>
            <p className="text-2xl font-bold text-warning">{insights.avgRiskScore}/100</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-warning/10 flex items-center justify-center text-warning">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card hover:bg-muted/50 transition-colors cursor-pointer border-border" onClick={() => navigate('/demo/aviation/fleet')}>
        <CardContent className="p-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Avg Utilization</p>
            <p className="text-2xl font-bold text-emerald-600">{insights.avgUtilization}%</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-600">
            <Percent className="w-5 h-5" />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card hover:bg-muted/50 transition-colors cursor-pointer border-border" onClick={() => navigate('/demo/aviation/scenarios')}>
        <CardContent className="p-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-1">Underutilized Assets</p>
            <div className="flex items-center gap-2">
              <p className="text-2xl font-bold text-blue-600">{insights.underutilizedCount}</p>
              <span className="text-xs font-medium text-blue-600 flex items-center">Action required <ArrowRight className="w-3 h-3 ml-1" /></span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-600">
            <TrendingDown className="w-5 h-5" />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DecisionInsightsPanel;