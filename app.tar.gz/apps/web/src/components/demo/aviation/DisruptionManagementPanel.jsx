import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { AlertTriangle, Activity, DollarSign, Zap, Clock, Users, Plane } from 'lucide-react';
import DisruptionDetailModal from './DisruptionDetailModal.jsx';
import CascadeImpactVisualization from './CascadeImpactVisualization.jsx';
import DisruptionTimelineView from './DisruptionTimelineView.jsx';

const DisruptionManagementPanel = () => {
  const { enhancedDisruptions, selectedDisruption, setSelectedDisruption, totalSavings, applySolution } = useDemo();
  const [activeTab, setActiveTab] = useState('overview');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const activeDisruptions = enhancedDisruptions.filter(d => d.status === 'Active');
  const totalCostRisk = activeDisruptions.reduce((sum, d) => sum + d.costImpact, 0);

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'Critical': return 'bg-red-500/10 text-red-700 border-red-500/30';
      case 'High': return 'bg-orange-500/10 text-orange-700 border-orange-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      default: return 'bg-slate-500/10 text-slate-700 border-slate-500/30';
    }
  };

  const handleDisruptionClick = (d) => {
    setSelectedDisruption(d);
    setIsModalOpen(true);
  };

  return (
    <div className="flex-auto-height gap-4 sm:gap-5 md:gap-6 animate-in fade-in duration-500 w-full">
      {/* KPI Header */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 w-full">
        <Card className="bg-card border border-border shadow-sm h-auto w-full">
          <CardContent className="p-3 sm:p-4 lg:p-5 flex items-center gap-3 sm:gap-4">
            <div className="p-2 sm:p-3 bg-red-500/10 rounded-xl shrink-0"><AlertTriangle className="w-5 h-5 sm:w-6 sm:h-6 text-red-600" /></div>
            <div className="min-w-0 flex-1">
              <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">Active Disruptions</p>
              <p className="text-lg sm:text-xl lg:text-2xl font-bold text-foreground">{activeDisruptions.length}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border border-border shadow-sm h-auto w-full">
          <CardContent className="p-3 sm:p-4 lg:p-5 flex items-center gap-3 sm:gap-4">
            <div className="p-2 sm:p-3 bg-orange-500/10 rounded-xl shrink-0"><Activity className="w-5 h-5 sm:w-6 sm:h-6 text-orange-600" /></div>
            <div className="min-w-0 flex-1">
              <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">Total Cost Risk</p>
              <p className="text-lg sm:text-xl lg:text-2xl font-bold text-foreground">€{totalCostRisk.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border border-border shadow-sm h-auto w-full">
          <CardContent className="p-3 sm:p-4 lg:p-5 flex items-center gap-3 sm:gap-4">
            <div className="p-2 sm:p-3 bg-green-500/10 rounded-xl shrink-0"><DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" /></div>
            <div className="min-w-0 flex-1">
              <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">AI Savings</p>
              <p className="text-lg sm:text-xl lg:text-2xl font-bold text-green-600">€{totalSavings.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border border-border shadow-sm h-auto w-full">
          <CardContent className="p-3 sm:p-4 lg:p-5 flex items-center gap-3 sm:gap-4">
            <div className="p-2 sm:p-3 bg-blue-500/10 rounded-xl shrink-0"><Zap className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" /></div>
            <div className="min-w-0 flex-1">
              <p className="text-xs sm:text-sm font-medium text-muted-foreground truncate">Auto-Resolved</p>
              <p className="text-lg sm:text-xl lg:text-2xl font-bold text-blue-600">12</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6 items-start w-full">
        {/* Disruption List */}
        <Card className="lg:col-span-1 bg-card border border-border shadow-sm flex flex-col h-auto w-full">
          <CardHeader className="border-b border-border p-3 sm:p-4">
            <CardTitle className="text-base sm:text-lg font-bold text-foreground">Detection Feed</CardTitle>
          </CardHeader>
          <CardContent className="p-0 flex-1 max-h-[400px] sm:max-h-[500px] overflow-y-auto scrollable-y">
            <div className="divide-y divide-border">
              {activeDisruptions.map(d => (
                <div 
                  key={d.id} 
                  onClick={() => handleDisruptionClick(d)}
                  className={`p-3 sm:p-4 cursor-pointer transition-colors hover:bg-muted/50 ${selectedDisruption?.id === d.id ? 'bg-primary/5 border-l-4 border-primary' : 'border-l-4 border-transparent'}`}
                >
                  <div className="flex justify-between items-start mb-1.5 sm:mb-2 gap-2">
                    <Badge className={`${getSeverityColor(d.severity)} border text-[10px] sm:text-xs shrink-0`}>{d.severity}</Badge>
                    <span className="text-[10px] sm:text-xs font-medium text-muted-foreground shrink-0">{d.timeImpact}m delay</span>
                  </div>
                  <h4 className="font-semibold text-sm sm:text-base text-foreground mb-1 break-words">{d.type}: {d.subtype}</h4>
                  <p className="text-xs sm:text-sm text-muted-foreground line-clamp-1 break-words">{d.airport} • {d.affectedFlights.length} flights affected</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Detail & Solutions Panel (Desktop View) */}
        <div className="hidden lg:flex lg:col-span-2 flex-col h-auto w-full">
          {selectedDisruption ? (
            <Card className="bg-card border border-border shadow-sm flex-1 flex flex-col h-auto w-full">
              <CardHeader className="border-b border-border bg-muted/30 p-4 sm:p-5">
                <div className="flex justify-between items-start gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <Badge className={`${getSeverityColor(selectedDisruption.severity)} border text-xs`}>{selectedDisruption.severity}</Badge>
                      <Badge variant="outline" className="bg-background text-xs">{selectedDisruption.type}</Badge>
                    </div>
                    <CardTitle className="text-xl sm:text-2xl font-bold text-foreground break-words">{selectedDisruption.subtype} at {selectedDisruption.airport}</CardTitle>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs sm:text-sm text-muted-foreground font-medium">Estimated Impact</p>
                    <p className="text-lg sm:text-xl font-bold text-destructive">€{selectedDisruption.costImpact.toLocaleString()}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-5 md:p-6 flex-1 overflow-y-auto scrollable-y">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-4 mb-4 sm:mb-6 bg-muted/50 h-auto">
                    <TabsTrigger value="overview" className="text-xs sm:text-sm py-1.5 sm:py-2">Overview</TabsTrigger>
                    <TabsTrigger value="solutions" className="text-xs sm:text-sm py-1.5 sm:py-2">AI Solutions</TabsTrigger>
                    <TabsTrigger value="cascade" className="text-xs sm:text-sm py-1.5 sm:py-2">Cascade Impact</TabsTrigger>
                    <TabsTrigger value="timeline" className="text-xs sm:text-sm py-1.5 sm:py-2">Timeline</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="overview" className="space-y-4 sm:space-y-6">
                    <div className="p-3 sm:p-4 bg-muted/20 rounded-xl border border-border">
                      <h3 className="font-semibold text-sm sm:text-base text-foreground mb-2">Root Cause Analysis</h3>
                      <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed break-words">{selectedDisruption.rootCauseAnalysis}</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                      <div className="p-3 sm:p-4 border border-border rounded-xl bg-card">
                        <div className="flex items-center gap-2 mb-2 sm:mb-3 text-sm sm:text-base text-foreground font-semibold">
                          <Plane className="w-4 h-4 text-primary" /> Affected Flights ({selectedDisruption.affectedFlights.length})
                        </div>
                        <div className="flex flex-wrap gap-1.5 sm:gap-2">
                          {selectedDisruption.affectedFlights.map(f => (
                            <Badge key={f} variant="secondary" className="bg-muted text-[10px] sm:text-xs">{f}</Badge>
                          ))}
                        </div>
                      </div>
                      <div className="p-3 sm:p-4 border border-border rounded-xl bg-card">
                        <div className="flex items-center gap-2 mb-2 sm:mb-3 text-sm sm:text-base text-foreground font-semibold">
                          <Users className="w-4 h-4 text-primary" /> Affected Crew ({selectedDisruption.affectedCrew.length})
                        </div>
                        <div className="flex flex-wrap gap-1.5 sm:gap-2">
                          {selectedDisruption.affectedCrew.map(c => (
                            <Badge key={c} variant="secondary" className="bg-muted text-[10px] sm:text-xs">{c}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="solutions" className="space-y-3 sm:space-y-4">
                    {selectedDisruption.solutions.map((sol, idx) => (
                      <div key={sol.id} className={`p-4 sm:p-5 rounded-xl border-2 transition-all ${sol.isRecommended ? 'border-primary bg-primary/5' : 'border-border bg-card'}`}>
                        <div className="flex flex-col sm:flex-row justify-between items-start mb-3 sm:mb-4 gap-3">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <h4 className="font-bold text-base sm:text-lg text-foreground break-words">{sol.actionSummary}</h4>
                              {sol.isRecommended && <Badge className="bg-primary text-primary-foreground text-[10px] sm:text-xs">Recommended</Badge>}
                            </div>
                            <p className="text-xs sm:text-sm text-muted-foreground break-words">{sol.operationalImpact}</p>
                          </div>
                          <div className="text-left sm:text-right shrink-0">
                            <p className="text-xs sm:text-sm font-medium text-muted-foreground">Net Impact</p>
                            <p className={`text-base sm:text-lg font-bold ${sol.costImpact < 0 ? 'text-green-600' : 'text-destructive'}`}>
                              {sol.costImpact < 0 ? '-' : '+'}€{Math.abs(sol.costImpact).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-3 sm:gap-4 mb-3 sm:mb-4 text-xs sm:text-sm text-muted-foreground">
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3 sm:w-4 sm:h-4" /> {sol.timeToImplement}m to execute</span>
                          <span className="flex items-center gap-1"><Activity className="w-3 h-3 sm:w-4 sm:h-4" /> {sol.confidenceScore}% Confidence</span>
                        </div>
                        <div className="flex flex-wrap gap-2 sm:gap-3">
                          <Button size="sm" onClick={() => applySolution(selectedDisruption.id, sol)} className={`text-xs sm:text-sm ${sol.isRecommended ? 'bg-primary hover:bg-primary/90' : ''}`}>
                            Apply Solution
                          </Button>
                          <Button size="sm" variant="outline" className="text-xs sm:text-sm">Simulate Scenario</Button>
                        </div>
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="cascade">
                    <CascadeImpactVisualization disruption={selectedDisruption} />
                  </TabsContent>

                  <TabsContent value="timeline">
                    <DisruptionTimelineView disruption={selectedDisruption} />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center bg-muted/10 rounded-xl border-2 border-dashed border-border text-muted-foreground p-8 sm:p-12 w-full">
              <AlertTriangle className="w-10 h-10 sm:w-12 sm:h-12 mb-3 sm:mb-4 opacity-20" />
              <h3 className="text-base sm:text-lg font-medium text-foreground mb-1 text-center">No Disruption Selected</h3>
              <p className="text-xs sm:text-sm text-center">Select an active disruption from the feed to view AI analysis and solutions.</p>
            </div>
          )}
        </div>
      </div>

      {/* Mobile/Tablet Modal View */}
      <DisruptionDetailModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        disruption={selectedDisruption} 
      />
    </div>
  );
};

export default DisruptionManagementPanel;