import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { AlertTriangle, Users, Plane, Clock, DollarSign } from 'lucide-react';

const DisruptionCard = ({ disruption, onClick, isSelected }) => {
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'Critical': return 'bg-red-500/10 text-red-700 border-red-500/30';
      case 'High': return 'bg-orange-500/10 text-orange-700 border-orange-500/30';
      case 'Medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30';
      case 'Low': return 'bg-blue-500/10 text-blue-700 border-blue-500/30';
      default: return 'bg-gray-500/10 text-gray-700 border-gray-500/30';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'crew-related': return Users;
      case 'technical': return AlertTriangle;
      case 'weather': return AlertTriangle;
      case 'ATC/congestion': return Plane;
      case 'passenger': return Users;
      default: return AlertTriangle;
    }
  };

  const TypeIcon = getTypeIcon(disruption.type);
  const isCritical = disruption.severity === 'Critical';

  return (
    <Card 
      onClick={onClick}
      className={`bg-white border-2 shadow-md hover:shadow-xl hover:-translate-y-1 cursor-pointer transition-all duration-200 active:scale-[0.98] ${
        isSelected ? 'border-blue-500 ring-2 ring-blue-500/20' : 'border-gray-200 hover:border-blue-400'
      } ${isCritical ? 'animate-pulse' : ''}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              isCritical ? 'bg-red-500/10' : 'bg-blue-500/10'
            }`}>
              <TypeIcon className={`w-5 h-5 ${isCritical ? 'text-red-600' : 'text-blue-600'}`} />
            </div>
            <div>
              <p className="font-bold text-gray-900 text-sm">{disruption.subtype}</p>
              <p className="text-xs text-gray-600">{disruption.airport}</p>
            </div>
          </div>
          <Badge className={`${getSeverityColor(disruption.severity)} border-2 font-semibold text-xs`}>
            {disruption.severity}
          </Badge>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <Plane className="w-3 h-3" />
              Flights:
            </span>
            <span className="font-semibold text-gray-900">{disruption.affectedFlights.length}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <Users className="w-3 h-3" />
              Crew:
            </span>
            <span className="font-semibold text-gray-900">{disruption.affectedCrew.length}</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Impact:
            </span>
            <span className="font-semibold text-gray-900">{disruption.timeImpactMinutes}min</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <DollarSign className="w-3 h-3" />
              Cost:
            </span>
            <span className="font-semibold text-red-600">€{disruption.estimatedCostImpact.toLocaleString()}</span>
          </div>

          <div className="pt-2 border-t-2 border-gray-200">
            <Badge className={`${
              disruption.status === 'active' ? 'bg-orange-500/10 text-orange-700 border-orange-500/30' : 'bg-green-500/10 text-green-700 border-green-500/30'
            } border-2 text-xs`}>
              {disruption.status === 'active' ? 'Active' : 'Resolved'}
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DisruptionCard;