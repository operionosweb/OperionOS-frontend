import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Card } from '@/components/ui/card.jsx';
import TabNavigation from './TabNavigation.jsx';
import VesselCard from './VesselCard.jsx';
import ProgressBar from './ProgressBar.jsx';
import { MapTouchHandler } from '@/hooks/useMapTouchControl.js';

// Fix Leaflet icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const VesselOperationsDashboard = () => {
  const { vesselData, openModal } = useDemo();
  const [activeTab, setActiveTab] = useState('live');

  return (
    <div className="flex flex-col h-full space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Vessel Operations</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Real-time coordination of the Operion Sentinel fleet.
          </p>
        </div>
        <TabNavigation 
          tabs={[
            { id: 'live', label: 'Live View' },
            { id: 'history', label: 'History' },
            { id: 'planning', label: 'Planning' }
          ]} 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-[500px]">
        {/* Map Area */}
        <div className="map-container lg:col-span-2 relative rounded-2xl overflow-hidden border border-border shadow-sm z-0">
          <MapContainer center={[20, 0]} zoom={2} className="w-full h-full" zoomControl={true}>
            <MapTouchHandler />
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            {vesselData.map(vessel => (
              <Marker 
                key={vessel.id} 
                position={[vessel.lat, vessel.lng]}
                eventHandlers={{
                  click: () => openModal('vessel', vessel),
                }}
              >
                <Popup>
                  <div className="font-bold">{vessel.name}</div>
                  <div className="text-xs text-muted-foreground">{vessel.location}</div>
                  <button 
                    className="text-xs text-primary mt-2 font-medium hover:underline"
                    onClick={(e) => {
                      e.stopPropagation();
                      openModal('vessel', vessel);
                    }}
                  >
                    View Details
                  </button>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
          
          {/* Map Overlay */}
          <div className="absolute top-4 left-4 z-[400] bg-background/90 backdrop-blur-md p-4 rounded-xl border border-border shadow-lg pointer-events-none">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-[hsl(var(--tertiary))] animate-pulse"></div>
              <span className="text-xs font-bold uppercase tracking-wider">Active Vessels {vesselData.length}</span>
            </div>
            <div className="text-sm font-medium text-muted-foreground mb-2">EST. ARRIVAL HUB Rotterdam</div>
          </div>
        </div>

        {/* Right Panel */}
        <div className="hidden lg:flex flex-col space-y-6">
          <Card className="p-5 border-border shadow-sm flex-1">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg">Fleet Status</h3>
              <button className="text-xs font-bold text-primary hover:underline">View All 128 Vessels</button>
            </div>
            <div className="space-y-3">
              {vesselData.map(vessel => (
                <div key={vessel.id} onClick={() => openModal('vessel', vessel)} className="cursor-pointer hover:scale-[1.02] transition-transform">
                  <VesselCard vessel={vessel} />
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5 border-border shadow-sm">
            <h3 className="font-bold text-lg mb-4">Operational Timeline</h3>
            <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-4">Next 72 Hours Projection</p>
            <div className="space-y-4">
              <div className="flex gap-3 cursor-pointer hover:bg-muted/50 p-2 rounded-lg transition-colors">
                <div className="w-1.5 bg-primary rounded-full"></div>
                <div>
                  <p className="text-sm font-bold">Sentinel Alpha</p>
                  <p className="text-xs text-muted-foreground">Transit: SG-HK, Unloading Ops</p>
                </div>
              </div>
              <div className="flex gap-3 cursor-pointer hover:bg-muted/50 p-2 rounded-lg transition-colors">
                <div className="w-1.5 bg-[hsl(var(--tertiary))] rounded-full"></div>
                <div>
                  <p className="text-sm font-bold">Ocean Guardian</p>
                  <p className="text-xs text-muted-foreground">Maintenance Cycle, Transit: LA-SF</p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Bottom Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4 border-border cursor-pointer hover:border-primary transition-colors" onClick={() => openModal('metric', 'personnel')}>
          <ProgressBar value={92} label="Total Personnel 1,248" colorClass="bg-primary" />
          <p className="text-xs text-muted-foreground mt-2">Currently Onboard 92% Capacity</p>
        </Card>
        <Card className="p-4 border-border cursor-pointer hover:border-primary transition-colors" onClick={() => openModal('metric', 'safety')}>
          <ProgressBar value={100} label="Safety Compliance" colorClass="bg-[hsl(var(--tertiary))]" />
          <p className="text-xs text-muted-foreground mt-2">Last 24h Audits 42/42 Passed</p>
        </Card>
        <Card className="p-4 border-border cursor-pointer hover:border-primary transition-colors" onClick={() => openModal('metric', 'fuel')}>
          <ProgressBar value={94.8} label="Fuel Efficiency" colorClass="bg-primary" />
          <p className="text-xs text-muted-foreground mt-2">Fleet Wide Index +4.2% vs Goal</p>
        </Card>
      </div>
    </div>
  );
};

export default VesselOperationsDashboard;