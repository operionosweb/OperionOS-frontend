import React from 'react';
import { Badge } from '@/components/ui/badge.jsx';
import { CheckCircle2, Clock, AlertCircle, Zap } from 'lucide-react';

const StatusBadge = ({ status, className = '' }) => {
  const config = {
    ACTIVE: { color: 'bg-green-500/10 text-green-700 border-green-500/30', icon: CheckCircle2 },
    STANDBY: { color: 'bg-blue-500/10 text-blue-700 border-blue-500/30', icon: Clock },
    RESTING: { color: 'bg-gray-500/10 text-gray-700 border-gray-500/30', icon: Zap },
    DELAYED: { color: 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30', icon: AlertCircle },
    ALERT: { color: 'bg-red-500/10 text-red-700 border-red-500/30', icon: AlertCircle },
    'On Time': { color: 'bg-green-500/10 text-green-700 border-green-500/30', icon: CheckCircle2 },
    Delayed: { color: 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30', icon: AlertCircle },
    Critical: { color: 'bg-red-500/10 text-red-700 border-red-500/30', icon: AlertCircle },
    Booked: { color: 'bg-green-500/10 text-green-700 border-green-500/30', icon: CheckCircle2 },
    Pending: { color: 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30', icon: Clock },
    Cancelled: { color: 'bg-red-500/10 text-red-700 border-red-500/30', icon: AlertCircle },
  };

  const { color, icon: Icon } = config[status] || config.RESTING;

  return (
    <Badge variant="outline" className={`flex items-center gap-1.5 px-2.5 py-0.5 font-semibold uppercase tracking-wider text-[10px] border ${color} ${className}`}>
      <Icon className="w-3 h-3" />
      {status}
    </Badge>
  );
};

export default StatusBadge;