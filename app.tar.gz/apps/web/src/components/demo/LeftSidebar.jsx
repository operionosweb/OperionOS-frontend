import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, Users, Plane, AlertTriangle, TrendingUp, 
  Briefcase, Bell, ShieldCheck, MessageSquare, Wrench, Anchor, Map, BarChart3, X, FileText, Calculator
} from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import Logo from '@/components/Logo.jsx';

const LeftSidebar = ({ industry = 'maritime', isMobileMenuOpen = false, setIsMobileMenuOpen, isMobile = false }) => {
  const location = useLocation();
  
  const maritimeLinks = [
    { path: '/demo/maritime', label: 'Mission Control', icon: LayoutDashboard },
    { path: '/demo/maritime/vessel-operations', label: 'Vessel Operations', icon: Anchor },
    { path: '/demo/maritime/crew', label: 'Crew Management', icon: Users },
    { path: '/demo/maritime/travel', label: 'Crew Movements & Logistics', icon: Briefcase },
    { path: '/demo/maritime/disruptions', label: 'Disruption Management', icon: AlertTriangle },
    { path: '/demo/maritime/planning', label: 'Planning & Forecasting', icon: Map },
    { path: '/demo/maritime/intelligence', label: 'Business Intelligence', icon: BarChart3 },
    { path: '/demo/maritime/roi-savings', label: 'ROI & Savings Tracking', icon: TrendingUp },
  ];

  const aviationLinks = [
    { path: '/demo/aviation/fleet', label: 'Fleet Overview', icon: Plane },
    { path: '/demo/aviation/contracts', label: 'Contract Intelligence', icon: FileText },
    { path: '/demo/aviation/financials', label: 'Financial Dashboard', icon: BarChart3 },
    { path: '/demo/aviation/scenarios', label: 'Scenario Simulator', icon: Calculator },
    { path: '/demo/aviation', label: 'Mission Control', icon: LayoutDashboard },
    { path: '/demo/aviation/crew', label: 'Crew Management', icon: Users },
    { path: '/demo/aviation/travel', label: 'Crew Movements & Logistics', icon: Briefcase },
    { path: '/demo/aviation/disruptions', label: 'Disruption Management', icon: AlertTriangle },
    { path: '/aviation-roi-savings', label: 'ROI & Savings', icon: TrendingUp },
  ];

  const links = industry === 'aviation' ? aviationLinks : maritimeLinks;

  const handleMenuItemClick = () => {
    if (isMobile && setIsMobileMenuOpen) {
      setIsMobileMenuOpen(false);
    }
  };

  const handleOverlayClick = () => {
    if (setIsMobileMenuOpen) {
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Overlay - only visible on mobile when menu is open */}
      {isMobile && isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={handleOverlayClick}
          aria-hidden="true"
        />
      )}

      {/* Sidebar/Drawer */}
      <aside 
        className={`
          fixed md:sticky top-0 h-screen w-64 bg-card border-r border-border z-40
          flex flex-col
          transition-transform duration-300 ease-in-out
          ${isMobile ? (isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full') : 'translate-x-0'}
          md:translate-x-0
        `}
      >
        {/* Header with Logo and Close Button */}
        <div className="p-6 border-b border-border flex items-center justify-between">
          <Logo variant="full" size="lg" />
          {isMobile && (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleMenuItemClick}
              className="md:hidden min-w-[44px] min-h-[44px]"
              aria-label="Close menu"
            >
              <X className="w-5 h-5" />
            </Button>
          )}
        </div>
        
        {/* Navigation Links */}
        <div className="flex-1 overflow-y-auto py-6 px-4 space-y-1 hide-scrollbar">
          <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider px-4 mb-4">
            {industry === 'aviation' ? 'Aviation Modules' : 'Maritime Modules'}
          </div>
          
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname === link.path || (link.path !== '/demo/aviation' && location.pathname.startsWith(link.path));
            
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={handleMenuItemClick}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 min-h-[44px] ${
                  isActive 
                    ? 'bg-primary/10 text-primary border border-primary/20 shadow-sm' 
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground border border-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-primary' : 'text-muted-foreground'}`} />
                {link.label}
              </Link>
            );
          })}
        </div>
        
        {/* Footer */}
        <div className="p-4 border-t border-border">
          <Link 
            to="/demo" 
            onClick={handleMenuItemClick}
            className="flex items-center justify-center gap-2 w-full py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors min-h-[44px]"
          >
            Exit Demo
          </Link>
        </div>
      </aside>
    </>
  );
};

export default LeftSidebar;