import React from 'react';
import { LayoutDashboard, Globe, BrainCircuit, FileText, History } from 'lucide-react';

const DisruptionsMobileBottomNav = () => {
  const navItems = [
    { icon: LayoutDashboard, label: 'Command', active: false },
    { icon: Globe, label: 'Map', active: false },
    { icon: BrainCircuit, label: 'AI Alerts', active: true },
    { icon: FileText, label: 'Manifests', active: false },
    { icon: History, label: 'History', active: false },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-card border-t border-border pb-safe z-40">
      <div className="flex items-center justify-around h-16 px-2">
        {navItems.map((item, idx) => (
          <button
            key={idx}
            className={`flex flex-col items-center justify-center w-full h-full space-y-1 touch-target ${
              item.active ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <div className={`relative p-1 rounded-full transition-colors ${item.active ? 'bg-primary/10' : ''}`}>
              <item.icon className="h-5 w-5" />
              {item.active && (
                <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-[hsl(var(--critical))] rounded-full border border-card"></span>
              )}
            </div>
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default DisruptionsMobileBottomNav;