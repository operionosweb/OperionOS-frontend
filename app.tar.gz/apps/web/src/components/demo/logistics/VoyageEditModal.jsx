import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { toast } from 'sonner';

const VoyageEditModal = ({ isOpen, onClose, voyage, onSave }) => {
  const [formData, setFormData] = useState({
    origin: '',
    destination: '',
    eta: '',
    etd: '',
    costLimit: '',
    specialRequirements: ''
  });

  useEffect(() => {
    if (voyage && isOpen) {
      let formattedEta = '';
      let formattedEtd = '';
      try {
        formattedEta = new Date(voyage.eta).toISOString().slice(0, 16);
        formattedEtd = new Date(voyage.etd || voyage.eta).toISOString().slice(0, 16);
      } catch (e) {
        // Fallback
      }

      setFormData({
        origin: voyage.origin || '',
        destination: voyage.destination || '',
        eta: formattedEta,
        etd: formattedEtd,
        costLimit: voyage.costLimit || '1500',
        specialRequirements: voyage.specialRequirements || ''
      });
    }
  }, [voyage, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const updatedVoyage = {
      ...voyage,
      origin: formData.origin,
      destination: formData.destination,
      eta: new Date(formData.eta).toISOString(),
      etd: new Date(formData.etd).toISOString(),
      costLimit: formData.costLimit,
      specialRequirements: formData.specialRequirements
    };
    onSave(updatedVoyage);
    toast.success('Movement adjusted successfully');
    onClose();
  };

  if (!voyage) return null;

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto custom-scrollbar">
        <DialogHeader>
          <DialogTitle className="text-xl">Adjust Movement: {voyage.voyageId}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-5 mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="origin">Origin Location</Label>
              <Input
                id="origin"
                name="origin"
                value={formData.origin}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="destination">Destination Location</Label>
              <Input
                id="destination"
                name="destination"
                value={formData.destination}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="etd">Movement Start Date</Label>
              <Input
                id="etd"
                name="etd"
                type="datetime-local"
                value={formData.etd}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="eta">Movement End Date</Label>
              <Input
                id="eta"
                name="eta"
                type="datetime-local"
                value={formData.eta}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="costLimit">Cost Limit ($)</Label>
              <Input
                id="costLimit"
                name="costLimit"
                type="number"
                value={formData.costLimit}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="specialRequirements">Special Requirements</Label>
              <Input
                id="specialRequirements"
                name="specialRequirements"
                value={formData.specialRequirements}
                onChange={handleChange}
                placeholder="e.g., Visa required"
              />
            </div>
          </div>

          <DialogFooter className="pt-4 border-t border-border">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit">Approve Movement</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default VoyageEditModal;