import React, { useState, useMemo, useEffect } from 'react';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Skeleton } from '@/components/ui/skeleton.jsx';
import { Search, Filter, Route, Zap } from 'lucide-react';
import { toast } from 'sonner';
import MovementPlanCard from './MovementPlanCard.jsx';
import MovementPlanDetailModal from './MovementPlanDetailModal.jsx';
import MovementPlanAdjustmentModal from './MovementPlanAdjustmentModal.jsx';
import { generateMovementData } from '@/lib/crewMovementExecutionData.js';

const CrewMovementExecution = () => {
  const [plans, setPlans] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [sortOption, setSortOption] = useState('start-asc');
  
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setPlans(generateMovementData());
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  const handleViewDetails = (plan) => {
    setSelectedPlan(plan);
    setIsDetailModalOpen(true);
  };

  const handleEdit = (plan) => {
    setSelectedPlan(plan);
    setIsEditModalOpen(true);
  };

  const createAuditTrail = (logs, action) => {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    return [...logs, { time, action }];
  };

  const handleSaveEdit = (updatedPlan) => {
    updatedPlan.auditTrail = createAuditTrail(updatedPlan.auditTrail, 'Plan adjusted by Operations Coordinator');
    setPlans(prev => prev.map(p => p.id === updatedPlan.id ? updatedPlan : p));
    if (selectedPlan?.id === updatedPlan.id) {
      setSelectedPlan(updatedPlan);
    }
  };

  // Mock Operations Functions requested in Task 9
  const sendMovementPlanToProviders = (id) => {
    setPlans(prev => prev.map(p => {
      if (p.id === id) {
        return { 
          ...p, 
          status: 'in_progress',
          progress: Math.max(10, p.progress),
          auditTrail: createAuditTrail(p.auditTrail, 'Sent to Providers: Awaiting confirmation')
        };
      }
      return p;
    }));
    toast.success('Plan sent to external providers for execution.');
    
    // Simulate async provider confirmation
    setTimeout(() => {
      trackProviderStatus(id);
    }, 2000);

    if (selectedPlan?.id === id) {
      setSelectedPlan(prev => ({
        ...prev,
        status: 'in_progress',
        progress: Math.max(10, prev.progress),
        auditTrail: createAuditTrail(prev.auditTrail, 'Sent to Providers: Awaiting confirmation')
      }));
    }
  };

  const trackProviderStatus = (id) => {
    setPlans(prev => prev.map(p => {
      if (p.id === id && p.status === 'in_progress') {
        return {
          ...p,
          auditTrail: createAuditTrail(p.auditTrail, `Provider Integration: Airline confirmed, Hotel confirmed.`)
        };
      }
      return p;
    }));
    toast.info('Provider tracking updated: All segments confirmed.');
  };

  const generateAlternativePlan = (id) => {
    setPlans(prev => prev.map(p => {
      if (p.id === id) {
        return { 
          ...p,
          complianceStatus: 'compliant',
          auditTrail: createAuditTrail(p.auditTrail, 'Alternative plan generated to mitigate disruption'),
          aiRecommendations: p.aiRecommendations.filter(r => r.type !== 'risk' && r.type !== 'compliance')
        };
      }
      return p;
    }));
    toast.success('Alternative route generated and compliance verified.');
    
    if (selectedPlan?.id === id) {
      setSelectedPlan(prev => ({
        ...prev,
        complianceStatus: 'compliant',
        auditTrail: createAuditTrail(prev.auditTrail, 'Alternative plan generated to mitigate disruption'),
        aiRecommendations: prev.aiRecommendations.filter(r => r.type !== 'risk' && r.type !== 'compliance')
      }));
    }
  };

  const filteredAndSortedPlans = useMemo(() => {
    let result = [...plans];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p => 
        p.crewMembers.some(c => c.toLowerCase().includes(q)) || 
        p.planId.toLowerCase().includes(q) ||
        p.origin.toLowerCase().includes(q) ||
        p.destination.toLowerCase().includes(q)
      );
    }

    if (filterStatus !== 'All') {
      result = result.filter(p => p.status === filterStatus);
    }

    result.sort((a, b) => {
      switch (sortOption) {
        case 'start-asc': return new Date(a.startDate) - new Date(b.startDate);
        case 'start-desc': return new Date(b.startDate) - new Date(a.startDate);
        case 'progress-desc': return b.progress - a.progress;
        case 'progress-asc': return a.progress - b.progress;
        default: return 0;
      }
    });

    return result;
  }, [plans, searchQuery, filterStatus, sortOption]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-card p-6 rounded-2xl border border-border shadow-sm">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Crew Movement Execution</h2>
          <p className="text-muted-foreground text-sm mt-1">Generate, adjust, and execute global crew movements via external providers.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search crew members..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-background border-border"
            />
          </div>
          <div className="flex gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-auto">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <select 
                className="flex h-10 w-full sm:w-40 rounded-md border border-input bg-background pl-9 pr-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="All">Filter by rotation</option>
                <option value="approved">Approved</option>
                <option value="in_progress">In Progress</option>
                <option value="executed">Executed</option>
                <option value="disrupted">Disrupted</option>
              </select>
            </div>
            <select 
              className="flex h-10 w-full sm:w-44 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
            >
              <option value="start-asc">Crew status (available)</option>
              <option value="start-desc">Crew status (assigned)</option>
              <option value="progress-desc">Progress (Highest)</option>
              <option value="progress-asc">Progress (Lowest)</option>
            </select>
          </div>
          <Button onClick={() => toast.success('New movement plan generation process started based on current schedule.')} className="w-full sm:w-auto">
            <Zap className="w-4 h-4 mr-2" /> Generate Plan
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex flex-col space-y-3 p-4 border border-border rounded-xl bg-card">
              <div className="flex justify-between">
                <Skeleton className="h-10 w-10 rounded-xl" />
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-20 w-full rounded-lg mt-4" />
              <div className="grid grid-cols-2 gap-2 mt-4">
                <Skeleton className="h-12 w-full rounded-lg" />
                <Skeleton className="h-12 w-full rounded-lg" />
              </div>
            </div>
          ))}
        </div>
      ) : filteredAndSortedPlans.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center border-2 border-dashed border-border rounded-2xl bg-muted/10">
          <Route className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
          <h3 className="text-lg font-medium">No movement plans found</h3>
          <p className="text-muted-foreground text-sm mt-1">Try adjusting your search or filters.</p>
          <Button variant="outline" className="mt-4" onClick={() => {setSearchQuery(''); setFilterStatus('All');}}>Clear Filters</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAndSortedPlans.map(plan => (
            <MovementPlanCard 
              key={plan.id} 
              plan={plan} 
              onViewDetails={handleViewDetails}
              onApprove={sendMovementPlanToProviders}
              onAdjust={handleEdit}
            />
          ))}
        </div>
      )}

      <MovementPlanDetailModal 
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        plan={selectedPlan}
        onAdjust={(p) => { setIsDetailModalOpen(false); handleEdit(p); }}
        onApprove={sendMovementPlanToProviders}
        onGenerateAlternative={generateAlternativePlan}
      />

      <MovementPlanAdjustmentModal 
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        plan={selectedPlan}
        onSave={handleSaveEdit}
      />
    </div>
  );
};

export default CrewMovementExecution;