import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Users, MapPin, Clock, AlertTriangle, ArrowRight, Settings2, Activity, DollarSign } from 'lucide-react';

const VoyageCard = ({ voyage, onViewDetails, onOptimize, onDelay, onUpdateStatus, onEdit }) => {
  const getStatusColor = (status) => {
    switch(status) {
      case 'in_progress': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'executed': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'disrupted': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'approved': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getRiskColor = (score) => {
    if (score <= 30) return 'bg-emerald-500';
    if (score <= 65) return 'bg-amber-500';
    return 'bg-destructive';
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <Card className="overflow-hidden flex flex-col h-full transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-border group cursor-pointer bg-card" onClick={() => onViewDetails(voyage)}>
      <div className="p-4 border-b border-border bg-muted/20 flex justify-between items-start">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-primary/10 rounded-xl text-primary group-hover:scale-110 transition-transform">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base leading-tight group-hover:text-primary transition-colors">{voyage.vesselName || 'Crew Movement'}</h3>
            <p className="text-xs text-muted-foreground font-medium mt-0.5">{voyage.voyageId}</p>
          </div>
        </div>
        <Badge variant="outline" className={`text-[10px] px-2.5 py-0.5 font-semibold uppercase tracking-wider ${getStatusColor(voyage.status || 'in_progress')}`}>
          {voyage.status || 'in_progress'}
        </Badge>
      </div>

      <CardContent className="p-5 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-5 text-sm bg-muted/30 p-3 rounded-xl border border-border/50">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1 font-semibold">Origin Location</span>
            <span className="font-medium flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-muted-foreground" /> {voyage.origin}</span>
          </div>
          <div className="flex flex-col items-center px-2">
            <ArrowRight className="w-4 h-4 text-muted-foreground/40 mb-1" />
            <span className="text-[10px] text-muted-foreground font-medium">Provider Status: OK</span>
          </div>
          <div className="flex flex-col text-right">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1 font-semibold">Destination Location</span>
            <span className="font-medium flex items-center gap-1.5 justify-end"><MapPin className="w-3.5 h-3.5 text-primary" /> {voyage.destination}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-5">
          <div className="flex flex-col p-3 rounded-xl border border-border/50 bg-card">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1.5 mb-1 font-semibold"><Clock className="w-3 h-3" /> Timeline</span>
            <span className="text-sm font-bold">{formatDate(voyage.eta)}</span>
          </div>
          <div className="flex flex-col p-3 rounded-xl border border-border/50 bg-card text-right">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1 font-semibold">Operational Cost</span>
            <span className="text-sm font-bold text-primary flex items-center justify-end gap-1"><DollarSign className="w-3.5 h-3.5" /> 1,450</span>
          </div>
        </div>

        <div className="mt-auto space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-muted-foreground font-medium">
              <AlertTriangle className="w-3.5 h-3.5" /> Risk Level
            </span>
            <span className="font-bold tabular-nums">{voyage.riskScore}/100</span>
          </div>
          <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
            <div 
              className={`h-full ${getRiskColor(voyage.riskScore)} transition-all duration-500`} 
              style={{ width: `${voyage.riskScore}%` }} 
            />
          </div>
        </div>
      </CardContent>

      <div className="p-3 border-t border-border bg-muted/10 grid grid-cols-2 sm:grid-cols-4 gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs h-8 w-full"
          onClick={(e) => { e.stopPropagation(); onOptimize(voyage.id); }}
        >
          <Activity className="w-3 h-3 mr-1.5" /> Optimize
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs h-8 w-full text-amber-600 hover:text-amber-700 hover:bg-amber-50"
          onClick={(e) => { e.stopPropagation(); onDelay(voyage.id); }}
        >
          <Clock className="w-3 h-3 mr-1.5" /> Delay
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs h-8 w-full"
          onClick={(e) => { e.stopPropagation(); onViewDetails(voyage); }}
        >
          View Movement
        </Button>
        <Button 
          variant="default"
          size="sm" 
          className="text-xs h-8 w-full"
          onClick={(e) => { e.stopPropagation(); onEdit(voyage); }}
        >
          <Settings2 className="w-3 h-3 mr-1.5" /> Adjust
        </Button>
      </div>
    </Card>
  );
};

export default VoyageCard;