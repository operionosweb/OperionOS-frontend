import React, { useState, useMemo, useEffect } from 'react';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Skeleton } from '@/components/ui/skeleton.jsx';
import { Search, Ship, Filter } from 'lucide-react';
import { toast } from 'sonner';
import VoyageCard from './VoyageCard.jsx';
import VoyageDetailModal from './VoyageDetailModal.jsx';
import VoyageEditModal from './VoyageEditModal.jsx';
import { generateTravelLogisticsData } from '@/lib/travelLogisticsData.js';

const GlobalTravelLogistics = () => {
  const [voyages, setVoyages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [sortOption, setSortOption] = useState('eta-asc');
  
  const [selectedVoyage, setSelectedVoyage] = useState(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  useEffect(() => {
    // Simulate network request
    const timer = setTimeout(() => {
      setVoyages(generateTravelLogisticsData());
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  const handleViewDetails = (voyage) => {
    setSelectedVoyage(voyage);
    setIsDetailModalOpen(true);
  };

  const handleEdit = (voyage) => {
    setSelectedVoyage(voyage);
    setIsEditModalOpen(true);
  };

  const handleSaveEdit = (updatedVoyage) => {
    setVoyages(prev => prev.map(v => v.id === updatedVoyage.id ? updatedVoyage : v));
    if (selectedVoyage?.id === updatedVoyage.id) {
      setSelectedVoyage(updatedVoyage);
    }
  };

  const handleOptimize = (id) => {
    setVoyages(prev => prev.map(v => {
      if (v.id === id) {
        const newDistance = Math.floor(v.distance * 0.92); // Reduce by ~8%
        const newEta = new Date(v.eta);
        newEta.setHours(newEta.getHours() - 12); // Save 12 hours
        return { 
          ...v, 
          distance: newDistance, 
          eta: newEta.toISOString(),
          riskScore: Math.max(0, v.riskScore - 15),
          aiRecommendations: [
            { type: 'efficiency', title: 'Route Optimized', description: 'Distance reduced by 8%. Fuel savings projected at 4.2%.', impact: 'High' },
            ...v.aiRecommendations
          ]
        };
      }
      return v;
    }));
    toast.success('Route optimized. Distance and ETA updated.');
    
    if (selectedVoyage?.id === id) {
      setSelectedVoyage(prev => ({
        ...prev,
        distance: Math.floor(prev.distance * 0.92),
        eta: new Date(new Date(prev.eta).getTime() - 12 * 60 * 60 * 1000).toISOString(),
        riskScore: Math.max(0, prev.riskScore - 15)
      }));
    }
  };

  const handleDelay = (id) => {
    setVoyages(prev => prev.map(v => {
      if (v.id === id) {
        const delayHours = Math.floor(Math.random() * 8) + 4; // 4-12 hours
        const newEta = new Date(v.eta);
        newEta.setHours(newEta.getHours() + delayHours);
        return { 
          ...v, 
          status: 'Delayed', 
          eta: newEta.toISOString(),
          riskScore: Math.min(100, v.riskScore + 25),
          delayProbability: Math.min(100, v.delayProbability + 30)
        };
      }
      return v;
    }));
    toast.error('Delay simulated. Status updated to Delayed.');
    
    if (selectedVoyage?.id === id) {
      setSelectedVoyage(prev => {
        const newEta = new Date(prev.eta);
        newEta.setHours(newEta.getHours() + 8);
        return {
          ...prev,
          status: 'Delayed',
          eta: newEta.toISOString(),
          riskScore: Math.min(100, prev.riskScore + 25)
        };
      });
    }
  };

  const handleUpdateStatus = (id) => {
    const statusCycle = {
      'En Route': 'Docked',
      'Docked': 'Completed',
      'Delayed': 'En Route',
      'Completed': 'En Route'
    };
    
    setVoyages(prev => prev.map(v => {
      if (v.id === id) {
        const newStatus = statusCycle[v.status] || 'En Route';
        return { ...v, status: newStatus };
      }
      return v;
    }));
    toast.success('Voyage status updated.');
    
    if (selectedVoyage?.id === id) {
      setSelectedVoyage(prev => ({
        ...prev,
        status: statusCycle[prev.status] || 'En Route'
      }));
    }
  };

  const filteredAndSortedVoyages = useMemo(() => {
    let result = [...voyages];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(v => 
        v.vesselName.toLowerCase().includes(q) || 
        v.voyageId.toLowerCase().includes(q) ||
        v.origin.toLowerCase().includes(q) ||
        v.destination.toLowerCase().includes(q)
      );
    }

    if (filterStatus !== 'All') {
      result = result.filter(v => v.status === filterStatus);
    }

    result.sort((a, b) => {
      switch (sortOption) {
        case 'eta-asc': return new Date(a.eta) - new Date(b.eta);
        case 'eta-desc': return new Date(b.eta) - new Date(a.eta);
        case 'risk-desc': return b.riskScore - a.riskScore;
        case 'risk-asc': return a.riskScore - b.riskScore;
        case 'days-asc': return a.daysRemaining - b.daysRemaining;
        default: return 0;
      }
    });

    return result;
  }, [voyages, searchQuery, filterStatus, sortOption]);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-card p-6 rounded-2xl border border-border shadow-sm">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Global Crew Movements & Logistics</h2>
          <p className="text-muted-foreground text-sm mt-1">Monitor and optimize fleet voyages worldwide.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search vessels, ports, IDs..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-background border-border"
            />
          </div>
          <div className="flex gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-auto">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <select 
                className="flex h-10 w-full sm:w-40 rounded-md border border-input bg-background pl-9 pr-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
              >
                <option value="All">All Statuses</option>
                <option value="En Route">En Route</option>
                <option value="Docked">Docked</option>
                <option value="Delayed">Delayed</option>
                <option value="Completed">Completed</option>
              </select>
            </div>
            <select 
              className="flex h-10 w-full sm:w-44 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
            >
              <option value="eta-asc">ETA (Earliest)</option>
              <option value="eta-desc">ETA (Latest)</option>
              <option value="risk-desc">Risk (Highest)</option>
              <option value="risk-asc">Risk (Lowest)</option>
              <option value="days-asc">Days Remaining</option>
            </select>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex flex-col space-y-3 p-4 border border-border rounded-xl bg-card">
              <div className="flex justify-between">
                <Skeleton className="h-10 w-10 rounded-xl" />
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-20 w-full rounded-lg mt-4" />
              <div className="grid grid-cols-2 gap-2 mt-4">
                <Skeleton className="h-12 w-full rounded-lg" />
                <Skeleton className="h-12 w-full rounded-lg" />
              </div>
            </div>
          ))}
        </div>
      ) : filteredAndSortedVoyages.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center border-2 border-dashed border-border rounded-2xl bg-muted/10">
          <Ship className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
          <h3 className="text-lg font-medium">No voyages found</h3>
          <p className="text-muted-foreground text-sm mt-1">Try adjusting your search or filters.</p>
          <Button variant="outline" className="mt-4" onClick={() => {setSearchQuery(''); setFilterStatus('All');}}>Clear Filters</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAndSortedVoyages.map(voyage => (
            <VoyageCard 
              key={voyage.id} 
              voyage={voyage} 
              onViewDetails={handleViewDetails}
              onOptimize={handleOptimize}
              onDelay={handleDelay}
              onUpdateStatus={handleUpdateStatus}
              onEdit={handleEdit}
            />
          ))}
        </div>
      )}

      <VoyageDetailModal 
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        voyage={selectedVoyage}
        onEdit={(v) => { setIsDetailModalOpen(false); handleEdit(v); }}
        onOptimize={handleOptimize}
        onDelay={handleDelay}
        onUpdateStatus={handleUpdateStatus}
      />

      <VoyageEditModal 
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        voyage={selectedVoyage}
        onSave={handleSaveEdit}
      />
    </div>
  );
};

export default GlobalTravelLogistics;