import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { toast } from 'sonner';

const MovementPlanAdjustmentModal = ({ isOpen, onClose, plan, onSave }) => {
  const [formData, setFormData] = useState({
    startDate: '',
    endDate: '',
    airline: '',
    hotel: '',
    origin: '',
    destination: ''
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (plan && isOpen) {
      let formattedStart = '';
      let formattedEnd = '';
      try {
        formattedStart = new Date(plan.startDate).toISOString().slice(0, 16);
        formattedEnd = new Date(plan.endDate).toISOString().slice(0, 16);
      } catch (e) {
        // Fallback
      }

      setFormData({
        startDate: formattedStart,
        endDate: formattedEnd,
        airline: plan.providers?.airline || '',
        hotel: plan.providers?.hotel || '',
        origin: plan.origin || '',
        destination: plan.destination || ''
      });
      setErrors({});
    }
  }, [plan, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: null }));
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.startDate) newErrors.startDate = 'Start Date is required';
    if (!formData.endDate) newErrors.endDate = 'End Date is required';
    
    if (formData.startDate && formData.endDate) {
      if (new Date(formData.startDate) >= new Date(formData.endDate)) {
        newErrors.endDate = 'End date must be after start date';
      }
    }
    
    if (!formData.airline) newErrors.airline = 'Provider required';
    if (!formData.hotel) newErrors.hotel = 'Accommodation provider required';

    // Mock duty hour validation
    if (formData.startDate && formData.endDate) {
      const diffHours = Math.abs(new Date(formData.endDate) - new Date(formData.startDate)) / 36e5;
      if (diffHours > 14) {
        newErrors.endDate = 'Adjustments violate 14-hour duty limit constraints.';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) {
      toast.error('Please fix compliance validation errors');
      return;
    }

    const updatedPlan = {
      ...plan,
      startDate: new Date(formData.startDate).toISOString(),
      endDate: new Date(formData.endDate).toISOString(),
      origin: formData.origin,
      destination: formData.destination,
      providers: {
        ...plan.providers,
        airline: formData.airline,
        hotel: formData.hotel
      }
    };

    onSave(updatedPlan);
    toast.success('Movement adjusted successfully');
    onClose();
  };

  if (!plan) return null;

  const airlinesList = ['Emirates', 'British Airways', 'Delta', 'Singapore Airlines', 'Lufthansa'];
  const hotelsList = ['Marriott', 'Hilton', 'InterContinental', 'Hyatt', 'Radisson'];
  const hubs = ['LHR (London)', 'DXB (Dubai)', 'JFK (New York)', 'CDG (Barcelona)', 'SIN (Singapore)', 'NRT (Tokyo)'];

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto custom-scrollbar">
        <DialogHeader>
          <DialogTitle className="text-xl">Provider Coordination: {plan.planId}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-5 mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="origin">Origin Location</Label>
              <select
                id="origin"
                name="origin"
                value={formData.origin}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {hubs.map(h => <option key={h} value={h}>{h}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="destination">Destination Location</Label>
              <select
                id="destination"
                name="destination"
                value={formData.destination}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {hubs.map(h => <option key={h} value={h}>{h}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="startDate">Movement Start Date *</Label>
              <Input
                id="startDate"
                name="startDate"
                type="datetime-local"
                value={formData.startDate}
                onChange={handleChange}
                className={errors.startDate ? "border-destructive" : ""}
              />
              {errors.startDate && <p className="text-xs text-destructive">{errors.startDate}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="endDate">Movement End Date *</Label>
              <Input
                id="endDate"
                name="endDate"
                type="datetime-local"
                value={formData.endDate}
                onChange={handleChange}
                className={errors.endDate ? "border-destructive" : ""}
              />
              {errors.endDate && <p className="text-xs text-destructive">{errors.endDate}</p>}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="airline">Preferred Provider *</Label>
              <select
                id="airline"
                name="airline"
                value={formData.airline}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="">Select Provider</option>
                {airlinesList.map(a => <option key={a} value={a}>{a}</option>)}
              </select>
              {errors.airline && <p className="text-xs text-destructive">{errors.airline}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="hotel">Preferred Accommodation Provider *</Label>
              <select
                id="hotel"
                name="hotel"
                value={formData.hotel}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <option value="">Select Provider</option>
                {hotelsList.map(h => <option key={h} value={h}>{h}</option>)}
              </select>
              {errors.hotel && <p className="text-xs text-destructive">{errors.hotel}</p>}
            </div>
          </div>

          <div className="bg-muted/30 p-4 rounded-lg border border-border text-sm">
            <p className="font-semibold text-foreground mb-1">Compliance Check</p>
            <p className="text-muted-foreground">Adjustments will automatically run through the fatigue modeling engine before saving.</p>
            <div className="mt-2 flex items-center gap-2">
              <span className="inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
              <span className="text-xs font-medium text-emerald-600">compliant</span>
            </div>
          </div>

          <DialogFooter className="pt-4 border-t border-border">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit">Approve Movement</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default MovementPlanAdjustmentModal;