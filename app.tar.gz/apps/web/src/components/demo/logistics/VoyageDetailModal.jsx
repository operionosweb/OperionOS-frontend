import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Users, MapPin, Clock, Navigation, Package, Droplets, CloudRain, Anchor, AlertTriangle, Activity, Calendar, Map, Settings2, DollarSign } from 'lucide-react';
import AIRecommendationsPanel from './AIRecommendationsPanel.jsx';

const VoyageDetailModal = ({ isOpen, onClose, voyage, onEdit, onOptimize, onDelay, onUpdateStatus }) => {
  if (!voyage) return null;

  const getStatusColor = (status) => {
    switch(status) {
      case 'in_progress': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'executed': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'disrupted': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'approved': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getRiskColor = (score) => {
    if (score <= 30) return 'text-emerald-500';
    if (score <= 65) return 'text-amber-500';
    return 'text-destructive';
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleString('en-US', { 
        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' 
      });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto custom-scrollbar p-0">
        <div className="p-6 border-b border-border bg-muted/30">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-xl text-primary">
                <Users className="w-8 h-8" />
              </div>
              <div>
                <DialogTitle className="text-2xl font-bold">{voyage.vesselName || 'Crew Movement'}</DialogTitle>
                <p className="text-sm text-muted-foreground font-medium mt-1">Movement ID: {voyage.voyageId}</p>
              </div>
            </div>
            <Badge variant="outline" className={`px-4 py-1.5 text-sm font-bold uppercase tracking-wider ${getStatusColor(voyage.status || 'in_progress')}`}>
              {voyage.status || 'in_progress'}
            </Badge>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 text-sm font-medium bg-background p-4 rounded-xl border border-border">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="p-2 bg-muted rounded-lg"><MapPin className="w-4 h-4 text-muted-foreground" /></div>
              <div>
                <p className="text-[10px] uppercase text-muted-foreground">Origin Location</p>
                <p>{voyage.origin}</p>
              </div>
            </div>
            <div className="hidden sm:flex h-px flex-1 bg-border relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-3 text-xs text-muted-foreground font-semibold border border-border rounded-full">
                Provider Status: OK
              </div>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto justify-start sm:justify-end">
              <div className="text-left sm:text-right">
                <p className="text-[10px] uppercase text-muted-foreground">Destination Location</p>
                <p>{voyage.destination}</p>
              </div>
              <div className="p-2 bg-primary/10 rounded-lg"><MapPin className="w-4 h-4 text-primary" /></div>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {/* Timeline & Logistics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> Movement Start Date</p>
              <p className="font-semibold text-sm">{formatDate(voyage.etd)}</p>
            </div>
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> Movement End Date</p>
              <p className="font-semibold text-sm">{formatDate(voyage.eta)}</p>
            </div>
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><Navigation className="w-3.5 h-3.5" /> Position</p>
              <p className="font-semibold text-sm truncate" title={voyage.currentPosition}>{voyage.currentPosition}</p>
            </div>
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><DollarSign className="w-3.5 h-3.5" /> Cost</p>
              <p className="font-semibold text-sm">$1,450</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Provider Operations */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                <Anchor className="w-4 h-4" /> Provider Operations
              </h4>
              <div className="p-5 rounded-xl border border-border bg-card space-y-4">
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Destination Location</span>
                  <span className="text-sm font-semibold">{voyage.portName}, {voyage.country}</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Assigned Provider</span>
                  <span className="text-sm font-semibold">{voyage.berth || 'Multiple'}</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Est. Turnaround</span>
                  <span className="text-sm font-semibold">{voyage.turnaroundTime} hours</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Congestion</span>
                  <Badge variant="outline" className={voyage.portCongestion === 'High' ? 'text-destructive border-destructive/30' : 'text-amber-600 border-amber-500/30'}>
                    {voyage.portCongestion}
                  </Badge>
                </div>
              </div>
            </div>

            {/* External Conditions & Risk */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                <Activity className="w-4 h-4" /> Conditions & Risk
              </h4>
              <div className="p-5 rounded-xl border border-border bg-card space-y-4">
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2"><CloudRain className="w-4 h-4" /> Weather</span>
                  <span className="text-sm font-semibold">{voyage.weather}</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2"><Droplets className="w-4 h-4" /> Compliance</span>
                  <span className={`text-sm font-semibold text-emerald-500`}>
                    compliant
                  </span>
                </div>
                <div className="pt-2">
                  <div className="flex justify-between items-end mb-2">
                    <span className="text-sm font-medium">Overall Risk Score</span>
                    <span className={`text-2xl font-bold tabular-nums ${getRiskColor(voyage.riskScore)}`}>
                      {voyage.riskScore}<span className="text-sm text-muted-foreground font-normal">/100</span>
                    </span>
                  </div>
                  <div className="h-2 w-full bg-secondary rounded-full overflow-hidden mb-3">
                    <div 
                      className={`h-full transition-all duration-500 ${voyage.riskScore > 65 ? 'bg-destructive' : voyage.riskScore > 30 ? 'bg-amber-500' : 'bg-emerald-500'}`} 
                      style={{ width: `${voyage.riskScore}%` }} 
                    />
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Delay Probability: <strong className="text-foreground">{voyage.delayProbability}%</strong></span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* AI Recommendations */}
          <AIRecommendationsPanel recommendations={voyage.aiRecommendations} />
        </div>

        <div className="p-6 border-t border-border bg-muted/10 flex flex-col sm:flex-row gap-3 justify-end">
          <Button variant="outline" onClick={() => onUpdateStatus(voyage.id)} className="w-full sm:w-auto">Cycle Status</Button>
          <Button variant="outline" onClick={() => onDelay(voyage.id)} className="w-full sm:w-auto text-amber-600 hover:text-amber-700 hover:bg-amber-50">Simulate Delay</Button>
          <Button variant="outline" onClick={() => onOptimize(voyage.id)} className="w-full sm:w-auto text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50">Optimize Route</Button>
          <Button onClick={() => onEdit(voyage)} className="w-full sm:w-auto"><Settings2 className="w-4 h-4 mr-2" /> Adjust Movement</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VoyageDetailModal;