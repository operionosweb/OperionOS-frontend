import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Lightbulb, TrendingDown, AlertCircle, Clock, Fuel, CloudLightning, ShieldAlert, Navigation } from 'lucide-react';
import { motion } from 'framer-motion';

const AIRecommendationsPanel = ({ recommendations }) => {
  if (!recommendations || recommendations.length === 0) return null;

  const getIconAndColor = (type) => {
    switch (type) {
      case 'fuel':
        return { icon: Fuel, color: 'text-amber-500', bg: 'bg-amber-500/10', border: 'border-amber-500/20' };
      case 'weather':
        return { icon: CloudLightning, color: 'text-destructive', bg: 'bg-destructive/10', border: 'border-destructive/20' };
      case 'risk':
        return { icon: ShieldAlert, color: 'text-destructive', bg: 'bg-destructive/10', border: 'border-destructive/20' };
      case 'efficiency':
        return { icon: TrendingDown, color: 'text-emerald-500', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' };
      case 'logistics':
        return { icon: Clock, color: 'text-blue-500', bg: 'bg-blue-500/10', border: 'border-blue-500/20' };
      default:
        return { icon: Navigation, color: 'text-primary', bg: 'bg-primary/10', border: 'border-primary/20' };
    }
  };

  const getImpactBadge = (impact) => {
    switch (impact) {
      case 'High':
        return <Badge variant="destructive" className="text-[10px] uppercase tracking-wider">High Impact</Badge>;
      case 'Medium':
        return <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20 text-[10px] uppercase tracking-wider">Medium Impact</Badge>;
      case 'Low':
        return <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-[10px] uppercase tracking-wider">Low Impact</Badge>;
      default:
        return null;
    }
  };

  return (
    <Card className="shadow-sm border-border overflow-hidden">
      <CardHeader className="pb-3 bg-muted/30 border-b border-border">
        <CardTitle className="text-sm font-bold flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          Crew Movement Optimization
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendations.map((rec, idx) => {
            const { icon: Icon, color, bg, border } = getIconAndColor(rec.type);
            return (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                key={idx} 
                className={`flex flex-col gap-2 p-4 rounded-xl border ${bg} ${border} transition-colors hover:bg-opacity-80`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className={`p-1.5 rounded-md bg-background/50 ${color}`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <h5 className="font-semibold text-sm text-foreground">{rec.title.replace(/booking/gi, 'movement plan').replace(/price/gi, 'cost')}</h5>
                  </div>
                  {getImpactBadge(rec.impact)}
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed mt-1">{rec.description.replace(/booking/gi, 'movement plan').replace(/price/gi, 'cost')}</p>
              </motion.div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default AIRecommendationsPanel;