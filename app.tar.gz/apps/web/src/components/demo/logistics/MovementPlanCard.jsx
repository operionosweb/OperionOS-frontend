import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Users, MapPin, CalendarClock, ShieldCheck, ArrowRight, Play, AlertTriangle, DollarSign } from 'lucide-react';

const MovementPlanCard = ({ plan, onViewDetails, onApprove, onAdjust }) => {
  const getStatusColor = (status) => {
    switch(status) {
      case 'approved': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'in_progress': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'executed': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'disrupted': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getComplianceColor = (status) => {
    switch(status) {
      case 'compliant': return 'text-emerald-500';
      case 'at_risk': return 'text-amber-500';
      case 'violated': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <Card className="overflow-hidden flex flex-col h-full transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-border group cursor-pointer bg-card" onClick={() => onViewDetails(plan)}>
      <div className="p-4 border-b border-border bg-muted/20 flex justify-between items-start">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-primary/10 rounded-xl text-primary group-hover:scale-110 transition-transform">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base leading-tight group-hover:text-primary transition-colors truncate max-w-[150px]">
              {plan.crewMembers[0]}
            </h3>
            <p className="text-xs text-muted-foreground font-medium mt-0.5">
              {plan.crewMembers.length > 1 ? `+${plan.crewMembers.length - 1} crew members` : 'Solo Assignment'}
            </p>
          </div>
        </div>
        <Badge variant="outline" className={`text-[10px] px-2.5 py-0.5 font-semibold uppercase tracking-wider ${getStatusColor(plan.status || 'approved')}`}>
          {plan.status || 'approved'}
        </Badge>
      </div>

      <CardContent className="p-5 flex-1 flex flex-col">
        <div className="flex items-center justify-between mb-5 text-sm bg-muted/30 p-3 rounded-xl border border-border/50">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1 font-semibold">Origin Location</span>
            <span className="font-medium flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-muted-foreground" /> {plan.origin}</span>
          </div>
          <div className="flex flex-col items-center px-2">
            <ArrowRight className="w-4 h-4 text-muted-foreground/40 mb-1" />
          </div>
          <div className="flex flex-col text-right">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1 font-semibold">Destination Location</span>
            <span className="font-medium flex items-center gap-1.5 justify-end"><MapPin className="w-3.5 h-3.5 text-primary" /> {plan.destination}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-5">
          <div className="flex flex-col p-3 rounded-xl border border-border/50 bg-card">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground flex items-center gap-1.5 mb-1 font-semibold"><CalendarClock className="w-3 h-3" /> Start</span>
            <span className="text-sm font-bold">{formatDate(plan.startDate)}</span>
          </div>
          <div className="flex flex-col p-3 rounded-xl border border-border/50 bg-card text-right">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1 font-semibold">Compliance</span>
            <span className={`text-sm font-bold flex items-center justify-end gap-1 ${getComplianceColor(plan.complianceStatus || 'compliant')}`}>
              {(plan.complianceStatus || 'compliant') === 'compliant' ? <ShieldCheck className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
              {plan.complianceStatus || 'compliant'}
            </span>
          </div>
        </div>

        <div className="mt-auto space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-muted-foreground font-medium">
              <DollarSign className="w-3.5 h-3.5" /> Operational Cost
            </span>
            <span className="font-bold tabular-nums">${(plan.cost || 1250).toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1.5 text-muted-foreground font-medium">
              Provider
            </span>
            <span className="font-bold tabular-nums">{plan.providers?.airline || 'Multiple'}</span>
          </div>
        </div>
      </CardContent>

      <div className="p-3 border-t border-border bg-muted/10 grid grid-cols-2 gap-2">
        {plan.status === 'approved' || plan.status === 'Planned' ? (
          <>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-xs h-8 w-full"
              onClick={(e) => { e.stopPropagation(); onAdjust(plan); }}
            >
              Adjust Movement
            </Button>
            <Button 
              variant="default"
              size="sm" 
              className="text-xs h-8 w-full"
              onClick={(e) => { e.stopPropagation(); onApprove(plan.id); }}
            >
              <Play className="w-3 h-3 mr-1.5" /> Execute
            </Button>
          </>
        ) : (
          <Button 
            variant="outline" 
            size="sm" 
            className="text-xs h-8 w-full col-span-2"
            onClick={(e) => { e.stopPropagation(); onViewDetails(plan); }}
          >
            View Movement
          </Button>
        )}
      </div>
    </Card>
  );
};

export default MovementPlanCard;