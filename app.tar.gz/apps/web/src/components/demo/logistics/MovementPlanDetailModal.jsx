import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Users, MapPin, Clock, Navigation, ShieldCheck, AlertTriangle, Plane, Bed, Network, Calendar, Activity, CheckCircle2, DollarSign } from 'lucide-react';
import MovementOptimizationPanel from './MovementOptimizationPanel.jsx';

const MovementPlanDetailModal = ({ isOpen, onClose, plan, onApprove, onAdjust, onGenerateAlternative }) => {
  if (!plan) return null;

  const getStatusColor = (status) => {
    switch(status) {
      case 'approved': return 'bg-blue-500/10 text-blue-600 border-blue-500/20';
      case 'in_progress': return 'bg-amber-500/10 text-amber-600 border-amber-500/20';
      case 'executed': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
      case 'disrupted': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getComplianceColor = (status) => {
    switch(status) {
      case 'compliant': return 'text-emerald-500';
      case 'at_risk': return 'text-amber-500';
      case 'violated': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleString('en-US', { 
        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' 
      });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[850px] max-h-[90vh] overflow-y-auto custom-scrollbar p-0">
        <div className="p-6 border-b border-border bg-muted/30">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-xl text-primary">
                <Navigation className="w-8 h-8" />
              </div>
              <div>
                <DialogTitle className="text-2xl font-bold">Your movement plan {plan.planId}</DialogTitle>
                <p className="text-sm text-muted-foreground font-medium mt-1">Crew: {plan.crewMembers.join(', ')}</p>
              </div>
            </div>
            <Badge variant="outline" className={`px-4 py-1.5 text-sm font-bold uppercase tracking-wider ${getStatusColor(plan.status || 'approved')}`}>
              {plan.status || 'approved'}
            </Badge>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 text-sm font-medium bg-background p-4 rounded-xl border border-border">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="p-2 bg-muted rounded-lg"><MapPin className="w-4 h-4 text-muted-foreground" /></div>
              <div>
                <p className="text-[10px] uppercase text-muted-foreground">Origin Location</p>
                <p>{plan.origin}</p>
              </div>
            </div>
            <div className="hidden sm:flex h-px flex-1 bg-border relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-3 text-xs text-muted-foreground font-semibold border border-border rounded-full">
                Route Path
              </div>
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto justify-start sm:justify-end">
              <div className="text-left sm:text-right">
                <p className="text-[10px] uppercase text-muted-foreground">Destination Location</p>
                <p>{plan.destination}</p>
              </div>
              <div className="p-2 bg-primary/10 rounded-lg"><MapPin className="w-4 h-4 text-primary" /></div>
            </div>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {/* Core Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> Movement Start Date</p>
              <p className="font-semibold text-sm">{formatDate(plan.startDate)}</p>
            </div>
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> Movement End Date</p>
              <p className="font-semibold text-sm">{formatDate(plan.endDate)}</p>
            </div>
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><Users className="w-3.5 h-3.5" /> Assigned Crew</p>
              <p className="font-semibold text-sm">{plan.crewMembers.length} Members</p>
            </div>
            <div className="p-4 rounded-xl border border-border bg-card space-y-1.5">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5"><DollarSign className="w-3.5 h-3.5" /> Total Cost</p>
              <p className="font-semibold text-sm">${(plan.cost || 1250).toLocaleString()}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Compliance & Duty Data */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" /> Compliance Verification
              </h4>
              <div className="p-5 rounded-xl border border-border bg-card space-y-4">
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <span className={`text-sm font-semibold flex items-center gap-1.5 ${getComplianceColor(plan.complianceStatus || 'compliant')}`}>
                    {(plan.complianceStatus || 'compliant') === 'compliant' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                    {plan.complianceStatus || 'compliant'}
                  </span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Duty Hours (Current)</span>
                  <span className="text-sm font-semibold">{plan.dutyHours?.current || 0}h / {plan.dutyHours?.limit || 14}h limit</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground">Rest Period Validated</span>
                  <span className="text-sm font-semibold">{plan.dutyHours?.restPeriodRemaining || 12}h remaining</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Certifications</span>
                  <Badge variant="outline" className={plan.certifications?.expiringSoon ? 'text-amber-600 border-amber-500/30' : 'text-emerald-600 border-emerald-500/30'}>
                    {plan.certifications?.expiringSoon ? 'Renewal Needed Soon' : 'Valid'}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Logistics Providers */}
            <div className="space-y-4">
              <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                <Network className="w-4 h-4" /> Provider Integrations
              </h4>
              <div className="p-5 rounded-xl border border-border bg-card space-y-4">
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2"><Plane className="w-4 h-4" /> Preferred Provider</span>
                  <span className="text-sm font-semibold">{plan.providers?.airline || 'Pending'}</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2"><Bed className="w-4 h-4" /> Preferred Accommodation Provider</span>
                  <span className="text-sm font-semibold">{plan.providers?.hotel || 'Pending'}</span>
                </div>
                <div className="flex justify-between items-center pb-3 border-b border-border/50">
                  <span className="text-sm text-muted-foreground flex items-center gap-2"><MapPin className="w-4 h-4" /> Ground Transfer</span>
                  <span className="text-sm font-semibold">{plan.providers?.logistics || 'Pending'}</span>
                </div>
                <div className="pt-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium text-muted-foreground">Provider Status</span>
                    <span className="font-bold text-primary">Connected & Syncing</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recommendations */}
          <MovementOptimizationPanel recommendations={plan.aiRecommendations} />

          {/* Audit Trail */}
          <div className="space-y-4">
             <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
                <Clock className="w-4 h-4" /> Execution Audit Trail
             </h4>
             <div className="p-5 rounded-xl border border-border bg-card space-y-4 max-h-[200px] overflow-y-auto custom-scrollbar">
                {plan.auditTrail?.map((log, i) => (
                  <div key={i} className="flex gap-4 text-sm">
                    <span className="text-muted-foreground font-mono w-12 shrink-0">{log.time}</span>
                    <span className="text-foreground">{log.action}</span>
                  </div>
                ))}
             </div>
          </div>
        </div>

        <div className="p-6 border-t border-border bg-muted/10 flex flex-col sm:flex-row gap-3 justify-end">
          <Button variant="outline" onClick={() => onGenerateAlternative(plan.id)} className="w-full sm:w-auto text-amber-600 hover:text-amber-700 hover:bg-amber-50">Generate Alternative</Button>
          <Button variant="outline" onClick={() => onAdjust(plan)} className="w-full sm:w-auto">Adjust Movement</Button>
          <Button variant="outline" className="w-full sm:w-auto text-destructive hover:text-destructive hover:bg-destructive/10">Cancel Movement</Button>
          {plan.status !== 'executed' && plan.status !== 'in_progress' && (
            <Button onClick={() => onApprove(plan.id)} className="w-full sm:w-auto bg-primary text-primary-foreground">
              Send to Providers
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default MovementPlanDetailModal;