import React from 'react';
import { Ship, Anchor } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Badge } from '@/components/ui/badge.jsx';

const CruiseModeToggle = () => {
  const { operatingMode, setOperatingMode, cruiseScenario, setCruiseScenario } = useDemo();

  return (
    <div className="flex items-center gap-3 bg-muted/50 p-1.5 rounded-lg border border-border">
      <div className="flex items-center bg-background rounded-md border border-border overflow-hidden">
        <button
          onClick={() => setOperatingMode('cargo')}
          className={`px-3 py-1.5 text-xs font-medium flex items-center gap-1.5 transition-colors ${
            operatingMode === 'cargo' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'
          }`}
        >
          <Anchor className="w-3.5 h-3.5" />
          Cargo
        </button>
        <button
          onClick={() => setOperatingMode('cruise')}
          className={`px-3 py-1.5 text-xs font-medium flex items-center gap-1.5 transition-colors ${
            operatingMode === 'cruise' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'
          }`}
        >
          <Ship className="w-3.5 h-3.5" />
          Cruise
        </button>
      </div>

      {operatingMode === 'cruise' && (
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-[10px] uppercase tracking-wider hidden xl:flex">Scenario</Badge>
          <Select value={cruiseScenario} onValueChange={setCruiseScenario}>
            <SelectTrigger className="h-8 w-[130px] text-xs bg-background">
              <SelectValue placeholder="Capacity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="small">Small (800 pax)</SelectItem>
              <SelectItem value="large">Large (3.5k pax)</SelectItem>
              <SelectItem value="full">Full (5.4k pax)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
};

export default CruiseModeToggle;