import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx';
import { MapPin, AlertTriangle, CheckCircle2 } from 'lucide-react';
import StatusBadge from './StatusBadge.jsx';

const CrewCard = ({ crew, isSelected, onClick }) => {
  return (
    <Card 
      className={`p-4 cursor-pointer transition-all duration-200 hover:shadow-md ${
        isSelected ? 'ring-2 ring-primary border-transparent' : 'border-border'
      }`}
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        <Avatar className="w-12 h-12 border-2 border-background shadow-sm">
          <AvatarImage src={crew.avatar} alt={crew.name} />
          <AvatarFallback className="bg-primary/10 text-primary font-bold">
            {crew.initials}
          </AvatarFallback>
        </Avatar>
        
        <div className="flex-grow min-w-0">
          <div className="flex justify-between items-start mb-1">
            <h4 className="font-bold text-foreground truncate">{crew.name}</h4>
            <StatusBadge status={crew.status} />
          </div>
          
          <p className="text-xs text-muted-foreground mb-2 truncate">{crew.role} • {crew.vessel}</p>
          
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/50">
            <div className="flex items-center gap-1.5 text-xs font-medium">
              {crew.alert ? (
                <span className="text-destructive flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> {crew.alert}
                </span>
              ) : (
                <span className="text-[hsl(var(--tertiary))] flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> {crew.certStatus}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="w-3 h-3" /> {crew.hub}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default CrewCard;