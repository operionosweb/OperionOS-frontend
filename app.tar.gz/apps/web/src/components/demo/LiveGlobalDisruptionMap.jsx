import React, { useEffect, useState, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, ZoomControl } from 'react-leaflet';
import L from 'leaflet';
import { Clock, AlertTriangle, Filter, Ship, MapPin, Activity, Lightbulb, CheckCircle2 } from 'lucide-react';
import { MapTouchHandler } from '@/hooks/useMapTouchControl.js';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';

// Custom icons
const createIcon = (color, isPulsing = false) => {
  return L.divIcon({
    className: 'custom-leaflet-icon',
    html: `<div style="background-color: ${color}; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3); position: relative;">
             ${isPulsing ? `<div style="position: absolute; top: -4px; left: -4px; right: -4px; bottom: -4px; border-radius: 50%; background-color: ${color}; opacity: 0.4; animation: ping 2s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>` : ''}
           </div>`,
    iconSize: [16, 16],
    iconAnchor: [8, 8],
    popupAnchor: [0, -10]
  });
};

const severityColors = {
  High: 'hsl(0, 72%, 51%)',    // Red
  Medium: 'hsl(38, 92%, 50%)', // Yellow
  Low: 'hsl(142, 71%, 45%)'    // Green
};

const LiveGlobalDisruptionMap = ({ onMarkerClick }) => {
  const { maritimeDisruptions } = useDemo();
  const [time, setTime] = useState(new Date());
  
  // Filters
  const [filterSeverity, setFilterSeverity] = useState('All');
  const [filterType, setFilterType] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const filteredDisruptions = useMemo(() => {
    return maritimeDisruptions.filter(d => {
      if (filterSeverity !== 'All' && d.severity !== filterSeverity) return false;
      if (filterType !== 'All' && d.type !== filterType) return false;
      if (filterStatus !== 'All' && d.status !== filterStatus) return false;
      return true;
    });
  }, [maritimeDisruptions, filterSeverity, filterType, filterStatus]);

  const getStatusBadge = (status) => {
    switch(status) {
      case 'Active': return <Badge variant="destructive" className="text-[10px] uppercase">Active</Badge>;
      case 'Monitoring': return <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20 text-[10px] uppercase">Monitoring</Badge>;
      case 'Resolved': return <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-[10px] uppercase">Resolved</Badge>;
      default: return null;
    }
  };

  return (
    <div className="map-container bg-card rounded-2xl border border-border shadow-sm flex flex-col h-[600px] md:h-[700px] relative overflow-hidden">
      
      {/* Top Bar & Filters */}
      <div className="absolute top-0 left-0 right-0 z-[400] bg-card/95 backdrop-blur-md border-b border-border p-3 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div className="flex items-center justify-between w-full sm:w-auto">
          <h3 className="font-bold text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-primary" />
            Live Global Map
          </h3>
          <Button 
            variant="ghost" 
            size="sm" 
            className="sm:hidden h-8 px-2"
            onClick={() => setIsFiltersOpen(!isFiltersOpen)}
          >
            <Filter className="w-4 h-4 mr-1" /> Filters
          </Button>
        </div>

        <div className={`flex-col sm:flex-row gap-2 w-full sm:w-auto ${isFiltersOpen ? 'flex' : 'hidden sm:flex'}`}>
          <select 
            className="h-8 rounded-md border border-input bg-background px-2 py-1 text-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            value={filterSeverity}
            onChange={(e) => setFilterSeverity(e.target.value)}
          >
            <option value="All">All Severities</option>
            <option value="High">High Severity</option>
            <option value="Medium">Medium Severity</option>
            <option value="Low">Low Severity</option>
          </select>
          <select 
            className="h-8 rounded-md border border-input bg-background px-2 py-1 text-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
          >
            <option value="All">All Types</option>
            <option value="Weather">Weather</option>
            <option value="Port Congestion">Port Congestion</option>
            <option value="Mechanical Issue">Mechanical Issue</option>
            <option value="Route Deviation">Route Deviation</option>
            <option value="Security Risk">Security Risk</option>
          </select>
          <select 
            className="h-8 rounded-md border border-input bg-background px-2 py-1 text-xs focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="All">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Monitoring">Monitoring</option>
            <option value="Resolved">Resolved</option>
          </select>
        </div>

        <div className="hidden md:flex items-center gap-2 text-xs font-mono text-muted-foreground bg-muted/50 px-2 py-1.5 rounded-md">
          <Clock className="w-3 h-3" />
          {time.toISOString().substring(11, 19)} UTC
        </div>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 z-[400] bg-card/90 backdrop-blur-sm border border-border rounded-lg p-3 shadow-lg hidden sm:block">
        <h4 className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Severity Legend</h4>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-medium">
            <div className="w-3 h-3 rounded-full bg-[hsl(0,72%,51%)] border border-white"></div>
            High Impact
          </div>
          <div className="flex items-center gap-2 text-xs font-medium">
            <div className="w-3 h-3 rounded-full bg-[hsl(38,92%,50%)] border border-white"></div>
            Medium Impact
          </div>
          <div className="flex items-center gap-2 text-xs font-medium">
            <div className="w-3 h-3 rounded-full bg-[hsl(142,71%,45%)] border border-white"></div>
            Low Impact
          </div>
        </div>
      </div>

      <div className="flex-1 w-full h-full z-0 mt-14 sm:mt-0">
        <MapContainer 
          center={[20, 0]} 
          zoom={2} 
          zoomControl={false}
          className="w-full h-full bg-[#0A192F]/5"
          style={{ background: 'hsl(var(--muted))' }}
        >
          <MapTouchHandler />
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          <ZoomControl position="bottomright" />
          
          {filteredDisruptions.map(disruption => {
            const isPulsing = disruption.status === 'Active' && disruption.severity === 'High';
            const icon = createIcon(severityColors[disruption.severity], isPulsing);

            return (
              <Marker 
                key={disruption.eventId} 
                position={[disruption.location.lat, disruption.location.lon]} 
                icon={icon}
              >
                <Popup className="custom-popup min-w-[280px] max-w-[320px]">
                  <div className="p-1 flex flex-col gap-3">
                    <div className="flex justify-between items-start gap-2 border-b border-border/50 pb-2">
                      <div>
                        <p className="font-bold text-sm flex items-center gap-1.5">
                          <Ship className="w-3.5 h-3.5 text-primary" />
                          {disruption.vesselName}
                        </p>
                        <p className="text-[10px] text-muted-foreground font-mono mt-0.5">{disruption.eventId}</p>
                      </div>
                      {getStatusBadge(disruption.status)}
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <Activity className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
                        <div>
                          <p className="text-xs font-semibold">{disruption.type}</p>
                          <p className="text-xs text-muted-foreground leading-snug">{disruption.description}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        <span>{disruption.region} ({disruption.location.lat.toFixed(2)}, {disruption.location.lon.toFixed(2)})</span>
                      </div>
                    </div>

                    {disruption.aiRecommendations?.length > 0 && (
                      <div className="bg-muted/30 rounded-md p-2 border border-border/50">
                        <p className="text-[10px] font-bold uppercase tracking-wider text-primary flex items-center gap-1 mb-1.5">
                          <Lightbulb className="w-3 h-3" /> AI Recommendations
                        </p>
                        <ul className="space-y-1.5">
                          {disruption.aiRecommendations.map((rec, idx) => (
                            <li key={idx} className="text-xs flex items-start gap-1.5">
                              <CheckCircle2 className="w-3 h-3 text-emerald-500 mt-0.5 shrink-0" />
                              <span className="leading-tight">{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    <div className="flex justify-between items-center pt-2 border-t border-border/50">
                      <span className="text-[10px] text-muted-foreground">
                        Updated: {new Date(disruption.timestamp).toLocaleTimeString()}
                      </span>
                      <button 
                        className="text-[10px] font-bold text-primary uppercase tracking-wider hover:underline"
                        onClick={(e) => {
                          e.stopPropagation();
                          onMarkerClick && onMarkerClick(disruption);
                        }}
                      >
                        View Details →
                      </button>
                    </div>
                  </div>
                </Popup>
              </Marker>
            );
          })}
        </MapContainer>
      </div>
    </div>
  );
};

export default LiveGlobalDisruptionMap;