import React, { useState } from 'react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import ModalWrapper from './ModalWrapper.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Search, X, Navigation } from 'lucide-react';

const SearchResultsModal = () => {
  const { openModals, closeModal, crewData, vesselData, openModal } = useDemo();
  const isOpen = openModals.has('search');
  const [query, setQuery] = useState('');

  const filteredCrew = crewData.filter(c => c.name.toLowerCase().includes(query.toLowerCase()));
  const filteredVessels = vesselData.filter(v => v.name.toLowerCase().includes(query.toLowerCase()));

  const footer = (
    <Button onClick={() => closeModal('search')}>Close</Button>
  );

  return (
    <ModalWrapper 
      isOpen={isOpen} 
      onClose={() => closeModal('search')} 
      title="Search Fleet & Personnel" 
      size="md"
      footer={footer}
    >
      <div className="space-y-6">
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input 
            type="text" 
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type to search..." 
            className="w-full h-12 bg-card border border-border rounded-xl pl-10 pr-10 text-base focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
          {query && (
            <button onClick={() => setQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {query && (
          <div className="space-y-6">
            {filteredCrew.length > 0 && (
              <div>
                <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground mb-3">Personnel</h4>
                <div className="space-y-2">
                  {filteredCrew.map(crew => (
                    <div 
                      key={crew.id} 
                      className="p-3 border border-border rounded-lg bg-card flex items-center gap-3 cursor-pointer hover:border-primary transition-colors"
                      onClick={() => {
                        closeModal('search');
                        openModal('crew', crew);
                      }}
                    >
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                        <img src={crew.avatar} alt={crew.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <p className="font-bold text-sm">{crew.name}</p>
                        <p className="text-xs text-muted-foreground">{crew.role} • {crew.vessel}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {filteredVessels.length > 0 && (
              <div>
                <h4 className="font-bold text-sm uppercase tracking-wider text-muted-foreground mb-3">Vessels</h4>
                <div className="space-y-2">
                  {filteredVessels.map(vessel => (
                    <div 
                      key={vessel.id} 
                      className="p-3 border border-border rounded-lg bg-card flex items-center gap-3 cursor-pointer hover:border-primary transition-colors"
                      onClick={() => {
                        closeModal('search');
                        openModal('vessel', vessel);
                      }}
                    >
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        <Navigation className="w-5 h-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-bold text-sm">{vessel.name}</p>
                        <p className="text-xs text-muted-foreground">{vessel.location}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {filteredCrew.length === 0 && filteredVessels.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <p>No results found for "{query}"</p>
              </div>
            )}
          </div>
        )}
      </div>
    </ModalWrapper>
  );
};

export default SearchResultsModal;