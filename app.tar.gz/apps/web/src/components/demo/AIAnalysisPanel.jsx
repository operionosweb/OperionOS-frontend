import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, BrainCircuit, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';

const AIAnalysisPanel = () => {
  const { selectedDisruption, setSelectedDisruption, setSelectedRecommendation } = useDemo();

  if (!selectedDisruption) return null;

  const recommendations = [
    { id: 1, title: 'Reassign backup crew from nearby port', cost: '+$2,300', time: '-4h', risk: 'Low' },
    { id: 2, title: 'Rebook alternative travel route', cost: '+$1,800', time: '-2h', risk: 'Medium' },
    { id: 3, title: 'Delay crew change schedule', cost: '$0', time: '+6h', risk: 'High' },
    { id: 4, title: 'Swap crew between vessels', cost: '+$1,200', time: '-3h', risk: 'Low' },
  ];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 50 }}
        className="bg-card border border-border rounded-2xl shadow-xl flex flex-col h-full max-h-[800px] overflow-hidden"
      >
        <div className="p-4 border-b border-border flex justify-between items-center bg-muted/30">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-primary" />
            <h3 className="font-bold text-lg">AI Analysis</h3>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setSelectedDisruption(null)} className="h-8 w-8 rounded-full">
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-6 hide-scrollbar">
          <div>
            <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-2">Selected Disruption</h4>
            <p className="font-semibold text-lg leading-tight">{selectedDisruption.title}</p>
            <p className="text-sm text-muted-foreground mt-1">{selectedDisruption.description}</p>
          </div>

          <div className="bg-destructive/5 border border-destructive/20 rounded-xl p-4">
            <h4 className="text-sm font-bold text-destructive flex items-center gap-2 mb-2">
              <AlertCircle className="w-4 h-4" /> Root Cause
            </h4>
            <p className="text-sm text-foreground">Cascading delay originating from severe weather cell over primary transit route, causing mandatory 6-hour hold for all outbound flights.</p>
          </div>

          <div>
            <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3">Impact Breakdown</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 border border-border rounded-lg bg-card">
                <p className="text-xs text-muted-foreground mb-1">Crew Delays</p>
                <p className="font-bold text-lg">14 hours</p>
              </div>
              <div className="p-3 border border-border rounded-lg bg-card">
                <p className="text-xs text-muted-foreground mb-1">Rotation Disrupted</p>
                <p className="font-bold text-lg text-destructive">Yes</p>
              </div>
              <div className="p-3 border border-border rounded-lg bg-card">
                <p className="text-xs text-muted-foreground mb-1">Compliance Risk</p>
                <p className="font-bold text-lg text-amber-500">18%</p>
              </div>
              <div className="p-3 border border-border rounded-lg bg-card">
                <p className="text-xs text-muted-foreground mb-1">Escalation Risk</p>
                <Badge variant="outline" className="bg-destructive/10 text-destructive mt-1">High</Badge>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[hsl(var(--tertiary))]" /> AI Recommendations
            </h4>
            <div className="space-y-3">
              {recommendations.map((rec, idx) => (
                <div key={rec.id} className="p-4 border border-border rounded-xl bg-card hover:border-primary/50 transition-colors group">
                  <div className="flex justify-between items-start mb-2">
                    <h5 className="font-semibold text-sm pr-4">{rec.title}</h5>
                    {idx === 0 && <Badge className="bg-primary text-primary-foreground text-[10px]">Optimal</Badge>}
                  </div>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                    <span>Cost: <strong className="text-foreground">{rec.cost}</strong></span>
                    <span>Time: <strong className="text-[hsl(var(--tertiary))]">{rec.time}</strong></span>
                    <span>Risk: <strong className={rec.risk === 'High' ? 'text-destructive' : 'text-foreground'}>{rec.risk}</strong></span>
                  </div>
                  <Button 
                    variant={idx === 0 ? "default" : "outline"} 
                    size="sm" 
                    className="w-full text-xs h-8"
                    onClick={() => setSelectedRecommendation(rec)}
                  >
                    Select Solution
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default AIAnalysisPanel;