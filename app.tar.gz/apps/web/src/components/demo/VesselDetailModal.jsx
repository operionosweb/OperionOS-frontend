import React from 'react';
import { useDemo } from '@/contexts/DemoStateContext.jsx';
import ModalWrapper from './ModalWrapper.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Navigation, Users, Activity, Anchor, Settings } from 'lucide-react';
import { toast } from 'sonner';

const VesselDetailModal = () => {
  const { openModals, closeModal, modalData } = useDemo();
  const isOpen = openModals.has('vessel');
  const selectedVessel = modalData['vessel'];

  if (!selectedVessel) return null;

  const footer = (
    <>
      <Button variant="outline" onClick={() => toast.info('Edit mode activated')}>Edit Vessel</Button>
      <Button variant="outline" onClick={() => toast.info('Exporting report...')}>Export Report</Button>
      <Button variant="destructive" onClick={() => toast.error('Delete action requires confirmation')}>Delete</Button>
      <Button className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => toast.info('Opening map view...')}>
        View on Map
      </Button>
    </>
  );

  return (
    <ModalWrapper 
      isOpen={isOpen} 
      onClose={() => closeModal('vessel')} 
      title="Vessel Details" 
      size="lg"
      footer={footer}
    >
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start bg-card p-6 rounded-xl border border-border gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h3 className="text-3xl font-bold">{selectedVessel.name}</h3>
              <Badge className={selectedVessel.status === 'ACTIVE' ? 'bg-[hsl(var(--tertiary))]/10 text-[hsl(var(--tertiary))]' : 'bg-destructive/10 text-destructive'}>
                {selectedVessel.status}
              </Badge>
            </div>
            <p className="text-muted-foreground flex items-center gap-2">
              <Navigation className="w-4 h-4" /> {selectedVessel.location}
            </p>
            <p className="text-sm font-mono text-muted-foreground mt-1">{selectedVessel.imo} • {selectedVessel.type}</p>
          </div>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="w-full justify-start overflow-x-auto hide-scrollbar bg-transparent border-b border-border rounded-none h-auto p-0">
            <TabsTrigger value="overview" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Overview</TabsTrigger>
            <TabsTrigger value="crew" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Crew Manifest</TabsTrigger>
            <TabsTrigger value="operations" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Operations</TabsTrigger>
            <TabsTrigger value="maintenance" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Maintenance</TabsTrigger>
            <TabsTrigger value="fuel" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none px-4 py-3">Fuel & Performance</TabsTrigger>
          </TabsList>
          
          <div className="mt-6">
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-card rounded-xl border border-border text-center">
                  <Users className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-2xl font-bold">{selectedVessel.crewCount}</p>
                  <p className="text-xs text-muted-foreground uppercase font-bold">Crew Onboard</p>
                </div>
                <div className="p-4 bg-card rounded-xl border border-border text-center">
                  <Activity className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-2xl font-bold">{selectedVessel.progressValue}%</p>
                  <p className="text-xs text-muted-foreground uppercase font-bold">Efficiency</p>
                </div>
                <div className="p-4 bg-card rounded-xl border border-border text-center">
                  <Anchor className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-2xl font-bold">14.2k</p>
                  <p className="text-xs text-muted-foreground uppercase font-bold">Tonnage</p>
                </div>
                <div className="p-4 bg-card rounded-xl border border-border text-center">
                  <Navigation className="w-6 h-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-2xl font-bold">22kn</p>
                  <p className="text-xs text-muted-foreground uppercase font-bold">Speed</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="crew" className="space-y-4">
              <div className="border border-border rounded-xl overflow-hidden bg-card">
                <table className="w-full text-sm text-left">
                  <thead className="bg-muted/50 text-muted-foreground uppercase font-bold text-xs">
                    <tr>
                      <th className="px-4 py-3">Name</th>
                      <th className="px-4 py-3">Role</th>
                      <th className="px-4 py-3">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-border hover:bg-muted/50 cursor-pointer">
                      <td className="px-4 py-3 font-medium">Capt. Sarah Miller</td>
                      <td className="px-4 py-3 text-muted-foreground">Commander</td>
                      <td className="px-4 py-3"><Badge variant="outline" className="bg-[hsl(var(--tertiary))]/10 text-[hsl(var(--tertiary))]">Active</Badge></td>
                    </tr>
                    <tr className="hover:bg-muted/50 cursor-pointer">
                      <td className="px-4 py-3 font-medium">F/O Marcus Chen</td>
                      <td className="px-4 py-3 text-muted-foreground">First Officer</td>
                      <td className="px-4 py-3"><Badge variant="outline" className="bg-primary/10 text-primary">Standby</Badge></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="operations" className="space-y-4">
              <div className="p-4 border border-border rounded-xl bg-card">
                <p className="font-bold">Loading Operations</p>
                <p className="text-sm text-muted-foreground">Scheduled for tomorrow at 08:00 AM</p>
              </div>
            </TabsContent>

            <TabsContent value="maintenance" className="space-y-4">
              <div className="p-4 border border-border rounded-xl bg-card flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <Settings className="w-5 h-5 text-muted-foreground" />
                  <div>
                    <p className="font-bold">Engine Overhaul</p>
                    <p className="text-sm text-muted-foreground">Due in 45 days</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">Schedule</Button>
              </div>
            </TabsContent>

            <TabsContent value="fuel" className="space-y-4">
              <div className="p-4 border border-border rounded-xl bg-card">
                <p className="font-bold mb-2">Fuel Consumption</p>
                <div className="h-32 bg-muted/50 rounded-lg flex items-center justify-center border border-dashed border-border">
                  <span className="text-muted-foreground text-sm">Chart Visualization Placeholder</span>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </ModalWrapper>
  );
};

export default VesselDetailModal;