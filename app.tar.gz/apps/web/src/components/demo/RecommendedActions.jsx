import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, ShieldAlert, Zap, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { toast } from 'sonner';

const RecommendedActions = () => {
  const actions = [
    {
      id: 1,
      priority: 'PRIORITY 1',
      title: 'Crew Swap: MV Aurora',
      desc: 'Swap Chief Engineer from standby pool to prevent 12h departure delay.',
      impact: { cost: '+$1.2k', time: '-12h', risk: 'Low' },
      btnText: 'Approve Action',
      primary: true
    },
    {
      id: 2,
      priority: 'PRIORITY 2',
      title: 'Re-route: Flight Y-720',
      desc: 'Rebook 4 crew members via Frankfurt to avoid weather cell.',
      impact: { cost: '+$800', time: '-4h', risk: 'Med' },
      btnText: 'View Routing',
      primary: false
    },
    {
      id: 3,
      priority: 'PRIORITY 3',
      title: 'Delay Vessel: MV Ocean Pioneer',
      desc: 'Hold departure by 4h to align with delayed inbound crew flight.',
      impact: { cost: '$0', time: '+4h', risk: 'High' },
      btnText: 'Simulate Outcome',
      primary: false
    }
  ];

  return (
    <div className="space-y-3 sm:space-y-4 w-full">
      <h2 className="text-lg sm:text-xl font-bold tracking-tight">Recommended Actions</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-5">
        {actions.map((action, idx) => (
          <motion.div
            key={action.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`relative flex flex-col p-4 sm:p-5 rounded-xl sm:rounded-2xl border transition-all duration-300 hover:-translate-y-1 w-full ${
              action.primary 
                ? 'bg-primary/5 border-primary shadow-lg shadow-primary/10' 
                : 'bg-card border-border shadow-sm hover:shadow-md'
            }`}
          >
            <div className="flex justify-between items-start mb-2 sm:mb-3">
              <Badge variant={action.primary ? 'default' : 'secondary'} className="text-[9px] sm:text-[10px] font-bold tracking-wider">
                {action.priority}
              </Badge>
              {action.primary && <Zap className="w-3 h-3 sm:w-4 sm:h-4 text-primary animate-pulse" />}
            </div>
            
            <h3 className="font-bold text-base sm:text-lg mb-1.5 sm:mb-2 leading-tight break-words">{action.title}</h3>
            <p className="text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4 flex-1 break-words">{action.desc}</p>
            
            <div className="grid grid-cols-3 gap-1 sm:gap-2 mb-4 sm:mb-5 p-2 sm:p-3 bg-background/50 rounded-lg border border-border/50">
              <div className="text-center">
                <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase font-semibold">Cost</p>
                <p className="text-xs sm:text-sm font-bold text-foreground">{action.impact.cost}</p>
              </div>
              <div className="text-center border-x border-border/50">
                <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase font-semibold">Time</p>
                <p className="text-xs sm:text-sm font-bold text-[hsl(var(--tertiary))]">{action.impact.time}</p>
              </div>
              <div className="text-center">
                <p className="text-[9px] sm:text-[10px] text-muted-foreground uppercase font-semibold">Risk</p>
                <p className={`text-xs sm:text-sm font-bold ${action.impact.risk === 'High' ? 'text-destructive' : 'text-foreground'}`}>
                  {action.impact.risk}
                </p>
              </div>
            </div>
            
            <Button 
              className={`w-full mt-auto text-xs sm:text-sm h-9 sm:h-10 ${action.primary ? 'bg-primary text-primary-foreground hover:bg-primary/90' : ''}`}
              variant={action.primary ? 'default' : 'outline'}
              onClick={() => toast.success(`${action.title} initiated.`)}
            >
              {action.btnText}
              <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ml-1.5 sm:ml-2" />
            </Button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default RecommendedActions;