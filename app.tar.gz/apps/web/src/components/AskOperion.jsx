import React, { useState, useRef, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { Bot, Send, User, RotateCcw, Sparkles } from 'lucide-react';
import { generateOperionResponse } from '@/lib/investorModeHelpers.js';

const AskOperion = ({ fleetList = [] }) => {
  const [messages, setMessages] = useState([
    { id: '1', role: 'bot', text: 'Investor intelligence mode active. Ask me about fleet profitability, operational risks, or utilization metrics.' }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);

  const suggestedQuestions = [
    "What is the most profitable aircraft?",
    "What is the fleet utilization rate?",
    "Which aircraft needs maintenance?",
    "What are the operational risks?"
  ];

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = (text) => {
    if (!text.trim()) return;

    // Add user message
    const userMsg = { id: Date.now().toString(), role: 'user', text: text.trim() };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    // Simulate network delay
    setTimeout(() => {
      const responseText = generateOperionResponse(text, fleetList);
      const botMsg = { id: (Date.now() + 1).toString(), role: 'bot', text: responseText };
      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 600);
  };

  const handleClear = () => {
    setMessages([{ id: Date.now().toString(), role: 'bot', text: 'Chat history cleared. How can I assist your analysis today?' }]);
  };

  const renderMessageContent = (text) => {
    // Simple markdown-lite parser for bold text
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold text-foreground">{part.slice(2, -2)}</strong>;
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <Card className="border-border shadow-sm bg-card flex flex-col h-[600px] lg:h-full">
      <CardHeader className="pb-3 border-b border-border/50 bg-muted/10 flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-primary/10 p-1.5 rounded-md">
            <Sparkles className="w-4 h-4 text-primary" />
          </div>
          <div>
            <CardTitle className="text-sm font-bold uppercase tracking-wider text-foreground">Ask Operion</CardTitle>
            <p className="text-xs text-muted-foreground">AI Intelligence Agent</p>
          </div>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground" onClick={handleClear} title="Clear Chat">
          <RotateCcw className="w-4 h-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="flex-1 p-0 overflow-hidden flex flex-col">
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth"
        >
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'bot' && (
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                  <Bot className="w-4 h-4 text-primary" />
                </div>
              )}
              
              <div 
                className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-primary text-primary-foreground rounded-tr-sm' 
                    : 'bg-muted text-muted-foreground rounded-tl-sm border border-border/50'
                }`}
              >
                {renderMessageContent(msg.text)}
              </div>

              {msg.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center shrink-0 border border-slate-300 dark:border-slate-700">
                  <User className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                </div>
              )}
            </div>
          ))}
          
          {isTyping && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                <Bot className="w-4 h-4 text-primary" />
              </div>
              <div className="bg-muted rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1.5 border border-border/50">
                <span className="w-1.5 h-1.5 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-muted-foreground/40 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}
        </div>

        <div className="px-4 pb-2 pt-0 flex flex-wrap gap-2 shrink-0">
          {suggestedQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(q)}
              className="text-xs bg-background border border-border text-muted-foreground hover:bg-muted hover:text-foreground px-3 py-1.5 rounded-full transition-colors truncate max-w-[200px] text-left"
            >
              {q}
            </button>
          ))}
        </div>
      </CardContent>

      <CardFooter className="p-4 border-t border-border/50 bg-background shrink-0">
        <form 
          className="flex w-full gap-2 items-center"
          onSubmit={(e) => { e.preventDefault(); handleSend(inputValue); }}
        >
          <Input 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask about profitability, risks, utilization..."
            className="flex-1 bg-muted/50 border-border/50 focus-visible:ring-1 focus-visible:ring-primary h-10 text-foreground"
          />
          <Button 
            type="submit" 
            size="icon" 
            disabled={!inputValue.trim() || isTyping}
            className="shrink-0 h-10 w-10 transition-transform active:scale-95"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
};

export default AskOperion;