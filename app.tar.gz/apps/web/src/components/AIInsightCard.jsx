
import React, { useState } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';
import { ChevronDown, ChevronUp, AlertCircle, Info, Zap, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils.js';
import { formatDistanceToNow } from 'date-fns';

export default function AIInsightCard({ insight }) {
  const [isOpen, setIsOpen] = useState(false);

  const getSeverityConfig = (severity) => {
    switch (severity) {
      case 'critical': return { color: 'bg-destructive/10 text-destructive border-destructive/20', icon: AlertCircle, label: 'Critical' };
      case 'warning': return { color: 'bg-warning/10 text-warning-foreground border-warning/20', icon: AlertCircle, label: 'Warning' };
      case 'optimization': return { color: 'bg-success/10 text-success border-success/20', icon: Zap, label: 'Optimization' };
      default: return { color: 'bg-primary/10 text-primary border-primary/20', icon: Info, label: 'Info' };
    }
  };

  const config = getSeverityConfig(insight.severity);
  const Icon = config.icon;

  return (
    <Card className="overflow-hidden border-border bg-card shadow-sm transition-all hover:shadow-md">
      <div className="p-4">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={cn("px-2 py-0.5 text-xs font-medium flex items-center gap-1", config.color)}>
              <Icon className="w-3 h-3" />
              {config.label}
            </Badge>
            <Badge variant="secondary" className="bg-muted text-muted-foreground text-xs">
              Priority: {insight.priority}/100
            </Badge>
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {insight.timestamp ? formatDistanceToNow(new Date(insight.timestamp), { addSuffix: true }) : 'Just now'}
          </span>
        </div>

        <p className="text-sm font-medium text-foreground leading-snug mb-2">
          {insight.message}
        </p>

        <Collapsible open={isOpen} onOpenChange={setIsOpen}>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 px-2 text-xs text-muted-foreground hover:text-foreground -ml-2">
              {isOpen ? 'Hide Details' : 'View Details'}
              {isOpen ? <ChevronUp className="w-3 h-3 ml-1" /> : <ChevronDown className="w-3 h-3 ml-1" />}
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent className="pt-3 pb-1 animate-in fade-in slide-in-from-top-2">
            <div className="p-3 rounded-md bg-muted/50 border border-border text-sm text-muted-foreground mb-3">
              {insight.details}
            </div>
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="outline" className="h-8 text-xs">Dismiss</Button>
              <Button size="sm" className="h-8 text-xs">Take Action</Button>
            </div>
          </CollapsibleContent>
        </Collapsible>
      </div>
    </Card>
  );
}
