import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, ShieldAlert, CheckCircle2, Clock, MoreVertical } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Checkbox } from '@/components/ui/checkbox.jsx';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu.jsx';
import { Button } from '@/components/ui/button.jsx';

const CrewCardInteractive = ({ crew, isSelected, onSelect, onClick, onAction }) => {
  const getStatusConfig = (status) => {
    switch(status) {
      case 'Available': return { color: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20', icon: <CheckCircle2 className="w-3 h-3 mr-1" /> };
      case 'On Assignment': return { color: 'bg-blue-500/10 text-blue-500 border-blue-500/20', icon: <MapPin className="w-3 h-3 mr-1" /> };
      case 'On Leave': return { color: 'bg-amber-500/10 text-amber-500 border-amber-500/20', icon: <Clock className="w-3 h-3 mr-1" /> };
      case 'Training': return { color: 'bg-purple-500/10 text-purple-500 border-purple-500/20', icon: <Clock className="w-3 h-3 mr-1" /> };
      default: return { color: 'bg-gray-500/10 text-gray-500 border-gray-500/20', icon: null };
    }
  };

  const statusConfig = getStatusConfig(crew.status);
  
  // Check certifications
  const now = new Date();
  const expiringCerts = crew.certifications?.filter(c => {
    const daysUntilExpiry = (new Date(c.expiry) - now) / (1000 * 60 * 60 * 24);
    return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
  }) || [];
  
  const expiredCerts = crew.certifications?.filter(c => new Date(c.expiry) < now) || [];

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      className="h-full"
    >
      <Card 
        className={`h-full overflow-hidden cursor-pointer transition-all duration-300 border ${isSelected ? 'border-primary ring-1 ring-primary/50' : 'border-border hover:border-primary/30 hover:shadow-lg'}`}
        onClick={() => onClick(crew.id)}
      >
        <CardContent className="p-0 flex flex-col h-full">
          <div className="p-5 flex items-start gap-4 relative">
            <div className="absolute top-3 left-3 z-10" onClick={(e) => e.stopPropagation()}>
              <Checkbox 
                checked={isSelected} 
                onCheckedChange={() => onSelect(crew.id)}
                className="w-5 h-5 rounded-md data-[state=checked]:bg-primary data-[state=checked]:border-primary"
              />
            </div>
            
            <div className="absolute top-3 right-3 z-10" onClick={(e) => e.stopPropagation()}>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground touch-target">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {crew.status !== 'On Assignment' && <DropdownMenuItem onClick={() => onAction('assign', crew)}>Assign to Vessel</DropdownMenuItem>}
                  {crew.status === 'On Assignment' && <DropdownMenuItem onClick={() => onAction('reassign', crew)}>Reassign</DropdownMenuItem>}
                  {crew.status !== 'On Leave' && <DropdownMenuItem onClick={() => onAction('leave', crew)}>Mark On Leave</DropdownMenuItem>}
                  {crew.status !== 'Available' && <DropdownMenuItem onClick={() => onAction('available', crew)}>Mark Available</DropdownMenuItem>}
                  <DropdownMenuItem className="text-destructive focus:text-destructive" onClick={() => onAction('remove', crew)}>Remove Crew</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="relative mt-2">
              <img src={crew.avatar} alt={crew.name} className="w-16 h-16 rounded-xl object-cover border border-border shadow-sm" />
              {(expiredCerts.length > 0 || expiringCerts.length > 0) && (
                <div className="absolute -top-2 -right-2 bg-background rounded-full p-0.5">
                  <ShieldAlert className={`w-5 h-5 ${expiredCerts.length > 0 ? 'text-destructive' : 'text-warning-foreground'}`} />
                </div>
              )}
            </div>

            <div className="flex-1 min-w-0 pt-1">
              <h3 className="font-bold text-lg text-foreground truncate pr-6">{crew.name}</h3>
              <p className="text-sm font-medium text-primary truncate">{crew.role}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <Badge variant="outline" className={`text-xs font-medium ${statusConfig.color}`}>
                  {statusConfig.icon}
                  {crew.status}
                </Badge>
              </div>
            </div>
          </div>

          <div className="mt-auto border-t border-border bg-muted/30 p-4 grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground block text-xs mb-1">Current Vessel</span>
              <span className="font-medium text-foreground truncate block">{crew.vessel}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-xs mb-1">Contract Ends</span>
              <span className={`font-medium truncate block ${new Date(crew.contractEndDate) < now ? 'text-destructive' : 'text-foreground'}`}>
                {crew.contractEndDate}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CrewCardInteractive;