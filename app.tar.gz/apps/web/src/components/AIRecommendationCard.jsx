
import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Sparkles, CheckCircle2 } from 'lucide-react';

export default function AIRecommendationCard({ aiRecommendation, suggestedActions, confidence, contractName }) {
  return (
    <Card className="overflow-hidden border-primary/20 bg-gradient-to-br from-primary/5 to-background shadow-sm">
      <div className="p-5 border-b border-primary/10 flex items-center justify-between bg-primary/5">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">AI Strategic Recommendation</h3>
        </div>
        <Badge variant="secondary" className="bg-background/50 text-xs font-medium">
          {confidence}% Confidence
        </Badge>
      </div>
      
      <div className="p-5 space-y-6">
        <div>
          <p className="text-sm text-muted-foreground mb-1">Analysis for {contractName}</p>
          <p className="text-base font-medium text-foreground leading-relaxed">
            {aiRecommendation}
          </p>
        </div>

        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-foreground uppercase tracking-wider">Suggested Actions</h4>
          <ul className="space-y-2">
            {suggestedActions?.map((action, index) => (
              <li key={index} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <span className="leading-snug">{action}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Card>
  );
}
