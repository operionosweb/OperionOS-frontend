
import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Calendar, DollarSign, Percent, Clock, Activity } from 'lucide-react';
import { useContractForecasting } from '@/hooks/useContractForecasting.js';
import { RenewalProbabilityBar, RiskScoreGauge, ExposureIndexBar } from '@/components/ForecastingMetrics.jsx';
import AIRecommendationCard from '@/components/AIRecommendationCard.jsx';
import { formatDistanceToNow, parseISO, format } from 'date-fns';
import { cn } from '@/lib/utils.js';

export default function ContractForecastingPanel({ contract }) {
  const { forecast, isLoading, error } = useContractForecasting(contract);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 space-y-4 animate-pulse">
        <Activity className="w-8 h-8 text-primary animate-spin" />
        <p className="text-sm text-muted-foreground">Generating predictive forecast...</p>
      </div>
    );
  }

  if (error || !forecast) {
    return (
      <div className="p-6 text-center border border-dashed border-destructive/30 rounded-xl bg-destructive/5">
        <p className="text-sm text-destructive">Unable to generate forecast: {error || 'Insufficient data'}</p>
      </div>
    );
  }

  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  
  const getProbabilityStatus = (prob) => {
    if (prob >= 80) return 'Highly Likely';
    if (prob >= 50) return 'Moderately Likely';
    if (prob >= 20) return 'Uncertain';
    return 'At Risk';
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-border">
        <div>
          <h2 className="text-xl font-bold text-foreground">{forecast.contractName}</h2>
          <p className="text-sm text-muted-foreground">Predictive Analysis & Forecasting</p>
        </div>
        <Badge variant="outline" className="bg-muted/50">
          ID: {forecast.contractId}
        </Badge>
      </div>

      {/* Core Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-5 bg-card border-border shadow-sm">
          <RenewalProbabilityBar 
            value={forecast.renewalProbability} 
            status={getProbabilityStatus(forecast.renewalProbability)} 
            trend={forecast.renewalTrend} 
          />
        </Card>
        <Card className="p-5 bg-card border-border shadow-sm">
          <RiskScoreGauge 
            value={forecast.riskScore} 
            level={forecast.riskLevel.charAt(0).toUpperCase() + forecast.riskLevel.slice(1)} 
            trend={forecast.riskTrend} 
          />
        </Card>
        <Card className="p-5 bg-card border-border shadow-sm">
          <ExposureIndexBar 
            value={forecast.exposureIndex} 
            level={forecast.exposureLevel.charAt(0).toUpperCase() + forecast.exposureLevel.slice(1)} 
            trend={forecast.exposureTrend} 
          />
        </Card>
      </div>

      {/* Forecast Details & AI Recommendation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Col: Forecast Numbers */}
        <Card className="lg:col-span-4 p-5 bg-card border-border shadow-sm flex flex-col">
          <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-4">Financial Forecast</h3>
          
          <div className="space-y-5 flex-1">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-primary/10 rounded-md text-primary shrink-0">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-0.5">Est. Renewal Date</p>
                <p className="font-medium text-sm">{format(parseISO(forecast.forecastedRenewalDate), 'MMM dd, yyyy')}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-2 bg-primary/10 rounded-md text-primary shrink-0">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-0.5">Projected Cost</p>
                <p className="font-medium text-sm">{formatCurrency(forecast.forecastedRenewalCost)}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className={cn("p-2 rounded-md shrink-0", forecast.forecastedRenewalCostChange > 0 ? "bg-destructive/10 text-destructive" : "bg-success/10 text-success")}>
                <Percent className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-0.5">Cost Variance</p>
                <p className={cn("font-medium text-sm", forecast.forecastedRenewalCostChange > 0 ? "text-destructive" : "text-success")}>
                  {forecast.forecastedRenewalCostChange > 0 ? '+' : ''}{forecast.forecastedRenewalCostChange}%
                </p>
              </div>
            </div>
          </div>
        </Card>

        {/* Right Col: AI Recommendation */}
        <div className="lg:col-span-8">
          <AIRecommendationCard 
            aiRecommendation={forecast.aiRecommendation}
            suggestedActions={forecast.suggestedActions}
            confidence={forecast.confidence}
            contractName={forecast.contractName}
          />
        </div>
      </div>

      {/* Footer Meta */}
      <div className="flex items-center justify-between text-xs text-muted-foreground pt-2">
        <div className="flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5" />
          Calculated {formatDistanceToNow(parseISO(forecast.lastCalculatedAt), { addSuffix: true })}
        </div>
        <div>
          Engine Confidence: <span className="font-medium text-foreground">{forecast.confidence}%</span>
        </div>
      </div>

    </div>
  );
}
