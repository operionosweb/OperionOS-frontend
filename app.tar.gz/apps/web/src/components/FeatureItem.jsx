import React from 'react';

const FeatureItem = ({ icon: Icon, title, description, className = '' }) => {
  return (
    <div className={`flex items-start gap-4 ${className}`}>
      <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mt-1">
        <Icon className="w-5 h-5 text-primary" />
      </div>
      <div>
        <h4 className="text-lg font-semibold text-foreground mb-1">{title}</h4>
        {description && <p className="text-muted-foreground leading-relaxed">{description}</p>}
      </div>
    </div>
  );
};

export default FeatureItem;