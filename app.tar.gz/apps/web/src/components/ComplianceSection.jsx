import React from 'react';
import { CheckCircle, AlertCircle } from 'lucide-react';

const ComplianceSection = () => {
  return (
    <div className="bg-card p-6 rounded-2xl shadow-lg border border-border">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <CheckCircle className="w-5 h-5 text-primary" />
          </div>
          <h3 className="text-lg font-bold text-foreground">Legality and Compliance</h3>
        </div>
        <div className="flex gap-2">
          <span className="px-2 py-1 bg-muted text-muted-foreground text-xs font-bold rounded-md border border-border">FAA PART 117</span>
          <span className="px-2 py-1 bg-muted text-muted-foreground text-xs font-bold rounded-md border border-border">EASA ORO FTL</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Desktop Metrics */}
        <div className="hidden md:flex flex-col items-center justify-center p-4 bg-muted/50 rounded-xl border border-border text-center">
          <CheckCircle className="w-6 h-6 text-[hsl(var(--tertiary))] mb-2" />
          <div className="text-sm font-bold text-foreground">100% COMPLIANT</div>
        </div>
        <div className="hidden md:flex flex-col items-center justify-center p-4 bg-muted/50 rounded-xl border border-border text-center">
          <CheckCircle className="w-6 h-6 text-[hsl(var(--tertiary))] mb-2" />
          <div className="text-sm font-bold text-foreground">99.4% VALIDATED</div>
        </div>
        <div className="hidden md:flex flex-col items-center justify-center p-4 bg-destructive/5 rounded-xl border border-destructive/20 text-center">
          <AlertCircle className="w-6 h-6 text-destructive mb-2" />
          <div className="text-sm font-bold text-destructive">42 EXPIRING &gt; 30D</div>
        </div>

        {/* Mobile Metrics */}
        <div className="md:hidden flex items-center justify-between p-3 bg-muted/50 rounded-xl border border-border">
          <span className="text-xs font-bold text-muted-foreground">DUTY LIMITS</span>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-foreground">100% VALIDATED</span>
            <CheckCircle className="w-4 h-4 text-[hsl(var(--tertiary))]" />
          </div>
        </div>
        <div className="md:hidden flex items-center justify-between p-3 bg-muted/50 rounded-xl border border-border">
          <span className="text-xs font-bold text-muted-foreground">REST PERIODS</span>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-foreground">99.4% VALIDATED</span>
            <CheckCircle className="w-4 h-4 text-[hsl(var(--tertiary))]" />
          </div>
        </div>
        <div className="md:hidden flex items-center justify-between p-3 bg-destructive/5 rounded-xl border border-destructive/20">
          <span className="text-xs font-bold text-destructive">VISA VALIDITY</span>
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-destructive">42 Issues ACTION REQ</span>
            <AlertCircle className="w-4 h-4 text-destructive" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ComplianceSection;