
import React, { useMemo } from 'react';
import { Download, AlertCircle, FileText, DollarSign, TrendingUp } from 'lucide-react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { generateInvoiceSimulation, generatePenaltySimulation } from '@/lib/financialSimulation.js';
import { toast } from 'sonner';

const FinancialSimulation = ({ contract }) => {
  const invoiceData = useMemo(() => generateInvoiceSimulation(contract), [contract]);
  const penaltyData = useMemo(() => generatePenaltySimulation(contract), [contract]);

  if (!contract || !invoiceData || !penaltyData) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-muted/20 rounded-xl border border-dashed border-border h-full">
        <DollarSign className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
        <h3 className="text-lg font-medium text-foreground">Select a Contract</h3>
        <p className="text-muted-foreground text-sm mt-1">
          Choose a contract to run financial and penalty simulations.
        </p>
      </div>
    );
  }

  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  const handleDownload = () => {
    toast.success("Financial Report generated successfully.", { description: "Report downloaded as PDF." });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      
      {/* INVOICE PROJECTION */}
      <Card className="flex flex-col h-full border-border shadow-sm">
        <div className="p-5 border-b border-border bg-muted/20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Invoice Projection</h3>
          </div>
          <Badge variant="outline" className="bg-background">12-Month Outlook</Badge>
        </div>
        
        <div className="p-5 space-y-6 flex-1">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-background border border-border">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">Base Annual Value</p>
              <p className="text-2xl font-bold tabular-nums text-foreground">{formatCurrency(invoiceData.base_annual_value)}</p>
            </div>
            <div className="p-4 rounded-xl bg-background border border-border">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-1">Total Projected</p>
              <p className="text-2xl font-bold tabular-nums text-emerald-600">{formatCurrency(invoiceData.total_projected_12m)}</p>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium text-foreground mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-muted-foreground" /> Payment Schedule
            </h4>
            <div className="rounded-xl border border-border overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left py-2 px-3 font-medium text-muted-foreground">Month</th>
                    <th className="text-right py-2 px-3 font-medium text-muted-foreground">Amount</th>
                    <th className="text-right py-2 px-3 font-medium text-muted-foreground">Cumulative</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {invoiceData.payment_schedule.slice(0, 6).map((row, idx) => (
                    <tr key={idx} className="hover:bg-muted/30">
                      <td className="py-2 px-3 text-foreground">{row.month}</td>
                      <td className="py-2 px-3 text-right tabular-nums">{formatCurrency(row.amount)}</td>
                      <td className="py-2 px-3 text-right tabular-nums text-muted-foreground">{formatCurrency(row.cumulative)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="bg-muted/30 p-2 text-center text-xs text-muted-foreground border-t border-border">
                Showing first 6 months
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* PENALTY SIMULATION */}
      <Card className="flex flex-col h-full border-border shadow-sm border-orange-500/20">
        <div className="p-5 border-b border-border bg-orange-500/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-orange-500" />
            <h3 className="font-semibold text-foreground">Penalty Simulation</h3>
          </div>
          <Badge variant="destructive" className="bg-destructive/10 text-destructive border-transparent hover:bg-destructive/20">
            Risk Analysis
          </Badge>
        </div>

        <div className="p-5 space-y-6 flex-1 flex flex-col">
          <div className="space-y-4 flex-1">
            
            <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-background">
              <div>
                <p className="text-sm font-medium text-foreground">Late Renewal Penalty</p>
                <p className="text-xs text-muted-foreground">{penaltyData.late_renewal_penalty.days_delay} days delay estimated</p>
              </div>
              <p className="text-base font-semibold tabular-nums text-orange-600">
                {formatCurrency(penaltyData.late_renewal_penalty.total_cost)}
              </p>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-background">
              <div>
                <p className="text-sm font-medium text-foreground">Downtime Penalties</p>
                <p className="text-xs text-muted-foreground">{penaltyData.downtime_penalties.estimated_days} days estimated risk</p>
              </div>
              <p className="text-base font-semibold tabular-nums text-orange-600">
                {formatCurrency(penaltyData.downtime_penalties.total_cost)}
              </p>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-background">
              <div>
                <p className="text-sm font-medium text-foreground">SLA Breach Probable Cost</p>
                <p className="text-xs text-muted-foreground">{penaltyData.sla_breach_penalties.probability}% probability</p>
              </div>
              <p className="text-base font-semibold tabular-nums text-orange-600">
                {formatCurrency(penaltyData.sla_breach_penalties.total_cost)}
              </p>
            </div>

          </div>

          <div className="mt-auto pt-4 border-t border-border">
            <div className="p-4 rounded-xl bg-destructive/5 border border-destructive/20 flex items-center justify-between mb-4">
              <div>
                <p className="text-xs font-bold text-destructive uppercase tracking-wider mb-1">Total Worst-Case Exposure</p>
                <div className="flex items-center gap-2">
                  <p className="text-3xl font-black tabular-nums text-destructive">
                    {formatCurrency(penaltyData.worst_case_scenario.total_exposure)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <Badge variant="outline" className={`border-${penaltyData.worst_case_scenario.risk_level === 'CRITICAL' ? 'destructive' : 'orange-500'} text-${penaltyData.worst_case_scenario.risk_level === 'CRITICAL' ? 'destructive' : 'orange-500'}`}>
                  {penaltyData.worst_case_scenario.risk_level} RISK
                </Badge>
                <p className="text-xs text-muted-foreground mt-1">{penaltyData.worst_case_scenario.probability}% Probability</p>
              </div>
            </div>

            <Button onClick={handleDownload} className="w-full bg-foreground text-background hover:bg-foreground/90">
              <Download className="w-4 h-4 mr-2" />
              Download Financial Report (PDF)
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default FinancialSimulation;
