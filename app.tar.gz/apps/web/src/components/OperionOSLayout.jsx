import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Eye, ShieldAlert, Cpu } from 'lucide-react';
import { useOperionOS } from '@/contexts/OperionOSContext.jsx';
import { useImpersonation } from '@/contexts/ImpersonationContext.jsx';

import InvestorModeToggle from './InvestorModeToggle.jsx';
import FundraisingModeToggle from './FundraisingModeToggle.jsx';
import AIAssistantOverlay from './AIAssistantOverlay.jsx';
import CommandPaletteOverlay from './CommandPaletteOverlay.jsx';

const OperionOSLayout = ({ children, companies, loading }) => {
  const { 
    activeTab, 
    setActiveTab, 
    getFeatureFlags, 
    getActiveLayer, 
    isDemo 
  } = useOperionOS();
  
  const { activeCompanyId, setActiveCompany } = useImpersonation();
  const flags = getFeatureFlags();

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'crew', label: 'Crew Ops' },
    { id: 'fleet', label: 'Fleet Ops' },
    { id: 'operations', label: 'Live Operations' },
  ];

  if (flags.enableSimulationTab) {
    tabs.push({ id: 'simulation', label: 'Simulation & Intelligence' });
  }
  if (flags.enableCommandCenter) {
    tabs.push({ id: 'command-center', label: 'Command Center' });
  }

  const handleImpersonate = (companyId) => {
    const comp = companies?.find(c => c.id === companyId);
    if (comp) setActiveCompany(comp.id, comp.name || comp.id);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background relative w-full overflow-x-hidden">
      {/* Global Overlays */}
      <AIAssistantOverlay />
      <CommandPaletteOverlay />

      {/* Layer Indicator Banner */}
      <div className={`w-full py-1.5 px-4 text-center text-xs font-bold uppercase tracking-widest ${
        isDemo() 
          ? 'bg-orange-500/10 text-orange-600 dark:bg-orange-950/40 dark:text-orange-500 border-b border-orange-500/20' 
          : 'bg-blue-500/10 text-blue-600 dark:bg-blue-950/40 dark:text-blue-500 border-b border-blue-500/20'
      }`}>
        {getActiveLayer().replace('_', ' ')} ACTIVE
      </div>

      <div className="flex-1 w-full max-w-[100vw]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 w-full">
          
          {/* Header & Controls Area */}
          <div className="flex flex-col xl:flex-row justify-between gap-6 items-start xl:items-center">
            <div className="space-y-2 max-w-2xl">
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground flex flex-wrap items-center gap-3">
                OS Control Panel
              </h1>
              <p className="text-muted-foreground text-lg">
                Unified operational intelligence and asset management.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 bg-card border border-border/50 p-2.5 rounded-2xl shadow-sm w-full xl:w-auto">
              <Select 
                value={activeCompanyId || ''} 
                onValueChange={handleImpersonate}
                disabled={loading || !companies?.length}
              >
                <SelectTrigger className="w-full sm:w-[240px] bg-background h-10">
                  <SelectValue placeholder="Select Operating Company" />
                </SelectTrigger>
                <SelectContent>
                  {companies?.map(company => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.name || company.id}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="flex items-center gap-2 w-full sm:w-auto mt-2 sm:mt-0">
                <InvestorModeToggle />
                <FundraisingModeToggle />
              </div>
            </div>
          </div>

          {/* Core Navigation Tabs */}
          <div className="border-b border-border/50 overflow-x-auto hide-scrollbar w-full">
            <div className="flex space-x-1 pb-px min-w-max">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-3 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground hover:border-border'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content Area */}
          <div className="pt-2 animate-in fade-in duration-500 min-h-[50vh] w-full">
            {children}
          </div>

        </div>
      </div>
    </div>
  );
};

export default OperionOSLayout;