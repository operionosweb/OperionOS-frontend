
import React, { useState } from 'react';
import { Ship, Plane, Droplet, FileText, ChevronDown, ChevronUp, MoreVertical, Edit, Trash2 } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu.jsx';
import { getAlertBadge } from '@/lib/contractAlerts.js';
import { formatDate } from '@/lib/contractUtils.js';
import { cn } from '@/lib/utils.js';

export default function ContractCard({ contract, onClick }) {
  const [expanded, setExpanded] = useState(false);
  const badgeConfig = getAlertBadge(contract.alert_level);
  
  const getAssetIcon = (type) => {
    switch(type.toLowerCase()) {
      case 'vessel': return <Ship className="w-5 h-5" />;
      case 'aircraft': return <Plane className="w-5 h-5" />;
      case 'offshore rig': return <Droplet className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  return (
    <Card 
      className="group relative cursor-pointer hover:-translate-y-1 hover:shadow-lg transition-all duration-300 flex flex-col h-full overflow-hidden border-border"
      onClick={() => onClick(contract)}
    >
      <div className={cn("h-1 w-full absolute top-0 left-0", badgeConfig.bgColor.replace('/10', ''))} />
      
      <CardHeader className="p-5 pb-3 flex flex-row items-start justify-between gap-4 space-y-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">
            {getAssetIcon(contract.asset_type)}
          </div>
          <div className="min-w-0">
            <h3 className="font-semibold text-base text-foreground truncate" title={contract.asset_name}>{contract.asset_name}</h3>
            <p className="text-sm text-muted-foreground truncate">{contract.contract_id}</p>
          </div>
        </div>
        <Badge className={cn("shrink-0", badgeConfig.bgColor, badgeConfig.textColor, badgeConfig.borderColor)} variant="outline">
          {badgeConfig.label}
        </Badge>
      </CardHeader>
      
      <CardContent className="p-5 py-3 flex-1">
        <div className="space-y-3">
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Company</span>
            <span className="font-medium truncate max-w-[140px]" title={contract.company_name}>{contract.company_name}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Value</span>
            <span className="font-medium font-mono">${(contract.contract_value).toLocaleString()} {contract.currency}</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Expiry</span>
            <span className="font-medium flex items-center gap-1">
              {formatDate(contract.expiry_date)}
              <span className={cn("text-xs px-1.5 py-0.5 rounded-md ml-1", 
                contract.days_until_expiry < 0 ? "bg-destructive/10 text-destructive" :
                contract.days_until_expiry <= 90 ? "bg-warning/10 text-warning-foreground" : "bg-muted text-muted-foreground"
              )}>
                {contract.days_until_expiry < 0 ? 'Expired' : `${contract.days_until_expiry}d`}
              </span>
            </span>
          </div>
          
          <div className="pt-3 border-t border-border mt-3">
            <div className="flex justify-between items-center text-sm mb-1">
              <span className="text-muted-foreground">Financial Risk</span>
              <span className={cn("font-semibold", contract.financial_risk_score > 70 ? "text-destructive" : contract.financial_risk_score > 40 ? "text-warning-foreground" : "text-success")}>
                {contract.financial_risk_score}/100
              </span>
            </div>
            <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
              <div 
                className={cn("h-full rounded-full transition-all", 
                  contract.financial_risk_score > 70 ? "bg-destructive" : 
                  contract.financial_risk_score > 40 ? "bg-[#F59E0B]" : "bg-success"
                )}
                style={{ width: `${contract.financial_risk_score}%` }}
              />
            </div>
          </div>
        </div>

        {expanded && (
          <div className="mt-4 pt-4 border-t border-border animate-in slide-in-from-top-2 fade-in duration-200">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Penalties</p>
            <ul className="text-sm space-y-1 text-destructive bg-destructive/5 p-2 rounded-md">
              {contract.penalty_clauses.map((clause, idx) => (
                <li key={idx} className="flex items-start gap-1.5">
                  <span className="shrink-0 mt-1">•</span>
                  <span>{clause}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-4 pt-0 border-t border-border flex items-center justify-between bg-muted/20">
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-xs h-8 text-muted-foreground hover:text-foreground"
          onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}
        >
          {expanded ? <ChevronUp className="w-4 h-4 mr-1" /> : <ChevronDown className="w-4 h-4 mr-1" />}
          {expanded ? 'Hide Terms' : 'View Terms'}
        </Button>

        <div className="flex items-center gap-1">
          <Button variant="secondary" size="sm" className="h-8 text-xs bg-background">Details</Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
              <DropdownMenuItem><Edit className="w-4 h-4 mr-2" /> Edit Contract</DropdownMenuItem>
              <DropdownMenuItem className="text-destructive"><Trash2 className="w-4 h-4 mr-2" /> Terminate</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardFooter>
    </Card>
  );
}
