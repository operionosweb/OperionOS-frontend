
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { cn } from '@/lib/utils.js';

export default function FinancialScenariosSection({ scenarios, currency = 'USD' }) {
  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(val);

  const getScenarioColor = (scenario) => {
    switch (scenario) {
      case 'best': return 'bg-success/10 text-success border-success/20';
      case 'expected': return 'bg-primary/10 text-primary border-primary/20';
      case 'worst': return 'bg-warning/10 text-warning-foreground border-warning/20';
      case 'catastrophic': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted text-muted-foreground border-border';
    }
  };

  return (
    <div className="rounded-xl border border-border overflow-hidden bg-card">
      <Table>
        <TableHeader className="bg-muted/50">
          <TableRow>
            <TableHead>Scenario</TableHead>
            <TableHead>Description</TableHead>
            <TableHead className="text-right">Probability</TableHead>
            <TableHead className="text-right">Penalties</TableHead>
            <TableHead className="text-right">Total Cost</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {scenarios.map((s, idx) => (
            <TableRow key={idx}>
              <TableCell>
                <Badge variant="outline" className={cn("capitalize", getScenarioColor(s.scenario))}>
                  {s.scenario}
                </Badge>
              </TableCell>
              <TableCell className="text-sm text-muted-foreground max-w-[250px] truncate" title={s.description}>
                {s.description}
              </TableCell>
              <TableCell className="text-right font-medium text-foreground">{s.probability}%</TableCell>
              <TableCell className="text-right text-muted-foreground">{formatCurrency(s.penaltyExposure)}</TableCell>
              <TableCell className="text-right font-bold text-foreground">{formatCurrency(s.totalCost)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
