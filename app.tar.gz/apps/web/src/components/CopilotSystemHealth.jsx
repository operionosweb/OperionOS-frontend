
import React from 'react';
import { Progress } from '@/components/ui/progress.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { TrendingUp, TrendingDown, Minus, RefreshCw } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function CopilotSystemHealth({ healthScore, alerts, lastUpdate, onRefresh }) {
  const criticalCount = alerts.filter(a => a.severity === 'critical').length;
  const warningCount = alerts.filter(a => a.severity === 'warning').length;

  const getHealthColor = (score) => {
    if (score >= 90) return "bg-emerald-500";
    if (score >= 70) return "bg-amber-500";
    return "bg-destructive";
  };

  const TrendIcon = healthScore >= 90 ? TrendingUp : healthScore < 70 ? TrendingDown : Minus;
  const trendColor = healthScore >= 90 ? "text-emerald-500" : healthScore < 70 ? "text-destructive" : "text-muted-foreground";

  return (
    <div className="p-4 bg-card border-b border-border space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-foreground flex items-center gap-2">
            System Health
            <TrendIcon className={`w-4 h-4 ${trendColor}`} />
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Updated {formatDistanceToNow(lastUpdate, { addSuffix: true })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20 font-mono">
            {criticalCount} Critical
          </Badge>
          <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20 font-mono">
            {warningCount} Warn
          </Badge>
          <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground" onClick={onRefresh}>
            <RefreshCw className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="flex justify-between text-xs font-medium">
          <span className="text-muted-foreground">Overall Status</span>
          <span className="text-foreground">{healthScore}/100</span>
        </div>
        <Progress value={healthScore} className="h-2" indicatorClassName={getHealthColor(healthScore)} />
      </div>
    </div>
  );
}
