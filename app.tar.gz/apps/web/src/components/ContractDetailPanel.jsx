
import React, { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs.jsx';
import { FileText, Edit, Trash2, ShieldAlert, Sparkles, Building2, Calendar, DollarSign, Activity, BrainCircuit } from 'lucide-react';
import { getAlertBadge } from '@/lib/contractAlerts.js';
import { formatDate, calculateMonths, getContractStatusColor } from '@/lib/contractUtils.js';
import ContractForecastingPanel from '@/components/ContractForecastingPanel.jsx';
import FinancialSimulationPanel from '@/components/FinancialSimulationPanel.jsx';
import { cn } from '@/lib/utils.js';

export default function ContractDetailPanel({ isOpen, onClose, contract }) {
  const [activeTab, setActiveTab] = useState('details');

  if (!contract) return null;

  const badgeConfig = getAlertBadge(contract.alert_level);
  const durationMonths = calculateMonths(contract.start_date, contract.expiry_date);

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-2xl lg:max-w-3xl p-0 flex flex-col border-l border-border bg-background">
        <div className={cn("h-1 w-full", badgeConfig.bgColor.replace('/10', ''))} />
        
        <SheetHeader className="p-6 pb-4 border-b border-border bg-card">
          <div className="flex justify-between items-start mb-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <FileText className="w-6 h-6" />
              </div>
              <div>
                <SheetTitle className="text-2xl text-foreground">{contract.asset_name}</SheetTitle>
                <SheetDescription className="text-muted-foreground">{contract.contract_id} • {contract.asset_type}</SheetDescription>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 mt-4">
            <Badge className={cn(badgeConfig.bgColor, badgeConfig.textColor, badgeConfig.borderColor)} variant="outline">
              {badgeConfig.label} Risk
            </Badge>
            <Badge className={getContractStatusColor(contract.status)} variant="outline">
              {contract.status}
            </Badge>
            <Badge variant="secondary" className="bg-muted text-muted-foreground">
              {contract.renewal_status}
            </Badge>
          </div>
        </SheetHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
          <div className="px-6 pt-4 border-b border-border bg-card">
            <TabsList className="w-full justify-start h-auto p-0 bg-transparent space-x-6">
              <TabsTrigger 
                value="details" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 pb-3 pt-2 font-medium"
              >
                <FileText className="w-4 h-4 mr-2" /> Contract Details
              </TabsTrigger>
              <TabsTrigger 
                value="forecasting" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 pb-3 pt-2 font-medium"
              >
                <BrainCircuit className="w-4 h-4 mr-2" /> AI Forecasting
              </TabsTrigger>
            </TabsList>
          </div>

          <ScrollArea className="flex-1">
            <div className="p-6">
              <TabsContent value="details" className="m-0 space-y-8 focus-visible:outline-none">
                {/* AI Analysis Section */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-5 h-5 text-primary" />
                    <h3 className="text-lg font-semibold">AI Risk Analysis</h3>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Financial Risk</span>
                        <span className="font-semibold">{contract.financial_risk_score}/100</span>
                      </div>
                      <Progress 
                        value={contract.financial_risk_score} 
                        indicatorClassName={contract.financial_risk_score > 70 ? "bg-destructive" : contract.financial_risk_score > 40 ? "bg-[#F59E0B]" : "bg-success"}
                      />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Expiry Urgency</span>
                        <span className="font-semibold">{contract.expiry_urgency_score}/100</span>
                      </div>
                      <Progress 
                        value={contract.expiry_urgency_score} 
                        indicatorClassName={contract.expiry_urgency_score > 70 ? "bg-destructive" : contract.expiry_urgency_score > 40 ? "bg-[#F59E0B]" : "bg-success"}
                      />
                    </div>
                  </div>

                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 mt-4">
                    <p className="text-sm font-medium text-primary mb-1">Recommended Action</p>
                    <p className="text-sm text-foreground leading-relaxed">{contract.recommended_action}</p>
                  </div>
                </div>

                {/* Core Details */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2"><Building2 className="w-5 h-5 text-muted-foreground"/> Contract Details</h3>
                  <div className="grid grid-cols-2 gap-y-4 gap-x-6 p-4 bg-muted/30 rounded-xl border border-border">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Company</p>
                      <p className="font-medium text-sm">{contract.company_name}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Asset Type</p>
                      <p className="font-medium text-sm">{contract.asset_type}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Value</p>
                      <p className="font-medium text-sm font-mono">${contract.contract_value.toLocaleString()} {contract.currency}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Duration</p>
                      <p className="font-medium text-sm">{durationMonths} Months</p>
                    </div>
                  </div>
                </div>

                {/* Timeline */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2"><Calendar className="w-5 h-5 text-muted-foreground"/> Timeline</h3>
                  <div className="relative pl-4 border-l-2 border-muted ml-2 space-y-6">
                    <div className="relative">
                      <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-muted border-2 border-background" />
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-0.5">Start Date</p>
                      <p className="font-medium text-sm">{formatDate(contract.start_date)}</p>
                    </div>
                    <div className="relative">
                      <div className={cn("absolute -left-[21px] top-1 w-3 h-3 rounded-full border-2 border-background", contract.days_until_expiry < 0 ? "bg-destructive" : contract.days_until_expiry <= 90 ? "bg-warning" : "bg-primary")} />
                      <p className="text-xs text-muted-foreground uppercase tracking-wider mb-0.5">Expiry Date</p>
                      <p className={cn("font-medium text-sm", contract.days_until_expiry < 0 && "text-destructive")}>
                        {formatDate(contract.expiry_date)}
                        <span className="ml-2 text-xs font-normal text-muted-foreground">
                          ({contract.days_until_expiry < 0 ? `${Math.abs(contract.days_until_expiry)} days ago` : `in ${contract.days_until_expiry} days`})
                        </span>
                      </p>
                    </div>
                  </div>
                </div>

                {/* Financial Simulation Panel */}
                <div className="pt-6 border-t border-border">
                  <FinancialSimulationPanel contract={contract} />
                </div>

              </TabsContent>

              <TabsContent value="forecasting" className="m-0 focus-visible:outline-none">
                <ContractForecastingPanel contract={contract} />
              </TabsContent>
            </div>
          </ScrollArea>
        </Tabs>
        
        <div className="p-4 border-t border-border bg-muted/10 flex gap-3 justify-end">
          <Button variant="outline" className="bg-background"><Edit className="w-4 h-4 mr-2"/> Edit Contract</Button>
          <Button variant="destructive"><Trash2 className="w-4 h-4 mr-2"/> Terminate</Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
