
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Presentation, TrendingUp, ShieldCheck } from 'lucide-react';

const InvestorModeSafeMode = ({ active }) => {
  if (!active) return null;

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-primary/10 text-primary p-4 rounded-xl flex items-center gap-3">
        <Presentation className="w-6 h-6" />
        <div>
          <h3 className="font-bold">Investor Presentation Mode Active</h3>
          <p className="text-sm opacity-80">Displaying deterministic static metrics only. No continuous calculations.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-card border border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><TrendingUp className="w-5 h-5 text-primary" /> Static Valuation Snapshot</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-extrabold mb-2">$42.5M</div>
            <p className="text-muted-foreground text-sm">Pre-money valuation based on fixed operational efficiency model.</p>
          </CardContent>
        </Card>

        <Card className="bg-card border border-border shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2"><ShieldCheck className="w-5 h-5 text-emerald-500" /> Readiness Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-extrabold text-emerald-600 mb-2">94 / 100</div>
            <p className="text-muted-foreground text-sm">Deterministic rating derived from static mock metrics.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InvestorModeSafeMode;
