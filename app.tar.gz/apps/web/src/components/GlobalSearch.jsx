
import React, { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input.jsx';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Search, User, Plane, Activity, ChevronRight } from 'lucide-react';
import { searchAcross } from '@/lib/commandCenterHelpers.js';
import { useActionSystem } from './ActionSystem.jsx';

const GlobalSearch = ({ crewData, fleetData }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState({ crew: [], fleet: [], operations: [] });
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef(null);
  const { executeModalAction } = useActionSystem();

  useEffect(() => {
    if (query.trim().length > 1) {
      const mockOperations = [{ id: 'op1', title: 'Route 7 Reassignment', description: 'Active disruption management' }];
      const searchData = { crew: crewData, fleet: fleetData, operations: mockOperations };
      setResults(searchAcross(query, searchData));
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  }, [query, crewData, fleetData]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleResultClick = (type, item) => {
    setIsOpen(false);
    setQuery('');
    executeModalAction(`view-${type}-details`, item);
  };

  const hasResults = results.crew.length > 0 || results.fleet.length > 0 || results.operations.length > 0;

  return (
    <div className="relative w-full max-w-xl" ref={wrapperRef}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input 
          placeholder="Search crew, fleet, operations..." 
          className="pl-9 h-11 bg-card/50 border-border/50 focus-visible:ring-primary shadow-sm"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => query.trim().length > 1 && setIsOpen(true)}
        />
        <div className="absolute right-3 top-1/2 -translate-y-1/2 hidden sm:flex items-center gap-1">
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono font-medium rounded-md bg-muted border border-border/50 text-muted-foreground">⌘</kbd>
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono font-medium rounded-md bg-muted border border-border/50 text-muted-foreground">K</kbd>
        </div>
      </div>

      {isOpen && (
        <Card className="absolute top-full mt-2 w-full z-50 max-h-[400px] overflow-y-auto border-border/50 shadow-xl bg-card">
          {!hasResults ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              No results found for "{query}"
            </div>
          ) : (
            <div className="py-2">
              {results.crew.length > 0 && (
                <div className="mb-2">
                  <div className="px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground bg-muted/30">
                    Personnel
                  </div>
                  {results.crew.map(c => (
                    <button 
                      key={c.id} 
                      onClick={() => handleResultClick('crew', c)}
                      className="w-full text-left px-3 py-2.5 hover:bg-accent/50 flex items-center justify-between group transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-1.5 bg-blue-500/10 rounded-md"><User className="w-4 h-4 text-blue-500" /></div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{c.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">{c.role}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              )}

              {results.fleet.length > 0 && (
                <div className="mb-2">
                  <div className="px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground bg-muted/30">
                    Fleet Assets
                  </div>
                  {results.fleet.map(f => (
                    <button 
                      key={f.id} 
                      onClick={() => handleResultClick('fleet', f)}
                      className="w-full text-left px-3 py-2.5 hover:bg-accent/50 flex items-center justify-between group transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-1.5 bg-emerald-500/10 rounded-md"><Plane className="w-4 h-4 text-emerald-500" /></div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{f.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">{f.type}</p>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-[10px] py-0">{f.status || 'Active'}</Badge>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

export default GlobalSearch;
