import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { Building2, ShieldAlert, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

const CompanyCreationForm = () => {
  const [companyName, setCompanyName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  
  // Auth state
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const checkAuthAndRole = async () => {
      try {
        if (!window.supabaseClient) {
          throw new Error('Supabase client not initialized');
        }

        // 1. Get authenticated user
        const { data: { user }, error: userError } = await window.supabaseClient.auth.getUser();
        
        if (userError || !user) {
          setIsAuthorized(false);
          setAuthLoading(false);
          return;
        }

        setUserId(user.id);

        // 2. Fetch role from profiles table gracefully
        const { data: profileData, error: profileError } = await window.supabaseClient
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .maybeSingle();

        if (profileError || !profileData) {
          setIsAuthorized(false);
        } else {
          // 3. Check if super_admin
          setIsAuthorized(profileData.role === 'super_admin');
        }
      } catch (err) {
        console.error('Auth check failed:', err);
        setIsAuthorized(false);
      } finally {
        setAuthLoading(false);
      }
    };

    checkAuthAndRole();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess(false);

    const trimmedName = companyName.trim();

    // Validation
    if (!trimmedName) {
      setError('Company name is required.');
      return;
    }
    if (trimmedName.length < 2) {
      setError('Company name must be at least 2 characters long.');
      return;
    }

    setLoading(true);

    try {
      const { error: insertError } = await window.supabaseClient
        .from('companies')
        .insert([
          { 
            name: trimmedName, 
            created_by: userId 
          }
        ]);

      if (insertError) throw insertError;

      // Success handling
      setSuccess(true);
      setCompanyName('');
      
      // Auto-hide success message after 4 seconds
      setTimeout(() => {
        setSuccess(false);
      }, 4000);

    } catch (err) {
      console.error('Error creating company:', err);
      setError(err.message || 'Failed to create company. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <Card className="w-full max-w-md mx-auto shadow-md">
        <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[200px] text-muted-foreground gap-3">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
          <p className="text-sm font-medium">Verifying permissions...</p>
        </CardContent>
      </Card>
    );
  }

  if (!isAuthorized) {
    return (
      <Card className="w-full max-w-md mx-auto border-destructive/20 shadow-md bg-destructive/5">
        <CardContent className="pt-6 flex flex-col items-center text-center space-y-3">
          <ShieldAlert className="w-10 h-10 text-destructive mb-2" />
          <h2 className="text-xl font-semibold text-destructive">Access Restricted</h2>
          <p className="text-sm text-muted-foreground">
            You do not have the required super administrator privileges to create a new company.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto shadow-md border-border">
      <CardHeader className="space-y-1 pb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Building2 className="w-5 h-5 text-primary" />
          </div>
          <CardTitle className="text-xl">Create Company</CardTitle>
        </div>
        <CardDescription>
          Register a new tenant organization in the system.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {error && (
            <Alert variant="destructive" className="py-2.5">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="ml-2 font-medium">
                {error}
              </AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="py-2.5 bg-emerald-50 text-emerald-900 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              <AlertDescription className="ml-2 font-medium">
                Company created successfully
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="companyName" className="text-foreground font-medium">
              Company Name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="companyName"
              placeholder="e.g., Acme Aviation Corp"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              disabled={loading}
              className="h-10"
              autoFocus
            />
          </div>

          <Button 
            type="submit" 
            className="w-full h-10 transition-all font-medium" 
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Creating...
              </>
            ) : (
              'Create Company'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default CompanyCreationForm;