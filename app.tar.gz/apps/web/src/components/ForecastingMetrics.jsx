
import React from 'react';
import { Progress } from '@/components/ui/progress.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, ShieldCheck, Activity } from 'lucide-react';
import { cn } from '@/lib/utils.js';

const TrendIcon = ({ trend, className }) => {
  if (trend === 'improving' || trend === 'increasing') return <TrendingUp className={cn("w-3 h-3", className)} />;
  if (trend === 'declining' || trend === 'decreasing') return <TrendingDown className={cn("w-3 h-3", className)} />;
  return <Minus className={cn("w-3 h-3", className)} />;
};

export function RenewalProbabilityBar({ value, status, trend, className }) {
  const isHigh = value >= 80;
  const isMedium = value >= 50 && value < 80;
  const colorClass = isHigh ? 'bg-success' : isMedium ? 'bg-warning' : 'bg-destructive';
  const textClass = isHigh ? 'text-success' : isMedium ? 'text-warning-foreground' : 'text-destructive';

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex justify-between items-end">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted-foreground">Renewal Probability</span>
          <Badge variant="outline" className={cn("text-[10px] h-5 px-1.5", textClass, "border-current/20 bg-current/10")}>
            {status}
          </Badge>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={cn("text-xl font-bold", textClass)}>{value}%</span>
          <TrendIcon trend={trend} className={textClass} />
        </div>
      </div>
      <Progress value={value} className="h-2.5" indicatorClassName={colorClass} />
    </div>
  );
}

export function RiskScoreGauge({ value, level, trend, className }) {
  const isCritical = value >= 70;
  const isHigh = value >= 50 && value < 70;
  const isMedium = value >= 30 && value < 50;
  
  const colorClass = isCritical ? 'bg-destructive' : isHigh ? 'bg-orange-500' : isMedium ? 'bg-warning' : 'bg-success';
  const textClass = isCritical ? 'text-destructive' : isHigh ? 'text-orange-500' : isMedium ? 'text-warning-foreground' : 'text-success';
  const Icon = isCritical || isHigh ? AlertTriangle : isMedium ? Activity : ShieldCheck;

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex justify-between items-end">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted-foreground">Risk Score</span>
          <Badge variant="outline" className={cn("text-[10px] h-5 px-1.5", textClass, "border-current/20 bg-current/10")}>
            <Icon className="w-3 h-3 mr-1" /> {level}
          </Badge>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={cn("text-xl font-bold", textClass)}>{value}/100</span>
          <TrendIcon trend={trend} className={textClass} />
        </div>
      </div>
      <Progress value={value} className="h-2.5" indicatorClassName={colorClass} />
    </div>
  );
}

export function ExposureIndexBar({ value, level, trend, className }) {
  const isCritical = value >= 70;
  const isHigh = value >= 50 && value < 70;
  const isMedium = value >= 30 && value < 50;
  
  const colorClass = isCritical ? 'bg-destructive' : isHigh ? 'bg-orange-500' : isMedium ? 'bg-warning' : 'bg-success';
  const textClass = isCritical ? 'text-destructive' : isHigh ? 'text-orange-500' : isMedium ? 'text-warning-foreground' : 'text-success';

  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex justify-between items-end">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-muted-foreground">Exposure Index</span>
          <Badge variant="outline" className={cn("text-[10px] h-5 px-1.5", textClass, "border-current/20 bg-current/10")}>
            {level}
          </Badge>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={cn("text-xl font-bold", textClass)}>{value}/100</span>
          <TrendIcon trend={trend} className={textClass} />
        </div>
      </div>
      <Progress value={value} className="h-2.5" indicatorClassName={colorClass} />
    </div>
  );
}
