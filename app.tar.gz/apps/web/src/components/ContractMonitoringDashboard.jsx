
import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { useContractMonitoring } from '@/hooks/useContractMonitoring.js';
import { useContractForecasting } from '@/hooks/useContractForecasting.js';
import { ShieldAlert, AlertTriangle, RefreshCw, Activity, Clock, BrainCircuit, ArrowRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { RenewalProbabilityBar, RiskScoreGauge, ExposureIndexBar } from '@/components/ForecastingMetrics.jsx';

// Mini Forecasting Card Component
function MiniForecastingCard({ contract }) {
  const { forecast, isLoading } = useContractForecasting(contract);

  if (isLoading || !forecast) {
    return (
      <Card className="p-4 bg-card border-border shadow-sm animate-pulse h-[180px] flex items-center justify-center">
        <Activity className="w-6 h-6 text-muted-foreground animate-spin" />
      </Card>
    );
  }

  const getProbabilityStatus = (prob) => {
    if (prob >= 80) return 'High';
    if (prob >= 50) return 'Medium';
    return 'Low';
  };

  return (
    <Card className="p-4 bg-card border-border shadow-sm flex flex-col h-full hover:border-primary/50 transition-colors">
      <div className="flex justify-between items-start mb-4">
        <div className="min-w-0 pr-2">
          <h4 className="font-semibold text-sm text-foreground truncate" title={forecast.contractName}>
            {forecast.contractName}
          </h4>
          <p className="text-xs text-muted-foreground truncate">{forecast.contractId}</p>
        </div>
        <Badge variant="outline" className="shrink-0 text-[10px] px-1.5 py-0 h-5">
          {forecast.riskLevel.toUpperCase()}
        </Badge>
      </div>

      <div className="space-y-3 flex-1">
        <RenewalProbabilityBar 
          value={forecast.renewalProbability} 
          status={getProbabilityStatus(forecast.renewalProbability)} 
          trend={forecast.renewalTrend} 
          className="scale-90 origin-left w-[111%]"
        />
        <div className="grid grid-cols-2 gap-2">
          <RiskScoreGauge 
            value={forecast.riskScore} 
            level={forecast.riskLevel.charAt(0).toUpperCase() + forecast.riskLevel.slice(1)} 
            trend={forecast.riskTrend} 
            className="scale-90 origin-left w-[111%]"
          />
          <ExposureIndexBar 
            value={forecast.exposureIndex} 
            level={forecast.exposureLevel.charAt(0).toUpperCase() + forecast.exposureLevel.slice(1)} 
            trend={forecast.exposureTrend} 
            className="scale-90 origin-left w-[111%]"
          />
        </div>
      </div>

      <Button variant="ghost" size="sm" className="w-full mt-3 text-xs h-8 text-primary hover:text-primary hover:bg-primary/10">
        View Full Forecast <ArrowRight className="w-3 h-3 ml-1" />
      </Button>
    </Card>
  );
}

export default function ContractMonitoringDashboard() {
  const { 
    criticalAlerts, 
    warningAlerts, 
    exposureMetrics, 
    lastMonitoredAt, 
    triggerMonitoring,
    getExpiringContracts,
    getHighRiskContracts
  } = useContractMonitoring();

  const expiringCount = getExpiringContracts(30).length;
  const highRiskContracts = getHighRiskContracts();
  const topForecastContracts = highRiskContracts.slice(0, 3);

  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', notation: 'compact', maximumFractionDigits: 2 }).format(val);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-card p-4 rounded-xl border border-border shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-primary/10 rounded-lg">
            <Activity className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-foreground">Real-Time Monitoring Engine</h2>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
              <Clock className="w-3 h-3" /> 
              Last updated: {lastMonitoredAt ? formatDistanceToNow(new Date(lastMonitoredAt), { addSuffix: true }) : 'Never'}
            </p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={triggerMonitoring} className="gap-2">
          <RefreshCw className="w-4 h-4" /> Force Analysis
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5 bg-card border-border flex flex-col justify-between">
          <div className="flex items-start justify-between mb-4">
            <span className="text-sm font-medium text-muted-foreground">Critical Alerts</span>
            <ShieldAlert className="w-5 h-5 text-destructive" />
          </div>
          <div className="flex items-end gap-3">
            <span className="text-4xl font-black text-foreground leading-none">{criticalAlerts.length}</span>
            {criticalAlerts.length > 0 && (
              <Badge variant="destructive" className="mb-1">Requires Action</Badge>
            )}
          </div>
        </Card>

        <Card className="p-5 bg-card border-border flex flex-col justify-between">
          <div className="flex items-start justify-between mb-4">
            <span className="text-sm font-medium text-muted-foreground">Warning Alerts</span>
            <AlertTriangle className="w-5 h-5 text-warning-foreground" />
          </div>
          <div className="flex items-end gap-3">
            <span className="text-4xl font-black text-foreground leading-none">{warningAlerts.length}</span>
            {warningAlerts.length > 0 && (
              <Badge variant="outline" className="mb-1 bg-warning/10 text-warning-foreground border-warning/20">Review Soon</Badge>
            )}
          </div>
        </Card>

        <Card className="p-5 bg-card border-border flex flex-col justify-between">
          <div className="flex items-start justify-between mb-4">
            <span className="text-sm font-medium text-muted-foreground">Expiring (30d)</span>
            <Clock className="w-5 h-5 text-primary" />
          </div>
          <div className="flex items-end gap-3">
            <span className="text-4xl font-black text-foreground leading-none">{expiringCount}</span>
            <span className="text-sm text-muted-foreground mb-1 font-medium">Contracts</span>
          </div>
        </Card>

        <Card className="p-5 bg-card border-border flex flex-col justify-between">
          <div className="flex items-start justify-between mb-4">
            <span className="text-sm font-medium text-muted-foreground">Total Exposure</span>
            <div className="w-5 h-5 rounded-full bg-emerald-500/20 flex items-center justify-center">
              <span className="text-emerald-600 font-bold text-xs">$</span>
            </div>
          </div>
          <div className="flex items-end gap-3">
            <span className="text-4xl font-black text-foreground leading-none">{formatCurrency(exposureMetrics.totalExposure)}</span>
          </div>
        </Card>
      </div>

      {/* Forecasting Insights Section */}
      {topForecastContracts.length > 0 && (
        <div className="pt-4 space-y-4">
          <div className="flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-bold text-foreground">AI Forecasting Insights</h3>
            <span className="text-sm text-muted-foreground ml-2">Top {topForecastContracts.length} High-Risk Contracts</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {topForecastContracts.map(contract => (
              <MiniForecastingCard key={contract.contract_id || contract.id} contract={contract} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
