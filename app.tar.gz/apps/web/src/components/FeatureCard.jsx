import React from 'react';
import { Card } from '@/components/ui/card.jsx';

const FeatureCard = ({ icon: Icon, title, description, showDot = false, className = '' }) => {
  return (
    <Card className={`p-8 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-none shadow-md bg-card relative overflow-hidden ${className}`}>
      {showDot && (
        <div className="absolute top-6 right-6 w-3 h-3 rounded-full bg-[hsl(var(--tertiary))] shadow-[0_0_10px_hsl(var(--tertiary))]"></div>
      )}
      <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
        <Icon className="h-6 w-6 text-primary" />
      </div>
      <h3 className="text-xl font-semibold mb-3 text-card-foreground">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </Card>
  );
};

export default FeatureCard;