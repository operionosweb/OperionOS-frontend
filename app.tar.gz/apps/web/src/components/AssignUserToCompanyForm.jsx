import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { UserPlus, ShieldAlert, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

const AssignUserToCompanyForm = () => {
  const [userEmail, setUserEmail] = useState('');
  const [selectedCompany, setSelectedCompany] = useState('');
  const [selectedRole, setSelectedRole] = useState('user');
  
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [authLoading, setAuthLoading] = useState(true);

  useEffect(() => {
    const initializeForm = async () => {
      try {
        if (!window.supabaseClient) {
          throw new Error('Supabase client not initialized');
        }

        // 1. Get authenticated user
        const { data: { user }, error: userError } = await window.supabaseClient.auth.getUser();
        
        if (userError || !user) {
          setIsAuthorized(false);
          setAuthLoading(false);
          return;
        }

        // 2. Fetch role from profiles table
        const { data: profileData, error: profileError } = await window.supabaseClient
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .maybeSingle();

        if (profileError || !profileData) {
          setIsAuthorized(false);
        } else {
          // 3. Check if super_admin
          const isSuperAdmin = profileData.role === 'super_admin';
          setIsAuthorized(isSuperAdmin);

          // 4. Fetch companies if authorized
          if (isSuperAdmin) {
            const { data: companiesData, error: companiesError } = await window.supabaseClient
              .from('companies')
              .select('*')
              .order('name', { ascending: true });
              
            if (!companiesError && companiesData) {
              setCompanies(companiesData);
            }
          }
        }
      } catch (err) {
        console.error('Initialization failed:', err);
        setIsAuthorized(false);
      } finally {
        setAuthLoading(false);
      }
    };

    initializeForm();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess(false);

    // Validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!userEmail.trim() || !emailRegex.test(userEmail)) {
      setError('Please enter a valid user email address.');
      return;
    }
    if (!selectedCompany) {
      setError('Please select a company.');
      return;
    }
    if (!selectedRole) {
      setError('Please select a role.');
      return;
    }

    setLoading(true);

    try {
      // Step 1: Find user by email in auth.users
      const { data: userData, error: userError } = await window.supabaseClient
        .from('auth.users')
        .select('id')
        .eq('email', userEmail.trim())
        .maybeSingle();

      if (userError) throw userError;
      
      if (!userData || !userData.id) {
        setError('User not found. Ensure the email belongs to a registered user.');
        setLoading(false);
        return;
      }

      const targetUserId = userData.id;

      // Step 2: Upsert into company_users
      const { error: upsertError } = await window.supabaseClient
        .from('company_users')
        .upsert({ 
          user_id: targetUserId, 
          company_id: selectedCompany, 
          role: selectedRole 
        }, { 
          onConflict: 'user_id,company_id' 
        });

      if (upsertError) throw upsertError;

      // Success handling
      setSuccess(true);
      setUserEmail('');
      setSelectedCompany('');
      setSelectedRole('user');
      
      // Auto-hide success message
      setTimeout(() => {
        setSuccess(false);
      }, 4000);

    } catch (err) {
      console.error('Error assigning user:', err);
      setError(err.message || 'Failed to assign user. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <Card className="w-full max-w-md mx-auto shadow-md">
        <CardContent className="pt-6 flex flex-col items-center justify-center min-h-[200px] text-muted-foreground gap-3">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
          <p className="text-sm font-medium">Verifying permissions...</p>
        </CardContent>
      </Card>
    );
  }

  if (!isAuthorized) {
    return (
      <Card className="w-full max-w-md mx-auto border-destructive/20 shadow-md bg-destructive/5">
        <CardContent className="pt-6 flex flex-col items-center text-center space-y-3">
          <ShieldAlert className="w-10 h-10 text-destructive mb-2" />
          <h2 className="text-xl font-semibold text-destructive">Access Restricted</h2>
          <p className="text-sm text-muted-foreground">
            You do not have the required super administrator privileges to assign users to companies.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto shadow-md border-border">
      <CardHeader className="space-y-1 pb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-primary/10 rounded-lg">
            <UserPlus className="w-5 h-5 text-primary" />
          </div>
          <CardTitle className="text-xl">Assign User</CardTitle>
        </div>
        <CardDescription>
          Link an existing user account to a company with specific role permissions.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {error && (
            <Alert variant="destructive" className="py-2.5">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="ml-2 font-medium">
                {error}
              </AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="py-2.5 bg-emerald-50 text-emerald-900 border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800">
              <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              <AlertDescription className="ml-2 font-medium">
                User assigned successfully
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="userEmail" className="text-foreground font-medium">
              User Email <span className="text-destructive">*</span>
            </Label>
            <Input
              id="userEmail"
              type="email"
              placeholder="user@example.com"
              value={userEmail}
              onChange={(e) => setUserEmail(e.target.value)}
              disabled={loading}
              className="h-10"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="companySelector" className="text-foreground font-medium">
              Company <span className="text-destructive">*</span>
            </Label>
            <Select 
              value={selectedCompany} 
              onValueChange={setSelectedCompany}
              disabled={loading || companies.length === 0}
            >
              <SelectTrigger id="companySelector" className="h-10">
                <SelectValue placeholder={companies.length === 0 ? "No companies available" : "Select a company"} />
              </SelectTrigger>
              <SelectContent>
                {companies.map((company) => (
                  <SelectItem key={company.id} value={company.id}>
                    {company.name || company.id}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="roleSelector" className="text-foreground font-medium">
              Role <span className="text-destructive">*</span>
            </Label>
            <Select 
              value={selectedRole} 
              onValueChange={setSelectedRole}
              disabled={loading}
            >
              <SelectTrigger id="roleSelector" className="h-10">
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="user">User</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button 
            type="submit" 
            className="w-full h-10 mt-2 transition-all font-medium" 
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Assigning...
              </>
            ) : (
              'Assign User'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default AssignUserToCompanyForm;