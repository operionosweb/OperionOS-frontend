import React from 'react';
import { motion } from 'framer-motion';
import { XCircle, CheckCircle2, ArrowRight } from 'lucide-react';

const CostVsSavingsComparison = () => {
  const losses = [
    "Excess fuel burn due to suboptimal routing and speed profiles",
    "Compounding delays from reactive disruption management",
    "Manual, error-prone crew scheduling and roster changes",
    "Reactive maintenance leading to unexpected downtime",
    "High emissions penalties and compliance reporting overhead"
  ];

  const savings = [
    "Optimized fuel consumption via AI-driven speed and route profiles",
    "Automated, predictive disruption recovery minimizing delay cascades",
    "Algorithmic crew pairing and fatigue risk management",
    "Predictive maintenance insights extending asset uptime",
    "Automated emissions tracking and reduced carbon tax exposure"
  ];

  return (
    <div className="w-full py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 tracking-tight text-balance">
          The Cost of Inaction
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Traditional operations leak margin at every step. Operion plugs the holes and optimizes the flow.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr] gap-8 items-center max-w-6xl mx-auto">
        {/* Without Operion */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="bg-destructive/5 border border-destructive/20 rounded-2xl p-8 h-full"
        >
          <h3 className="text-xl font-semibold text-destructive mb-6 flex items-center gap-2">
            <XCircle className="w-5 h-5" />
            Typical Losses Without Operion
          </h3>
          <ul className="space-y-4">
            {losses.map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-muted-foreground">
                <span className="w-1.5 h-1.5 rounded-full bg-destructive/50 mt-2 shrink-0" />
                <span className="leading-relaxed">{item}</span>
              </li>
            ))}
          </ul>
        </motion.div>

        {/* Arrow Indicator (Desktop only) */}
        <div className="hidden lg:flex justify-center text-muted-foreground/30">
          <ArrowRight className="w-8 h-8" />
        </div>

        {/* With Operion */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="bg-primary/5 border border-primary/20 rounded-2xl p-8 h-full relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl -mr-10 -mt-10 pointer-events-none" />
          <h3 className="text-xl font-semibold text-primary mb-6 flex items-center gap-2 relative z-10">
            <CheckCircle2 className="w-5 h-5" />
            Optimized Operations With Operion
          </h3>
          <ul className="space-y-4 relative z-10">
            {savings.map((item, i) => (
              <li key={i} className="flex items-start gap-3 text-foreground">
                <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                <span className="leading-relaxed font-medium">{item}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </div>
  );
};

export default CostVsSavingsComparison;