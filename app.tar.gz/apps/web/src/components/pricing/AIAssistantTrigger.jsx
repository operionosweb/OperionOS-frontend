import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';

const AIAssistantTrigger = () => {
  const prompts = [
    "How much can I save with 50 vessels?",
    "Explain the emissions compliance savings",
    "Run a scenario for my specific fleet"
  ];

  return (
    <div className="w-full max-w-4xl mx-auto my-16">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-sm flex flex-col md:flex-row items-center gap-8"
      >
        <div className="flex-shrink-0 w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center">
          <Sparkles className="w-8 h-8 text-primary" />
        </div>
        
        <div className="flex-grow text-center md:text-left">
          <h3 className="text-xl font-semibold text-foreground mb-2">Ask the Operion AI</h3>
          <p className="text-muted-foreground text-sm mb-6">
            Get instant answers about pricing, ROI, and deployment tailored to your operations.
          </p>
          
          <div className="flex flex-wrap justify-center md:justify-start gap-3">
            {prompts.map((prompt, i) => (
              <Link 
                key={i}
                to="/contact-sales"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-muted hover:bg-primary/10 hover:text-primary text-sm text-muted-foreground transition-colors border border-border/50"
              >
                <MessageSquare className="w-4 h-4" />
                {prompt}
              </Link>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AIAssistantTrigger;