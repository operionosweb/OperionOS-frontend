import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Calendar, Target, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Link } from 'react-router-dom';

const PilotProgramSection = () => {
  return (
    <section className="py-24 bg-secondary text-secondary-foreground relative overflow-hidden rounded-3xl my-12">
      {/* Background Texture */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-soft-light" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")' }}></div>
      
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/3 pointer-events-none"></div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-bold mb-6 tracking-tight text-balance"
          >
            Start with a Pilot. Prove the Savings.
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-xl text-secondary-foreground/80 max-w-3xl mx-auto leading-relaxed"
          >
            We don't sell licenses upfront. We validate savings in your operations first. You see measurable results before scaling.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {[
            { icon: Calendar, title: "90-Day Evaluation", desc: "Run Operion in parallel with your existing systems on a subset of your fleet." },
            { icon: Target, title: "Define Success KPIs", desc: "We agree on baseline metrics and target savings before the pilot begins." },
            { icon: BarChart3, title: "Measure & Scale", desc: "Review the generated ROI. If we hit the targets, we scale to the full fleet." }
          ].map((step, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 + (i * 0.1) }}
              className="bg-secondary-foreground/5 border border-secondary-foreground/10 rounded-2xl p-6"
            >
              <step.icon className="w-8 h-8 text-primary mb-4" />
              <h4 className="text-lg font-semibold mb-2">{step.title}</h4>
              <p className="text-secondary-foreground/70 text-sm leading-relaxed">{step.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Button size="lg" className="w-full sm:w-auto text-base h-14 px-8 bg-primary text-primary-foreground hover:bg-primary/90" asChild>
            <Link to="/contact-sales">
              Request Pilot Program <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" className="w-full sm:w-auto text-base h-14 px-8 border-secondary-foreground/20 text-secondary-foreground hover:bg-secondary-foreground/10" asChild>
            <Link to="/contact">
              Talk to Operion Team
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default PilotProgramSection;