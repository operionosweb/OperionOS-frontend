import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card.jsx';

const ValueBreakdownCard = ({ title, amount, description, icon: Icon, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
    >
      <Card className="h-full flex flex-col hover:shadow-lg hover:-translate-y-1 transition-all duration-300 border-border/50 bg-card">
        <CardContent className="p-6 flex flex-col h-full">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
          <div className="text-3xl font-bold text-foreground mb-4 tracking-tight">
            {amount}
            <span className="text-sm font-normal text-muted-foreground ml-1">/year saved</span>
          </div>
          <p className="text-muted-foreground text-sm leading-relaxed mt-auto">
            {description}
          </p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ValueBreakdownCard;