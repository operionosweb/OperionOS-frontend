import React from 'react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion.jsx';
import { Info } from 'lucide-react';

const TransparencyPanel = () => {
  return (
    <div className="w-full max-w-3xl mx-auto my-16 bg-muted/30 rounded-2xl border border-border p-6 md:p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-primary/10 rounded-lg">
          <Info className="w-5 h-5 text-primary" />
        </div>
        <h3 className="text-xl font-semibold text-foreground">How these numbers are calculated</h3>
      </div>
      
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="benchmarks" className="border-border/50">
          <AccordionTrigger className="text-base font-medium hover:no-underline hover:text-primary transition-colors">
            Industry Benchmarks & Baselines
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground leading-relaxed">
            Our savings models use aggregated baseline data from IATA, IMO, and our existing customer base. We assume a baseline operational efficiency typical of legacy systems (e.g., manual routing, static crew rosters). The delta represents the optimization gap Operion closes.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="fleet" className="border-border/50">
          <AccordionTrigger className="text-base font-medium hover:no-underline hover:text-primary transition-colors">
            Fleet Size & Utilization Assumptions
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground leading-relaxed">
            The default simulation assumes a mid-sized enterprise fleet (e.g., 50 commercial aircraft or 30 cargo vessels) operating at 85% utilization. Savings scale non-linearly; larger fleets typically see higher percentage gains due to increased network complexity and compounding optimization opportunities.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="fuel" className="border-border/50">
          <AccordionTrigger className="text-base font-medium hover:no-underline hover:text-primary transition-colors">
            Fuel Price Ranges
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground leading-relaxed">
            Fuel savings are calculated using a trailing 6-month average of global Jet A-1 or VLSFO prices. We apply a conservative 2.5% to 4.8% reduction in total fuel burn based on historical performance of our AI routing and speed profiling algorithms.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="averages" className="border-border/50 border-b-0">
          <AccordionTrigger className="text-base font-medium hover:no-underline hover:text-primary transition-colors">
            Operational Averages & Disruption Costs
          </AccordionTrigger>
          <AccordionContent className="text-muted-foreground leading-relaxed">
            Disruption costs are modeled at €85/minute for aviation delays and €15,000/day for maritime off-hire events. Operion's predictive recovery typically reduces total delay minutes by 18-24%, directly translating to the operational efficiency savings shown.
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

export default TransparencyPanel;