import React from 'react';
import FeatureAccordion from './FeatureAccordion.jsx';

const FeatureCategory = ({ title, description, icon: Icon, items }) => {
  return (
    <div className="mb-16 scroll-mt-24">
      <div className="mb-8 max-w-3xl">
        <div className="flex items-center gap-3 mb-3">
          {Icon && (
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Icon className="w-5 h-5 text-primary" />
            </div>
          )}
          <h3 className="text-2xl md:text-3xl font-bold text-foreground">{title}</h3>
        </div>
        {description && (
          <p className="text-lg text-muted-foreground leading-relaxed">
            {description}
          </p>
        )}
      </div>
      
      <div className="w-full">
        <FeatureAccordion items={items} />
      </div>
    </div>
  );
};

export default FeatureCategory;