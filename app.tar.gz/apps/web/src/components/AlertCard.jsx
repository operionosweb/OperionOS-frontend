
import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Check, X, AlertTriangle, Info, ShieldAlert } from 'lucide-react';
import { Card } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { getSeverityColor } from '@/lib/alertRules.js';
import { cn } from '@/lib/utils.js';

export default function AlertCard({ alert, onAcknowledge, onDismiss }) {
  const colors = getSeverityColor(alert.severity);
  
  const Icon = alert.severity === 'critical' ? ShieldAlert : 
               alert.severity === 'warning' ? AlertTriangle : Info;

  return (
    <Card className={cn(
      "relative overflow-hidden transition-all duration-200",
      !alert.read ? `border-l-4 ${colors.border} shadow-md` : "opacity-70 shadow-sm border-l-4 border-l-transparent"
    )}>
      <div className="p-4">
        <div className="flex items-start gap-3">
          <div className={cn("mt-0.5 p-1.5 rounded-full", colors.bg)}>
            <Icon className={cn("w-4 h-4", colors.icon)} />
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="text-sm font-semibold text-foreground truncate">
                {alert.entityName}
              </span>
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {formatDistanceToNow(alert.timestamp, { addSuffix: true })}
              </span>
            </div>
            
            <p className="text-sm text-foreground mb-2 leading-snug">
              {alert.message}
            </p>
            
            {alert.suggestedAction && (
              <p className="text-xs font-medium text-muted-foreground bg-muted/50 p-2 rounded-md mb-3">
                Action: {alert.suggestedAction}
              </p>
            )}
            
            <div className="flex items-center gap-2 mt-2">
              {!alert.read && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-7 text-xs"
                  onClick={() => onAcknowledge(alert.id)}
                >
                  <Check className="w-3 h-3 mr-1" /> Acknowledge
                </Button>
              )}
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-7 text-xs text-muted-foreground hover:text-destructive"
                onClick={() => onDismiss(alert.id)}
              >
                <X className="w-3 h-3 mr-1" /> Dismiss
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
