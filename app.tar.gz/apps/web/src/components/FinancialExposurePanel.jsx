
import React, { useMemo } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { useContractMonitoring } from '@/hooks/useContractMonitoring.js';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts';
import { DollarSign, TrendingUp, AlertTriangle } from 'lucide-react';

const COLORS = {
  High: 'hsl(var(--destructive))',
  Medium: 'hsl(var(--warning))',
  Low: 'hsl(var(--success))',
  Unknown: 'hsl(var(--muted-foreground))'
};

export default function FinancialExposurePanel() {
  const { contracts, exposureMetrics, exposureTrend } = useContractMonitoring();

  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', notation: 'compact', maximumFractionDigits: 1 }).format(val);
  const formatFullCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);

  const exposureByRisk = useMemo(() => {
    const data = { High: 0, Medium: 0, Low: 0, Unknown: 0 };
    contracts.forEach(c => {
      const level = c.risk_level || 'Unknown';
      if (data[level] !== undefined) {
        data[level] += (Number(c.contract_value) || 0);
      } else {
        data.Unknown += (Number(c.contract_value) || 0);
      }
    });
    return Object.entries(data).filter(([_, val]) => val > 0).map(([name, value]) => ({ name, value }));
  }, [contracts]);

  const topContracts = useMemo(() => {
    return [...contracts]
      .sort((a, b) => (Number(b.contract_value) || 0) - (Number(a.contract_value) || 0))
      .slice(0, 5);
  }, [contracts]);

  const chartTrendData = useMemo(() => {
    if (!exposureTrend || exposureTrend.length === 0) {
      // Mock some trend data if empty
      return Array.from({length: 7}).map((_, i) => ({
        time: `T-${7-i}`,
        value: exposureMetrics.totalExposure * (0.9 + (Math.random() * 0.2))
      }));
    }
    return exposureTrend.map((t, i) => ({
      time: new Date(t.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}),
      value: t.value
    }));
  }, [exposureTrend, exposureMetrics.totalExposure]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Summary Cards */}
      <div className="lg:col-span-1 space-y-4">
        <Card className="p-5 bg-card border-border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">Total Exposure</span>
            <div className="p-2 bg-primary/10 rounded-lg"><DollarSign className="w-4 h-4 text-primary" /></div>
          </div>
          <div className="text-3xl font-bold text-foreground">{formatCurrency(exposureMetrics.totalExposure)}</div>
          <p className="text-xs text-muted-foreground mt-1">Across {contracts.length} active contracts</p>
        </Card>

        <Card className="p-5 bg-card border-border">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">Average per Contract</span>
            <div className="p-2 bg-secondary rounded-lg"><TrendingUp className="w-4 h-4 text-secondary-foreground" /></div>
          </div>
          <div className="text-2xl font-bold text-foreground">{formatCurrency(exposureMetrics.averageExposure)}</div>
        </Card>

        <Card className="p-5 bg-card border-border border-l-4 border-l-destructive">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-muted-foreground">Highest Exposure</span>
            <div className="p-2 bg-destructive/10 rounded-lg"><AlertTriangle className="w-4 h-4 text-destructive" /></div>
          </div>
          <div className="text-xl font-bold text-foreground line-clamp-1" title={exposureMetrics.highestExposure?.asset_name}>
            {exposureMetrics.highestExposure?.asset_name || 'N/A'}
          </div>
          <div className="text-sm font-medium text-destructive mt-1">
            {formatFullCurrency(exposureMetrics.highestExposure?.contract_value || 0)}
          </div>
        </Card>
      </div>

      {/* Charts */}
      <Card className="lg:col-span-2 p-5 bg-card border-border flex flex-col">
        <h3 className="text-lg font-bold text-foreground mb-4">Exposure Distribution & Trend</h3>
        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 min-h-[250px]">
          
          {/* Pie Chart */}
          <div className="flex flex-col items-center justify-center">
            <h4 className="text-sm font-medium text-muted-foreground mb-2 self-start">By Risk Level</h4>
            <div className="w-full h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={exposureByRisk}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {exposureByRisk.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[entry.name] || COLORS.Unknown} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    formatter={(value) => formatCurrency(value)}
                    contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', backgroundColor: 'hsl(var(--card))', color: 'hsl(var(--foreground))' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex gap-4 mt-2">
              {exposureByRisk.map(entry => (
                <div key={entry.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[entry.name] }} />
                  {entry.name}
                </div>
              ))}
            </div>
          </div>

          {/* Line Chart */}
          <div className="flex flex-col">
            <h4 className="text-sm font-medium text-muted-foreground mb-2">Exposure Trend</h4>
            <div className="w-full h-[200px] mt-auto">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false}
                    tickFormatter={(val) => `$${(val/1000000).toFixed(1)}M`}
                    width={50}
                  />
                  <RechartsTooltip 
                    formatter={(value) => formatCurrency(value)}
                    contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', backgroundColor: 'hsl(var(--card))', color: 'hsl(var(--foreground))' }}
                  />
                  <Line type="monotone" dataKey="value" stroke="hsl(var(--primary))" strokeWidth={3} dot={false} activeDot={{ r: 6, fill: 'hsl(var(--primary))' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>
      </Card>
    </div>
  );
}
