
import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';
import { Search, Clock, CheckCircle2, XCircle, ChevronDown, ShieldCheck, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils.js';
import { ACTION_STATUS } from '@/lib/ActionableAIEngine.js';
import { AuditLogger } from '@/lib/AuditLogger.js';

export default function AuditLogPanel({ logs, onClear }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [expandedId, setExpandedId] = useState(null);

  const filteredLogs = AuditLogger.filterLogs(logs, {
    status: statusFilter,
    type: typeFilter,
    search: searchTerm
  });

  const getStatusIcon = (status) => {
    switch (status) {
      case ACTION_STATUS.COMPLETED: return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
      case ACTION_STATUS.FAILED: return <XCircle className="w-4 h-4 text-destructive" />;
      case ACTION_STATUS.CANCELLED: return <XCircle className="w-4 h-4 text-muted-foreground" />;
      default: return <Clock className="w-4 h-4 text-amber-500" />;
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search audit logs..."
            className="pl-9 bg-background"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[140px] bg-background">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Status</SelectItem>
            <SelectItem value={ACTION_STATUS.COMPLETED}>Completed</SelectItem>
            <SelectItem value={ACTION_STATUS.FAILED}>Failed</SelectItem>
            <SelectItem value={ACTION_STATUS.CANCELLED}>Cancelled</SelectItem>
          </SelectContent>
        </Select>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full sm:w-[140px] bg-background">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Types</SelectItem>
            <SelectItem value="USER">User</SelectItem>
            <SelectItem value="CONTRACT">Contract</SelectItem>
            <SelectItem value="FLEET">Fleet</SelectItem>
            <SelectItem value="FINANCIAL">Financial</SelectItem>
            <SelectItem value="SYSTEM">System</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center justify-between px-1">
        <p className="text-xs text-muted-foreground font-medium">
          Showing {filteredLogs.length} records
        </p>
        {logs.length > 0 && (
          <Button variant="ghost" size="sm" onClick={onClear} className="h-7 text-xs text-destructive hover:text-destructive hover:bg-destructive/10">
            <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Clear Logs
          </Button>
        )}
      </div>

      <div className="space-y-2">
        {filteredLogs.length === 0 ? (
          <div className="p-8 text-center border border-dashed border-border rounded-xl bg-card">
            <ShieldCheck className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-50" />
            <p className="text-sm font-medium text-foreground">No audit records found</p>
            <p className="text-xs text-muted-foreground mt-1">Adjust your filters or execute actions to generate logs.</p>
          </div>
        ) : (
          filteredLogs.map(log => (
            <Collapsible 
              key={log.id} 
              open={expandedId === log.id} 
              onOpenChange={(isOpen) => setExpandedId(isOpen ? log.id : null)}
              className="border border-border rounded-lg bg-card overflow-hidden"
            >
              <CollapsibleTrigger className="w-full flex items-center justify-between p-3 hover:bg-muted/50 transition-colors text-left">
                <div className="flex items-center gap-3 overflow-hidden">
                  {getStatusIcon(log.status)}
                  <div className="truncate">
                    <p className="text-sm font-semibold text-foreground truncate">{log.actionTitle}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-2 mt-0.5">
                      <span>{format(log.timestamp, 'MMM d, HH:mm:ss')}</span>
                      <span className="w-1 h-1 rounded-full bg-border" />
                      <span className="uppercase tracking-wider">{log.category}</span>
                    </p>
                  </div>
                </div>
                <ChevronDown className={cn("w-4 h-4 text-muted-foreground transition-transform", expandedId === log.id && "rotate-180")} />
              </CollapsibleTrigger>
              
              <CollapsibleContent className="p-4 pt-0 border-t border-border/50 bg-muted/10">
                <div className="grid grid-cols-2 gap-4 mt-4 text-xs">
                  <div>
                    <p className="font-bold text-muted-foreground uppercase tracking-wider mb-1">Action ID</p>
                    <p className="font-mono text-foreground">{log.actionId}</p>
                  </div>
                  <div>
                    <p className="font-bold text-muted-foreground uppercase tracking-wider mb-1">Initiated By</p>
                    <p className="text-foreground">{log.initiatedBy}</p>
                  </div>
                  <div>
                    <p className="font-bold text-muted-foreground uppercase tracking-wider mb-1">Approved By</p>
                    <p className="text-foreground">{log.approvedBy || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="font-bold text-muted-foreground uppercase tracking-wider mb-1">Affected Entities</p>
                    <p className="text-foreground">{log.affectedEntities}</p>
                  </div>
                  <div className="col-span-2 p-3 rounded bg-background border border-border">
                    <p className="font-bold text-muted-foreground uppercase tracking-wider mb-1">Result Details</p>
                    <p className="text-foreground leading-relaxed">{log.result?.message || 'No details available.'}</p>
                    {log.result?.durationMs && (
                      <p className="text-muted-foreground mt-1">Execution time: {log.result.durationMs}ms</p>
                    )}
                  </div>
                </div>
              </CollapsibleContent>
            </Collapsible>
          ))
        )}
      </div>
    </div>
  );
}
