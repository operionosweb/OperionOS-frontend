import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'Q1', efficiency: 65, cost: 85 },
  { name: 'Q2', efficiency: 75, cost: 70 },
  { name: 'Q3', efficiency: 85, cost: 55 },
  { name: 'Q4', efficiency: 95, cost: 40 },
];

const MetricsSection = () => {
  return (
    <section className="py-24 bg-secondary text-secondary-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">Quantifiable Operational Excellence</h2>
            <p className="text-xl text-secondary-foreground/70 mb-12">
              Measurable impact across your entire logistics chain.
            </p>
            
            <div className="space-y-10">
              <div>
                <div className="text-5xl md:text-6xl font-bold text-[hsl(var(--tertiary))] mb-2" style={{ fontVariantNumeric: 'tabular-nums' }}>
                  24%
                </div>
                <div className="text-sm font-bold text-secondary-foreground/80 uppercase tracking-wider">
                  Logistics Cost Reduction
                </div>
              </div>
              
              <div>
                <div className="text-5xl md:text-6xl font-bold text-primary mb-2" style={{ fontVariantNumeric: 'tabular-nums' }}>
                  4.2x
                </div>
                <div className="text-sm font-bold text-secondary-foreground/80 uppercase tracking-wider">
                  Faster Re-Planning
                </div>
              </div>
            </div>
          </div>
          
          <div className="hidden lg:block h-[400px] w-full bg-secondary-foreground/5 rounded-2xl p-6 border border-white/10">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
                <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" tick={{ fill: 'rgba(255,255,255,0.5)' }} axisLine={false} tickLine={false} />
                <YAxis stroke="rgba(255,255,255,0.5)" tick={{ fill: 'rgba(255,255,255,0.5)' }} axisLine={false} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                  contentStyle={{ backgroundColor: '#0A192F', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
                />
                <Bar dataKey="efficiency" name="Efficiency" radius={[4, 4, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="hsl(211 100% 49%)" />
                  ))}
                </Bar>
                <Bar dataKey="cost" name="Cost" radius={[4, 4, 0, 0]}>
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="hsl(160 84% 60%)" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MetricsSection;