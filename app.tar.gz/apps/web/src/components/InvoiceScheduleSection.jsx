
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Card } from '@/components/ui/card.jsx';
import { format, parseISO } from 'date-fns';
import { cn } from '@/lib/utils.js';

export default function InvoiceScheduleSection({ invoiceSchedule, cashFlowMetrics, currency = 'USD' }) {
  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(val);

  const getStatusColor = (status) => {
    switch (status) {
      case 'paid': return 'bg-success/10 text-success border-success/20';
      case 'overdue': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-warning/10 text-warning-foreground border-warning/20';
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-3 bg-muted/30 border-border">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total Invoices</p>
          <p className="text-lg font-bold text-foreground">{cashFlowMetrics.totalInvoices}</p>
        </Card>
        <Card className="p-3 bg-success/5 border-success/20">
          <p className="text-xs text-success uppercase tracking-wider mb-1">Paid</p>
          <p className="text-lg font-bold text-success">{formatCurrency(cashFlowMetrics.totalPaidAmount)}</p>
          <p className="text-xs text-success/80">{cashFlowMetrics.paidInvoices} invoices</p>
        </Card>
        <Card className="p-3 bg-warning/5 border-warning/20">
          <p className="text-xs text-warning-foreground uppercase tracking-wider mb-1">Pending</p>
          <p className="text-lg font-bold text-warning-foreground">{formatCurrency(cashFlowMetrics.totalPendingAmount)}</p>
          <p className="text-xs text-warning-foreground/80">{cashFlowMetrics.pendingInvoices} invoices</p>
        </Card>
        <Card className="p-3 bg-destructive/5 border-destructive/20">
          <p className="text-xs text-destructive uppercase tracking-wider mb-1">Overdue</p>
          <p className="text-lg font-bold text-destructive">{formatCurrency(cashFlowMetrics.totalOverdueAmount)}</p>
          <p className="text-xs text-destructive/80">{cashFlowMetrics.overdueInvoices} invoices</p>
        </Card>
      </div>

      <div className="rounded-xl border border-border overflow-hidden bg-card">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead>Invoice #</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Timeline</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invoiceSchedule.map((inv) => (
              <TableRow key={inv.invoiceId}>
                <TableCell className="font-medium text-foreground">{inv.invoiceNumber}</TableCell>
                <TableCell className="text-muted-foreground">{format(parseISO(inv.dueDate), 'MMM dd, yyyy')}</TableCell>
                <TableCell className="text-right font-medium text-foreground">{formatCurrency(inv.amount)}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={cn("capitalize", getStatusColor(inv.status))}>
                    {inv.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right text-sm text-muted-foreground">
                  {inv.status === 'paid' ? 'Paid' : 
                   inv.daysUntilDue < 0 ? `${Math.abs(inv.daysUntilDue)} days late` : 
                   `In ${inv.daysUntilDue} days`}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
