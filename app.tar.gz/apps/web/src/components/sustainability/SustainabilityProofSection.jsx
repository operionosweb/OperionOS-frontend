import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { BarChart3, Users, Fuel } from 'lucide-react';

const SustainabilityProofSection = () => {
  const insights = [
    {
      icon: BarChart3,
      stat: '12–22%',
      text: 'Fleet operators using optimized scheduling can reduce operational inefficiencies by 12–22%.'
    },
    {
      icon: Users,
      stat: '18–28%',
      text: 'AI-driven crew management reduces crew-related travel and accommodation costs by 18–28%.'
    },
    {
      icon: Fuel,
      stat: '15–20%',
      text: 'Route optimization combined with real-time monitoring reduces fuel consumption by 15–20%.'
    }
  ];

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1679830238737-5bc41f101bbb?q=80&w=2070&auto=format&fit=crop" 
          alt="Sustainable operations" 
          className="w-full h-full object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-background/95 backdrop-blur-sm"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Proven Operational Impact</h2>
          <p className="text-lg text-muted-foreground">
            Real-world results from maritime and aviation operators using Operion to drive efficiency and sustainability.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {insights.map((insight, index) => (
            <div key={index} className="flex flex-col p-8 rounded-3xl bg-card border border-border shadow-sm hover:shadow-md transition-shadow">
              <div className="p-3 bg-primary/10 text-primary rounded-xl w-fit mb-6">
                <insight.icon className="w-6 h-6" />
              </div>
              <div className="text-5xl font-extrabold text-foreground mb-4 tracking-tighter">
                {insight.stat}
              </div>
              <p className="text-base text-foreground font-medium mb-6 flex-grow">
                {insight.text}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button asChild variant="outline" size="lg" className="rounded-full px-8">
            <Link to="/features">View Platform Features</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default SustainabilityProofSection;