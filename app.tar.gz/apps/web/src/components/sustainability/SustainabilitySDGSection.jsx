import React from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip.jsx';
import { Globe, Zap, Recycle, CloudRain, Anchor, HeartHandshake as Handshake } from 'lucide-react';

const SustainabilitySDGSection = () => {
  const sdgs = [
    {
      id: 9,
      name: 'Industry, Innovation & Infrastructure',
      icon: Zap,
      color: 'bg-orange-500',
      contribution: 'AI-powered innovation in legacy maritime and aviation systems.',
      impact: 'Modernizing infrastructure through digital transformation and predictive analytics.'
    },
    {
      id: 8,
      name: 'Decent Work & Economic Growth',
      icon: Globe,
      color: 'bg-red-800',
      contribution: 'Optimizing crew schedules to prevent fatigue and ensure fair rotations.',
      impact: 'Improving working conditions while driving economic efficiency for operators.'
    },
    {
      id: 12,
      name: 'Responsible Consumption',
      icon: Recycle,
      color: 'bg-amber-600',
      contribution: 'Eliminating redundant travel and optimizing resource allocation.',
      impact: 'Reducing operational waste in global logistics chains.'
    },
    {
      id: 13,
      name: 'Climate Action',
      icon: CloudRain,
      color: 'bg-green-700',
      contribution: 'Direct reduction of fuel consumption through route and schedule optimization.',
      impact: 'Measurable decrease in Scope 1 and Scope 3 emissions.'
    },
    {
      id: 14,
      name: 'Life Below Water',
      icon: Anchor,
      color: 'bg-blue-600',
      contribution: 'Enhancing maritime operational efficiency to reduce ocean transit times.',
      impact: 'Lowering the environmental footprint of global shipping fleets.'
    },
    {
      id: 17,
      name: 'Partnerships for the Goals',
      icon: Handshake,
      color: 'bg-indigo-800',
      contribution: 'Connecting disparate systems and stakeholders across the supply chain.',
      impact: 'Fostering data-sharing and collaborative efficiency across industries.'
    }
  ];

  return (
    <section className="py-24 bg-background overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Alignment with UN SDGs</h2>
          <p className="text-lg text-muted-foreground">
            Operion's technology directly supports the United Nations Sustainable Development Goals by embedding efficiency into the core of global operations.
          </p>
        </div>

        {/* Desktop Concentric Layout */}
        <div className="hidden lg:flex relative justify-center items-center min-h-[500px] max-w-4xl mx-auto">
          {/* Outer Ring (SDGs) */}
          <div className="absolute inset-0 rounded-full border border-dashed border-border/60 animate-[spin_120s_linear_infinite]"></div>
          
          {/* Middle Ring (Benefits) */}
          <div className="absolute w-[350px] h-[350px] rounded-full border border-primary/20 bg-primary/5 flex items-center justify-center">
            <div className="absolute -top-4 bg-background px-3 text-sm font-medium text-primary">Cost Reduction</div>
            <div className="absolute -bottom-4 bg-background px-3 text-sm font-medium text-primary">Efficiency Gains</div>
            <div className="absolute -left-12 top-1/2 -translate-y-1/2 bg-background px-3 text-sm font-medium text-primary">Workforce Optimization</div>
          </div>

          {/* Center Circle */}
          <div className="relative z-10 w-40 h-40 rounded-full bg-primary text-primary-foreground flex flex-col items-center justify-center shadow-xl shadow-primary/20">
            <span className="font-bold text-xl">Operion</span>
            <span className="text-xs opacity-80">Platform</span>
          </div>

          {/* SDG Nodes */}
          <TooltipProvider delayDuration={200}>
            {sdgs.map((sdg, index) => {
              const angle = (index * 360) / sdgs.length;
              const radius = 250; // Distance from center
              const x = Math.cos((angle * Math.PI) / 180) * radius;
              const y = Math.sin((angle * Math.PI) / 180) * radius;

              return (
                <Tooltip key={sdg.id}>
                  <TooltipTrigger asChild>
                    <div 
                      className="absolute z-20 flex flex-col items-center justify-center cursor-help transition-transform hover:scale-110"
                      style={{ transform: `translate(${x}px, ${y}px)` }}
                    >
                      <div className={`w-16 h-16 rounded-xl ${sdg.color} text-white flex items-center justify-center shadow-lg mb-2`}>
                        <sdg.icon className="w-8 h-8" />
                      </div>
                      <span className="text-xs font-bold bg-background/80 backdrop-blur-sm px-2 py-1 rounded border border-border">
                        SDG {sdg.id}
                      </span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent side="top" className="max-w-xs p-4">
                    <div className="font-bold text-sm mb-1">SDG {sdg.id}: {sdg.name}</div>
                    <div className="text-xs text-muted-foreground mb-2">{sdg.contribution}</div>
                    <div className="text-xs font-medium text-primary bg-primary/10 p-2 rounded">
                      Impact: {sdg.impact}
                    </div>
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </TooltipProvider>
        </div>

        {/* Mobile/Tablet Grid Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:hidden">
          {sdgs.map((sdg) => (
            <div key={sdg.id} className="flex items-start gap-4 p-4 rounded-xl border border-border bg-card">
              <div className={`shrink-0 w-12 h-12 rounded-lg ${sdg.color} text-white flex items-center justify-center`}>
                <sdg.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-sm mb-1">SDG {sdg.id}: {sdg.name}</h3>
                <p className="text-xs text-muted-foreground mb-2">{sdg.contribution}</p>
                <p className="text-xs font-medium text-primary">{sdg.impact}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SustainabilitySDGSection;