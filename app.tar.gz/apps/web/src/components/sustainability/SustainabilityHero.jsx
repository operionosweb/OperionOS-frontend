import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { motion } from 'framer-motion';
import { ArrowRight, Activity, Leaf } from 'lucide-react';

const SustainabilityHero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden bg-slate-950">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1698666348132-fa9121fd6d19?q=80&w=2070&auto=format&fit=crop" 
          alt="Abstract representation of sustainable maritime and aviation operations" 
          className="w-full h-full object-cover opacity-40 mix-blend-luminosity"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-teal-900/40"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full py-12 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          
          {/* Left Content */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col items-start text-left"
          >
            <div className="inline-flex items-center gap-2 rounded-full border border-teal-500/30 bg-teal-500/10 px-3 py-1 text-sm font-medium text-teal-300 mb-6">
              <Leaf className="w-4 h-4" />
              <span>ESG & Operational Excellence</span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight text-white mb-6 text-balance leading-tight">
              Efficiency That Drives <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-400">Sustainability</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-8 max-w-xl leading-relaxed text-balance">
              Operion transforms operational performance into measurable environmental and economic impact. Our operational intelligence platform optimizes maritime and aviation logistics to reduce emissions, eliminate waste, and support your ESG goals.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <Button asChild size="lg" className="bg-teal-500 text-slate-950 hover:bg-teal-400 rounded-full px-8 h-14 text-base font-semibold transition-all w-full sm:w-auto group">
                <Link to="/demo/maritime">
                  Explore Maritime Demo
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-full px-8 h-14 text-base font-semibold border-slate-600 text-slate-900 hover:bg-slate-800 hover:text-slate-900 transition-all w-full sm:w-auto">
                <Link to="/demo/aviation">Explore Aviation Demo</Link>
              </Button>
            </div>
          </motion.div>

          {/* Right Visual */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden md:block"
          >
            <div className="relative rounded-2xl border border-slate-700/50 bg-slate-900/50 backdrop-blur-xl p-6 shadow-2xl shadow-teal-900/20">
              <div className="flex items-center justify-between mb-6 border-b border-slate-700/50 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-teal-500/20 rounded-lg">
                    <Activity className="w-5 h-5 text-teal-400" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-slate-200">Live Fleet Optimization</div>
                    <div className="text-xs text-slate-400">Global Operations</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-teal-500"></span>
                  </span>
                  <span className="text-xs font-medium text-teal-400">Active</span>
                </div>
              </div>
              
              <div className="space-y-4">
                {[
                  { label: 'Fuel Consumption Variance', value: '-18.4%', color: 'text-teal-400', bg: 'bg-teal-400/20' },
                  { label: 'Crew Routing Efficiency', value: '+22.1%', color: 'text-blue-400', bg: 'bg-blue-400/20' },
                  { label: 'Idle Time Reduction', value: '-15.3%', color: 'text-emerald-400', bg: 'bg-emerald-400/20' }
                ].map((stat, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50 border border-slate-700/50">
                    <span className="text-sm text-slate-300">{stat.label}</span>
                    <span className={`text-sm font-bold px-2 py-1 rounded-md ${stat.bg} ${stat.color}`}>
                      {stat.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default SustainabilityHero;