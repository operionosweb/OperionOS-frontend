import React from 'react';
import { Ship, Plane, Droplets, Wind, Users, Clock, ShieldAlert, Recycle } from 'lucide-react';

const SustainabilityIndustryImpact = () => {
  const maritimeImpacts = [
    { icon: Droplets, title: 'Fuel Efficiency', desc: 'Optimized port arrivals reduce loitering and fuel burn.', metric: '10-15% less fuel' },
    { icon: Ship, title: 'Route Optimization', desc: 'Weather and current-aware routing for minimal resistance.', metric: 'Shorter transit times' },
    { icon: Users, title: 'Crew Scheduling', desc: 'Consolidated crew changes reduce international flights.', metric: '20% fewer flights' },
    { icon: ShieldAlert, title: 'Environmental Compliance', desc: 'Automated tracking of emission control areas (ECAs).', metric: '100% compliance' }
  ];

  const aviationImpacts = [
    { icon: Users, title: 'Crew Optimization', desc: 'Efficient pairings reduce deadheading and positioning flights.', metric: '15% less deadheading' },
    { icon: Clock, title: 'Reduced Delays', desc: 'Predictive disruption management prevents cascading delays.', metric: 'Higher on-time performance' },
    { icon: Recycle, title: 'Lower Operational Waste', desc: 'Precise catering and resource planning based on actual loads.', metric: 'Reduced cabin waste' },
    { icon: Wind, title: 'Scheduling Efficiency', desc: 'Optimized ground times reduce APU (Auxiliary Power Unit) usage.', metric: 'Lower ground emissions' }
  ];

  return (
    <section className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Industry-Specific Impact</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Tailored operational intelligence that addresses the unique sustainability challenges of maritime and aviation sectors.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          
          {/* Maritime Column */}
          <div className="rounded-3xl bg-slate-900 p-8 border border-slate-800 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-8">
                <div className="p-3 bg-blue-500/20 rounded-xl">
                  <Ship className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-2xl font-bold text-white">Maritime Efficiency</h3>
              </div>
              
              <div className="space-y-6">
                {maritimeImpacts.map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1 p-2 bg-slate-800 rounded-lg shrink-0 h-fit">
                      <item.icon className="w-5 h-5 text-blue-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-200 text-lg">{item.title}</h4>
                      <p className="text-slate-400 text-sm mt-1 mb-2">{item.desc}</p>
                      <span className="inline-block px-2 py-1 bg-blue-500/10 text-blue-300 text-xs font-medium rounded">
                        {item.metric}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Aviation Column */}
          <div className="rounded-3xl bg-teal-950 p-8 border border-teal-900 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-8">
                <div className="p-3 bg-teal-500/20 rounded-xl">
                  <Plane className="w-8 h-8 text-teal-400" />
                </div>
                <h3 className="text-2xl font-bold text-white">Aviation Sustainability</h3>
              </div>
              
              <div className="space-y-6">
                {aviationImpacts.map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1 p-2 bg-teal-900 rounded-lg shrink-0 h-fit">
                      <item.icon className="w-5 h-5 text-teal-400" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-teal-100 text-lg">{item.title}</h4>
                      <p className="text-teal-300/70 text-sm mt-1 mb-2">{item.desc}</p>
                      <span className="inline-block px-2 py-1 bg-teal-500/20 text-teal-300 text-xs font-medium rounded">
                        {item.metric}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default SustainabilityIndustryImpact;