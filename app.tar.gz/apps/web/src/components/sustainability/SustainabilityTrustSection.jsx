import React from 'react';
import { Database, LineChart, ShieldCheck } from 'lucide-react';

const SustainabilityTrustSection = () => {
  const badges = [
    {
      icon: Database,
      title: 'Data-Driven',
      description: 'Decisions backed by real-time operational intelligence.'
    },
    {
      icon: LineChart,
      title: 'Measurable Impact',
      description: 'Quantifiable reductions in emissions and resource waste.'
    },
    {
      icon: ShieldCheck,
      title: 'Enterprise-Ready',
      description: 'Built for global maritime and aviation compliance standards.'
    }
  ];

  return (
    <section className="py-16 bg-background border-b border-border/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4 text-balance">
            Sustainability Through Operational Excellence
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            We believe that true sustainability isn't just about reporting—it's about fundamentally improving how operations run. Operion aligns with UN SDGs and global ESG standards by eliminating the inefficiencies that drive excess emissions and waste.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {badges.map((badge, index) => (
            <div 
              key={index} 
              className="flex flex-col items-center text-center p-6 rounded-2xl bg-muted/30 border border-border/50 hover:bg-muted/50 transition-colors"
            >
              <div className="p-3 bg-primary/10 text-primary rounded-xl mb-4">
                <badge.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{badge.title}</h3>
              <p className="text-sm text-muted-foreground">{badge.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SustainabilityTrustSection;