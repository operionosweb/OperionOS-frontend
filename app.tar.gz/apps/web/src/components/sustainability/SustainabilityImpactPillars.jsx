import React from 'react';
import { Gauge, Leaf, Recycle, Users } from 'lucide-react';
import { Card } from '@/components/ui/card.jsx';

const SustainabilityImpactPillars = () => {
  const pillars = [
    {
      icon: Gauge,
      title: 'Operational Efficiency',
      metric: 'Up to 22% improvement',
      details: 'Through AI-driven scheduling and real-time optimization of complex logistics networks.',
      color: 'text-blue-600',
      bg: 'bg-blue-500/10',
      border: 'hover:border-blue-500/30'
    },
    {
      icon: Leaf,
      title: 'Emissions Reduction',
      metric: 'Up to 18% reduction',
      details: 'Through route optimization, reduced idle times, and scheduling efficiency that lowers fuel consumption.',
      color: 'text-emerald-600',
      bg: 'bg-emerald-500/10',
      border: 'hover:border-emerald-500/30'
    },
    {
      icon: Recycle,
      title: 'Resource Optimization',
      metric: 'Up to 25% less waste',
      details: 'Through optimized crew rotations, precise accommodation planning, and elimination of redundant travel.',
      color: 'text-teal-600',
      bg: 'bg-teal-500/10',
      border: 'hover:border-teal-500/30'
    },
    {
      icon: Users,
      title: 'Workforce Optimization',
      metric: 'Up to 30% better utilization',
      details: 'Through intelligent scheduling, fatigue management, and equitable workload balancing across fleets.',
      color: 'text-indigo-600',
      bg: 'bg-indigo-500/10',
      border: 'hover:border-indigo-500/30'
    }
  ];

  return (
    <section className="py-20 bg-muted/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Core Impact Pillars</h2>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Our platform targets four critical areas where operational efficiency directly translates to environmental and social governance (ESG) outcomes.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((pillar, index) => (
            <Card 
              key={index} 
              className={`p-6 flex flex-col h-full transition-all duration-300 hover:-translate-y-1 hover:shadow-lg border-border/60 ${pillar.border}`}
            >
              <div className={`p-3 rounded-xl w-fit mb-6 ${pillar.bg} ${pillar.color}`}>
                <pillar.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">{pillar.title}</h3>
              <div className="text-2xl font-bold text-foreground mb-3 tracking-tight">
                {pillar.metric}
              </div>
              <p className="text-sm text-muted-foreground mt-auto leading-relaxed">
                {pillar.details}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SustainabilityImpactPillars;