import React from 'react';
import { Settings, TrendingDown, Zap, Leaf, Trophy, ArrowRight } from 'lucide-react';

const SustainabilityROItoESG = () => {
  const steps = [
    { icon: Settings, title: 'Operational Optimization', desc: 'AI streamlines scheduling and routing.', color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { icon: TrendingDown, title: 'Cost Reduction', desc: 'Fewer redundant flights and hotel stays.', color: 'text-cyan-500', bg: 'bg-cyan-500/10' },
    { icon: Zap, title: 'Efficiency Gains', desc: 'Maximized asset and crew utilization.', color: 'text-teal-500', bg: 'bg-teal-500/10' },
    { icon: Leaf, title: 'Emissions Reduction', desc: 'Lower fuel burn and carbon footprint.', color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { icon: Trophy, title: 'ESG Value', desc: 'Measurable sustainability reporting.', color: 'text-green-600', bg: 'bg-green-600/10' }
  ];

  return (
    <section className="py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Left Content */}
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
              From ROI to ESG: The Operational Sustainability Bridge
            </h2>
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                Sustainability in heavy industries doesn't require sacrificing profitability. In fact, the most effective environmental strategies are rooted in rigorous operational efficiency.
              </p>
              <p>
                When Operion optimizes a crew rotation or a flight schedule, the immediate result is a reduction in operational costs (ROI). However, that same optimization—eliminating an unnecessary positioning flight, reducing idle hotel days, or finding a more direct route—directly translates to fewer carbon emissions and less resource waste (ESG).
              </p>
              <p>
                By bridging the gap between financial performance and environmental responsibility, Operion turns your operational data into a competitive sustainability advantage.
              </p>
            </div>
          </div>

          {/* Right Visual Flow */}
          <div className="relative">
            {/* Background Image */}
            <div className="absolute inset-0 rounded-3xl overflow-hidden opacity-20 mix-blend-luminosity">
              <img 
                src="https://images.unsplash.com/photo-1610442620503-424f77eaa141?q=80&w=2070&auto=format&fit=crop" 
                alt="Aviation operations" 
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="relative z-10 flex flex-col gap-4 p-6 sm:p-8 bg-background/80 backdrop-blur-xl rounded-3xl border border-border shadow-xl">
              {steps.map((step, index) => (
                <div key={index} className="relative">
                  <div className="flex items-center gap-4 p-4 rounded-xl bg-card border border-border/50 shadow-sm hover:shadow-md transition-shadow">
                    <div className={`p-3 rounded-lg shrink-0 ${step.bg} ${step.color}`}>
                      <step.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-foreground">{step.title}</h4>
                      <p className="text-sm text-muted-foreground">{step.desc}</p>
                    </div>
                  </div>
                  {/* Connector Arrow */}
                  {index < steps.length - 1 && (
                    <div className="absolute -bottom-5 left-9 z-10 text-muted-foreground/50">
                      <ArrowRight className="w-5 h-5 rotate-90" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default SustainabilityROItoESG;