import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';

const SustainabilityCTASection = () => {
  return (
    <section className="py-24 bg-primary/5 border-t border-primary/10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6 tracking-tight text-balance">
          Turn Efficiency Into Competitive Advantage
        </h2>
        <p className="text-xl text-muted-foreground mb-10 leading-relaxed text-balance">
          Experience how Operion transforms operational performance into measurable sustainability outcomes for your fleet.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 h-14 text-lg font-semibold transition-all">
            <Link to="/demo/aviation">Launch Mission Control</Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="rounded-full px-8 h-14 text-lg font-semibold bg-background hover:bg-muted transition-all">
            <Link to="/features">View Live Demo</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default SustainabilityCTASection;