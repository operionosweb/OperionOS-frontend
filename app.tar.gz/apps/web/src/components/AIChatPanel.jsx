
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Sparkles, ChevronRight } from 'lucide-react';
import { useAIResponse } from '@/hooks/useAIResponse.js';
import { buildAISystemPrompt } from '@/lib/aiPositioning.js';
import { cn } from '@/lib/utils.js';

const SUGGESTED_PROMPTS = [
  "How do I create a movement?",
  "Show crew status",
  "What's my compliance score?",
  "Help with fleet management"
];

export default function AIChatPanel({ isOpen, onClose, title = "Operion AI", roleContext = "viewer" }) {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  
  const { fetchResponse, loading } = useAIResponse();

  useEffect(() => {
    if (isOpen && inputRef.current) inputRef.current.focus();
  }, [isOpen]);

  useEffect(() => {
    if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  useEffect(() => {
    const handleEsc = (e) => { if (e.key === 'Escape' && isOpen) onClose(); };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [isOpen, onClose]);

  const handleSend = async (text = inputValue) => {
    const trimmedMessage = text.trim();
    if (!trimmedMessage || loading) return;

    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: trimmedMessage }]);
    setInputValue('');

    // In a real implementation, we would pass the system prompt to the backend
    const systemPrompt = buildAISystemPrompt(roleContext);
    
    // For now, we just use the existing fetchResponse
    const response = await fetchResponse(trimmedMessage);
    if (response) {
      setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'assistant', content: response }]);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-[80px] right-5 w-[360px] h-[500px] bg-card border border-border rounded-[12px] shadow-[0_10px_40px_rgba(0,0,0,0.2)] flex flex-col z-50 animate-in fade-in slide-in-from-bottom-4 duration-300 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-card">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <span className="font-bold text-[15px] text-foreground tracking-tight">{title}</span>
        </div>
        <button onClick={onClose} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted rounded-full transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 bg-card hide-scrollbar">
        {messages.length === 0 && (
          <div className="flex flex-col gap-4 h-full">
            <div className="bg-muted/50 rounded-lg p-4 text-sm text-foreground leading-relaxed border border-border">
              <span className="font-semibold block mb-1">Hi there.</span>
              I'm your {title} assistant. How can I help you today?
            </div>
            
            <div className="mt-auto space-y-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Suggested</p>
              {SUGGESTED_PROMPTS.map((prompt, idx) => (
                <button 
                  key={idx} 
                  onClick={() => handleSend(prompt)}
                  className="w-full text-left p-2.5 rounded-[8px] bg-card border border-border text-sm text-foreground hover:border-primary hover:text-primary transition-colors flex items-center justify-between group"
                >
                  {prompt}
                  <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              ))}
            </div>
          </div>
        )}
        
        {messages.map((msg) => (
          <div key={msg.id} className={cn("flex flex-col max-w-[85%]", msg.role === 'user' ? "self-end items-end" : "self-start items-start")}>
            <div className={cn(
              "rounded-[12px] px-4 py-2.5 text-[14px] leading-relaxed",
              msg.role === 'user' ? "bg-primary text-primary-foreground rounded-br-sm" : "bg-muted text-foreground rounded-bl-sm"
            )}>
              {msg.content}
            </div>
          </div>
        ))}
        
        {loading && (
          <div className="self-start bg-muted rounded-[12px] rounded-bl-sm px-4 py-3">
            <div className="flex gap-1 items-center h-4">
              <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} className="h-1" />
      </div>

      <div className="p-3 border-t border-border bg-card">
        <div className="flex items-end gap-2 bg-muted/30 border border-border rounded-[8px] p-1 pr-2 focus-within:ring-2 focus-within:ring-primary focus-within:border-transparent transition-all">
          <textarea
            ref={inputRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask me anything..."
            className="w-full bg-transparent border-none focus:ring-0 resize-none max-h-24 min-h-[36px] py-2 px-3 text-sm text-foreground placeholder:text-muted-foreground hide-scrollbar"
            rows={1}
            disabled={loading}
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputValue.trim() || loading}
            className="mb-0.5 p-1.5 rounded-[6px] bg-primary text-primary-foreground disabled:opacity-50 hover:bg-primary/90 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
