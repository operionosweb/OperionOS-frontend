
import React from 'react';
import { Progress } from '@/components/ui/progress.jsx';
import { cn } from '@/lib/utils.js';

export default function FinancialRiskScore({ riskScores }) {
  const getRiskColor = (score) => {
    if (score >= 70) return 'bg-destructive';
    if (score >= 30) return 'bg-warning';
    return 'bg-success';
  };

  const getRiskTextColor = (score) => {
    if (score >= 70) return 'text-destructive';
    if (score >= 30) return 'text-warning-foreground';
    return 'text-success';
  };

  const metrics = [
    { label: 'Overall Financial Risk', score: riskScores.overallFinancialRisk },
    { label: 'Penalty Exposure Risk', score: riskScores.penaltyRiskScore },
    { label: 'Cash Flow Risk', score: riskScores.cashFlowRiskScore },
    { label: 'Concentration Risk', score: riskScores.exposureRiskScore }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {metrics.map((m, idx) => (
        <div key={idx} className="space-y-2 p-4 rounded-xl border border-border bg-card">
          <div className="flex justify-between items-end">
            <span className="text-sm font-medium text-muted-foreground">{m.label}</span>
            <span className={cn("text-lg font-bold", getRiskTextColor(m.score))}>{m.score}/100</span>
          </div>
          <Progress value={m.score} className="h-2" indicatorClassName={getRiskColor(m.score)} />
        </div>
      ))}
    </div>
  );
}
