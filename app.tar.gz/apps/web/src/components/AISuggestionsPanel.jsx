
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Sparkles, AlertTriangle, Users, PenTool, X } from 'lucide-react';
import { generateSuggestions } from '@/lib/commandCenterHelpers.js';
import { useActionSystem } from './ActionSystem.jsx';

const AISuggestionsPanel = ({ context }) => {
  const [suggestions, setSuggestions] = useState([]);
  const { executeModalAction } = useActionSystem();

  useEffect(() => {
    // Generate suggestions based on context
    const sugs = generateSuggestions(context, {});
    setSuggestions(sugs);
  }, [context]);

  const dismissSuggestion = (id) => {
    setSuggestions(prev => prev.filter(s => s.id !== id));
  };

  const getPriorityColor = (priority) => {
    if (priority === 'HIGH') return 'bg-destructive/10 text-destructive border-destructive/20';
    if (priority === 'MEDIUM') return 'bg-amber-500/10 text-amber-600 dark:text-amber-500 border-amber-500/20';
    return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
  };

  const getIcon = (type) => {
    if (type === 'alert') return <AlertTriangle className="w-4 h-4 text-destructive" />;
    if (type === 'users') return <Users className="w-4 h-4 text-amber-500" />;
    return <PenTool className="w-4 h-4 text-blue-500" />;
  };

  return (
    <Card className="border-border/50 shadow-sm bg-card h-full flex flex-col">
      <CardHeader className="pb-3 border-b border-border/50 bg-primary/5">
        <CardTitle className="text-sm font-bold uppercase tracking-wider flex items-center gap-2 text-foreground">
          <Sparkles className="w-4 h-4 text-primary" /> Copilot Intelligence
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 flex-1 overflow-y-auto">
        {suggestions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-3 py-8">
            <div className="p-3 bg-muted rounded-full">
              <Sparkles className="w-6 h-6 text-muted-foreground opacity-50" />
            </div>
            <p className="text-sm font-medium text-muted-foreground">Operations are nominal.</p>
            <p className="text-xs text-muted-foreground">No active intelligence suggestions.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {suggestions.map(sug => (
              <div key={sug.id} className="relative group p-4 rounded-xl border border-border/50 bg-background hover:border-border transition-colors shadow-sm">
                <button 
                  onClick={() => dismissSuggestion(sug.id)}
                  className="absolute top-2 right-2 p-1 text-muted-foreground hover:bg-muted rounded-md opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
                
                <div className="flex items-start gap-3">
                  <div className="shrink-0 mt-0.5">
                    {getIcon(sug.icon)}
                  </div>
                  <div className="space-y-1.5 flex-1 pr-6">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-foreground leading-none">{sug.title}</h4>
                      <Badge variant="outline" className={`text-[10px] px-1.5 py-0 h-4 font-bold border ${getPriorityColor(sug.priority)}`}>
                        {sug.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed text-balance">
                      {sug.description}
                    </p>
                    <div className="pt-2">
                      <Button 
                        variant="secondary" 
                        size="sm" 
                        className="h-7 text-xs"
                        onClick={() => executeModalAction(sug.actionParams.type, sug.actionParams)}
                      >
                        {sug.actionLabel}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AISuggestionsPanel;
