
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { AlertTriangle, ShieldCheck, Zap, ArrowRight, CheckCircle2, Clock, Server } from 'lucide-react';
import { cn } from '@/lib/utils.js';
import ActionApprovalModal from './ActionApprovalModal.jsx';

export default function ActionPreviewModal({ action, isOpen, onClose, onApprove, canApprove }) {
  const [showApproval, setShowApproval] = useState(false);

  if (!action) return null;

  const handleProceedToApproval = () => {
    setShowApproval(true);
  };

  const handleConfirmApproval = () => {
    setShowApproval(false);
    onApprove(action.id);
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen && !showApproval} onOpenChange={(open) => !open && onClose()}>
        <DialogContent className="sm:max-w-[600px] p-0 overflow-hidden bg-card border-border">
          <div className="p-6 border-b border-border bg-muted/30">
            <div className="flex items-center gap-2 mb-3">
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 uppercase tracking-wider text-[10px] font-bold">
                {action.category} ACTION
              </Badge>
              <Badge variant="secondary" className="bg-background text-muted-foreground text-[10px] font-mono">
                ID: {action.id.split('_')[1]?.substring(0, 8)}
              </Badge>
            </div>
            <DialogTitle className="text-xl font-bold text-foreground leading-tight mb-2">
              {action.title}
            </DialogTitle>
            <DialogDescription className="text-sm text-muted-foreground">
              {action.description}
            </DialogDescription>
          </div>

          <ScrollArea className="max-h-[60vh]">
            <div className="p-6 space-y-6">
              
              {/* Expected Impact */}
              <section>
                <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4" /> Expected Impact & Risk
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-muted/50 border border-border">
                    <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">Impact Level</p>
                    <p className="text-sm font-semibold text-foreground">{action.expectedImpact?.level || 'Unknown'}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-muted/50 border border-border">
                    <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">Reversibility</p>
                    <p className="text-sm font-semibold text-foreground">{action.expectedImpact?.reversibility || 'Unknown'}</p>
                  </div>
                  <div className="col-span-2 p-3 rounded-xl bg-muted/50 border border-border">
                    <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">System Assessment</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">{action.expectedImpact?.description}</p>
                  </div>
                </div>
              </section>

              {/* Target Entities */}
              <section>
                <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Server className="w-4 h-4" /> Target Entities ({action.targetEntities?.length || 0})
                </h4>
                <div className="space-y-2">
                  {action.targetEntities?.map((entity, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg border border-border bg-background">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                          <span className="text-xs font-bold text-primary">{entity.type?.charAt(0).toUpperCase() || 'E'}</span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{entity.id}</p>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{entity.type}</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-muted">Target</Badge>
                    </div>
                  ))}
                  {(!action.targetEntities || action.targetEntities.length === 0) && (
                    <p className="text-sm text-muted-foreground italic">No specific entities targeted. System-wide action.</p>
                  )}
                </div>
              </section>

              {/* Execution Steps */}
              <section>
                <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" /> Execution Sequence
                </h4>
                <div className="space-y-3 relative before:absolute before:inset-0 before:ml-[11px] before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border before:to-transparent">
                  {action.executionSteps?.map((step, idx) => (
                    <div key={idx} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                      <div className="flex items-center justify-center w-6 h-6 rounded-full border-2 border-background bg-muted text-muted-foreground shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                        <span className="text-[10px] font-bold">{idx + 1}</span>
                      </div>
                      <div className="w-[calc(100%-2.5rem)] md:w-[calc(50%-1.5rem)] p-3 rounded-lg border border-border bg-background shadow-sm">
                        <p className="text-xs font-medium text-foreground">{step}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

            </div>
          </ScrollArea>

          <DialogFooter className="p-4 border-t border-border bg-muted/30 flex-row sm:justify-between items-center gap-3">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Est. Time: ~5s</span>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" onClick={onClose}>Cancel</Button>
              <Button 
                onClick={handleProceedToApproval} 
                disabled={!canApprove}
                className={cn("gap-2", !canApprove && "opacity-50 cursor-not-allowed")}
              >
                Proceed to Approval <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          </DialogFooter>
          {!canApprove && (
            <div className="px-6 pb-4 pt-0 text-center">
              <p className="text-xs text-destructive flex items-center justify-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                Super Admin role required to approve and execute actions.
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <ActionApprovalModal 
        action={action}
        isOpen={showApproval}
        onClose={() => setShowApproval(false)}
        onConfirm={handleConfirmApproval}
      />
    </>
  );
}
