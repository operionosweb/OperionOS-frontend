import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { AlertCircle, Lightbulb, Activity, TrendingUp, Maximize } from 'lucide-react';
import { generatePitchNarrative } from '@/lib/investorPresentationHelpers.js';

const PitchNarrativeEngine = ({ operationsData, fleetData, crewData }) => {
  const narrative = generatePitchNarrative(operationsData, fleetData, crewData);

  const sections = [
    { id: 'problem', title: 'Problem Statement', content: narrative.problem, icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-500/10' },
    { id: 'solution', title: 'Operion Solution', content: narrative.solution, icon: Lightbulb, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { id: 'operational', title: 'Operational Impact', content: narrative.operationalImpact, icon: Activity, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { id: 'financial', title: 'Financial Impact', content: narrative.financialImpact, icon: TrendingUp, color: 'text-indigo-500', bg: 'bg-indigo-500/10' },
    { id: 'scalability', title: 'Scalability Outlook', content: narrative.scalability, icon: Maximize, color: 'text-purple-500', bg: 'bg-purple-500/10' }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="show"
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
    >
      {sections.map((section, index) => {
        const Icon = section.icon;
        // Make the last two items span differently to break the generic grid
        const spanClass = index === 3 ? 'md:col-span-2 lg:col-span-1' : index === 4 ? 'md:col-span-2 lg:col-span-2' : '';
        
        return (
          <motion.div key={section.id} variants={itemVariants} className={spanClass}>
            <Card className="h-full border-border/50 shadow-sm hover:shadow-md transition-all duration-300 bg-card overflow-hidden group">
              <CardContent className="p-6 flex flex-col h-full">
                <div className="flex items-center gap-4 mb-4">
                  <div className={`p-3 rounded-xl ${section.bg} group-hover:scale-110 transition-transform duration-300`}>
                    <Icon className={`w-6 h-6 ${section.color}`} />
                  </div>
                  <h3 className="text-lg font-bold text-foreground tracking-tight">{section.title}</h3>
                </div>
                <p className="text-muted-foreground leading-relaxed flex-1">
                  {section.content}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </motion.div>
  );
};

export default PitchNarrativeEngine;