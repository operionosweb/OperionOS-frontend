
import React, { useState, useEffect, useRef } from "react";

export default function ControlPanelCopilot({ isOpen, onClose, user }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, loading]);

  if (!isOpen) return null;

  // -----------------------------
  // MOCK AI RESPONSE GENERATOR
  // -----------------------------
  const generateMockResponse = (text) => {
    const lowerInput = text.toLowerCase();
    
    if (lowerInput.includes("contract")) {
      return {
        type: "risk",
        title: "Contract Risk Analysis",
        risks: [
          "3 high-value contracts expiring in 30 days",
          "Vendor X SLA compliance dropping below 95%"
        ],
        financial_impact: "Potential exposure: $1.2M",
        recommendation: "Initiate early renewal negotiations with Vendor X."
      };
    }
    
    if (lowerInput.includes("fleet") || lowerInput.includes("vessel")) {
      return {
        type: "analysis",
        title: "Fleet Status Overview",
        data: [
          { name: "Vessel Alpha", uptime: "99.9%", status: "Operational" },
          { name: "Vessel Beta", uptime: "92.4%", status: "Maintenance Required" }
        ],
        alerts: ["Vessel Beta engine efficiency down 4%"],
        recommendation: "Schedule Vessel Beta for predictive maintenance at next port."
      };
    }
    
    if (lowerInput.includes("crew")) {
      return {
        type: "recommendation",
        title: "Crew Optimization",
        candidates: [
          { name: "Crew Team A (Available)", score: 95 },
          { name: "Crew Team B (Resting)", score: 88 }
        ],
        recommendation: "Deploy Crew Team A for upcoming high-priority voyage to minimize fatigue risk."
      };
    }

    return {
      type: "text",
      message: `I understand you're asking about "${text}". As your local AI assistant, I'm monitoring all systems. Everything is currently operating within normal parameters. Try asking about "contracts", "fleet", or "crew".`
    };
  };

  // -----------------------------
  // SEND MESSAGE
  // -----------------------------
  const handleSendMessage = () => {
    if (!input.trim()) return;

    const userMessage = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    
    const currentInput = input;
    setInput("");
    setLoading(true);

    // Simulate processing delay
    setTimeout(() => {
      const aiResponse = generateMockResponse(currentInput);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: aiResponse
        }
      ]);
      setLoading(false);
    }, 1000);
  };

  // -----------------------------
  // ACTIONS
  // -----------------------------
  const runAction = (type) => {
    setMessages((prev) => [
      ...prev,
      {
        role: "assistant",
        content: {
          type: "text",
          message: `System Action [${type}] has been queued for execution.`
        }
      }
    ]);
  };

  // -----------------------------
  // RENDER AI RESPONSE
  // -----------------------------
  const renderAI = (data) => {
    if (!data || typeof data === "string") {
      return <div>{data}</div>;
    }

    if (data.type === "analysis") {
      return (
        <div className="flex flex-col gap-3">
          <h3 className="font-semibold text-foreground">{data.title}</h3>
          <div className="flex flex-col gap-1">
            {data.data?.map((f, i) => (
              <div key={i} className="text-sm text-muted-foreground">
                • {f.name} — {f.uptime} ({f.status})
              </div>
            ))}
          </div>
          <div>
            <strong className="text-sm text-foreground">Alerts:</strong>
            {data.alerts?.map((a, i) => (
              <div key={i} className="text-sm text-amber-500 mt-1">
                ⚠ {a}
              </div>
            ))}
          </div>
          <div className="text-sm font-medium text-emerald-500 mt-2">
            💡 {data.recommendation}
          </div>
        </div>
      );
    }

    if (data.type === "risk") {
      return (
        <div className="flex flex-col gap-3">
          <h3 className="font-semibold text-foreground">{data.title}</h3>
          <div className="flex flex-col gap-1">
            {data.risks?.map((r, i) => (
              <div key={i} className="text-sm text-destructive">
                ⚠ {r}
              </div>
            ))}
          </div>
          <div className="text-sm font-medium text-foreground">
            {data.financial_impact}
          </div>
          <div className="text-sm font-medium text-emerald-500 mt-2">
            💡 {data.recommendation}
          </div>
        </div>
      );
    }

    if (data.type === "recommendation") {
      return (
        <div className="flex flex-col gap-3">
          <h3 className="font-semibold text-foreground">{data.title}</h3>
          <div className="flex flex-col gap-1">
            {data.candidates?.map((c, i) => (
              <div key={i} className="text-sm text-muted-foreground">
                • {c.name} (Score: {c.score})
              </div>
            ))}
          </div>
          <div className="text-sm font-medium text-emerald-500 mt-2">
            💡 {data.recommendation}
          </div>
          <button
            onClick={() => runAction("REPLACE_CREW")}
            className="mt-2 px-3 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors w-fit"
          >
            Execute Recommendation
          </button>
        </div>
      );
    }

    return <div className="text-sm leading-relaxed">{data.message}</div>;
  };

  return (
    <div className="fixed right-0 top-0 w-[420px] h-[100dvh] bg-background border-l border-border z-[9999] flex flex-col shadow-2xl">
      {/* HEADER */}
      <div className="p-4 border-b border-border flex justify-between items-center bg-card">
        <div className="flex items-center gap-2">
          <span className="text-lg">🧠</span>
          <b className="text-sm tracking-wide text-card-foreground">Copilot Intelligence</b>
        </div>
        <button 
          onClick={onClose}
          className="text-muted-foreground hover:text-foreground transition-colors p-1"
          aria-label="Close Copilot"
        >
          ✕
        </button>
      </div>

      {/* CHAT */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
        {messages.length === 0 && (
          <div className="text-center text-muted-foreground mt-10 text-sm">
            How can I assist you with your operations today?
          </div>
        )}
        
        {messages.map((m, i) => (
          <div key={i} className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}>
            <div className="text-[11px] text-muted-foreground mb-1 uppercase tracking-wider">
              {m.role === "user" ? "You" : "Copilot"}
            </div>

            <div
              className={`p-3 rounded-lg max-w-[85%] ${
                m.role === "user" 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-muted text-muted-foreground border border-border"
              }`}
            >
              {m.role === "assistant" ? renderAI(m.content) : m.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex flex-col items-start">
            <div className="text-[11px] text-muted-foreground mb-1 uppercase tracking-wider">
              Copilot
            </div>
            <div className="p-3 rounded-lg bg-muted border border-border text-muted-foreground text-sm flex items-center gap-2">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-75" />
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-150" />
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* INPUT */}
      <div className="p-4 border-t border-border bg-card">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Ask about fleet, crew, contracts..."
          className="w-full p-3 mb-3 bg-background text-foreground border border-input rounded-md text-sm outline-none focus:ring-2 focus:ring-ring transition-all"
        />

        <button 
          onClick={handleSendMessage} 
          disabled={!input.trim() || loading}
          className="w-full p-3 bg-primary text-primary-foreground rounded-md font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary/90 transition-colors"
        >
          Send Message
        </button>
      </div>
    </div>
  );
}
