
import React from 'react';
import { useImpersonation } from '@/contexts/ImpersonationContext.jsx';
import { Button } from '@/components/ui/button.jsx';
import { UserCircle, XCircle } from 'lucide-react';

const ImpersonationBanner = () => {
  const { activeCompanyId, activeCompanyName, exitImpersonation } = useImpersonation();

  if (!activeCompanyId) return null;

  return (
    <div className="w-full bg-orange-600 text-white px-4 py-3 shadow-md border-b border-orange-700">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 font-medium text-sm sm:text-base flex-1 min-w-0">
          <UserCircle className="w-5 h-5 opacity-90 flex-shrink-0" />
          <span className="truncate">
            You are viewing as Company: <strong className="font-bold tracking-wide">{activeCompanyName}</strong>
          </span>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={exitImpersonation} 
          className="bg-white/10 border-white/20 text-white hover:bg-white/20 hover:text-white transition-colors h-8 flex-shrink-0"
        >
          <XCircle className="w-4 h-4 mr-1.5" />
          Exit
        </Button>
      </div>
    </div>
  );
};

export default ImpersonationBanner;
