
import React, { createContext, useContext, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { blockAutoUpdates } from '@/lib/AutoUpdateBlocker.js';
import { blockRandomValues } from '@/lib/RandomValueBlocker.js';
import { getViolationHistory } from '@/lib/ViolationLogger.js';
import { CONFIG, SEVERITY } from '@/lib/FoundationLockConfig.js';

import { SystemLayerLockProvider } from '@/contexts/SystemLayerLock.jsx';
import { DemoLayerLockProvider } from '@/contexts/DemoLayerLock.jsx';
import { UILayerLockProvider } from '@/contexts/UILayerLock.jsx';

const FoundationLockContext = createContext(null);

export const FoundationLockProvider = ({ children }) => {
  const [isLocked, setIsLocked] = useState(false);

  useEffect(() => {
    // Initialize global runtime blockers
    blockAutoUpdates();
    blockRandomValues();
    setIsLocked(true);
    
    if (CONFIG.enableUIAlerts) {
      toast.success('Foundation Lock Active', {
        description: 'Enforcing deterministic, event-driven architecture. Auto-updates blocked.'
      });
    }

    // A small polling checker specifically for detecting violations visually in dev (ironic, but necessary for the UI)
    const checkInterval = setInterval(() => {
      const violations = getViolationHistory();
      const recentCritical = violations.find(v => 
        v.severity === SEVERITY.CRITICAL && 
        new Date(v.timestamp).getTime() > Date.now() - 5000
      );

      if (recentCritical && CONFIG.enableUIAlerts) {
        toast.error(`Architecture Violation: ${recentCritical.type}`, {
          description: recentCritical.message
        });
      }
    }, 5000);

    return () => clearInterval(checkInterval);
  }, []);

  const getLockStatus = () => ({
    active: isLocked,
    mode: CONFIG.enforcementMode,
    violations: getViolationHistory().length
  });

  return (
    <FoundationLockContext.Provider value={{ getLockStatus }}>
      <SystemLayerLockProvider>
        <DemoLayerLockProvider>
          <UILayerLockProvider>
            {children}
          </UILayerLockProvider>
        </DemoLayerLockProvider>
      </SystemLayerLockProvider>
    </FoundationLockContext.Provider>
  );
};

export const useFoundationLock = () => {
  const context = useContext(FoundationLockContext);
  if (!context) throw new Error('useFoundationLock must be used within FoundationLockProvider');
  return context;
};
