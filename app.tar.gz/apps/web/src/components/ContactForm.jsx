import React, { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient.js';
import { Loader2 } from 'lucide-react';

const initialFormState = {
  firstName: '',
  lastName: '',
  companyName: '',
  workEmail: '',
  phoneNumber: '',
  jobTitle: '',
  country: '',
  industry: '',
  companySize: '',
  inquiryType: '',
  message: ''
};

const ContactForm = () => {
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    if (!formData.companyName.trim()) newErrors.companyName = 'Company name is required';
    
    if (!formData.workEmail.trim()) {
      newErrors.workEmail = 'Work email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.workEmail)) {
      newErrors.workEmail = 'Please enter a valid email address';
    }
    
    if (!formData.phoneNumber.trim()) {
      newErrors.phoneNumber = 'Phone number is required';
    } else if (!/^\+?[\d\s-]{7,20}$/.test(formData.phoneNumber)) {
      newErrors.phoneNumber = 'Please enter a valid phone number';
    }
    
    if (!formData.industry) newErrors.industry = 'Please select an industry';
    if (!formData.companySize) newErrors.companySize = 'Please select a company size';
    if (!formData.inquiryType) newErrors.inquiryType = 'Please select an inquiry type';
    if (!formData.message.trim()) newErrors.message = 'Message is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSelectChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error('Please fix the errors in the form before submitting.');
      return;
    }

    setIsSubmitting(true);

    try {
      await pb.collection('contact_submissions').create(formData, { $autoCancel: false });
      toast.success('Thank you. Our team will contact you shortly.');
      setFormData(initialFormState);
    } catch (error) {
      console.error('Submission error:', error);
      toast.error('Failed to submit your inquiry. Please try again later.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6" id="contact-form">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="firstName">First Name *</Label>
          <Input 
            id="firstName" 
            name="firstName" 
            value={formData.firstName} 
            onChange={handleChange} 
            className={errors.firstName ? 'border-destructive' : ''}
            disabled={isSubmitting}
          />
          {errors.firstName && <p className="text-sm text-destructive">{errors.firstName}</p>}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="lastName">Last Name *</Label>
          <Input 
            id="lastName" 
            name="lastName" 
            value={formData.lastName} 
            onChange={handleChange} 
            className={errors.lastName ? 'border-destructive' : ''}
            disabled={isSubmitting}
          />
          {errors.lastName && <p className="text-sm text-destructive">{errors.lastName}</p>}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="workEmail">Work Email *</Label>
          <Input 
            id="workEmail" 
            name="workEmail" 
            type="email" 
            value={formData.workEmail} 
            onChange={handleChange} 
            className={errors.workEmail ? 'border-destructive' : ''}
            disabled={isSubmitting}
          />
          {errors.workEmail && <p className="text-sm text-destructive">{errors.workEmail}</p>}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phoneNumber">Phone Number *</Label>
          <Input 
            id="phoneNumber" 
            name="phoneNumber" 
            type="tel" 
            value={formData.phoneNumber} 
            onChange={handleChange} 
            className={errors.phoneNumber ? 'border-destructive' : ''}
            disabled={isSubmitting}
          />
          {errors.phoneNumber && <p className="text-sm text-destructive">{errors.phoneNumber}</p>}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="companyName">Company Name *</Label>
          <Input 
            id="companyName" 
            name="companyName" 
            value={formData.companyName} 
            onChange={handleChange} 
            className={errors.companyName ? 'border-destructive' : ''}
            disabled={isSubmitting}
          />
          {errors.companyName && <p className="text-sm text-destructive">{errors.companyName}</p>}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="jobTitle">Job Title</Label>
          <Input 
            id="jobTitle" 
            name="jobTitle" 
            value={formData.jobTitle} 
            onChange={handleChange} 
            disabled={isSubmitting}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="industry">Industry *</Label>
          <Select 
            value={formData.industry} 
            onValueChange={(val) => handleSelectChange('industry', val)}
            disabled={isSubmitting}
          >
            <SelectTrigger className={errors.industry ? 'border-destructive' : ''}>
              <SelectValue placeholder="Select Industry" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Aviation">Aviation</SelectItem>
              <SelectItem value="Maritime">Maritime</SelectItem>
              <SelectItem value="Both">Both</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
          {errors.industry && <p className="text-sm text-destructive">{errors.industry}</p>}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="companySize">Company Size *</Label>
          <Select 
            value={formData.companySize} 
            onValueChange={(val) => handleSelectChange('companySize', val)}
            disabled={isSubmitting}
          >
            <SelectTrigger className={errors.companySize ? 'border-destructive' : ''}>
              <SelectValue placeholder="Select Size" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1–50">1–50 Employees</SelectItem>
              <SelectItem value="51–200">51–200 Employees</SelectItem>
              <SelectItem value="201–1000">201–1000 Employees</SelectItem>
              <SelectItem value="1000+">1000+ Employees</SelectItem>
            </SelectContent>
          </Select>
          {errors.companySize && <p className="text-sm text-destructive">{errors.companySize}</p>}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="inquiryType">Inquiry Type *</Label>
          <Select 
            value={formData.inquiryType} 
            onValueChange={(val) => handleSelectChange('inquiryType', val)}
            disabled={isSubmitting}
          >
            <SelectTrigger className={errors.inquiryType ? 'border-destructive' : ''}>
              <SelectValue placeholder="Select Inquiry Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Request Demo">Request Demo</SelectItem>
              <SelectItem value="Pricing">Pricing</SelectItem>
              <SelectItem value="Product Information">Product Information</SelectItem>
              <SelectItem value="Partnership">Partnership</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
          {errors.inquiryType && <p className="text-sm text-destructive">{errors.inquiryType}</p>}
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="country">Country</Label>
          <Input 
            id="country" 
            name="country" 
            value={formData.country} 
            onChange={handleChange} 
            disabled={isSubmitting}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">How can we help you? *</Label>
        <Textarea 
          id="message" 
          name="message" 
          rows={5} 
          value={formData.message} 
          onChange={handleChange} 
          className={`resize-none ${errors.message ? 'border-destructive' : ''}`}
          disabled={isSubmitting}
        />
        {errors.message && <p className="text-sm text-destructive">{errors.message}</p>}
      </div>

      <Button 
        type="submit" 
        className="w-full md:w-auto min-w-[200px] h-12 text-base font-semibold" 
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <>
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            Submitting...
          </>
        ) : (
          'Submit Inquiry'
        )}
      </Button>
    </form>
  );
};

export default ContactForm;