import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Download, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { chartData } from '@/lib/roiSavingsData.js';

const KPIDetailPanel = ({ isOpen, onClose, kpi }) => {
  if (!kpi) return null;

  const formatValue = (val, isPct) => {
    if (isPct) return `${val}%`;
    return new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto">
        <SheetHeader className="mb-6">
          <SheetTitle className="text-2xl font-bold">{kpi.label}</SheetTitle>
          <SheetDescription>Detailed breakdown and historical performance.</SheetDescription>
        </SheetHeader>

        <div className="space-y-6">
          <div className="bg-muted/50 p-6 rounded-2xl border border-border flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground font-medium mb-1">Current Value</p>
              <p className="text-4xl font-extrabold tabular-nums tracking-tight text-foreground">
                {formatValue(kpi.value, kpi.isPercentage)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground font-medium mb-1">Trend</p>
              <div className="flex items-center gap-1 text-emerald-600 bg-emerald-500/10 px-3 py-1 rounded-full font-bold">
                <TrendingUp className="w-4 h-4" />
                {kpi.trend}
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Historical Trend</h3>
            <div className="h-[250px] w-full bg-card border border-border rounded-xl p-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData.trend}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(val) => `€${val/1000000}M`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    formatter={(value) => [`€${(value/1000).toFixed(0)}k`, 'Savings']}
                  />
                  <Line type="monotone" dataKey="savings" stroke="hsl(var(--primary))" strokeWidth={3} dot={{ r: 4, fill: 'hsl(var(--primary))' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="pt-4 border-t border-border">
            <Button className="w-full touch-target">
              <Download className="w-4 h-4 mr-2" /> Export KPI Report
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default KPIDetailPanel;