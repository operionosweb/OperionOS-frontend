import React, { useState } from 'react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';
import { Users, TrendingUp } from 'lucide-react';
import CrewOptimizationPanel from './CrewOptimizationPanel.jsx';

const CrewAnalysisSection = () => {
  const { crew } = useROISavings();
  const [selectedCrew, setSelectedCrew] = useState(null);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {crew.map((member) => (
          <div 
            key={member.id}
            onClick={() => setSelectedCrew(member)}
            className="bg-card border border-border rounded-2xl p-4 shadow-sm hover:shadow-md hover:-translate-y-1 hover:border-primary/30 transition-all duration-300 cursor-pointer touch-target flex items-center gap-4"
          >
            <img src={`https://i.pravatar.cc/150?u=${member.id}`} alt={member.name} className="w-12 h-12 rounded-full border border-border" />
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm truncate">{member.name}</h3>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold truncate">{member.role}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs font-bold text-emerald-600 tabular-nums">€{member.totalSavings.toLocaleString()}</span>
                <span className="text-[10px] text-primary font-medium bg-primary/10 px-1.5 rounded">+{member.efficiency}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <CrewOptimizationPanel isOpen={!!selectedCrew} onClose={() => setSelectedCrew(null)} crew={selectedCrew} />
    </div>
  );
};

export default CrewAnalysisSection;