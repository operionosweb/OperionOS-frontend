import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Play, Check, X, AlertTriangle, Ship, Users } from 'lucide-react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';

const OpportunityDetailPanel = ({ isOpen, onClose, opp }) => {
  const { applySimulation } = useROISavings();

  if (!opp) return null;

  const handleApply = () => {
    applySimulation(opp.id);
    onClose();
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto">
        <SheetHeader className="mb-6">
          <div className="flex gap-2 mb-2">
            <Badge variant="secondary">{opp.category}</Badge>
            <Badge variant="outline" className={opp.risk === 'Low' ? 'text-emerald-600' : opp.risk === 'Medium' ? 'text-amber-600' : 'text-destructive'}>
              {opp.risk} Risk
            </Badge>
          </div>
          <SheetTitle className="text-2xl font-bold">{opp.desc}</SheetTitle>
          <SheetDescription>AI-identified savings opportunity.</SheetDescription>
        </SheetHeader>

        <div className="space-y-6">
          <div className="bg-card border border-border rounded-xl p-5 text-center shadow-sm">
            <p className="text-sm text-muted-foreground font-medium mb-1">Estimated Savings</p>
            <p className="text-4xl font-extrabold text-emerald-600 tabular-nums">
              €{opp.amount.toLocaleString()}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-muted/50 border border-border rounded-xl p-4 flex items-center gap-3">
              <div className="p-2 bg-background rounded-lg shadow-sm"><Ship className="w-5 h-5 text-primary" /></div>
              <div>
                <p className="text-xs text-muted-foreground font-bold uppercase">Vessels</p>
                <p className="font-bold">{opp.vessels} Affected</p>
              </div>
            </div>
            <div className="bg-muted/50 border border-border rounded-xl p-4 flex items-center gap-3">
              <div className="p-2 bg-background rounded-lg shadow-sm"><Users className="w-5 h-5 text-primary" /></div>
              <div>
                <p className="text-xs text-muted-foreground font-bold uppercase">Crew</p>
                <p className="font-bold">{opp.crew} Affected</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-2">Recommended Action</h4>
              <div className="bg-primary/5 p-4 rounded-xl border border-primary/20 text-sm font-medium text-foreground">
                {opp.recommendation}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-2">Implementation Steps</h4>
              <ol className="space-y-3 text-sm list-decimal list-inside pl-2">
                <li className="pl-2">Run simulation to verify operational constraints.</li>
                <li className="pl-2">Notify affected vessel masters and crew managers.</li>
                <li className="pl-2">Execute schedule adjustments in planning module.</li>
              </ol>
            </div>
          </div>

          <div className="pt-6 border-t border-border flex flex-col gap-3">
            <Button className="w-full touch-target bg-primary text-primary-foreground" onClick={handleApply}>
              <Check className="w-4 h-4 mr-2"/> Apply Recommendation
            </Button>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1 touch-target"><Play className="w-4 h-4 mr-2"/> Simulate</Button>
              <Button variant="ghost" className="flex-1 touch-target text-destructive hover:text-destructive hover:bg-destructive/10" onClick={onClose}>
                <X className="w-4 h-4 mr-2"/> Dismiss
              </Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default OpportunityDetailPanel;