import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Slider } from '@/components/ui/slider.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Info, Calculator, Waves, TrendingDown, Clock, ShieldCheck } from 'lucide-react';
import { formatCurrency, formatNumber } from '@/lib/formatters.js';

const OffshoreSavingsSimulator = () => {
  // Simulator State
  const [crewCount, setCrewCount] = useState(500);
  const [rotationLength, setRotationLength] = useState(28);
  const [monthlyRotations, setMonthlyRotations] = useState(50);
  const [costPerMovement, setCostPerMovement] = useState(1500);
  const [disruptionRate, setDisruptionRate] = useState(15);

  // Results State
  const [results, setResults] = useState({
    annualMovements: 0,
    inefficiencyCost: 0,
    annualSavings: 0,
  });

  // Optimization factor (15-25% range, using 20% as the baseline for display)
  const OPTIMIZATION_FACTOR = 0.20;

  useEffect(() => {
    // Dynamic Calculations
    const annualMovements = monthlyRotations * 12;
    const inefficiencyCost = annualMovements * costPerMovement * (disruptionRate / 100);
    const annualSavings = inefficiencyCost * OPTIMIZATION_FACTOR;

    setResults({
      annualMovements,
      inefficiencyCost,
      annualSavings,
    });
  }, [crewCount, rotationLength, monthlyRotations, costPerMovement, disruptionRate]);

  return (
    <div className="py-8 border-t border-border mt-8">
      <div className="mb-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-4">
          <Waves className="w-4 h-4" />
          Interactive Tool
        </div>
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
          Offshore Operations Savings Simulator
        </h2>
        <p className="text-muted-foreground text-lg max-w-3xl">
          Estimate the operational savings from optimizing offshore crew rotations and coordination.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Inputs */}
        <Card className="lg:col-span-7 border-border/60 shadow-sm">
          <CardHeader className="bg-muted/30 border-b border-border/50 pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <Calculator className="w-5 h-5 text-primary" />
              Operational Parameters
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-8">
            {/* Input: Number of offshore crew */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="crew-count" className="text-base font-medium">Number of Offshore Crew</Label>
                <span className="text-muted-foreground font-medium tabular-nums">{formatNumber(crewCount)}</span>
              </div>
              <div className="flex gap-4 items-center">
                <Slider 
                  id="crew-count"
                  min={50} max={5000} step={10} 
                  value={[crewCount]} 
                  onValueChange={(val) => setCrewCount(val[0])}
                  className="flex-1"
                />
                <Input 
                  type="number" 
                  value={crewCount} 
                  onChange={(e) => setCrewCount(Number(e.target.value))}
                  className="w-24 text-right text-foreground font-medium"
                />
              </div>
            </div>

            {/* Input: Rotation cycle length */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="rotation-length" className="text-base font-medium">Rotation Cycle Length (Days)</Label>
                <span className="text-muted-foreground font-medium tabular-nums">{rotationLength} days</span>
              </div>
              <div className="flex gap-4 items-center">
                <Slider 
                  id="rotation-length"
                  min={7} max={90} step={1} 
                  value={[rotationLength]} 
                  onValueChange={(val) => setRotationLength(val[0])}
                  className="flex-1"
                />
                <Input 
                  type="number" 
                  value={rotationLength} 
                  onChange={(e) => setRotationLength(Number(e.target.value))}
                  className="w-24 text-right text-foreground font-medium"
                />
              </div>
            </div>

            {/* Input: Monthly crew rotations */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="monthly-rotations" className="text-base font-medium">Monthly Crew Rotations</Label>
                <span className="text-muted-foreground font-medium tabular-nums">{formatNumber(monthlyRotations)}</span>
              </div>
              <div className="flex gap-4 items-center">
                <Slider 
                  id="monthly-rotations"
                  min={10} max={1000} step={5} 
                  value={[monthlyRotations]} 
                  onValueChange={(val) => setMonthlyRotations(val[0])}
                  className="flex-1"
                />
                <Input 
                  type="number" 
                  value={monthlyRotations} 
                  onChange={(e) => setMonthlyRotations(Number(e.target.value))}
                  className="w-24 text-right text-foreground font-medium"
                />
              </div>
            </div>

            {/* Input: Average cost per crew movement */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="cost-movement" className="text-base font-medium">Avg. Cost per Movement (€)</Label>
                <span className="text-muted-foreground font-medium tabular-nums">{formatCurrency(costPerMovement)}</span>
              </div>
              <div className="flex gap-4 items-center">
                <Slider 
                  id="cost-movement"
                  min={200} max={10000} step={100} 
                  value={[costPerMovement]} 
                  onValueChange={(val) => setCostPerMovement(val[0])}
                  className="flex-1"
                />
                <Input 
                  type="number" 
                  value={costPerMovement} 
                  onChange={(e) => setCostPerMovement(Number(e.target.value))}
                  className="w-28 text-right text-foreground font-medium"
                />
              </div>
            </div>

            {/* Input: Estimated disruption rate */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <Label htmlFor="disruption-rate" className="text-base font-medium">Estimated Disruption Rate (%)</Label>
                <span className="text-muted-foreground font-medium tabular-nums">{disruptionRate}%</span>
              </div>
              <div className="flex gap-4 items-center">
                <Slider 
                  id="disruption-rate"
                  min={0} max={50} step={1} 
                  value={[disruptionRate]} 
                  onValueChange={(val) => setDisruptionRate(val[0])}
                  className="flex-1"
                />
                <Input 
                  type="number" 
                  value={disruptionRate} 
                  onChange={(e) => setDisruptionRate(Number(e.target.value))}
                  className="w-24 text-right text-foreground font-medium"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Right Column: Results */}
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-primary/20 shadow-md bg-gradient-to-br from-primary/5 to-transparent relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-2xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
            <CardContent className="p-8 relative z-10">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                Estimated Annual Savings
              </h3>
              <div className="text-4xl md:text-5xl font-extrabold text-primary tabular-nums tracking-tight mb-4">
                {formatCurrency(results.annualSavings)}
              </div>
              <p className="text-sm text-foreground/80 leading-relaxed pb-6 border-b border-border/50">
                Based on a conservative {formatNumber(OPTIMIZATION_FACTOR * 100)}% efficiency gain applied to your estimated annual inefficiency costs of {formatCurrency(results.inefficiencyCost)}.
              </p>

              <div className="mt-6 space-y-5">
                <div className="flex items-start gap-4">
                  <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-500 shrink-0">
                    <TrendingDown className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-sm">Disruption Reduction</h4>
                    <p className="text-emerald-600 dark:text-emerald-400 font-medium text-lg">20% Reduction</p>
                    <p className="text-xs text-muted-foreground mt-0.5">In overlapping logistics and layovers</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500 shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-sm">Improved Crew Utilization</h4>
                    <p className="text-blue-600 dark:text-blue-400 font-medium text-lg">+15% Productive Time</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Fewer standby crews and idle days</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-2 bg-purple-500/10 rounded-lg text-purple-500 shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground text-sm">Annual Movements Managed</h4>
                    <p className="text-purple-600 dark:text-purple-400 font-medium text-lg tabular-nums">{formatNumber(results.annualMovements)}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Fully optimized via AI logistics</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Important Note Callout */}
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-5 flex gap-4">
            <Info className="w-6 h-6 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-blue-900 dark:text-blue-200 mb-1">Integration Note</h4>
              <p className="text-sm text-blue-800/80 dark:text-blue-300/80 leading-relaxed">
                Operion improves offshore operational efficiency by optimizing planning and coordination. Execution of crew movements is handled via integrated external providers.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OffshoreSavingsSimulator;