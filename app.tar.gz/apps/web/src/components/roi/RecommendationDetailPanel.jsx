import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Check, X, Zap, Clock } from 'lucide-react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';

const RecommendationDetailPanel = ({ isOpen, onClose, rec }) => {
  const { dismissRecommendation } = useROISavings();

  if (!rec) return null;

  const handleDismiss = () => {
    dismissRecommendation(rec.id);
    onClose();
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto">
        <SheetHeader className="mb-6">
          <div className="flex gap-2 mb-2">
            <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20"><Zap className="w-3 h-3 mr-1"/> AI Generated</Badge>
          </div>
          <SheetTitle className="text-2xl font-bold">{rec.title}</SheetTitle>
          <SheetDescription>{rec.desc}</SheetDescription>
        </SheetHeader>

        <div className="space-y-6">
          <div className="bg-card border border-border rounded-xl p-5 text-center shadow-sm">
            <p className="text-sm text-muted-foreground font-medium mb-1">Projected Savings</p>
            <p className="text-4xl font-extrabold text-emerald-600 tabular-nums">
              €{rec.amount.toLocaleString()}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-muted/50 border border-border rounded-xl p-4">
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Time Impact</p>
              <p className="font-bold flex items-center gap-2"><Clock className="w-4 h-4 text-primary"/> {rec.timeImpact}</p>
            </div>
            <div className="bg-muted/50 border border-border rounded-xl p-4">
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Confidence</p>
              <p className="font-bold">{rec.confidence}</p>
            </div>
          </div>

          <div className="pt-6 border-t border-border flex flex-col gap-3">
            <Button className="w-full touch-target bg-primary text-primary-foreground">
              <Check className="w-4 h-4 mr-2"/> Apply Optimization
            </Button>
            <Button variant="ghost" className="w-full touch-target text-destructive hover:text-destructive hover:bg-destructive/10" onClick={handleDismiss}>
              <X className="w-4 h-4 mr-2"/> Dismiss
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default RecommendationDetailPanel;