import React from 'react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const CHART_COLORS = ['hsl(var(--primary))', 'hsl(var(--teal))', 'hsl(var(--warning))', 'hsl(var(--destructive))'];

const SavingsByCategorySection = () => {
  const { chartData } = useROISavings();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-card border border-border rounded-2xl p-5 shadow-sm h-[350px] flex flex-col">
        <h3 className="text-base font-bold mb-4">Savings by Category</h3>
        <div className="flex-1 min-h-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie 
                data={chartData.category} 
                cx="50%" cy="50%" 
                innerRadius={60} outerRadius={100} 
                paddingAngle={5} 
                dataKey="value"
              >
                {chartData.category.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => [`€${(value/1000000).toFixed(1)}M`, 'Savings']}
                contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex justify-center gap-4 mt-4 flex-wrap">
          {chartData.category.map((entry, index) => (
            <div key={entry.name} className="flex items-center gap-2 text-xs font-medium">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}></div>
              {entry.name}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 shadow-sm h-[350px] flex flex-col">
        <h3 className="text-base font-bold mb-4">Cumulative Savings vs Target</h3>
        <div className="flex-1 min-h-0">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData.trend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(val) => `€${val/1000000}M`} />
              <Tooltip 
                formatter={(value) => [`€${(value/1000000).toFixed(1)}M`, '']}
                contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))' }}
                cursor={{ fill: 'hsl(var(--muted)/0.5)' }}
              />
              <Bar dataKey="savings" name="Actual Savings" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="target" name="Target" fill="hsl(var(--muted-foreground)/0.3)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default SavingsByCategorySection;