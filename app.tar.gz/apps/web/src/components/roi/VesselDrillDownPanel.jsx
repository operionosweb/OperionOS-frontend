import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Download, Ship, Activity, Zap } from 'lucide-react';

const VesselDrillDownPanel = ({ isOpen, onClose, vessel }) => {
  if (!vessel) return null;

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto">
        <SheetHeader className="mb-6">
          <div className="flex gap-2 mb-2">
            <Badge variant="secondary">{vessel.type}</Badge>
          </div>
          <SheetTitle className="text-2xl font-bold">{vessel.name}</SheetTitle>
          <SheetDescription>Vessel-specific ROI and efficiency metrics.</SheetDescription>
        </SheetHeader>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card border border-border rounded-xl p-4 text-center shadow-sm">
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Total Savings</p>
              <p className="text-2xl font-extrabold text-emerald-600 tabular-nums">€{(vessel.totalSavings/1000).toFixed(0)}k</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center shadow-sm">
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Efficiency Gain</p>
              <p className="text-2xl font-extrabold text-primary tabular-nums">+{vessel.efficiency}%</p>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold flex items-center gap-2"><Zap className="w-4 h-4 text-amber-500"/> AI Decisions Applied ({vessel.decisions})</h4>
            <div className="space-y-2">
              {[1, 2, 3].map(i => (
                <div key={i} className="bg-muted/50 p-3 rounded-lg border border-border text-sm flex justify-between items-center">
                  <span className="font-medium">Speed optimization route {i}</span>
                  <span className="text-emerald-600 font-bold tabular-nums">+€12k</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-6 border-t border-border flex flex-col gap-3">
            <Button className="w-full touch-target">View Full Vessel Profile</Button>
            <Button variant="outline" className="w-full touch-target"><Download className="w-4 h-4 mr-2"/> Export Vessel Report</Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default VesselDrillDownPanel;