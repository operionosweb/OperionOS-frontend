import React, { useState } from 'react';
import { Search, Bell, Settings, User, Menu, X, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar.jsx';
import Logo from '@/components/Logo.jsx';

const ROISavingsHeader = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navTabs = [
    { name: 'Analytics', active: false },
    { name: 'ROI Tracker', active: true },
    { name: 'Communications', active: false },
    { name: 'Fleet Status', active: false },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-background border-b border-border flex items-center justify-between px-4 lg:px-6 z-50">
      {/* Left: Logo & Mobile Menu Toggle */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden touch-target"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </Button>
        <div className="hidden md:block">
          <Logo variant="full" size="md" isClickable={true} />
        </div>
        <div className="block md:hidden">
          <Logo variant="icon" size="md" isClickable={true} />
        </div>
      </div>

      {/* Center: Nav Tabs (Desktop) */}
      <nav className="hidden lg:flex items-center space-x-1 mx-6">
        {navTabs.map((tab) => (
          <button
            key={tab.name}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              tab.active
                ? 'bg-primary/10 text-primary'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            }`}
          >
            {tab.name}
          </button>
        ))}
      </nav>

      {/* Center-Right: Search */}
      <div className="flex-1 max-w-md mx-4 hidden md:block">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Global Fleet Search..."
            className="w-full h-9 bg-muted/50 border border-border rounded-full pl-9 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        <Button className="hidden sm:flex bg-blue-600 hover:bg-blue-700 text-white gap-2 h-9 rounded-full px-4 shadow-sm transition-all active:scale-95">
          <Rocket className="w-4 h-4" />
          <span className="hidden xl:inline font-semibold">Mission Control</span>
        </Button>

        <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground touch-target">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-destructive rounded-full border-2 border-background"></span>
        </Button>

        <Button variant="ghost" size="icon" className="hidden sm:flex text-muted-foreground hover:text-foreground touch-target">
          <Settings className="w-5 h-5" />
        </Button>

        <div className="pl-2 sm:pl-4 border-l border-border flex items-center">
          <Avatar className="w-8 h-8 border border-border cursor-pointer hover:ring-2 ring-primary transition-all">
            <AvatarImage src="https://i.pravatar.cc/150?u=admin" />
            <AvatarFallback><User className="w-4 h-4" /></AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="absolute top-16 left-0 right-0 bg-background border-b border-border p-4 shadow-lg lg:hidden flex flex-col gap-2 animate-in slide-in-from-top-2">
          <div className="relative mb-4">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Global Fleet Search..."
              className="w-full h-10 bg-muted/50 border border-border rounded-lg pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
            />
          </div>
          {navTabs.map((tab) => (
            <button
              key={tab.name}
              className={`w-full text-left px-4 py-3 rounded-md text-sm font-medium transition-colors touch-target ${
                tab.active
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              }`}
            >
              {tab.name}
            </button>
          ))}
          <Button className="w-full mt-2 bg-blue-600 hover:bg-blue-700 text-white gap-2 touch-target h-10">
            <Rocket className="w-4 h-4" />
            Mission Control
          </Button>
        </div>
      )}
    </header>
  );
};

export default ROISavingsHeader;