import React, { useState, useMemo } from 'react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Search, Filter, Download } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import SavingsDetailPanel from './SavingsDetailPanel.jsx';

const SavingsLogSection = () => {
  const { savingsLog } = useROISavings();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [selectedLog, setSelectedLog] = useState(null);

  const filteredLogs = useMemo(() => {
    return savingsLog.filter(log => {
      const matchesSearch = log.vessel.toLowerCase().includes(search.toLowerCase()) || 
                            log.action.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = categoryFilter === 'All' || log.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [savingsLog, search, categoryFilter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div className="flex items-center gap-2 flex-1">
          <div className="relative flex-1 sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search vessel or action..." 
              className="pl-9 touch-target"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[140px] touch-target">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Categories</SelectItem>
              <SelectItem value="Travel">Crew Movements</SelectItem>
              <SelectItem value="Operations">Operations</SelectItem>
              <SelectItem value="Crew">Crew</SelectItem>
              <SelectItem value="Disruption">Disruption</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button variant="outline" className="touch-target"><Download className="w-4 h-4 mr-2"/> Export CSV</Button>
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
        <table className="w-full text-sm text-left">
          <thead className="bg-muted/50 text-muted-foreground text-xs uppercase tracking-wider">
            <tr>
              <th className="px-6 py-4 font-semibold">Date</th>
              <th className="px-6 py-4 font-semibold">Vessel</th>
              <th className="px-6 py-4 font-semibold">Category</th>
              <th className="px-6 py-4 font-semibold">Action Taken</th>
              <th className="px-6 py-4 font-semibold text-right">Savings</th>
              <th className="px-6 py-4 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filteredLogs.map((log) => (
              <tr 
                key={log.id} 
                onClick={() => setSelectedLog(log)}
                className="hover:bg-muted/50 transition-colors cursor-pointer group"
              >
                <td className="px-6 py-4 whitespace-nowrap text-muted-foreground">{log.date}</td>
                <td className="px-6 py-4 font-medium">{log.vessel}</td>
                <td className="px-6 py-4"><Badge variant="secondary">{log.category === 'Travel' ? 'Crew Movements' : log.category}</Badge></td>
                <td className="px-6 py-4 max-w-xs truncate">{log.action}</td>
                <td className="px-6 py-4 text-right font-bold tabular-nums text-emerald-600">€{log.amount.toLocaleString()}</td>
                <td className="px-6 py-4">
                  <Badge variant="outline" className={log.status === 'Realized' ? 'text-emerald-600 border-emerald-500/20' : 'text-amber-600 border-amber-500/20'}>
                    {log.status}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden space-y-3">
        {filteredLogs.map((log) => (
          <div 
            key={log.id}
            onClick={() => setSelectedLog(log)}
            className="bg-card border border-border rounded-xl p-4 shadow-sm active:scale-[0.98] transition-transform cursor-pointer touch-target flex flex-col h-auto items-stretch"
          >
            <div className="flex justify-between items-start mb-2">
              <Badge variant="secondary" className="text-[10px]">{log.category === 'Travel' ? 'Crew Movements' : log.category}</Badge>
              <span className="text-xs text-muted-foreground">{log.date}</span>
            </div>
            <h4 className="font-bold text-sm mb-1">{log.action}</h4>
            <p className="text-xs text-muted-foreground mb-3">{log.vessel}</p>
            <div className="flex justify-between items-center mt-auto pt-3 border-t border-border/50">
              <Badge variant="outline" className={`text-[10px] ${log.status === 'Realized' ? 'text-emerald-600 border-emerald-500/20' : 'text-amber-600 border-amber-500/20'}`}>
                {log.status}
              </Badge>
              <span className="font-bold text-emerald-600 tabular-nums">€{log.amount.toLocaleString()}</span>
            </div>
          </div>
        ))}
      </div>

      <SavingsDetailPanel isOpen={!!selectedLog} onClose={() => setSelectedLog(null)} log={selectedLog} />
    </div>
  );
};

export default SavingsLogSection;