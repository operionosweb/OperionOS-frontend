import React, { useState } from 'react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';
import { Ship, TrendingUp, ChevronRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge.jsx';
import VesselDrillDownPanel from './VesselDrillDownPanel.jsx';

const VesselAnalysisSection = () => {
  const { vessels } = useROISavings();
  const [selectedVessel, setSelectedVessel] = useState(null);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {vessels.map((vessel) => (
          <div 
            key={vessel.id}
            onClick={() => setSelectedVessel(vessel)}
            className="bg-card border border-border rounded-2xl p-5 shadow-sm hover:shadow-lg hover:-translate-y-1 hover:border-primary/30 transition-all duration-300 cursor-pointer touch-target flex flex-col"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg text-primary">
                  <Ship className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base leading-none">{vessel.name}</h3>
                  <p className="text-xs text-muted-foreground mt-1">{vessel.type}</p>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-2">
              <div>
                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider mb-1">Total Savings</p>
                <p className="text-lg font-extrabold text-emerald-600 tabular-nums">€{(vessel.totalSavings/1000).toFixed(0)}k</p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider mb-1">Efficiency</p>
                <div className="flex items-center gap-1 text-primary font-bold">
                  <TrendingUp className="w-4 h-4" /> +{vessel.efficiency}%
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <VesselDrillDownPanel isOpen={!!selectedVessel} onClose={() => setSelectedVessel(null)} vessel={selectedVessel} />
    </div>
  );
};

export default VesselAnalysisSection;