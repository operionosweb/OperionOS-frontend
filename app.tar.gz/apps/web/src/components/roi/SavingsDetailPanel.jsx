import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Download, Copy, CheckCircle2, Clock, Ship, Tag } from 'lucide-react';

const SavingsDetailPanel = ({ isOpen, onClose, log }) => {
  if (!log) return null;

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto">
        <SheetHeader className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <Badge variant="outline" className={log.status === 'Realized' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-amber-500/10 text-amber-600 border-amber-500/20'}>
              {log.status}
            </Badge>
            <span className="text-sm text-muted-foreground flex items-center gap-1"><Clock className="w-4 h-4"/> {log.date}</span>
          </div>
          <SheetTitle className="text-2xl font-bold">{log.action}</SheetTitle>
          <SheetDescription>Detailed view of savings realization.</SheetDescription>
        </SheetHeader>

        <div className="space-y-6">
          <div className="bg-primary/5 border border-primary/20 rounded-xl p-5 text-center">
            <p className="text-sm text-muted-foreground font-medium mb-1">Savings Achieved</p>
            <p className="text-4xl font-extrabold text-primary tabular-nums">
              €{log.amount.toLocaleString()}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <Ship className="w-4 h-4" /> <span className="text-xs font-bold uppercase tracking-wider">Vessel</span>
              </div>
              <p className="font-medium">{log.vessel}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <Tag className="w-4 h-4" /> <span className="text-xs font-bold uppercase tracking-wider">Category</span>
              </div>
              <p className="font-medium">{log.category}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-2">AI Recommendation</h4>
              <div className="bg-muted/50 p-4 rounded-xl border border-border text-sm">
                {log.recommendation}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-2">Impact Analysis</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> Efficiency gain: +14%</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> Time saved: 12 hours</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> Carbon reduction: 4.2 tons</li>
              </ul>
            </div>
          </div>

          <div className="pt-6 border-t border-border flex flex-col gap-3">
            <Button className="w-full touch-target">View Full Decision Log</Button>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1 touch-target"><Download className="w-4 h-4 mr-2"/> Export</Button>
              <Button variant="outline" className="flex-1 touch-target"><Copy className="w-4 h-4 mr-2"/> Duplicate</Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default SavingsDetailPanel;