import React, { useState } from 'react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Plane, Users, Calendar, AlertTriangle, ChevronRight } from 'lucide-react';
import OpportunityDetailPanel from './OpportunityDetailPanel.jsx';

const PendingOpportunitiesSection = () => {
  const { opportunities } = useROISavings();
  const [selectedOpp, setSelectedOpp] = useState(null);

  const getIcon = (category) => {
    switch(category) {
      case 'Travel Optimization': 
      case 'Crew Movements Optimization': return <Plane className="w-5 h-5 text-blue-500" />;
      case 'Crew Reallocation': return <Users className="w-5 h-5 text-violet-500" />;
      case 'Vessel Scheduling': return <Calendar className="w-5 h-5 text-emerald-500" />;
      case 'Disruption Mitigation': return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      default: return <Plane className="w-5 h-5 text-primary" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-6">
        {opportunities.map((opp) => (
          <div 
            key={opp.id}
            onClick={() => setSelectedOpp(opp)}
            className="bg-card border border-border rounded-2xl p-5 shadow-sm hover:shadow-lg hover:-translate-y-1 hover:border-primary/30 transition-all duration-300 cursor-pointer touch-target flex flex-col h-full"
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-muted rounded-lg">
                  {getIcon(opp.category)}
                </div>
                <Badge variant="secondary" className="text-[10px]">{opp.category === 'Travel Optimization' ? 'Crew Movements Optimization' : opp.category}</Badge>
              </div>
              <Badge variant="outline" className={`text-[10px] ${opp.risk === 'Low' ? 'text-emerald-600 border-emerald-500/20' : opp.risk === 'Medium' ? 'text-amber-600 border-amber-500/20' : 'text-destructive border-destructive/20'}`}>
                {opp.risk} Risk
              </Badge>
            </div>
            
            <h3 className="font-bold text-base mb-2 leading-snug flex-1">{opp.desc}</h3>
            
            <div className="mt-4 pt-4 border-t border-border/50 flex items-end justify-between">
              <div>
                <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider mb-1">Est. Savings</p>
                <p className="text-xl font-extrabold text-emerald-600 tabular-nums">€{opp.amount.toLocaleString()}</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <OpportunityDetailPanel isOpen={!!selectedOpp} onClose={() => setSelectedOpp(null)} opp={selectedOpp} />
    </div>
  );
};

export default PendingOpportunitiesSection;