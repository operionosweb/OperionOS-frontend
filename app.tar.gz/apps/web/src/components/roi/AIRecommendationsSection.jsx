import React, { useState } from 'react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';
import { Zap, ChevronRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge.jsx';
import RecommendationDetailPanel from './RecommendationDetailPanel.jsx';

const AIRecommendationsSection = () => {
  const { recommendations } = useROISavings();
  const [selectedRec, setSelectedRec] = useState(null);

  if (recommendations.length === 0) {
    return (
      <div className="py-12 text-center text-muted-foreground bg-muted/20 rounded-2xl border border-dashed border-border">
        <Zap className="w-8 h-8 mx-auto mb-2 opacity-50" />
        <p>All recommendations have been processed.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {recommendations.map((rec) => (
          <div 
            key={rec.id}
            onClick={() => setSelectedRec(rec)}
            className="bg-primary/5 border border-primary/20 rounded-2xl p-5 hover:bg-primary/10 transition-colors cursor-pointer touch-target flex flex-col h-full"
          >
            <div className="flex justify-between items-start mb-3">
              <Badge variant="secondary" className="bg-background text-primary border-primary/20 text-[10px]">
                <Zap className="w-3 h-3 mr-1" /> AI Suggestion
              </Badge>
              <Badge variant="outline" className="text-[10px] bg-background">{rec.confidence} Conf.</Badge>
            </div>
            
            <h3 className="font-bold text-sm mb-2 leading-snug text-foreground">{rec.title}</h3>
            <p className="text-xs text-muted-foreground mb-4 flex-1 line-clamp-2">{rec.desc}</p>
            
            <div className="flex items-center justify-between mt-auto pt-3 border-t border-primary/10">
              <span className="font-bold text-emerald-600 tabular-nums">€{rec.amount.toLocaleString()}</span>
              <ChevronRight className="w-4 h-4 text-primary" />
            </div>
          </div>
        ))}
      </div>

      <RecommendationDetailPanel isOpen={!!selectedRec} onClose={() => setSelectedRec(null)} rec={selectedRec} />
    </div>
  );
};

export default AIRecommendationsSection;