import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Download, Users, Zap } from 'lucide-react';

const CrewOptimizationPanel = ({ isOpen, onClose, crew }) => {
  if (!crew) return null;

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-md md:max-w-lg overflow-y-auto">
        <SheetHeader className="mb-6">
          <div className="flex gap-2 mb-2">
            <Badge variant="secondary">{crew.role}</Badge>
          </div>
          <SheetTitle className="text-2xl font-bold">{crew.name}</SheetTitle>
          <SheetDescription>Crew-specific cost efficiency and optimizations.</SheetDescription>
        </SheetHeader>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-card border border-border rounded-xl p-4 text-center shadow-sm">
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Savings Generated</p>
              <p className="text-2xl font-extrabold text-emerald-600 tabular-nums">€{crew.totalSavings.toLocaleString()}</p>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 text-center shadow-sm">
              <p className="text-xs text-muted-foreground font-bold uppercase tracking-wider mb-1">Efficiency</p>
              <p className="text-2xl font-extrabold text-primary tabular-nums">+{crew.efficiency}%</p>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold flex items-center gap-2"><Zap className="w-4 h-4 text-amber-500"/> Optimizations Applied ({crew.optimizations})</h4>
            <div className="space-y-2">
              <div className="bg-muted/50 p-3 rounded-lg border border-border text-sm flex justify-between items-center">
                <span className="font-medium">Travel route consolidated</span>
                <span className="text-emerald-600 font-bold tabular-nums">+€1,200</span>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-border flex flex-col gap-3">
            <Button className="w-full touch-target">View Full Crew Profile</Button>
            <Button variant="outline" className="w-full touch-target"><Download className="w-4 h-4 mr-2"/> Export Report</Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default CrewOptimizationPanel;