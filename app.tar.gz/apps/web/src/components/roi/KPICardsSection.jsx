import React, { useState } from 'react';
import { useROISavings } from '@/contexts/ROISavingsContext.jsx';
import { TrendingUp, TrendingDown, DollarSign, Percent, Ship, Users, Zap } from 'lucide-react';
import KPIDetailPanel from './KPIDetailPanel.jsx';

const KPICardsSection = () => {
  const { kpiData } = useROISavings();
  const [selectedKPI, setSelectedKPI] = useState(null);

  const formatValue = (val, isPct) => {
    if (isPct) return `${val}%`;
    if (val >= 1000000) return `€${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `€${(val / 1000).toFixed(0)}K`;
    return `€${val}`;
  };

  const cards = [
    { key: 'totalSavings', icon: DollarSign, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { key: 'aiDrivenSavings', icon: Zap, color: 'text-primary', bg: 'bg-primary/10' },
    { key: 'costReduction', icon: Percent, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { key: 'savingsPerVessel', icon: Ship, color: 'text-indigo-500', bg: 'bg-indigo-500/10' },
    { key: 'savingsPerCrew', icon: Users, color: 'text-violet-500', bg: 'bg-violet-500/10' },
    { key: 'pendingOpportunities', icon: TrendingUp, color: 'text-amber-500', bg: 'bg-amber-500/10' }
  ];

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {cards.map((card) => {
          const data = kpiData[card.key];
          const Icon = card.icon;
          return (
            <div 
              key={card.key}
              onClick={() => setSelectedKPI(data)}
              className="bg-card border border-border rounded-2xl p-5 md:p-6 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 hover:border-primary/30 cursor-pointer active:scale-[0.98] touch-target flex flex-col justify-between min-h-[140px]"
            >
              <div className="flex justify-between items-start mb-4">
                <p className="text-sm font-medium text-muted-foreground">{data.label}</p>
                <div className={`p-2 rounded-lg ${card.bg}`}>
                  <Icon className={`w-5 h-5 ${card.color}`} />
                </div>
              </div>
              <div className="flex items-end justify-between">
                <p className="text-3xl md:text-4xl font-extrabold tabular-nums tracking-tight text-foreground">
                  {formatValue(data.value, data.isPercentage)}
                </p>
                <div className="flex items-center text-xs font-bold text-emerald-600 bg-emerald-500/10 px-2 py-1 rounded-md">
                  {data.trend}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <KPIDetailPanel 
        isOpen={!!selectedKPI} 
        onClose={() => setSelectedKPI(null)} 
        kpi={selectedKPI} 
      />
    </>
  );
};

export default KPICardsSection;