
import React from 'react';
import { useUserRole } from '@/hooks/useUserRole.js';
import { ROLES } from '@/constants/roles.js';
import CEODashboard from './dashboards/CEODashboard.jsx';
import ManagerDashboard from './dashboards/ManagerDashboard.jsx';
import OperatorDashboard from './dashboards/OperatorDashboard.jsx';
import ViewerDashboard from './dashboards/ViewerDashboard.jsx';

export default function RoleBasedUI() {
  const { role } = useUserRole();

  if (role === ROLES.SUPER_ADMIN) return <CEODashboard />;
  if (role === ROLES.ADMIN) return <ManagerDashboard />;
  if (role === ROLES.OPERATOR) return <OperatorDashboard />;
  
  return <ViewerDashboard />;
}
