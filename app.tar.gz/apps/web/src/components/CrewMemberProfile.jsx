import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Mail, Phone, MapPin, Calendar, ShieldCheck, AlertTriangle, Activity, FileText } from 'lucide-react';

const CrewMemberProfile = ({ crew, isOpen, onClose, onAction }) => {
  if (!crew) return null;

  const now = new Date();

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-xl md:max-w-2xl overflow-y-auto p-0">
        <div className="bg-muted/30 p-6 border-b border-border">
          <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
            <img src={crew.avatar} alt={crew.name} className="w-24 h-24 rounded-2xl object-cover border-2 border-background shadow-md" />
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <div>
                  <SheetTitle className="text-2xl font-bold">{crew.name}</SheetTitle>
                  <SheetDescription className="text-primary font-medium text-base mt-1">{crew.role}</SheetDescription>
                </div>
                <Badge variant="outline" className="bg-background">{crew.status}</Badge>
              </div>
              <div className="flex flex-wrap gap-4 mt-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><MapPin className="w-4 h-4"/> {crew.vessel}</span>
                <span className="flex items-center gap-1"><Mail className="w-4 h-4"/> {crew.contact?.email}</span>
                <span className="flex items-center gap-1"><Phone className="w-4 h-4"/> {crew.contact?.phone}</span>
              </div>
            </div>
          </div>
          
          <div className="flex gap-3 mt-6">
            {crew.status !== 'On Assignment' && <Button onClick={() => onAction('assign', crew)} className="flex-1">Assign Vessel</Button>}
            {crew.status === 'On Assignment' && <Button onClick={() => onAction('reassign', crew)} className="flex-1">Reassign</Button>}
            {crew.status !== 'On Leave' && <Button variant="outline" onClick={() => onAction('leave', crew)} className="flex-1">Mark On Leave</Button>}
          </div>
        </div>

        <div className="p-6">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="certifications">Certifications</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-6 focus-visible:outline-none">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold flex items-center gap-2"><Activity className="w-4 h-4 text-primary"/> Performance Metrics</h3>
                  <div className="bg-card border border-border rounded-xl p-4 space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">Utilization Rate</span>
                        <span className="font-medium">{crew.performanceMetrics?.utilization || 0}%</span>
                      </div>
                      <Progress value={crew.performanceMetrics?.utilization || 0} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-muted-foreground">On-Time Rotations</span>
                        <span className="font-medium">{crew.performanceMetrics?.onTimeRotations || 0}%</span>
                      </div>
                      <Progress value={crew.performanceMetrics?.onTimeRotations || 0} className="h-2" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold flex items-center gap-2"><Calendar className="w-4 h-4 text-primary"/> Contract Details</h3>
                  <div className="bg-card border border-border rounded-xl p-4 space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Hire Date</span>
                      <span className="font-medium">{crew.hireDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Contract End</span>
                      <span className={`font-medium ${new Date(crew.contractEndDate) < now ? 'text-destructive' : ''}`}>{crew.contractEndDate}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Nationality</span>
                      <span className="font-medium">{crew.nationality}</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="certifications" className="space-y-4 focus-visible:outline-none">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-primary"/> Active Certifications</h3>
                <Button variant="outline" size="sm">Add Certificate</Button>
              </div>
              <div className="space-y-3">
                {crew.certifications?.map((cert, idx) => {
                  const expiryDate = new Date(cert.expiry);
                  const daysUntilExpiry = (expiryDate - now) / (1000 * 60 * 60 * 24);
                  let statusColor = 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20';
                  if (daysUntilExpiry < 0) statusColor = 'bg-destructive/10 text-destructive border-destructive/20';
                  else if (daysUntilExpiry <= 30) statusColor = 'bg-warning/10 text-warning-foreground border-warning/20';

                  return (
                    <div key={idx} className="flex justify-between items-center p-4 rounded-xl border border-border bg-card">
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-muted-foreground" />
                        <span className="font-medium">{cert.name}</span>
                      </div>
                      <Badge variant="outline" className={statusColor}>
                        Exp: {cert.expiry}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="history" className="space-y-4 focus-visible:outline-none">
              <h3 className="font-semibold flex items-center gap-2"><MapPin className="w-4 h-4 text-primary"/> Assignment History</h3>
              <div className="relative border-l border-border ml-3 space-y-6 pb-4">
                {crew.assignmentHistory?.map((assignment, idx) => (
                  <div key={idx} className="relative pl-6">
                    <div className="absolute w-3 h-3 bg-primary rounded-full -left-[6.5px] top-1.5 ring-4 ring-background"></div>
                    <div className="bg-card border border-border rounded-xl p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-semibold">{assignment.vessel}</h4>
                        <span className="text-xs text-muted-foreground">{assignment.startDate} to {assignment.endDate}</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{assignment.role}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default CrewMemberProfile;