
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Bot, Send, X } from 'lucide-react';

const AIAssistantSafeMode = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const handleSend = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMsg = { id: Date.now(), role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    // Deterministic response (No auto-polling, no background intervals)
    const aiMsg = {
      id: Date.now() + 1,
      role: 'ai',
      content: `Received query. Static analysis confirms operations are compliant. No automated actions taken.`
    };
    setMessages(prev => [...prev, aiMsg]);
  };

  if (!isOpen) {
    return (
      <Button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full bg-primary hover:bg-primary/90 shadow-lg p-0"
        aria-label="Open AI Assistant"
      >
        <Bot className="w-6 h-6 text-primary-foreground" />
      </Button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-full max-w-[380px]">
      <Card className="border-border shadow-xl bg-card flex flex-col h-[500px]">
        <CardHeader className="py-3 bg-muted/30 border-b border-border/50 flex flex-row items-center justify-between shrink-0">
          <CardTitle className="text-sm font-bold flex items-center gap-2"><Bot className="w-4 h-4 text-primary" /> AI Assistant</CardTitle>
          <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => setIsOpen(false)}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center text-sm text-muted-foreground mt-4">
              I am ready when you are. I only act upon explicit requests.
            </div>
          )}
          {messages.map((msg) => (
            <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`px-3 py-2 rounded-lg text-sm max-w-[85%] ${
                msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground border border-border/50'
              }`}>
                {msg.content}
              </div>
            </div>
          ))}
        </CardContent>

        <CardFooter className="p-3 border-t border-border/50 shrink-0">
          <form onSubmit={handleSend} className="flex w-full gap-2">
            <Input 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Explicit command..."
              className="bg-muted/30"
            />
            <Button type="submit" size="icon" disabled={!input.trim()}>
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AIAssistantSafeMode;
