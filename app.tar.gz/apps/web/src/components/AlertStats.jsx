
import React from 'react';
import { Badge } from '@/components/ui/badge.jsx';
import { getSeverityColor } from '@/lib/alertRules.js';

export default function AlertStats({ alertStats }) {
  if (!alertStats) return null;

  const { critical = 0, warning = 0, info = 0 } = alertStats;

  return (
    <div className="flex items-center gap-2">
      {critical > 0 && (
        <Badge className={getSeverityColor('critical').badge}>
          Critical: {critical}
        </Badge>
      )}
      {warning > 0 && (
        <Badge className={getSeverityColor('warning').badge}>
          Warning: {warning}
        </Badge>
      )}
      {info > 0 && (
        <Badge className={getSeverityColor('info').badge}>
          Info: {info}
        </Badge>
      )}
      {critical === 0 && warning === 0 && info === 0 && (
        <span className="text-sm text-muted-foreground">All caught up</span>
      )}
    </div>
  );
}
