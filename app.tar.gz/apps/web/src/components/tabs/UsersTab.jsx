
import React, { useState } from 'react';
import { useSafeData } from '@/hooks/useSafeData.js';
import { useSearch } from '@/hooks/useSearch.js';
import { useFilter } from '@/hooks/useFilter.js';
import { useDetailPanel } from '@/hooks/useDetailPanel.js';
import { performAction } from '@/lib/actionUtils.js';
import GlobalSearch from '@/components/ui/GlobalSearch.jsx';
import AdvancedFilters from '@/components/ui/AdvancedFilters.jsx';
import FilterControls from '@/components/ui/FilterControls.jsx';
import UserCard from '@/components/ui/UserCard.jsx';
import UserDetailPanel from '@/components/ui/UserDetailPanel.jsx';
import EditUserModal from '@/components/ui/EditUserModal.jsx';
import CreateUserModal from '@/components/ui/CreateUserModal.jsx';
import DeleteConfirmation from '@/components/ui/DeleteConfirmation.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Plus } from 'lucide-react';

export default function UsersTab() {
  const rawData = useSafeData([], 'users');
  const { searchQuery, setSearchQuery, searchedData } = useSearch(rawData, ['name', 'email', 'company_name']);
  const { filters, updateFilter, clearFilters, filteredData } = useFilter(searchedData, { role: 'all', status: 'all' });
  
  const { isOpen: isPanelOpen, selectedItem, openPanel, closePanel } = useDetailPanel();
  const [modalState, setModalState] = useState({ type: null, item: null });

  const handleAction = async (action, item) => {
    await performAction(action, item);
    setModalState({ type: null, item: null });
    if (action === 'Delete User') closePanel();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 bg-card p-4 rounded-xl border border-border shadow-sm">
        <GlobalSearch onSearch={setSearchQuery} />
        <div className="flex items-center gap-4">
          <AdvancedFilters onClear={clearFilters}>
            <FilterControls 
              filters={filters} 
              onFilterChange={updateFilter}
              options={[
                { key: 'role', label: 'Role', values: [{label: 'Admin', value: 'admin'}, {label: 'Operator', value: 'operator'}] },
                { key: 'status', label: 'Status', values: [{label: 'Active', value: 'active'}, {label: 'Inactive', value: 'inactive'}] }
              ]} 
            />
          </AdvancedFilters>
          <Button onClick={() => setModalState({ type: 'create', item: null })}><Plus className="w-4 h-4 mr-2"/> Create User</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredData.map(user => (
          <UserCard 
            key={user.id} 
            user={user} 
            onClick={(u) => openPanel(u, 'user')}
            onEdit={(u) => setModalState({ type: 'edit', item: u })}
            onDelete={(u) => setModalState({ type: 'delete', item: u })}
          />
        ))}
      </div>

      <UserDetailPanel 
        isOpen={isPanelOpen} 
        onClose={closePanel} 
        user={selectedItem} 
        onEdit={(u) => setModalState({ type: 'edit', item: u })}
        onDelete={(u) => setModalState({ type: 'delete', item: u })}
      />

      <EditUserModal isOpen={modalState.type === 'edit'} onClose={() => setModalState({ type: null, item: null })} user={modalState.item} onSave={(u) => handleAction('Update User', u)} />
      <CreateUserModal isOpen={modalState.type === 'create'} onClose={() => setModalState({ type: null, item: null })} onSave={(u) => handleAction('Create User', u)} />
      <DeleteConfirmation isOpen={modalState.type === 'delete'} onClose={() => setModalState({ type: null, item: null })} onConfirm={() => handleAction('Delete User', modalState.item)} itemName={modalState.item?.name} />
    </div>
  );
}
