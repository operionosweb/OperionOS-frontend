
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card.jsx';
import { Switch } from '@/components/ui/switch.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Button } from '@/components/ui/button.jsx';
import { getFeatureFlag, setFeatureFlag } from '@/config/featureFlags.js';
import { Download, Upload, RefreshCw } from 'lucide-react';

export default function SettingsTab() {
  const [enableDemoData, setEnableDemoData] = useState(true);

  useEffect(() => {
    setEnableDemoData(getFeatureFlag('ENABLE_DEMO_DATA'));
  }, []);

  const handleToggleDemoData = (checked) => {
    setEnableDemoData(checked);
    setFeatureFlag('ENABLE_DEMO_DATA', checked);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>Data Configuration</CardTitle>
          <CardDescription>Manage how data is sourced and displayed in the Control Panel.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-muted/30">
            <div className="space-y-0.5">
              <Label className="text-base">Enable Mock Data</Label>
              <p className="text-sm text-muted-foreground">
                When enabled, the system will generate deterministic mock data if real data is unavailable. Disable to view only real database records.
              </p>
            </div>
            <Switch checked={enableDemoData} onCheckedChange={handleToggleDemoData} />
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle>System Operations</CardTitle>
          <CardDescription>Administrative actions for system maintenance.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <Button variant="outline" className="gap-2">
              <Download className="w-4 h-4" /> Export System State
            </Button>
            <Button variant="outline" className="gap-2">
              <Upload className="w-4 h-4" /> Import Configuration
            </Button>
            <Button variant="outline" className="gap-2 text-destructive hover:text-destructive hover:bg-destructive/10">
              <RefreshCw className="w-4 h-4" /> Clear Cache
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
