
import React, { useState } from 'react';
import { useSafeData } from '@/hooks/useSafeData.js';
import { useSearch } from '@/hooks/useSearch.js';
import { useFilter } from '@/hooks/useFilter.js';
import { useDetailPanel } from '@/hooks/useDetailPanel.js';
import { performAction } from '@/lib/actionUtils.js';
import GlobalSearch from '@/components/ui/GlobalSearch.jsx';
import AdvancedFilters from '@/components/ui/AdvancedFilters.jsx';
import FilterControls from '@/components/ui/FilterControls.jsx';
import AssetCard from '@/components/ui/AssetCard.jsx';
import AssetDetailPanel from '@/components/ui/AssetDetailPanel.jsx';
import DeleteConfirmation from '@/components/ui/DeleteConfirmation.jsx';

export default function FleetTab() {
  const rawData = useSafeData([], 'fleet');
  const { searchQuery, setSearchQuery, searchedData } = useSearch(rawData, ['asset_name', 'company_name']);
  const { filters, updateFilter, clearFilters, filteredData } = useFilter(searchedData, { type: 'all', status: 'all' });
  
  const { isOpen: isPanelOpen, selectedItem, openPanel, closePanel } = useDetailPanel();
  const [modalState, setModalState] = useState({ type: null, item: null });

  const handleAction = async (action, item) => {
    await performAction(action, item);
    setModalState({ type: null, item: null });
    if (action === 'Delete Asset') closePanel();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 bg-card p-4 rounded-xl border border-border shadow-sm">
        <GlobalSearch onSearch={setSearchQuery} />
        <AdvancedFilters onClear={clearFilters}>
          <FilterControls 
            filters={filters} 
            onFilterChange={updateFilter}
            options={[
              { key: 'type', label: 'Type', values: [{label: 'Vessel', value: 'Vessel'}, {label: 'Aircraft', value: 'Aircraft'}] },
              { key: 'status', label: 'Status', values: [{label: 'Active', value: 'active'}, {label: 'Maintenance', value: 'maintenance'}] }
            ]} 
          />
        </AdvancedFilters>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredData.map(asset => (
          <AssetCard 
            key={asset.id} 
            asset={asset} 
            onClick={(a) => openPanel(a, 'asset')}
            onEdit={(a) => handleAction('Edit Asset', a)}
            onDelete={(a) => setModalState({ type: 'delete', item: a })}
          />
        ))}
      </div>

      <AssetDetailPanel 
        isOpen={isPanelOpen} 
        onClose={closePanel} 
        asset={selectedItem} 
        onEdit={(a) => handleAction('Edit Asset', a)}
        onDelete={(a) => setModalState({ type: 'delete', item: a })}
      />

      <DeleteConfirmation isOpen={modalState.type === 'delete'} onClose={() => setModalState({ type: null, item: null })} onConfirm={() => handleAction('Delete Asset', modalState.item)} itemName={modalState.item?.asset_name} />
    </div>
  );
}
