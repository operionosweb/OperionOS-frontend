
import React from 'react';
import { useSafeData } from '@/hooks/useSafeData.js';
import { useSearch } from '@/hooks/useSearch.js';
import { useFilter } from '@/hooks/useFilter.js';
import { useSort } from '@/hooks/useSort.js';
import { usePagination } from '@/hooks/usePagination.js';
import SearchBar from '@/components/ui/SearchBar.jsx';
import FilterControls from '@/components/ui/FilterControls.jsx';
import SortControls from '@/components/ui/SortControls.jsx';
import Pagination from '@/components/ui/Pagination.jsx';
import DataTable from '@/components/ui/DataTable.jsx';
import StatusBadge from '@/components/ui/StatusBadge.jsx';

export default function SystemLogsTab() {
  const rawData = useSafeData([], 'systemLogs');
  
  const { searchQuery, setSearchQuery, searchedData } = useSearch(rawData, ['event', 'user_name', 'company_name', 'description']);
  const { filters, updateFilter, filteredData } = useFilter(searchedData, { severity: 'all' });
  const { sortConfig, requestSort, sortedData } = useSort(filteredData, 'timestamp', 'desc');
  const { currentPage, totalPages, goToPage, paginatedData, totalItems } = usePagination(sortedData, 10);

  const columns = [
    { header: 'Timestamp', accessor: 'timestamp', render: (row) => new Date(row.timestamp).toLocaleString() },
    { header: 'Event', accessor: 'event', className: 'font-medium' },
    { header: 'Severity', accessor: 'severity', render: (row) => <StatusBadge status={row.severity} /> },
    { header: 'User', accessor: 'user_name' },
    { header: 'Company', accessor: 'company_name' },
    { header: 'Description', accessor: 'description', className: 'text-muted-foreground max-w-[300px] truncate' }
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4 bg-card p-4 rounded-xl border border-border shadow-sm">
        <SearchBar value={searchQuery} onChange={setSearchQuery} placeholder="Search logs..." />
        <div className="flex flex-wrap items-center gap-4">
          <FilterControls 
            filters={filters} 
            onFilterChange={updateFilter}
            options={[
              { key: 'severity', label: 'Severity', values: [{label: 'Info', value: 'info'}, {label: 'Warning', value: 'warning'}, {label: 'Error', value: 'error'}] }
            ]} 
          />
          <SortControls 
            sortConfig={sortConfig} 
            onSortChange={requestSort}
            options={[
              { label: 'Timestamp', value: 'timestamp' },
              { label: 'Event', value: 'event' }
            ]}
          />
        </div>
      </div>

      <DataTable columns={columns} data={paginatedData} />
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={goToPage} totalItems={totalItems} />
    </div>
  );
}
