
import React, { useState } from 'react';
import { useSafeData } from '@/hooks/useSafeData.js';
import { useSearch } from '@/hooks/useSearch.js';
import { useFilter } from '@/hooks/useFilter.js';
import { useDetailPanel } from '@/hooks/useDetailPanel.js';
import { performAction } from '@/lib/actionUtils.js';
import GlobalSearch from '@/components/ui/GlobalSearch.jsx';
import AdvancedFilters from '@/components/ui/AdvancedFilters.jsx';
import FilterControls from '@/components/ui/FilterControls.jsx';
import OperationCard from '@/components/ui/OperationCard.jsx';
import OperationDetailPanel from '@/components/ui/OperationDetailPanel.jsx';
import DeleteConfirmation from '@/components/ui/DeleteConfirmation.jsx';

export default function OperationsTab() {
  const rawData = useSafeData([], 'operations');
  const { searchQuery, setSearchQuery, searchedData } = useSearch(rawData, ['type', 'company_name']);
  const { filters, updateFilter, clearFilters, filteredData } = useFilter(searchedData, { status: 'all' });
  
  const { isOpen: isPanelOpen, selectedItem, openPanel, closePanel } = useDetailPanel();
  const [modalState, setModalState] = useState({ type: null, item: null });

  const handleAction = async (action, item) => {
    await performAction(action, item);
    setModalState({ type: null, item: null });
    if (action === 'Delete Operation') closePanel();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 bg-card p-4 rounded-xl border border-border shadow-sm">
        <GlobalSearch onSearch={setSearchQuery} />
        <AdvancedFilters onClear={clearFilters}>
          <FilterControls 
            filters={filters} 
            onFilterChange={updateFilter}
            options={[
              { key: 'status', label: 'Status', values: [{label: 'In Progress', value: 'in_progress'}, {label: 'Completed', value: 'completed'}] }
            ]} 
          />
        </AdvancedFilters>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredData.map(op => (
          <OperationCard 
            key={op.id} 
            operation={op} 
            onClick={(o) => openPanel(o, 'operation')}
            onEdit={(o) => handleAction('Edit Operation', o)}
            onDelete={(o) => setModalState({ type: 'delete', item: o })}
          />
        ))}
      </div>

      <OperationDetailPanel 
        isOpen={isPanelOpen} 
        onClose={closePanel} 
        operation={selectedItem} 
        onEdit={(o) => handleAction('Edit Operation', o)}
        onDelete={(o) => setModalState({ type: 'delete', item: o })}
      />

      <DeleteConfirmation isOpen={modalState.type === 'delete'} onClose={() => setModalState({ type: null, item: null })} onConfirm={() => handleAction('Delete Operation', modalState.item)} itemName={modalState.item?.type} />
    </div>
  );
}
