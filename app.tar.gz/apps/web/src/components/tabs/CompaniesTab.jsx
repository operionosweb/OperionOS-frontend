
import React, { useState } from 'react';
import { useSafeData } from '@/hooks/useSafeData.js';
import { useSearch } from '@/hooks/useSearch.js';
import { useFilter } from '@/hooks/useFilter.js';
import { useDetailPanel } from '@/hooks/useDetailPanel.js';
import { performAction } from '@/lib/actionUtils.js';
import GlobalSearch from '@/components/ui/GlobalSearch.jsx';
import AdvancedFilters from '@/components/ui/AdvancedFilters.jsx';
import FilterControls from '@/components/ui/FilterControls.jsx';
import CompanyCard from '@/components/ui/CompanyCard.jsx';
import CompanyDetailPanel from '@/components/ui/CompanyDetailPanel.jsx';
import EditCompanyModal from '@/components/ui/EditCompanyModal.jsx';
import CreateCompanyModal from '@/components/ui/CreateCompanyModal.jsx';
import DeleteConfirmation from '@/components/ui/DeleteConfirmation.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Plus } from 'lucide-react';

export default function CompaniesTab() {
  const rawData = useSafeData([], 'companies');
  const { searchQuery, setSearchQuery, searchedData } = useSearch(rawData, ['company_name', 'industry']);
  const { filters, updateFilter, clearFilters, filteredData } = useFilter(searchedData, { status: 'all', industry: 'all' });
  
  const { isOpen: isPanelOpen, selectedItem, openPanel, closePanel } = useDetailPanel();
  const [modalState, setModalState] = useState({ type: null, item: null });

  const handleAction = async (action, item) => {
    await performAction(action, item);
    setModalState({ type: null, item: null });
    if (action === 'Delete Company') closePanel();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 bg-card p-4 rounded-xl border border-border shadow-sm">
        <GlobalSearch onSearch={setSearchQuery} />
        <div className="flex items-center gap-4">
          <AdvancedFilters onClear={clearFilters}>
            <FilterControls 
              filters={filters} 
              onFilterChange={updateFilter}
              options={[
                { key: 'status', label: 'Status', values: [{label: 'Active', value: 'active'}, {label: 'Inactive', value: 'inactive'}] },
                { key: 'industry', label: 'Industry', values: [{label: 'Maritime', value: 'Maritime'}, {label: 'Aviation', value: 'Aviation'}] }
              ]} 
            />
          </AdvancedFilters>
          <Button onClick={() => setModalState({ type: 'create', item: null })}><Plus className="w-4 h-4 mr-2"/> Create Company</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredData.map(company => (
          <CompanyCard 
            key={company.id} 
            company={company} 
            onClick={(c) => openPanel(c, 'company')}
            onEdit={(c) => setModalState({ type: 'edit', item: c })}
            onDelete={(c) => setModalState({ type: 'delete', item: c })}
          />
        ))}
      </div>

      <CompanyDetailPanel 
        isOpen={isPanelOpen} 
        onClose={closePanel} 
        company={selectedItem} 
        onEdit={(c) => setModalState({ type: 'edit', item: c })}
        onDelete={(c) => setModalState({ type: 'delete', item: c })}
      />

      <EditCompanyModal isOpen={modalState.type === 'edit'} onClose={() => setModalState({ type: null, item: null })} company={modalState.item} onSave={(c) => handleAction('Update Company', c)} />
      <CreateCompanyModal isOpen={modalState.type === 'create'} onClose={() => setModalState({ type: null, item: null })} onSave={(c) => handleAction('Create Company', c)} />
      <DeleteConfirmation isOpen={modalState.type === 'delete'} onClose={() => setModalState({ type: null, item: null })} onConfirm={() => handleAction('Delete Company', modalState.item)} itemName={modalState.item?.company_name} />
    </div>
  );
}
