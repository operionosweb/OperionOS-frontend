
import React, { useRef, useEffect } from 'react';

const TabNavigation = React.memo(({ tabs, activeTab, onTabChange }) => {
  const navRef = useRef(null);

  const handleKeyDown = (e) => {
    const currentIndex = tabs.findIndex(t => t.id === activeTab);
    let nextIndex = currentIndex;

    if (e.key === 'ArrowRight') {
      nextIndex = (currentIndex + 1) % tabs.length;
    } else if (e.key === 'ArrowLeft') {
      nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
    } else {
      return;
    }

    e.preventDefault();
    onTabChange(tabs[nextIndex].id);
    
    // Focus the new button
    const buttons = navRef.current?.querySelectorAll('button');
    if (buttons && buttons[nextIndex]) {
      buttons[nextIndex].focus();
    }
  };

  return (
    <div 
      ref={navRef}
      className="flex space-x-6 border-b border-gray-200 overflow-x-auto w-full px-6 bg-white hide-scrollbar"
      role="tablist"
      aria-label="Application Tabs"
      onKeyDown={handleKeyDown}
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`py-3 px-1 text-sm transition-all duration-150 whitespace-nowrap border-b-2 outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-1 rounded-t-sm ${
              isActive
                ? 'border-[#3B82F6] text-gray-900 font-semibold'
                : 'border-transparent text-[#6B7280] font-medium hover:text-gray-900 hover:border-gray-300'
            }`}
            aria-selected={isActive}
            role="tab"
            tabIndex={isActive ? 0 : -1}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
});

TabNavigation.displayName = 'TabNavigation';
export default TabNavigation;
