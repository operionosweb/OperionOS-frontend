import React, { useState, useEffect, useCallback } from 'react';
import { useTabData } from '@/hooks/useTabData.js';
import { useTabRefresh } from '@/hooks/useTabRefresh.js';
import PageHeader from '@/components/PageHeader.jsx';
import MetricCard from '@/components/MetricCard.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { RefreshCw, Users, UserCheck, AlertTriangle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton.jsx';

const fetchCrew = async (isDemo) => {
  await new Promise(resolve => setTimeout(resolve, 600));
  return {
    metrics: { total: 145, active: 112, resting: 33 },
    list: [
      { id: 1, name: 'Capt. Sarah Jenkins', role: 'Command', status: 'On Duty' },
      { id: 2, name: 'First Officer Vance', role: 'Navigation', status: 'Resting' }
    ]
  };
};

const CrewTab = React.memo(({ companyId, isDemoActive }) => {
  const fetcher = useCallback(() => fetchCrew(isDemoActive), [isDemoActive]);
  const { data, loading: fetchLoading } = useTabData('crew', companyId, fetcher);
  const [currentData, setCurrentData] = useState(null);

  useEffect(() => { if (data) setCurrentData(data); }, [data]);
  const { handleRefresh, loading: refreshLoading } = useTabRefresh('crew', companyId, fetcher, setCurrentData);
  const isLoading = fetchLoading || refreshLoading;

  return (
    <div className="w-full">
      <PageHeader 
        title="Crew Roster" 
        subtitle="Manage personnel, rotations, and compliance status."
        actions={
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isLoading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} /> Refresh
          </Button>
        }
      />
      
      <div className="summary-section">
        {isLoading && !currentData ? (
          <div className="summary-grid">
            <Skeleton className="h-[100px] rounded-[8px]" />
            <Skeleton className="h-[100px] rounded-[8px]" />
            <Skeleton className="h-[100px] rounded-[8px]" />
          </div>
        ) : currentData && (
          <div className="summary-grid">
            <MetricCard label="Total Crew" value={currentData.metrics.total} icon={Users} />
            <MetricCard label="Active Duty" value={currentData.metrics.active} icon={UserCheck} />
            <MetricCard label="Resting" value={currentData.metrics.resting} icon={AlertTriangle} />
          </div>
        )}
      </div>

      <div className="detailed-content">
        {currentData?.list && (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentData.list.map((crew) => (
                <TableRow key={crew.id}>
                  <TableCell className="font-medium">{crew.name}</TableCell>
                  <TableCell>{crew.role}</TableCell>
                  <TableCell>
                    <Badge variant={crew.status === 'On Duty' ? 'success' : 'secondary'}>{crew.status}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  );
});
CrewTab.displayName = 'CrewTab';
export default CrewTab;