import React, { useState, useEffect, useCallback } from 'react';
import { useTabData } from '@/hooks/useTabData.js';
import { useTabRefresh } from '@/hooks/useTabRefresh.js';
import PageHeader from '@/components/PageHeader.jsx';
import MetricCard from '@/components/MetricCard.jsx';
import { Button } from '@/components/ui/button.jsx';
import { RefreshCw, Activity, ShieldCheck, MapPin } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton.jsx';

const fetchOverview = async (isDemo) => {
  await new Promise(resolve => setTimeout(resolve, 500));
  return { activeRoutes: 12, complianceScore: 98, activeAlerts: 2 };
};

const OverviewTab = React.memo(({ companyId, isDemoActive }) => {
  const fetcher = useCallback(() => fetchOverview(isDemoActive), [isDemoActive]);
  const { data, loading: fetchLoading } = useTabData('overview', companyId, fetcher);
  const [currentData, setCurrentData] = useState(null);

  useEffect(() => { if (data) setCurrentData(data); }, [data]);
  const { handleRefresh, loading: refreshLoading } = useTabRefresh('overview', companyId, fetcher, setCurrentData);
  const isLoading = fetchLoading || refreshLoading;

  return (
    <div className="w-full">
      <PageHeader 
        title="System Overview" 
        subtitle="Global logistics network status and high-level performance metrics."
        actions={
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isLoading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} /> Refresh
          </Button>
        }
      />
      
      <div className="summary-section">
        {isLoading && !currentData ? (
          <div className="summary-grid">
            <Skeleton className="h-[100px] rounded-[8px]" />
            <Skeleton className="h-[100px] rounded-[8px]" />
            <Skeleton className="h-[100px] rounded-[8px]" />
          </div>
        ) : currentData && (
          <div className="summary-grid">
            <MetricCard label="Active Routes" value={currentData.activeRoutes} icon={MapPin} trend="up" trendValue="+2 from yesterday" />
            <MetricCard label="Compliance Score" value={currentData.complianceScore} unit="/ 100" icon={ShieldCheck} trend="up" trendValue="Optimal" />
            <MetricCard label="Active Alerts" value={currentData.activeAlerts} icon={Activity} trend="down" trendValue="-3 resolved" />
          </div>
        )}
      </div>

      <div className="detailed-content">
        <div className="p-[24px] text-center text-gray-500 border border-dashed border-gray-300 rounded-[8px] bg-gray-50">
          <p className="font-medium text-gray-700 mb-1">Detailed Map View</p>
          <p className="text-sm">Select 'Command Center' for interactive geographical tracking.</p>
        </div>
      </div>
    </div>
  );
});
OverviewTab.displayName = 'OverviewTab';
export default OverviewTab;