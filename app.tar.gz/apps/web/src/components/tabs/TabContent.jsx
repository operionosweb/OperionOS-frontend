
import React from 'react';

const TabContent = React.memo(({ children }) => {
  return (
    <div className="tab-content transition-opacity duration-200 ease-in-out opacity-100 animate-in fade-in w-full">
      {children}
    </div>
  );
});

TabContent.displayName = 'TabContent';
export default TabContent;
