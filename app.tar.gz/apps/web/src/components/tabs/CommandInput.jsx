
import React, { useState } from 'react';
import { Input } from '@/components/ui/input.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Terminal } from 'lucide-react';

export default function CommandInput({ onCommandSubmit, error }) {
  const [input, setInput] = useState('');

  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    if (!input.trim()) return;
    
    const success = onCommandSubmit(input);
    if (success) {
      setInput('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Terminal className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter command (e.g., 'go to crew')"
            className="pl-9 font-mono text-sm"
            autoComplete="off"
            spellCheck="false"
          />
        </div>
        <Button type="submit">Execute</Button>
      </div>
      {error && <p className="text-sm text-destructive font-medium">{error}</p>}
    </form>
  );
}
