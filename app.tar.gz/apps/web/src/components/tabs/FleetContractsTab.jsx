
import React, { useState, useMemo, useEffect } from 'react';
import { Search, BrainCircuit, Activity, LineChart, FileText, RefreshCw, ShieldAlert } from 'lucide-react';
import { useSafeData } from '@/hooks/useSafeData.js';
import { generateMockFleetContracts } from '@/lib/mockData/fleetContracts.js';
import { analyzeContractRisk } from '@/lib/contractAnalysis.js';
import { getCompanyOptions, filterContracts } from '@/lib/contractUtils.js';
import { generateAlerts } from '@/lib/alertEngine.js';
import { generateForecasts } from '@/lib/forecastingEngine.js';

import ContractAlertDashboard from '@/components/ContractAlertDashboard.jsx';
import ContractFilters from '@/components/ContractFilters.jsx';
import ContractCard from '@/components/ContractCard.jsx';
import ContractDetailPanel from '@/components/ContractDetailPanel.jsx';
import AlertFeed from '@/components/AlertFeed.jsx';
import ContractForecasting from '@/components/ContractForecasting.jsx';
import FinancialSimulation from '@/components/FinancialSimulation.jsx';
import NegotiationAssistant from '@/components/NegotiationAssistant.jsx';

// New Monitoring Components
import ContractMonitoringDashboard from '@/components/ContractMonitoringDashboard.jsx';
import ContractRiskCard from '@/components/ContractRiskCard.jsx';
import ExpiringContractsList from '@/components/ExpiringContractsList.jsx';
import FinancialExposurePanel from '@/components/FinancialExposurePanel.jsx';
import { useContractMonitoring } from '@/hooks/useContractMonitoring.js';

import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs.jsx';
import { useRealTimeEvents } from '@/hooks/useRealTimeEvents.js';
import { CONTRACT_UPDATED, ALERT_TRIGGERED } from '@/types/events.js';
import { useDataSync } from '@/hooks/useDataSync.js';

export default function FleetContractsTab() {
  const rawContracts = useSafeData(generateMockFleetContracts(), 'fleet_contracts');
  const [analyzedContracts, setAnalyzedContracts] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [forecasts, setForecasts] = useState([]);
  
  const [selectedContract, setSelectedContract] = useState(null);
  const [activeTab, setActiveTab] = useState('monitoring'); // Default to new monitoring tab
  const [isDetailPanelOpen, setIsDetailPanelOpen] = useState(false);
  
  // Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    status: 'all',
    assetType: 'all',
    company: 'all',
    riskLevel: 'all'
  });
  const [activeDashFilter, setActiveDashFilter] = useState('all');

  const { isPolling, lastSyncTime } = useDataSync();
  const { getHighRiskContracts, acknowledgeAlert } = useContractMonitoring();

  // Initial Data Load
  useEffect(() => {
    if (rawContracts && rawContracts.length > 0) {
      const processed = rawContracts.map(analyzeContractRisk);
      setAnalyzedContracts(processed);
      setAlerts(generateAlerts(processed));
      setForecasts(generateForecasts(processed));
    }
  }, [rawContracts]);

  // Real-time Event Subscriptions
  useRealTimeEvents(CONTRACT_UPDATED, (payload) => {
    if (payload.data) {
      const analyzed = analyzeContractRisk(payload.data);
      setAnalyzedContracts(prev => {
        const index = prev.findIndex(c => c.contract_id === analyzed.contract_id);
        if (index >= 0) {
          const newArr = [...prev];
          newArr[index] = analyzed;
          return newArr;
        }
        return [analyzed, ...prev];
      });
      
      if (selectedContract?.contract_id === analyzed.contract_id) {
        setSelectedContract(analyzed);
      }
    }
  });

  useRealTimeEvents(ALERT_TRIGGERED, (payload) => {
    if (payload.data) {
      setAlerts(prev => [payload.data, ...prev]);
    }
  });

  const companyOptions = useMemo(() => getCompanyOptions(analyzedContracts), [analyzedContracts]);

  const stats = useMemo(() => {
    return {
      total: analyzedContracts.length,
      expiring: analyzedContracts.filter(c => c.days_until_expiry >= 0 && c.days_until_expiry <= 90).length,
      highRisk: analyzedContracts.filter(c => c.risk_level === 'High').length,
      expired: analyzedContracts.filter(c => c.status === 'Expired').length
    };
  }, [analyzedContracts]);

  const displayedContracts = useMemo(() => {
    let result = filterContracts(analyzedContracts, filters, searchTerm);
    if (activeDashFilter === 'expiring') {
      result = result.filter(c => c.days_until_expiry >= 0 && c.days_until_expiry <= 90);
    } else if (activeDashFilter === 'highRisk') {
      result = result.filter(c => c.risk_level === 'High');
    } else if (activeDashFilter === 'expired') {
      result = result.filter(c => c.status === 'Expired');
    }
    return result;
  }, [analyzedContracts, filters, searchTerm, activeDashFilter]);

  const handleCardClick = (contract) => {
    setSelectedContract(contract);
    setIsDetailPanelOpen(true);
  };

  const handleAlertClick = (alert) => {
    const contract = analyzedContracts.find(c => (c.contract_id || c.id) === alert.entity_id);
    if (contract) {
      setSelectedContract(contract);
      setActiveTab('contracts');
      setIsDetailPanelOpen(true);
    }
  };

  const handleDashFilter = (filterKey) => {
    setActiveDashFilter(prev => prev === filterKey ? 'all' : filterKey);
  };

  const selectedForecast = useMemo(() => {
    if (!selectedContract) return null;
    return forecasts.find(f => f.contract_id === selectedContract.contract_id);
  }, [selectedContract, forecasts]);

  const highRiskContracts = getHighRiskContracts();

  return (
    <div className="space-y-8 pb-12">
      
      {/* TOP SECTION: Alert Feed */}
      <section className="animate-in fade-in slide-in-from-bottom-4 duration-500">
        <AlertFeed alerts={alerts} onAlertClick={handleAlertClick} />
      </section>

      {/* MIDDLE SECTION: Intelligence Tabs */}
      <section className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="border-b border-border bg-muted/20 px-4 py-3 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-xl font-bold text-foreground">Contract Intelligence Hub</h2>
                {isPolling && (
                  <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    Live Sync
                  </div>
                )}
              </div>
              <p className="text-sm text-muted-foreground mt-0.5">
                {selectedContract 
                  ? `Active Analysis: ${selectedContract.asset_name} (${selectedContract.contract_id})` 
                  : 'Select a contract to activate deep analysis'}
              </p>
            </div>
            
            <TabsList className="bg-background border border-border h-10 p-1 flex-wrap h-auto sm:h-10">
              <TabsTrigger value="monitoring" className="text-sm px-4 data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none">
                <ShieldAlert className="w-4 h-4 mr-2" /> Live Monitoring
              </TabsTrigger>
              <TabsTrigger value="contracts" className="text-sm px-4 data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none">
                <FileText className="w-4 h-4 mr-2" /> Database
              </TabsTrigger>
              <TabsTrigger value="forecasting" className="text-sm px-4 data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none">
                <Activity className="w-4 h-4 mr-2" /> Forecast
              </TabsTrigger>
              <TabsTrigger value="financial" className="text-sm px-4 data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none">
                <LineChart className="w-4 h-4 mr-2" /> Financial
              </TabsTrigger>
              <TabsTrigger value="negotiation" className="text-sm px-4 data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none">
                <BrainCircuit className="w-4 h-4 mr-2" /> AI Negotiation
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="p-6">
            
            {/* TAB: LIVE MONITORING (NEW) */}
            <TabsContent value="monitoring" className="m-0 focus-visible:outline-none space-y-8">
              <ContractMonitoringDashboard />
              
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-destructive" /> High Risk Contracts
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {highRiskContracts.slice(0, 3).map(contract => (
                    <ContractRiskCard 
                      key={contract.contract_id} 
                      contract={contract} 
                      onViewDetails={handleCardClick}
                      onAcknowledge={() => console.log('Acknowledged risk for', contract.contract_id)}
                    />
                  ))}
                  {highRiskContracts.length === 0 && (
                    <div className="col-span-full py-8 text-center text-muted-foreground bg-muted/20 rounded-xl border border-dashed border-border">
                      No high risk contracts detected.
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-bold text-foreground">Financial Exposure</h3>
                <FinancialExposurePanel />
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-bold text-foreground">Expiring Contracts Action List</h3>
                <ExpiringContractsList />
              </div>
            </TabsContent>

            {/* TAB: CONTRACTS DATABASE */}
            <TabsContent value="contracts" className="m-0 focus-visible:outline-none">
              <div className="space-y-6">
                <ContractAlertDashboard 
                  stats={stats} 
                  activeFilter={activeDashFilter}
                  onSelectFilter={handleDashFilter}
                />
                <ContractFilters 
                  filters={filters}
                  setFilters={setFilters}
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  companyOptions={companyOptions}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {displayedContracts.map(contract => (
                    <ContractCard 
                      key={contract.contract_id} 
                      contract={contract} 
                      onClick={() => handleCardClick(contract)}
                      isActive={selectedContract?.contract_id === contract.contract_id}
                    />
                  ))}
                  {displayedContracts.length === 0 && (
                    <div className="col-span-full py-12 text-center bg-background rounded-xl border border-border border-dashed">
                      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-muted text-muted-foreground mb-4">
                        <Search className="w-6 h-6" />
                      </div>
                      <h3 className="text-lg font-medium text-foreground">No contracts found</h3>
                      <p className="text-muted-foreground mt-1">Try adjusting your filters or search term.</p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* TAB: FORECASTING */}
            <TabsContent value="forecasting" className="m-0 focus-visible:outline-none">
              <ContractForecasting forecast={selectedForecast} />
            </TabsContent>

            {/* TAB: FINANCIAL ANALYSIS */}
            <TabsContent value="financial" className="m-0 focus-visible:outline-none">
              <FinancialSimulation contract={selectedContract} />
            </TabsContent>

            {/* TAB: NEGOTIATION */}
            <TabsContent value="negotiation" className="m-0 focus-visible:outline-none">
              <NegotiationAssistant contract={selectedContract} />
            </TabsContent>

          </div>
        </Tabs>
      </section>

      {/* Detail Panel Modal/Slide-over */}
      <ContractDetailPanel 
        isOpen={isDetailPanelOpen}
        onClose={() => setIsDetailPanelOpen(false)}
        contract={selectedContract}
        onAnalyze={() => {
          setIsDetailPanelOpen(false);
          setActiveTab('forecasting');
        }}
      />
    </div>
  );
}
