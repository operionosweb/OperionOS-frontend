
import React from 'react';
import { useSafeData } from '@/hooks/useSafeData.js';
import { useSearch } from '@/hooks/useSearch.js';
import { useFilter } from '@/hooks/useFilter.js';
import { useSort } from '@/hooks/useSort.js';
import { usePagination } from '@/hooks/usePagination.js';
import SearchBar from '@/components/ui/SearchBar.jsx';
import FilterControls from '@/components/ui/FilterControls.jsx';
import SortControls from '@/components/ui/SortControls.jsx';
import Pagination from '@/components/ui/Pagination.jsx';
import DataTable from '@/components/ui/DataTable.jsx';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export default function AnalyticsTab() {
  const rawData = useSafeData([], 'analytics');
  
  const { searchQuery, setSearchQuery, searchedData } = useSearch(rawData, ['metric_name', 'company_name']);
  const { filters, updateFilter, filteredData } = useFilter(searchedData, { timeframe: 'all' });
  const { sortConfig, requestSort, sortedData } = useSort(filteredData, 'metric_name', 'asc');
  const { currentPage, totalPages, goToPage, paginatedData, totalItems } = usePagination(sortedData, 10);

  const columns = [
    { header: 'Metric', accessor: 'metric_name', className: 'font-medium' },
    { header: 'Company', accessor: 'company_name' },
    { header: 'Value', accessor: 'value', render: (row) => `${row.value} ${row.unit}` },
    { header: 'Timeframe', accessor: 'timeframe' },
    { header: 'Trend', accessor: 'trend', render: (row) => (
      <div className="flex items-center gap-1">
        {row.trend === 'up' && <ArrowUpRight className="w-4 h-4 text-emerald-600" />}
        {row.trend === 'down' && <ArrowDownRight className="w-4 h-4 text-red-600" />}
        {row.trend === 'neutral' && <Minus className="w-4 h-4 text-slate-500" />}
        <span className={row.trend === 'up' ? 'text-emerald-600' : row.trend === 'down' ? 'text-red-600' : 'text-slate-500'}>
          {row.change_percent}%
        </span>
      </div>
    )}
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row justify-between gap-4 bg-card p-4 rounded-xl border border-border shadow-sm">
        <SearchBar value={searchQuery} onChange={setSearchQuery} placeholder="Search metrics..." />
        <div className="flex flex-wrap items-center gap-4">
          <FilterControls 
            filters={filters} 
            onFilterChange={updateFilter}
            options={[
              { key: 'timeframe', label: 'Timeframe', values: [{label: 'Last 7 Days', value: 'Last 7 Days'}, {label: 'Last 30 Days', value: 'Last 30 Days'}] }
            ]} 
          />
          <SortControls 
            sortConfig={sortConfig} 
            onSortChange={requestSort}
            options={[
              { label: 'Metric Name', value: 'metric_name' },
              { label: 'Value', value: 'value' }
            ]}
          />
        </div>
      </div>

      <DataTable columns={columns} data={paginatedData} />
      <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={goToPage} totalItems={totalItems} />
    </div>
  );
}
