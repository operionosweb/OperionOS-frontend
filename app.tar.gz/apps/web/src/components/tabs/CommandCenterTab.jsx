
import React, { useMemo, useCallback } from 'react';
import { useTabState } from '@/contexts/TabStateContext.jsx';
import { useCommandCenter } from '@/hooks/useCommandCenter.js';
import { useTabData } from '@/hooks/useTabData.js';
import PageHeader from '@/components/PageHeader.jsx';
import CommandInput from './CommandInput.jsx';
import CommandOutput from './CommandOutput.jsx';
import { Skeleton } from '@/components/ui/skeleton.jsx';
import { TerminalSquare } from 'lucide-react';

const fetchCommandData = async () => {
  await new Promise(resolve => setTimeout(resolve, 300));
  return { status: 'ready', version: '1.0.0' };
};

const CommandCenterTab = React.memo(({ companyId }) => {
  const { handleTabChange } = useTabState();
  const fetcher = useCallback(() => fetchCommandData(), []);
  const { loading } = useTabData('command-center', companyId, fetcher);

  const handlers = useMemo(() => ({
    onNavigate: (target) => {
      const tabId = target.toLowerCase();
      if (tabId) handleTabChange(tabId);
    }
  }), [handleTabChange]);

  const { result, error, history, handleCommandSubmit, clearHistory } = useCommandCenter(handlers);

  return (
    <div className="w-full">
      <PageHeader 
        title="Command Center" 
        subtitle="Advanced deterministic execution environment."
      />
      <div className="p-[24px]">
        {loading ? (
          <div className="space-y-4">
            <Skeleton className="h-12 w-full rounded-[8px]" />
            <Skeleton className="h-[300px] w-full rounded-[8px]" />
          </div>
        ) : (
          <div className="space-y-6">
            <CommandInput onCommandSubmit={handleCommandSubmit} error={error} />
            <CommandOutput result={result} history={history} onClearHistory={clearHistory} />
          </div>
        )}
      </div>
    </div>
  );
});

CommandCenterTab.displayName = 'CommandCenterTab';
export default CommandCenterTab;
