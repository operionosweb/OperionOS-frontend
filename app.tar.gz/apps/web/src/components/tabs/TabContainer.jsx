
import React, { useState } from 'react';
import { LayoutDashboard, Building2, Users, Activity, Ship, BarChart3, Sparkles, ScrollText, Settings, FileSignature } from 'lucide-react';
import DashboardTab from './DashboardTab.jsx';
import CompaniesTab from './CompaniesTab.jsx';
import UsersTab from './UsersTab.jsx';
import OperationsTab from './OperationsTab.jsx';
import FleetTab from './FleetTab.jsx';
import FleetContractsTab from './FleetContractsTab.jsx';
import AnalyticsTab from './AnalyticsTab.jsx';
import AIInsightsTab from './AIInsightsTab.jsx';
import SystemLogsTab from './SystemLogsTab.jsx';
import SettingsTab from './SettingsTab.jsx';
import { cn } from '@/lib/utils.js';
import { useUserRole } from '@/hooks/useUserRole.js';

const CONTROL_PANEL_TABS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, component: DashboardTab, superAdminOnly: false },
  { id: 'companies', label: 'Companies', icon: Building2, component: CompaniesTab, superAdminOnly: false },
  { id: 'users', label: 'Users', icon: Users, component: UsersTab, superAdminOnly: false },
  { id: 'operations', label: 'Operations', icon: Activity, component: OperationsTab, superAdminOnly: false },
  { id: 'fleet', label: 'Fleet', icon: Ship, component: FleetTab, superAdminOnly: false },
  { id: 'fleet-contracts', label: 'Fleet Contracts', icon: FileSignature, component: FleetContractsTab, description: 'Contract management & AI risk analysis', superAdminOnly: true },
  { id: 'analytics', label: 'Analytics', icon: BarChart3, component: AnalyticsTab, superAdminOnly: false },
  { id: 'ai-insights', label: 'AI Insights', icon: Sparkles, component: AIInsightsTab, superAdminOnly: false },
  { id: 'logs', label: 'System Logs', icon: ScrollText, component: SystemLogsTab, superAdminOnly: false },
  { id: 'settings', label: 'Settings', icon: Settings, component: SettingsTab, superAdminOnly: false }
];

export default function TabContainer() {
  const [activeTabId, setActiveTabId] = useState('dashboard');
  const { role } = useUserRole();

  const visibleTabs = CONTROL_PANEL_TABS.filter(tab => 
    !tab.superAdminOnly || role === 'super_admin'
  );

  const ActiveComponent = visibleTabs.find(t => t.id === activeTabId)?.component || DashboardTab;

  return (
    <div className="flex flex-col w-full bg-card rounded-xl shadow-sm border border-border overflow-hidden min-h-[800px]">
      <div className="flex items-center overflow-x-auto border-b border-border bg-muted/30 hide-scrollbar px-2 pt-2">
        {visibleTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTabId === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTabId(tab.id)}
              className={cn(
                "flex items-center gap-2 px-4 py-3 text-sm font-medium transition-all border-b-2 whitespace-nowrap",
                isActive 
                  ? "border-primary text-primary bg-background rounded-t-lg" 
                  : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-t-lg"
              )}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>
      
      <div className="p-6 bg-background flex-1">
        <div className="animate-in fade-in duration-300">
          <ActiveComponent />
        </div>
      </div>
    </div>
  );
}
