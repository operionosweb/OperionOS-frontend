
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { CheckCircle2, XCircle, Trash2 } from 'lucide-react';

export default function CommandOutput({ result, history, onClearHistory }) {
  return (
    <div className="space-y-4">
      {result && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-md flex items-center gap-2 text-emerald-600 text-sm font-medium">
          <CheckCircle2 className="w-4 h-4" />
          {result}
        </div>
      )}

      <Card className="border-border shadow-none">
        <CardHeader className="flex flex-row items-center justify-between py-3 bg-muted/50 border-b border-border">
          <CardTitle className="text-sm font-medium text-muted-foreground">Command History</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClearHistory} className="h-8 px-2 text-muted-foreground hover:text-foreground">
            <Trash2 className="w-4 h-4 mr-1" /> Clear
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="h-[250px]">
            {history.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No commands executed yet.</p>
            ) : (
              <div className="flex flex-col divide-y divide-border/50">
                {history.map((item, i) => (
                  <div key={i} className="p-3 text-sm">
                    <div className="font-mono text-muted-foreground mb-1">&gt; {item.input}</div>
                    {item.result && (
                      <div className="text-emerald-600 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5" /> {item.result}
                      </div>
                    )}
                    {item.error && (
                      <div className="text-destructive flex items-center gap-1.5">
                        <XCircle className="w-3.5 h-3.5" /> {item.error}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
