
import React from 'react';
import { Building2, Users, Activity, ShieldCheck } from 'lucide-react';
import MetricCard from '@/components/ui/MetricCard.jsx';
import LineChart from '@/components/charts/LineChart.jsx';
import PieChart from '@/components/charts/PieChart.jsx';
import ActivityFeedItem from '@/components/ui/ActivityFeedItem.jsx';
import StatusItem from '@/components/ui/StatusItem.jsx';
import { useSafeData } from '@/hooks/useSafeData.js';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';

export default function DashboardTab() {
  const companies = useSafeData([], 'companies');
  const users = useSafeData([], 'users');
  const operations = useSafeData([], 'operations');
  const activityFeed = useSafeData([], 'activityFeed');

  // Generate chart data
  const trendData = Array.from({ length: 7 }).map((_, i) => ({
    name: `Day ${i+1}`,
    value: Math.floor(Math.random() * 50) + 10 // Safe random for visual only
  }));

  const roleDistribution = [
    { name: 'Admin', value: users.filter(u => u.role === 'admin').length || 5 },
    { name: 'Operator', value: users.filter(u => u.role === 'operator').length || 15 },
    { name: 'Viewer', value: users.filter(u => u.role === 'viewer').length || 10 }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard title="Total Companies" value={companies.length} icon={Building2} trend="up" trendValue="+12%" />
        <MetricCard title="Total Users" value={users.length} icon={Users} trend="up" trendValue="+5%" />
        <MetricCard title="Active Operations" value={operations.filter(o => o.status === 'in_progress').length} icon={Activity} trend="neutral" trendValue="0%" />
        <MetricCard title="System Health" value="99.9%" icon={ShieldCheck} trend="up" trendValue="Optimal" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">Operations Trend (Last 7 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <LineChart data={trendData} />
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">User Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <PieChart data={roleDistribution} />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="p-0 px-6 pb-6">
            {activityFeed.slice(0, 5).map(item => (
              <ActivityFeedItem key={item.id} {...item} />
            ))}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">System Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <StatusItem label="API Gateway" status="online" />
            <StatusItem label="Database Cluster" status="online" />
            <StatusItem label="Cache Layer" status="online" />
            <StatusItem label="Background Workers" status="online" />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
