
import React from 'react';
import { Sparkles, BrainCircuit, TrendingUp, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';

export default function AIInsightsTab() {
  return (
    <div className="space-y-6">
      <div className="bg-primary/10 border border-primary/20 rounded-xl p-6 flex items-start gap-4">
        <div className="p-3 bg-primary rounded-lg shrink-0">
          <Sparkles className="w-6 h-6 text-primary-foreground" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-foreground mb-2">Operion Intelligence Engine</h2>
          <p className="text-muted-foreground">
            AI-driven insights across all organizations. The system is currently analyzing fleet utilization patterns and crew rotation efficiencies to identify cross-company optimization opportunities.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <BrainCircuit className="w-5 h-5 text-primary" /> Predictive Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Forecasted operational bottlenecks based on historical data.</p>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" /> High probability of crew shortage in APAC region next month.</li>
              <li className="flex items-start gap-2"><div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5" /> Maintenance delays predicted for older vessel classes.</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-500" /> Optimization Opportunities
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Actionable recommendations to improve efficiency.</p>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5" /> Consolidate logistics providers across 3 subsidiaries to save 12%.</li>
              <li className="flex items-start gap-2"><div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5" /> Adjust rotation schedules to align with off-peak travel times.</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" /> Risk Assessment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">Identified compliance and operational risks.</p>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2"><div className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5" /> 2 companies approaching fatigue compliance limits.</li>
              <li className="flex items-start gap-2"><div className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5" /> Weather disruptions likely to impact North Sea operations.</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
