import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Lightbulb } from 'lucide-react';

const OperationalInsights = ({ insights = [] }) => {
  if (!insights || insights.length === 0) return null;

  return (
    <Card className="border-border shadow-sm bg-card">
      <CardHeader className="pb-3 border-b border-border/50 bg-muted/20">
        <CardTitle className="text-sm font-bold flex items-center gap-2 uppercase tracking-wider text-muted-foreground">
          <Lightbulb className="w-4 h-4 text-amber-500" /> Operational Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {insights.map((insight, index) => (
            <div 
              key={index} 
              className="p-4 rounded-xl bg-muted/40 border border-border/50 flex items-start gap-3 hover:bg-muted/60 transition-colors duration-200"
            >
              <Lightbulb className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-sm font-medium text-foreground leading-relaxed">
                {insight}
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default OperationalInsights;