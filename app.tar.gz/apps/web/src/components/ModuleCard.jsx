import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { CheckCircle2 } from 'lucide-react';

const ModuleCard = ({ icon: Icon, title, description, features = [] }) => {
  return (
    <Card className="p-8 border-none shadow-lg bg-card hover:shadow-xl transition-all duration-300 flex flex-col h-full">
      <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
        <Icon className="w-7 h-7 text-primary" />
      </div>
      <h3 className="text-2xl font-bold text-card-foreground mb-3">{title}</h3>
      <p className="text-muted-foreground mb-8 flex-grow">{description}</p>
      
      <ul className="space-y-3 mt-auto">
        {features.map((feature, idx) => (
          <li key={idx} className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-[hsl(var(--tertiary))] shrink-0 mt-0.5" />
            <span className="text-sm font-medium text-card-foreground/80">{feature}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
};

export default ModuleCard;