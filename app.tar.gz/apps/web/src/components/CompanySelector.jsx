
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCompanyContext } from '@/hooks/useCompanyContext.js';
import { useProductTier } from '@/hooks/useProductTier.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Building } from 'lucide-react';

export default function CompanySelector() {
  const { companyId, setCompanyId, companyProfile } = useCompanyContext();
  const { tier } = useProductTier();
  const navigate = useNavigate();

  // Only show dropdown for enterprise users
  if (tier !== 'enterprise') {
    return null;
  }

  const handleCompanyChange = (newId) => {
    setCompanyId(newId);
    navigate(`/control-panel`);
  };

  return (
    <div className="flex items-center gap-2">
      <Building className="w-4 h-4 text-muted-foreground" />
      <Select value={companyId} onValueChange={handleCompanyChange}>
        <SelectTrigger className="w-[220px] h-9 bg-background border-border">
          <SelectValue placeholder="Select Company" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="comp_default">{companyProfile.name || 'Primary Organization'}</SelectItem>
          <SelectItem value="comp_subsidiary_1">Alpha Logistics (Subsidiary)</SelectItem>
          <SelectItem value="comp_subsidiary_2">Global Marine Ltd</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}
