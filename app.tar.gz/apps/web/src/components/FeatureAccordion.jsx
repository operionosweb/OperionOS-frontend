import React from 'react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { CheckCircle2, Zap, Target, TrendingUp } from 'lucide-react';

const FeatureAccordion = ({ items }) => {
  if (!items || items.length === 0) return null;

  return (
    <Accordion type="single" collapsible className="w-full space-y-4">
      {items.map((item, index) => (
        <AccordionItem 
          key={item.id || index} 
          value={item.id || `item-${index}`} 
          className="bg-card border border-border rounded-xl overflow-hidden shadow-sm data-[state=open]:border-primary/30 data-[state=open]:shadow-md transition-all duration-200"
        >
          <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-muted/30 transition-colors group">
            <div className="flex flex-col items-start text-left gap-2 w-full pr-4">
              <div className="flex items-center justify-between w-full">
                <h4 className="text-lg font-bold group-hover:text-primary transition-colors">{item.title}</h4>
                {item.businessBenefit && (
                  <Badge variant="secondary" className="hidden md:inline-flex bg-primary/10 text-primary hover:bg-primary/20 border-none">
                    {item.businessBenefit}
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground font-normal leading-relaxed max-w-3xl">
                {item.shortDescription}
              </p>
              {item.businessBenefit && (
                <Badge variant="secondary" className="md:hidden mt-2 bg-primary/10 text-primary border-none">
                  {item.businessBenefit}
                </Badge>
              )}
            </div>
          </AccordionTrigger>
          
          <AccordionContent className="px-6 py-6 border-t border-border bg-muted/10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              
              {/* Left Column: Features & Capabilities */}
              <div className="space-y-6">
                {item.features && item.features.length > 0 && (
                  <div>
                    <h5 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-primary" /> Core Features
                    </h5>
                    <ul className="space-y-2">
                      {item.features.map((feature, idx) => (
                        <li key={idx} className="text-sm flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary/50 mt-1.5 shrink-0" />
                          <span className="text-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {item.capabilities && item.capabilities.length > 0 && (
                  <div>
                    <h5 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-500" /> Key Capabilities
                    </h5>
                    <ul className="space-y-2">
                      {item.capabilities.map((cap, idx) => (
                        <li key={idx} className="text-sm flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500/50 mt-1.5 shrink-0" />
                          <span className="text-foreground">{cap}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Right Column: Use Cases & Benefits */}
              <div className="space-y-6">
                {item.useCases && item.useCases.length > 0 && (
                  <div>
                    <h5 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                      <Target className="w-4 h-4 text-emerald-500" /> Common Use Cases
                    </h5>
                    <ul className="space-y-2">
                      {item.useCases.map((useCase, idx) => (
                        <li key={idx} className="text-sm flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500/50 mt-1.5 shrink-0" />
                          <span className="text-foreground">{useCase}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {item.benefits && item.benefits.length > 0 && (
                  <div>
                    <h5 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-blue-500" /> Measurable Benefits
                    </h5>
                    <ul className="space-y-2">
                      {item.benefits.map((benefit, idx) => (
                        <li key={idx} className="text-sm flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-blue-500/50 mt-1.5 shrink-0" />
                          <span className="text-foreground">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

            </div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
};

export default FeatureAccordion;