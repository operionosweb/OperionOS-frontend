
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip.jsx';
import { Users, Wrench as Tool, AlertTriangle, LineChart, FileText, CalendarClock, Loader2 } from 'lucide-react';
import { useActionSystem } from './ActionSystem.jsx';

const QuickActionPanel = () => {
  const { executeModalAction, executeNavigationAction, showConfirmationDialog } = useActionSystem();
  const [loadingAction, setLoadingAction] = useState(null);

  const actions = [
    { id: 'assign-crew', label: 'Assign Crew', icon: Users, desc: 'Open crew assignment workflow', handler: () => executeModalAction('assign-crew') },
    { id: 'maint', label: 'Maintenance', icon: Tool, desc: 'Schedule asset maintenance', handler: () => executeModalAction('schedule-maintenance') },
    { id: 'risk', label: 'High Risk', icon: AlertTriangle, desc: 'View assets at risk of delay', handler: () => executeNavigationAction('overview') },
    { id: 'kpi', label: 'View KPIs', icon: LineChart, desc: 'Open operational dashboards', handler: () => executeNavigationAction('overview') },
    { id: 'report', label: 'Generate Report', icon: FileText, desc: 'Export executive summary', handler: () => handleAsyncAction('report') },
    { id: 'availability', label: 'Crew Availability', icon: CalendarClock, desc: 'Check standby roster', handler: () => executeModalAction('view-roster') }
  ];

  const handleAsyncAction = (id) => {
    showConfirmationDialog({
      title: 'Generate Executive Report',
      description: 'This will compile current operational metrics into a PDF report. Proceed?',
      onConfirm: () => {
        setLoadingAction(id);
        setTimeout(() => {
          setLoadingAction(null);
        }, 1500);
      }
    });
  };

  return (
    <Card className="border-border/50 shadow-sm bg-card h-full">
      <CardHeader className="pb-3 border-b border-border/50 bg-muted/10">
        <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
          Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <TooltipProvider>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
            {actions.map((action) => {
              const Icon = action.icon;
              const isLoading = loadingAction === action.id;
              
              return (
                <Tooltip key={action.id} delayDuration={300}>
                  <TooltipTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="h-20 flex flex-col items-center justify-center gap-2 border-border/50 hover:border-primary/30 hover:bg-primary/5 transition-all w-full"
                      onClick={action.handler}
                      disabled={loadingAction !== null}
                    >
                      {isLoading ? <Loader2 className="w-5 h-5 animate-spin text-primary" /> : <Icon className="w-5 h-5 text-muted-foreground" />}
                      <span className="text-xs font-medium text-foreground">{action.label}</span>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">{action.desc}</p>
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </div>
        </TooltipProvider>
      </CardContent>
    </Card>
  );
};

export default QuickActionPanel;
