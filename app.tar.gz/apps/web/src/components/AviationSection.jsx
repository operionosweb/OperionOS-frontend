import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import MapVisualization from './MapVisualization.jsx';
import FatigueModelingCard from './FatigueModelingCard.jsx';
import IROPsRecoveryCard from './IROPsRecoveryCard.jsx';
import ComplianceSection from './ComplianceSection.jsx';
import CTASection from './CTASection.jsx';

const AviationSection = () => {
  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="pt-24 pb-12 md:pt-32 md:pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="hidden md:inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[hsl(var(--tertiary))]/10 border border-[hsl(var(--tertiary))]/20 text-[hsl(var(--tertiary))] text-sm font-bold tracking-wider mb-8">
              <span className="w-2 h-2 rounded-full bg-[hsl(var(--tertiary))] animate-pulse"></span>
              SYSTEM STATUS: OPERATIONAL
            </div>
            
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-foreground mb-6 text-balance">
              <span className="hidden md:inline">Aviation: The Operating System for </span>
              <span className="md:hidden">Mission Control </span>
              <span className="text-primary">Airline Crew Operations</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-10 leading-relaxed hidden md:block">
              A unified coordination engine that synchronizes crew scheduling, fatigue risk management, and disruption recovery in real-time.
            </p>

            <div className="hidden md:flex justify-center gap-4">
              <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-8 h-14 text-lg font-bold">
                <Link to="/demo">Book Demo</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="rounded-full px-8 h-14 text-lg font-bold">
                <Link to="/platform">View Technical Specs</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Main Dashboard Layout */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto mb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
          
          {/* Left Column: Map Visualization */}
          <div className="lg:col-span-7 h-[500px] md:h-[700px]">
            <MapVisualization />
          </div>

          {/* Right Column: Metrics & Controls */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <FatigueModelingCard />
            <IROPsRecoveryCard />
            <ComplianceSection />
          </div>

        </div>
      </section>

      {/* CTA Section */}
      <CTASection />
    </div>
  );
};

export default AviationSection;