
import React, { useState, useMemo, useEffect } from 'react';
import { formatDistanceToNow, parseISO } from 'date-fns';
import { 
  AlertTriangle, AlertCircle, Info, X, 
  Search, Filter, ChevronRight, Clock, ShieldAlert
} from 'lucide-react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { Input } from '@/components/ui/input.jsx';

const AlertFeed = ({ alerts = [], onAlertClick }) => {
  const [dismissedIds, setDismissedIds] = useState(new Set());
  const [severityFilter, setSeverityFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [now, setNow] = useState(new Date());

  // Update relative timestamps every minute
  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(interval);
  }, []);

  const activeAlerts = useMemo(() => {
    return alerts.filter(alert => {
      if (dismissedIds.has(alert.alert_id)) return false;
      if (severityFilter !== 'All' && alert.severity !== severityFilter) return false;
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return (
          alert.entity_name.toLowerCase().includes(query) ||
          alert.title.toLowerCase().includes(query) ||
          alert.alert_type.toLowerCase().includes(query)
        );
      }
      return true;
    });
  }, [alerts, dismissedIds, severityFilter, searchQuery]);

  const handleDismiss = (e, id) => {
    e.stopPropagation();
    setDismissedIds(prev => new Set(prev).add(id));
  };

  const getSeverityConfig = (severity) => {
    switch (severity) {
      case 'CRITICAL':
        return { icon: AlertTriangle, color: 'text-destructive', bg: 'bg-destructive/10', border: 'border-destructive/20' };
      case 'WARNING':
        return { icon: AlertCircle, color: 'text-orange-500', bg: 'bg-orange-500/10', border: 'border-orange-500/20' };
      default:
        return { icon: Info, color: 'text-blue-500', bg: 'bg-blue-500/10', border: 'border-blue-500/20' };
    }
  };

  return (
    <Card className="flex flex-col h-full border-border shadow-sm overflow-hidden bg-card">
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Live Intelligence Feed</h3>
            <Badge variant="secondary" className="ml-2 bg-primary/10 text-primary hover:bg-primary/20 font-mono">
              {activeAlerts.length}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            {['All', 'CRITICAL', 'WARNING'].map(level => (
              <Button
                key={level}
                variant={severityFilter === level ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSeverityFilter(level)}
                className={`h-7 text-xs ${severityFilter === level && level === 'CRITICAL' ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90' : ''} ${severityFilter === level && level === 'WARNING' ? 'bg-orange-500 text-white hover:bg-orange-600 border-transparent' : ''}`}
              >
                {level}
              </Button>
            ))}
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Filter by entity, type, or keyword..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-8 text-sm bg-background"
          />
        </div>
      </div>

      <ScrollArea className="flex-1 max-h-[400px]">
        {activeAlerts.length > 0 ? (
          <div className="divide-y divide-border">
            {activeAlerts.map(alert => {
              const { icon: Icon, color, bg, border } = getSeverityConfig(alert.severity);
              const timeAgo = formatDistanceToNow(parseISO(alert.timestamp), { addSuffix: true });
              
              return (
                <div 
                  key={alert.alert_id} 
                  className={`p-4 hover:bg-muted/50 transition-colors cursor-pointer group relative ${bg} ${border} border-l-4`}
                  onClick={() => onAlertClick && onAlertClick(alert)}
                >
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 shrink-0 ${color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1 block">
                            {alert.entity_name} • {alert.alert_type}
                          </span>
                          <h4 className="text-sm font-semibold text-foreground truncate">
                            {alert.title}
                          </h4>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-xs text-muted-foreground flex items-center gap-1 tabular-nums whitespace-nowrap">
                            <Clock className="w-3 h-3" />
                            {timeAgo}
                          </span>
                          <button 
                            onClick={(e) => handleDismiss(e, alert.alert_id)}
                            className="text-muted-foreground hover:text-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                            aria-label="Dismiss alert"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2 leading-relaxed">
                        {alert.description}
                      </p>
                      {alert.suggested_action && (
                        <div className="mt-3 flex items-center justify-between">
                          <div className="text-xs font-medium text-foreground bg-background/60 px-2 py-1 rounded-md border border-border inline-block">
                            <span className="text-primary mr-1">↳ Action:</span> 
                            {alert.suggested_action}
                          </div>
                          <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity transform group-hover:translate-x-1" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center flex flex-col items-center justify-center h-full text-muted-foreground">
            <ShieldAlert className="w-12 h-12 mb-3 opacity-20" />
            <p className="font-medium text-foreground">No active alerts</p>
            <p className="text-sm mt-1">Your feed is clear based on current filters.</p>
          </div>
        )}
      </ScrollArea>
    </Card>
  );
};

export default AlertFeed;
