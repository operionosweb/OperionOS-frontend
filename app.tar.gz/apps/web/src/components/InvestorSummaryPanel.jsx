import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { BookOpen, TrendingUp, CheckCircle2 } from 'lucide-react';
import { generateInvestorNarrative } from '@/lib/fundraisingModeHelpers.js';

const InvestorSummaryPanel = ({ operationsData, fleetList }) => {
  const narrative = generateInvestorNarrative(operationsData, fleetList);

  // Parse bold text (markdown style **bold**)
  const renderFormattedText = (text) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold text-foreground">{part.slice(2, -2)}</strong>;
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <Card className="border-border shadow-sm bg-gradient-to-br from-card to-muted/20 overflow-hidden h-full">
      <CardHeader className="pb-2 border-b border-border/50">
        <CardTitle className="text-lg font-bold flex items-center gap-2 text-foreground">
          <BookOpen className="w-5 h-5 text-primary" /> Investor Value Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="prose prose-sm dark:prose-invert max-w-none space-y-5">
          <p className="text-base text-muted-foreground leading-relaxed">
            {renderFormattedText(narrative.opening)}
          </p>

          <div className="bg-background rounded-xl p-5 border border-border/60 shadow-sm">
            <h4 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-foreground mb-3">
              <TrendingUp className="w-4 h-4 text-emerald-500" /> Value Creation Highlights
            </h4>
            <ul className="space-y-2.5 m-0 p-0 list-none">
              {narrative.bullets.map((bullet, idx) => {
                // Highlight numbers automatically if not marked down
                const formattedBullet = bullet.replace(/([\d.]+%|€[\d.,]+[MK]?)/g, '**$1**');
                return (
                  <li key={idx} className="flex items-start gap-2.5 text-sm text-muted-foreground leading-snug">
                    <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <span>{renderFormattedText(formattedBullet)}</span>
                  </li>
                );
              })}
            </ul>
          </div>

          <p className="text-sm text-muted-foreground leading-relaxed">
            {renderFormattedText(narrative.comparableAnalysis.replace(/([\d.]+%|€[\d.,]+[MK]?)/g, '**$1**'))}
          </p>

          <p className="text-sm text-muted-foreground leading-relaxed">
            {renderFormattedText(narrative.keyDrivers.replace(/([\d.]+%|€[\d.,]+[MK]?)/g, '**$1**'))}
          </p>

          <div className="mt-6 p-4 border-l-2 border-primary bg-primary/5 rounded-r-lg">
            <p className="text-sm font-medium text-foreground leading-relaxed m-0 italic">
              {renderFormattedText(narrative.thesis)}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default InvestorSummaryPanel;