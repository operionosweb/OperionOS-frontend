
import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { DollarSign, Calendar, TrendingUp } from 'lucide-react';

export default function CostBreakdownSection({ contract, scenarios }) {
  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency: contract.currency || 'USD', maximumFractionDigits: 0 }).format(val);
  const expectedScenario = scenarios?.find(s => s.scenario === 'expected') || scenarios?.[0];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card className="p-4 bg-card border-border shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-muted-foreground">
          <DollarSign className="w-4 h-4" />
          <span className="text-sm font-medium">Base Contract Value</span>
        </div>
        <p className="text-2xl font-bold text-foreground">{formatCurrency(contract.contract_value)}</p>
      </Card>

      <Card className="p-4 bg-card border-border shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-muted-foreground">
          <TrendingUp className="w-4 h-4" />
          <span className="text-sm font-medium">Expected Total Cost</span>
        </div>
        <div className="flex items-end gap-2">
          <p className="text-2xl font-bold text-foreground">{formatCurrency(expectedScenario?.totalCost || contract.contract_value)}</p>
          <Badge variant="secondary" className="mb-1 bg-muted text-muted-foreground">With Penalties</Badge>
        </div>
      </Card>

      <Card className="p-4 bg-card border-border shadow-sm">
        <div className="flex items-center gap-2 mb-2 text-muted-foreground">
          <Calendar className="w-4 h-4" />
          <span className="text-sm font-medium">Cost Run Rate</span>
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Per Month</span>
            <span className="font-medium text-foreground">{formatCurrency(expectedScenario?.costPerMonth || 0)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Per Day</span>
            <span className="font-medium text-foreground">{formatCurrency(expectedScenario?.costPerDay || 0)}</span>
          </div>
        </div>
      </Card>
    </div>
  );
}
