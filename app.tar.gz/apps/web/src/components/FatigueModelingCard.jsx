import React from 'react';
import { BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const FatigueModelingCard = () => {
  return (
    <div className="bg-card p-6 rounded-2xl shadow-lg border border-border flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-primary" />
          </div>
          <h3 className="text-lg font-bold text-foreground">Fatigue Modeling</h3>
        </div>
        <div className="hidden md:block px-3 py-1 rounded-full bg-destructive/10 text-destructive text-xs font-bold uppercase tracking-wider">
          Alert Level Index
        </div>
        <div className="md:hidden px-2 py-1 rounded-full bg-destructive/10 text-destructive text-[10px] font-bold uppercase tracking-wider">
          FATIGUE INDEX CRITICAL
        </div>
      </div>

      <div className="mb-6">
        <div className="flex justify-between text-sm mb-2">
          <span className="font-medium text-muted-foreground">Current Status</span>
          <span className="font-bold text-destructive">Elevated</span>
        </div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-destructive w-[85%] rounded-full"></div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-muted/50 p-3 rounded-xl border border-border">
          <div className="text-xs text-muted-foreground font-medium mb-1">RISK GROUP A</div>
          <div className="text-xl font-bold text-foreground">14%</div>
        </div>
        <div className="bg-muted/50 p-3 rounded-xl border border-border">
          <div className="text-xs text-muted-foreground font-medium mb-1">MEAN REST</div>
          <div className="text-xl font-bold text-foreground">11.2h</div>
        </div>
      </div>

      <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary/5 font-semibold">
        Adjust Shift Parameters
      </Button>
    </div>
  );
};

export default FatigueModelingCard;