
import React from 'react';
import { cn } from '@/lib/utils';

export default function PageHeader({ title, subtitle, actions, className }) {
  return (
    <div className={cn("page-header", className)}>
      <div className="flex flex-col gap-1">
        <h1 className="text-[28px] font-bold text-gray-900 leading-tight tracking-tight">{title}</h1>
        {subtitle && <p className="text-[14px] text-gray-500">{subtitle}</p>}
      </div>
      {actions && (
        <div className="flex items-center gap-3">
          {actions}
        </div>
      )}
    </div>
  );
}
