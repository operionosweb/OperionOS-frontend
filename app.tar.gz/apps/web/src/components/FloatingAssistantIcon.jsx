import React from 'react';
import { useProductTier } from '@/hooks/useProductTier.js';
import RoleBasedAI from './RoleBasedAI.jsx';

export default function FloatingAssistantIcon() {
  const { hasFeature } = useProductTier();

  // Only show the AI assistant if the tier supports it
  if (!hasFeature('ai_assistant')) return null;

  return <RoleBasedAI />;
}