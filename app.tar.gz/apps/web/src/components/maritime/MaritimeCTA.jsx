import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const MaritimeCTA = () => {
  return (
    <section className="w-full py-20 md:py-28 bg-gradient-to-br from-slate-50 to-slate-100 border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          {/* Main Heading */}
          <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight text-slate-900 mb-4 text-balance">
            Ready to Transform Your Maritime Operations?
          </h2>

          {/* Subheading - Updated Text and Color */}
          <p className="text-lg md:text-xl text-slate-700 mb-8 leading-relaxed">
            Join Operion to reduce logistics overhead by 30%.
          </p>

          {/* Description */}
          <p className="text-base text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
            Experience real-time vessel coordination, automated crew scheduling, and intelligent port logistics optimization across your entire global fleet.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-8 py-6 rounded-xl shadow-lg transition-all duration-200 flex items-center gap-2"
            >
              Schedule Demo
              <ArrowRight className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-slate-900 text-slate-900 hover:bg-slate-900 hover:text-white font-bold px-8 py-6 rounded-xl transition-all duration-200"
            >
              Learn More
            </Button>
          </div>

          {/* Trust Indicator */}
          <div className="mt-12 pt-8 border-t border-slate-200">
            <p className="text-sm font-semibold text-slate-600 uppercase tracking-wider mb-4">
              Trusted by Leading Maritime Operators
            </p>
            <div className="flex flex-wrap justify-center items-center gap-6 md:gap-8">
              <div className="text-slate-700 font-medium text-sm">Global Fleet Coverage</div>
              <div className="w-1 h-1 rounded-full bg-slate-400"></div>
              <div className="text-slate-700 font-medium text-sm">24/7 Operations</div>
              <div className="w-1 h-1 rounded-full bg-slate-400"></div>
              <div className="text-slate-700 font-medium text-sm">ISO Compliant</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default MaritimeCTA;