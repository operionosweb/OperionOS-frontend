import React from 'react';
import { MapPin, Anchor } from 'lucide-react';

const PortLogisticsCard = () => {
  return (
    <div className="bg-secondary rounded-2xl shadow-lg border border-secondary-foreground/10 p-6 relative overflow-hidden">
      <div className="flex justify-between items-start mb-6 relative z-10">
        <h3 className="text-xl font-bold text-white">Port Logistics</h3>
        <div className="px-3 py-1 bg-white/10 text-white text-xs font-bold rounded-full border border-white/20 backdrop-blur-sm">
          ACTIVE CREW CHANGES: 12 PORTS
        </div>
      </div>

      {/* Map Visualization Area */}
      <div className="relative h-48 bg-secondary-foreground/5 rounded-xl border border-white/5 mb-4 overflow-hidden flex items-center justify-center">
        {/* Abstract Map Lines */}
        <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 400 200">
          <path d="M50,100 Q150,50 250,120 T380,80" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" className="text-primary" />
          <path d="M100,150 Q200,180 300,100" fill="none" stroke="currentColor" strokeWidth="1" className="text-[hsl(var(--tertiary))]" />
        </svg>

        {/* Markers */}
        <div className="absolute top-1/4 left-1/4 flex flex-col items-center">
          <div className="w-3 h-3 bg-destructive rounded-full animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.8)]"></div>
          <span className="text-[10px] font-bold text-white mt-1 bg-secondary/80 px-1.5 py-0.5 rounded">Port Singapore (Congested)</span>
        </div>

        <div className="absolute bottom-1/3 right-1/3 flex flex-col items-center">
          <div className="w-3 h-3 bg-primary rounded-full shadow-[0_0_10px_rgba(0,130,251,0.8)]"></div>
          <span className="text-[10px] font-bold text-white mt-1 bg-secondary/80 px-1.5 py-0.5 rounded">Port Rotterdam (Down)</span>
        </div>

        <div className="absolute top-1/2 right-1/4 flex flex-col items-center">
          <Anchor className="w-5 h-5 text-[hsl(var(--tertiary))] drop-shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
          <span className="text-[10px] font-bold text-[hsl(var(--tertiary))] mt-1 bg-secondary/80 px-1.5 py-0.5 rounded border border-[hsl(var(--tertiary))]/30">ETA Port Busan 04:20 HRS</span>
        </div>
      </div>

      <div className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl p-4 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <MapPin className="w-4 h-4 text-primary" />
          </div>
          <div>
            <div className="text-xs text-white/60 font-medium">Next Major Change</div>
            <div className="text-sm font-bold text-white">Port Busan, KR</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs text-white/60 font-medium">Crew Inbound</div>
          <div className="text-sm font-bold text-[hsl(var(--tertiary))]">+14 M</div>
        </div>
      </div>
    </div>
  );
};

export default PortLogisticsCard;