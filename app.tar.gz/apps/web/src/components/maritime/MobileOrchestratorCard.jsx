import React from 'react';
import { AlertCircle } from 'lucide-react';

const MobileOrchestratorCard = () => {
  return (
    <div className="bg-card rounded-2xl shadow-lg border border-border p-6 flex flex-col md:flex-row gap-6 items-center">
      <div className="flex-1 space-y-4">
        <h3 className="text-xl font-bold text-foreground">Mobile Orchestrator</h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          Full native mobile app included with Operion Enterprise Architecture. Keep captains and crew synchronized globally.
        </p>
        
        <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-3 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
          <div>
            <div className="text-xs font-bold text-destructive uppercase tracking-wider mb-1">Urgent Action</div>
            <div className="text-sm font-medium text-foreground">5 Medical Certificates expiring for MV Sentinel crew.</div>
          </div>
        </div>
      </div>

      {/* Smartphone Mockup */}
      <div className="w-[240px] shrink-0 bg-secondary rounded-[2rem] p-2 shadow-2xl border-4 border-muted relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-4 bg-muted rounded-b-xl z-20"></div>
        <div className="bg-background w-full h-[320px] rounded-[1.5rem] overflow-hidden flex flex-col relative z-10">
          <div className="bg-primary p-4 pb-6 text-primary-foreground">
            <h4 className="text-sm font-bold mb-4 mt-2">Global Ops Control</h4>
            <div className="flex justify-between items-end">
              <div>
                <div className="text-[10px] opacity-80 font-medium uppercase tracking-wider mb-1">Fleet Status</div>
                <div className="text-3xl font-extrabold">94%</div>
              </div>
              <div className="text-xs bg-white/20 px-2 py-1 rounded-md font-medium">+2.4% MoM</div>
            </div>
          </div>
          
          <div className="flex-1 p-3 -mt-3 bg-background rounded-t-xl space-y-3 overflow-hidden">
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider pl-1">Next Rotations</div>
            
            <div className="bg-card border border-border rounded-lg p-2.5 shadow-sm">
              <div className="text-xs font-bold text-foreground mb-1">MV SENTINEL</div>
              <div className="text-[10px] text-muted-foreground">Arrival Busan • 24 Hrs</div>
            </div>
            
            <div className="bg-card border border-border rounded-lg p-2.5 shadow-sm">
              <div className="text-xs font-bold text-foreground mb-1">CREW RELIEF ALPHA</div>
              <div className="text-[10px] text-muted-foreground">Depart Pending • Port 4</div>
            </div>
          </div>
          
          {/* Mock Bottom Nav */}
          <div className="h-12 border-t border-border bg-card flex justify-around items-center px-4">
            <div className="w-5 h-5 rounded bg-primary/20"></div>
            <div className="w-5 h-5 rounded bg-muted"></div>
            <div className="w-5 h-5 rounded bg-muted"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MobileOrchestratorCard;