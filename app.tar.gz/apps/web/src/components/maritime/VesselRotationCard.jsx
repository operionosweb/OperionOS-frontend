import React from 'react';
import { ChevronRight } from 'lucide-react';

const VesselRotationCard = () => {
  return (
    <div className="bg-card rounded-2xl shadow-lg border border-border p-6 flex flex-col h-full">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-xl font-bold text-foreground mb-1">Vessel Rotation Management</h3>
          <p className="text-sm text-muted-foreground font-medium">Global Fleet / Multi-Month Rotation Strategy</p>
        </div>
        <div className="px-3 py-1 bg-primary/10 text-primary text-xs font-bold rounded-full">
          Q3 2024 Live View
        </div>
      </div>

      <div className="space-y-4 flex-grow">
        {/* Vessel 1 */}
        <div className="bg-muted/30 rounded-xl border border-border p-4 relative overflow-hidden group hover:border-primary/30 transition-colors">
          <div className="absolute top-0 left-0 w-1 h-full bg-primary"></div>
          <div className="flex justify-between items-center mb-3 pl-2">
            <h4 className="font-bold text-foreground">MV SENTINEL</h4>
            <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-md">ROTATION ALPHA</span>
          </div>
          <div className="pl-2">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>On-Duty</span>
              <span>Transition</span>
            </div>
            <div className="progress-indicator">
              <div className="progress-indicator-fill bg-primary w-[75%]"></div>
            </div>
          </div>
        </div>

        {/* Vessel 2 */}
        <div className="bg-muted/30 rounded-xl border border-border p-4 relative overflow-hidden group hover:border-[hsl(var(--tertiary))]/30 transition-colors">
          <div className="absolute top-0 left-0 w-1 h-full bg-[hsl(var(--tertiary))]"></div>
          <div className="flex justify-between items-center mb-3 pl-2">
            <h4 className="font-bold text-foreground">RE DISCOVERY</h4>
            <span className="text-xs font-bold text-[hsl(var(--tertiary))] bg-[hsl(var(--tertiary))]/10 px-2 py-1 rounded-md">RELIEF TEAM B</span>
          </div>
          <div className="pl-2">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>Maintenance</span>
              <span>On-Duty</span>
            </div>
            <div className="progress-indicator">
              <div className="progress-indicator-fill bg-[hsl(var(--tertiary))] w-[40%]"></div>
            </div>
          </div>
        </div>

        {/* Vessel 3 */}
        <div className="bg-muted/30 rounded-xl border border-border p-4 relative overflow-hidden group hover:border-blue-400/30 transition-colors">
          <div className="absolute top-0 left-0 w-1 h-full bg-blue-400"></div>
          <div className="flex justify-between items-center mb-3 pl-2">
            <h4 className="font-bold text-foreground">GLOBAL CARRIER</h4>
            <span className="text-xs font-bold text-blue-500 bg-blue-500/10 px-2 py-1 rounded-md">MANDATORY PORT-STAY</span>
          </div>
          <div className="pl-2">
            <div className="flex justify-between text-xs text-muted-foreground mb-1">
              <span>Port-Stay</span>
              <span>Departure</span>
            </div>
            <div className="progress-indicator">
              <div className="progress-indicator-fill bg-blue-400 w-[90%]"></div>
            </div>
          </div>
        </div>
      </div>

      <button className="mt-6 w-full py-3 flex items-center justify-center gap-2 text-sm font-bold text-primary hover:bg-primary/5 rounded-xl transition-colors">
        EXPAND TIMELINE <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};

export default VesselRotationCard;