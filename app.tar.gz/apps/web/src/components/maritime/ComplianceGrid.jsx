import React from 'react';
import { Shield, Heart, FileText, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const ComplianceGrid = () => {
  return (
    <div className="mt-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">Compliance & Certifications</h2>
          <p className="text-muted-foreground">Automated tracking for STCW & Medical Clearances</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="font-semibold">Audit History</Button>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold">Add New Document</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {/* Card 1 */}
        <div className="bg-card rounded-2xl p-5 border border-border shadow-sm hover:shadow-md transition-shadow">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
            <Shield className="w-5 h-5 text-primary" />
          </div>
          <h4 className="font-bold text-foreground text-sm mb-1">STCW BASIC SAFETY</h4>
          <p className="text-xs text-muted-foreground mb-4">98% Fleet-wide Compliance</p>
          <div className="progress-indicator">
            <div className="progress-indicator-fill bg-primary w-[98%]"></div>
          </div>
        </div>

        {/* Card 2 */}
        <div className="bg-card rounded-2xl p-5 border border-border shadow-sm hover:shadow-md transition-shadow">
          <div className="w-10 h-10 rounded-xl bg-[hsl(var(--tertiary))]/10 flex items-center justify-center mb-4">
            <Heart className="w-5 h-5 text-[hsl(var(--tertiary))]" />
          </div>
          <h4 className="font-bold text-foreground text-sm mb-1">MEDICAL CLEARANCE</h4>
          <p className="text-xs text-muted-foreground mb-4">Expiring within 30 days</p>
          <div className="flex items-center gap-2 text-xs font-bold text-[hsl(var(--tertiary))] bg-[hsl(var(--tertiary))]/10 px-2 py-1 rounded-md w-fit">
            <div className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--tertiary))]"></div>
            Validated
          </div>
        </div>

        {/* Card 3 */}
        <div className="bg-card rounded-2xl p-5 border border-border shadow-sm hover:shadow-md transition-shadow">
          <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center mb-4">
            <FileText className="w-5 h-5 text-foreground" />
          </div>
          <h4 className="font-bold text-foreground text-sm mb-1">SEAFARER CONTRACTS</h4>
          <p className="text-xs text-muted-foreground mb-4">Batch Renewal Pending</p>
          <div className="flex gap-1">
            <div className="w-2 h-2 rounded-full bg-primary"></div>
            <div className="w-2 h-2 rounded-full bg-primary/40"></div>
            <div className="w-2 h-2 rounded-full bg-primary/20"></div>
          </div>
        </div>

        {/* Card 4 */}
        <div className="bg-destructive/5 rounded-2xl p-5 border border-destructive/20 shadow-sm hover:shadow-md transition-shadow">
          <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center mb-4">
            <AlertTriangle className="w-5 h-5 text-destructive" />
          </div>
          <h4 className="font-bold text-destructive text-sm mb-1">VESSEL FLAG AUDIT</h4>
          <p className="text-xs text-destructive/80 mb-4">Action required for NS Discovery</p>
          <button className="text-xs font-bold text-destructive hover:underline uppercase tracking-wider">
            View Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default ComplianceGrid;