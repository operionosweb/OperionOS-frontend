import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, FileText } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import SEOHead from '@/components/SEOHead.jsx';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';

const LegalPageLayout = ({ seoTitle, seoDescription, title, description, lastUpdated, sections }) => {
  const [activeSection, setActiveSection] = useState(sections[0]?.id || '');
  const [isMobileTocOpen, setIsMobileTocOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const sectionElements = sections.map(s => document.getElementById(s.id));
      const scrollPosition = window.scrollY + 150; // Offset for header

      for (let i = sectionElements.length - 1; i >= 0; i--) {
        const section = sectionElements[i];
        if (section && section.offsetTop <= scrollPosition) {
          setActiveSection(sections[i].id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [sections]);

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 100; // Header offset
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setIsMobileTocOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <SEOHead title={seoTitle} description={seoDescription} />
      <Header />

      <main className="flex-grow pt-20">
        {/* Hero Section */}
        <section className="bg-slate-950 py-16 md:py-24 border-b border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-2xl mb-6">
              <FileText className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 tracking-tight text-balance">
              {title}
            </h1>
            <p className="text-lg md:text-xl text-slate-300 max-w-2xl mx-auto text-balance">
              {description}
            </p>
            {lastUpdated && (
              <p className="mt-8 text-sm text-slate-400 font-medium">
                Last Updated: {lastUpdated}
              </p>
            )}
          </div>
        </section>

        {/* Content Section */}
        <section className="py-12 md:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-12 items-start">
              
              {/* Mobile TOC */}
              <div className="w-full lg:hidden mb-8">
                <Collapsible open={isMobileTocOpen} onOpenChange={setIsMobileTocOpen} className="bg-muted/30 border border-border rounded-xl overflow-hidden">
                  <CollapsibleTrigger className="w-full p-4 flex items-center justify-between font-semibold text-foreground">
                    <span>Table of Contents</span>
                    {isMobileTocOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="p-4 pt-0 border-t border-border/50 flex flex-col gap-2">
                      {sections.map((section) => (
                        <button
                          key={section.id}
                          onClick={() => scrollToSection(section.id)}
                          className={`text-left text-sm py-2 px-3 rounded-md transition-colors ${
                            activeSection === section.id 
                              ? 'bg-primary/10 text-primary font-medium' 
                              : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                          }`}
                        >
                          {section.title}
                        </button>
                      ))}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </div>

              {/* Desktop TOC (Sticky) */}
              <aside className="hidden lg:block w-64 shrink-0 sticky top-32">
                <div className="bg-muted/20 border border-border rounded-xl p-6">
                  <h3 className="font-semibold text-foreground mb-4 uppercase tracking-wider text-xs">Contents</h3>
                  <nav className="flex flex-col gap-1.5">
                    {sections.map((section) => (
                      <button
                        key={section.id}
                        onClick={() => scrollToSection(section.id)}
                        className={`text-left text-sm py-2 px-3 rounded-md transition-all duration-200 ${
                          activeSection === section.id 
                            ? 'bg-primary/10 text-primary font-medium translate-x-1' 
                            : 'text-muted-foreground hover:text-foreground hover:bg-muted/50'
                        }`}
                      >
                        {section.title}
                      </button>
                    ))}
                  </nav>
                </div>
              </aside>

              {/* Main Content */}
              <div className="flex-1 max-w-[75ch] mx-auto lg:mx-0">
                <div className="space-y-16">
                  {sections.map((section) => (
                    <div key={section.id} id={section.id} className="scroll-mt-32">
                      <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6 tracking-tight">
                        {section.title}
                      </h2>
                      <div className="prose prose-slate dark:prose-invert max-w-none text-muted-foreground leading-relaxed space-y-6">
                        {section.content}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default LegalPageLayout;