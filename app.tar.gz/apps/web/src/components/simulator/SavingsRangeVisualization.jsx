import React from 'react';
import { formatCurrency } from '@/lib/formatters.js';

const SavingsRangeVisualization = ({ min, expected, max }) => {
  // Calculate percentages for positioning
  const range = max - (min * 0.5); // Add some padding to the left
  const minPos = ((min - (min * 0.5)) / range) * 100;
  const expectedPos = ((expected - (min * 0.5)) / range) * 100;
  const maxPos = ((max - (min * 0.5)) / range) * 100;

  return (
    <div className="w-full py-8 px-4">
      <div className="text-center mb-8">
        <h3 className="text-lg font-semibold text-foreground mb-1">Estimated Savings Range</h3>
        <p className="text-sm text-muted-foreground">
          {formatCurrency(min)} – {formatCurrency(max)} per year
        </p>
      </div>

      <div className="relative w-full max-w-4xl mx-auto h-24">
        {/* Background Track */}
        <div className="absolute top-1/2 left-0 w-full h-3 -translate-y-1/2 bg-muted rounded-full overflow-hidden">
          {/* Gradient Fill */}
          <div 
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-muted-foreground/30 via-primary/60 to-primary"
            style={{ width: `${maxPos}%` }}
          />
        </div>

        {/* Markers */}
        <div 
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center"
          style={{ left: `${minPos}%` }}
        >
          <div className="w-4 h-4 rounded-full bg-background border-2 border-muted-foreground z-10" />
          <div className="absolute top-6 text-center w-24">
            <div className="text-xs font-medium text-muted-foreground">Conservative</div>
            <div className="text-xs font-semibold text-foreground">{formatCurrency(min)}</div>
          </div>
        </div>

        <div 
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center z-20"
          style={{ left: `${expectedPos}%` }}
        >
          <div className="w-6 h-6 rounded-full bg-primary border-4 border-background shadow-md" />
          <div className="absolute bottom-8 text-center w-32">
            <div className="text-xs font-bold text-primary uppercase tracking-wider bg-primary/10 px-2 py-1 rounded-full inline-block mb-1">Expected</div>
          </div>
          <div className="absolute top-8 text-center w-32">
            <div className="text-sm font-bold text-foreground">{formatCurrency(expected)}</div>
          </div>
        </div>

        <div 
          className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center"
          style={{ left: `${maxPos}%` }}
        >
          <div className="w-4 h-4 rounded-full bg-background border-2 border-primary z-10" />
          <div className="absolute top-6 text-center w-24">
            <div className="text-xs font-medium text-muted-foreground">Aggressive</div>
            <div className="text-xs font-semibold text-foreground">{formatCurrency(max)}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SavingsRangeVisualization;