import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button.jsx';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

const RefinedPilotProgram = ({ industry = 'maritime' }) => {
  const scopeText = industry === 'maritime' ? 'Single vessel or small fleet segment' : 'Single aircraft or specific route network';
  
  return (
    <div className="bg-secondary text-secondary-foreground rounded-3xl p-8 md:p-12 my-12 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
      
      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6 tracking-tight">
          Validate Savings in Your Own Operations
        </h2>
        <p className="text-lg text-secondary-foreground/80 mb-8 leading-relaxed">
          Don't rely on estimates. Start with a controlled pilot program to measure real savings before scaling. No assumptions — only proven results.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center gap-6 mb-10 text-sm font-medium">
          <div className="flex items-center justify-center gap-2 bg-background/10 px-4 py-2 rounded-full border border-secondary-foreground/10">
            <CheckCircle2 className="w-4 h-4 text-primary" />
            Typical duration: 3–6 months
          </div>
          <div className="flex items-center justify-center gap-2 bg-background/10 px-4 py-2 rounded-full border border-secondary-foreground/10">
            <CheckCircle2 className="w-4 h-4 text-primary" />
            Scope: {scopeText}
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button size="lg" className="h-14 px-8 text-base bg-primary text-primary-foreground hover:bg-primary/90" asChild>
            <Link to="/contact-sales">
              Request Pilot Program <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" className="h-14 px-8 text-base border-secondary-foreground/20 text-secondary-foreground hover:bg-secondary-foreground/10" asChild>
            <Link to="/contact">
              Speak with Operion Team
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RefinedPilotProgram;