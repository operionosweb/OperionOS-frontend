import React from 'react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion.jsx';
import { formatCurrency } from '@/lib/formatters.js';
import { Calculator, Settings2, PieChart, Clock } from 'lucide-react';

const CollapsibleExplainabilityPanel = ({ scenarioName, assumptions, breakdown, adoption, timeframe }) => {
  return (
    <div className="w-full bg-card border border-border rounded-xl overflow-hidden shadow-sm">
      <div className="px-6 py-4 bg-muted/30 border-b border-border flex items-center justify-between">
        <h3 className="font-semibold text-foreground">How the {scenarioName} scenario is calculated</h3>
      </div>
      
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="assumptions" className="border-border/50 px-6">
          <AccordionTrigger className="hover:no-underline hover:text-primary py-4">
            <div className="flex items-center gap-3 text-sm font-medium">
              <Settings2 className="w-4 h-4 text-muted-foreground" />
              Baseline Assumptions
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 text-muted-foreground">
            <ul className="space-y-2 text-sm">
              {Object.entries(assumptions).map(([key, value], idx) => (
                <li key={idx} className="flex justify-between items-start gap-4 border-b border-border/30 pb-2 last:border-0 last:pb-0">
                  <span className="font-medium text-foreground">{key}</span>
                  <span className="text-right">{value}</span>
                </li>
              ))}
            </ul>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="breakdown" className="border-border/50 px-6">
          <AccordionTrigger className="hover:no-underline hover:text-primary py-4">
            <div className="flex items-center gap-3 text-sm font-medium">
              <Calculator className="w-4 h-4 text-muted-foreground" />
              Savings Breakdown
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 text-muted-foreground">
            <div className="space-y-3 text-sm">
              {breakdown.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center">
                  <span>{item.label}</span>
                  <span className="font-medium text-foreground">{formatCurrency(item.value)}/yr</span>
                </div>
              ))}
              <div className="pt-3 mt-3 border-t border-border flex justify-between items-center font-semibold text-foreground">
                <span>Total Estimated Savings</span>
                <span className="text-primary">{formatCurrency(breakdown.reduce((acc, curr) => acc + curr.value, 0))}/yr</span>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="adoption" className="border-border/50 px-6">
          <AccordionTrigger className="hover:no-underline hover:text-primary py-4">
            <div className="flex items-center gap-3 text-sm font-medium">
              <PieChart className="w-4 h-4 text-muted-foreground" />
              Adoption Level
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 text-muted-foreground text-sm leading-relaxed">
            <p className="mb-2"><strong className="text-foreground">Assumed Usage:</strong> {adoption.percentage}%</p>
            <p>{adoption.description}</p>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="timeframe" className="border-border/50 px-6 border-b-0">
          <AccordionTrigger className="hover:no-underline hover:text-primary py-4">
            <div className="flex items-center gap-3 text-sm font-medium">
              <Clock className="w-4 h-4 text-muted-foreground" />
              Timeframe & Realization
            </div>
          </AccordionTrigger>
          <AccordionContent className="pb-4 text-muted-foreground text-sm leading-relaxed">
            <ul className="space-y-2">
              <li><strong className="text-foreground">Annualization:</strong> {timeframe.annualization}</li>
              <li><strong className="text-foreground">Ramp-up Period:</strong> {timeframe.rampUp}</li>
              <li><strong className="text-foreground">Realization Timeline:</strong> {timeframe.realization}</li>
            </ul>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

export default CollapsibleExplainabilityPanel;