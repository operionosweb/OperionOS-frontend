import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { DollarSign, TrendingDown, Clock, Leaf, Zap } from 'lucide-react';
import { formatCurrency, formatNumber } from '@/lib/formatters.js';

const SavingsSummaryCards = ({ metrics, industry = 'maritime' }) => {
  if (!metrics) return null;

  const { totalSavings, costReductionPercent, paybackMonths, fourthMetric, ranges } = metrics;

  const cards = [
    {
      title: 'Total Annual Savings',
      value: formatCurrency(totalSavings),
      subtext: ranges ? `${formatCurrency(ranges.totalSavings.min)} - ${formatCurrency(ranges.totalSavings.max)}` : 'Projected yearly impact',
      icon: DollarSign,
      colorClass: 'text-emerald-500',
      bgClass: 'bg-emerald-500/10',
      borderClass: 'border-emerald-500/20'
    },
    {
      title: 'Cost Reduction',
      value: `${formatNumber(costReductionPercent, 1)}%`,
      subtext: 'Of addressable spend',
      icon: TrendingDown,
      colorClass: 'text-blue-500',
      bgClass: 'bg-blue-500/10',
      borderClass: 'border-blue-500/20'
    },
    {
      title: 'Payback Period',
      value: `${formatNumber(paybackMonths, 1)} mo`,
      subtext: 'Estimated time to ROI',
      icon: Clock,
      colorClass: 'text-teal-500',
      bgClass: 'bg-teal-500/10',
      borderClass: 'border-teal-500/20'
    },
    {
      title: industry === 'maritime' ? 'CO₂ Reduction' : 'Fuel Efficiency Gain',
      value: industry === 'maritime' ? `${formatNumber(fourthMetric, 0)} t` : `+${formatNumber(fourthMetric, 1)}%`,
      subtext: industry === 'maritime' ? 'Annual emissions avoided' : 'Fleet-wide improvement',
      icon: industry === 'maritime' ? Leaf : Zap,
      colorClass: 'text-green-600',
      bgClass: 'bg-green-600/10',
      borderClass: 'border-green-600/20'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
      {cards.map((card, index) => (
        <Card key={index} className={`p-6 flex flex-col relative overflow-hidden border ${card.borderClass} shadow-sm hover:shadow-md transition-shadow`}>
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-sm font-medium text-muted-foreground">{card.title}</h3>
            <div className={`p-2 rounded-lg ${card.bgClass} ${card.colorClass}`}>
              <card.icon className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-auto">
            <div className={`text-3xl md:text-4xl font-bold tracking-tight tabular-nums mb-1 ${card.colorClass}`}>
              {card.value}
            </div>
            <p className="text-xs text-muted-foreground font-medium">{card.subtext}</p>
          </div>
        </Card>
      ))}
    </div>
  );
};

export default SavingsSummaryCards;