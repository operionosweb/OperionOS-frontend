import React, { useState } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';
import { ChevronDown } from 'lucide-react';
import { formatCurrency, formatNumber } from '@/lib/formatters.js';

const SavingsResultsCard = ({ title, savingsAmount, percentOfTotal, calculationBasis, expandedDetails }) => {
  const [isOpen, setIsOpen] = useState(false);

  // Ensure high contrast for Emissions and Operational Efficiency labels to meet WCAG AA
  const isHighContrastLabel = typeof title === 'string' && 
    (title.includes('Emissions') || title.includes('Operational'));
    
  const titleClass = isHighContrastLabel 
    ? "font-bold text-slate-900 dark:text-slate-50 text-lg" 
    : "font-semibold text-foreground text-lg";

  return (
    <Card className="overflow-hidden border-border/60 shadow-sm hover:shadow-md transition-all duration-200">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger className="w-full p-5 flex items-center justify-between bg-card hover:bg-muted/30 transition-colors text-left">
          <div className="flex flex-col gap-1">
            <h4 className={titleClass}>{title}</h4>
            <p className={`text-sm ${isHighContrastLabel ? 'text-slate-700 dark:text-slate-300 font-medium' : 'text-muted-foreground'}`}>
              {calculationBasis}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className={`font-bold text-xl tabular-nums ${isHighContrastLabel ? 'text-slate-900 dark:text-slate-50' : 'text-foreground'}`}>
                {formatCurrency(savingsAmount)}
              </div>
              <div className="text-xs font-medium text-primary">
                {formatNumber(percentOfTotal, 1)}% of total
              </div>
            </div>
            <div className={`p-1.5 rounded-full bg-muted transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}>
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
          <div className="p-5 pt-0 border-t border-border/50 bg-muted/10">
            <div className="grid grid-cols-2 gap-4 mt-4">
              {Object.entries(expandedDetails).map(([key, value], idx) => (
                <div key={idx} className="flex flex-col gap-1 p-3 rounded-lg bg-background border border-border/50">
                  <span className={`text-xs font-medium uppercase tracking-wider ${isHighContrastLabel ? 'text-slate-700 dark:text-slate-300' : 'text-muted-foreground'}`}>{key}</span>
                  <span className={`text-sm font-semibold tabular-nums ${isHighContrastLabel ? 'text-slate-900 dark:text-slate-50' : 'text-foreground'}`}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};

export default SavingsResultsCard;