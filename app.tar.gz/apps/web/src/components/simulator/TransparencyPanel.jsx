import React, { useState } from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible.jsx';
import { Info, ChevronDown, Calculator } from 'lucide-react';

const TransparencyPanel = ({ industry, formulas, assumptions }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Card className="border-border/60 shadow-sm overflow-hidden bg-muted/10">
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger className="w-full p-6 flex items-center justify-between hover:bg-muted/30 transition-colors">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 text-primary rounded-lg">
              <Info className="w-5 h-5" />
            </div>
            <div className="text-left">
              <h3 className="font-semibold text-foreground text-lg">How are these savings calculated?</h3>
              <p className="text-sm text-muted-foreground">View formulas, assumptions, and methodology.</p>
            </div>
          </div>
          <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        
        <CollapsibleContent className="data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
          <div className="p-6 pt-0 border-t border-border/50">
            
            <div className="mb-8 mt-4 p-4 bg-background rounded-lg border border-border/50">
              <p className="text-sm text-foreground leading-relaxed">
                Our calculations are based on industry benchmarks and proven optimization models. 
                <strong> All financial estimates are in Euros (€).</strong> Savings ranges vary by scenario: 
                Conservative (lower bound), Expected (mid-range, recommended), and Aggressive (upper bound).
              </p>
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                {industry === 'maritime' ? (
                  <>
                    <div><span className="font-medium">Fuel Savings:</span> 5% - 12% reduction</div>
                    <div><span className="font-medium">Maintenance Savings:</span> 10% - 20% reduction</div>
                    <div><span className="font-medium">Downtime Reduction:</span> 10% - 25% reduction</div>
                    <div><span className="font-medium">Emissions Savings:</span> Tied to fuel reduction</div>
                  </>
                ) : (
                  <>
                    <div><span className="font-medium">Fuel Savings:</span> 4% - 10% reduction</div>
                    <div><span className="font-medium">Maintenance Savings:</span> 8% - 15% reduction</div>
                    <div><span className="font-medium">Delay Reduction:</span> 8% - 20% reduction</div>
                    <div><span className="font-medium">Operational Efficiency:</span> 5% - 15% gain</div>
                  </>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Formulas */}
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider flex items-center gap-2">
                  <Calculator className="w-4 h-4" /> Core Formulas
                </h4>
                <div className="space-y-4">
                  {formulas.map((f, idx) => (
                    <div key={idx} className="bg-background p-4 rounded-lg border border-border/50">
                      <div className="font-medium text-sm text-foreground mb-2">{f.name}</div>
                      <code className="block text-xs text-primary bg-primary/5 p-2 rounded font-mono mb-2">
                        {f.equation}
                      </code>
                      <p className="text-xs text-muted-foreground">{f.description}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Assumptions */}
              <div>
                <h4 className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">
                  Baseline Assumptions
                </h4>
                <ul className="space-y-3">
                  {Object.entries(assumptions).map(([key, value], idx) => (
                    <li key={idx} className="flex items-start gap-3 text-sm">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                      <div>
                        <span className="font-medium text-foreground">{key}: </span>
                        <span className="text-muted-foreground">{value}</span>
                      </div>
                    </li>
                  ))}
                </ul>
                <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    <strong>Note:</strong> These calculations are estimates based on aggregated industry data. Actual results may vary based on specific operational constraints and implementation depth.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </CollapsibleContent>
      </Collapsible>
    </Card>
  );
};

export default TransparencyPanel;