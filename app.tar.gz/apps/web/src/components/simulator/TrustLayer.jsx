import React from 'react';
import { BarChart3, Target, ShieldCheck, TrendingDown, FileSearch } from 'lucide-react';

const TrustLayer = () => {
  const points = [
    {
      icon: BarChart3,
      title: 'Based on Industry Benchmarks',
      description: 'Calculations use aggregated baseline data from IATA, IMO, and existing customer deployments.'
    },
    {
      icon: Target,
      title: 'Built from Real Inefficiencies',
      description: 'Models target specific, measurable operational gaps like manual routing and reactive maintenance.'
    },
    {
      icon: ShieldCheck,
      title: 'Validated Through Simulation',
      description: 'Algorithms are back-tested against historical flight and voyage data to ensure accuracy.'
    },
    {
      icon: TrendingDown,
      title: 'Conservative Baselines',
      description: 'Our "Conservative" scenario assumes minimal adoption, ensuring realistic floor estimates.'
    },
    {
      icon: FileSearch,
      title: 'Transparent Assumptions',
      description: 'Every variable used in our calculations is visible and adjustable to match your reality.'
    }
  ];

  return (
    <div className="py-12 border-t border-border/50">
      <div className="text-center mb-10">
        <h3 className="text-2xl font-bold text-foreground mb-3">Why these estimates are realistic</h3>
        <p className="text-muted-foreground">We build trust through transparency and conservative modeling.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {points.map((point, idx) => (
          <div key={idx} className="flex gap-4 p-4 rounded-xl hover:bg-muted/30 transition-colors">
            <div className="shrink-0 mt-1">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <point.icon className="w-5 h-5 text-primary" />
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground text-sm mb-1">{point.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{point.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrustLayer;