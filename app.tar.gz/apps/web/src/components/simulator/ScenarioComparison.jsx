import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { formatCurrency, formatNumber } from '@/lib/formatters.js';
import { TrendingDown, CheckCircle2, Zap } from 'lucide-react';

const ScenarioComparison = ({ scenarios }) => {
  if (!scenarios || !scenarios.conservative || !scenarios.expected || !scenarios.aggressive) return null;

  const cards = [
    {
      id: 'conservative',
      title: 'Conservative',
      subtitle: 'Baseline Optimization',
      data: scenarios.conservative,
      icon: TrendingDown,
      highlight: false,
      description: 'Assumes minimal adoption and partial fleet rollout. Focuses on easily attainable low-hanging fruit.'
    },
    {
      id: 'expected',
      title: 'Expected',
      subtitle: 'Most Likely Outcome',
      data: scenarios.expected,
      icon: CheckCircle2,
      highlight: true,
      description: 'Based on average customer adoption and standard integration into daily operational workflows.'
    },
    {
      id: 'aggressive',
      title: 'Aggressive',
      subtitle: 'High-Performance Operations',
      data: scenarios.aggressive,
      icon: Zap,
      highlight: false,
      description: 'Assumes full fleet adoption, deep API integration, and high organizational commitment to change.'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {cards.map((card) => (
        <Card 
          key={card.id} 
          className={`relative flex flex-col h-full transition-all duration-300 ${
            card.highlight 
              ? 'ring-2 ring-primary shadow-lg scale-100 md:scale-105 z-10 bg-card' 
              : 'border-border/50 shadow-sm bg-muted/10 hover:bg-muted/20'
          }`}
        >
          {card.highlight && (
            <div className="absolute -top-3 left-1/2 -translate-x-1/2">
              <Badge className="bg-primary text-primary-foreground font-semibold tracking-wide uppercase text-[10px] px-3 py-1">
                Most Likely Outcome
              </Badge>
            </div>
          )}
          
          <CardHeader className="pb-4">
            <div className="flex items-center gap-3 mb-2">
              <div className={`p-2 rounded-lg ${card.highlight ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                <card.icon className="w-5 h-5" />
              </div>
              <div>
                <CardTitle className="text-lg">{card.title}</CardTitle>
                <p className="text-xs text-muted-foreground font-medium">{card.subtitle}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mt-2">
              {card.description}
            </p>
          </CardHeader>
          
          <CardContent className="flex-grow flex flex-col">
            <div className="mb-6">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mb-1">Total Est. Savings</p>
              <div className={`text-3xl font-bold tracking-tight ${card.highlight ? 'text-primary' : 'text-foreground'}`}>
                {formatCurrency(card.data.totalSavings)}
                <span className="text-sm font-normal text-muted-foreground ml-1">/yr</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6 p-4 rounded-xl bg-background border border-border/50">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Est. ROI</p>
                <p className="text-lg font-semibold text-foreground">{formatNumber(card.data.roiMultiple, 1)}x</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">Payback</p>
                <p className="text-lg font-semibold text-foreground">{formatNumber(card.data.paybackMonths || card.data.paybackPeriod, 1)} mo</p>
              </div>
            </div>

            <div className="mt-auto space-y-3">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Improvement Breakdown</p>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">Fuel Efficiency</span>
                <span className="font-medium text-foreground">+{formatNumber(card.data.percentageImprovements?.fuel || 0, 1)}%</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">Operational/Delay</span>
                <span className="font-medium text-foreground">+{formatNumber(card.data.percentageImprovements?.efficiency || 0, 1)}%</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">Maintenance</span>
                <span className="font-medium text-foreground">+{formatNumber(card.data.percentageImprovements?.maintenance || 0, 1)}%</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default ScenarioComparison;