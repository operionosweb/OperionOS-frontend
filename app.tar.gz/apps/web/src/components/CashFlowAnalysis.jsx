
import React from 'react';
import { Card } from '@/components/ui/card.jsx';

export default function CashFlowAnalysis({ invoiceSchedule, currency = 'USD' }) {
  const formatCurrency = (val) => new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(val);

  // Group by month for a simple timeline
  const timeline = invoiceSchedule.slice(0, 12).map(inv => ({
    month: new Date(inv.dueDate).toLocaleString('default', { month: 'short', year: '2-digit' }),
    amount: inv.amount,
    status: inv.status
  }));

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground mb-4">Upcoming 12-month payment obligations timeline.</p>
      
      <div className="flex gap-2 overflow-x-auto pb-4 snap-x">
        {timeline.map((item, idx) => (
          <Card key={idx} className="p-3 min-w-[120px] shrink-0 snap-start bg-card border-border flex flex-col items-center justify-center text-center">
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">{item.month}</p>
            <p className="text-sm font-bold text-foreground mb-2">{formatCurrency(item.amount)}</p>
            <div className={`w-2 h-2 rounded-full ${item.status === 'paid' ? 'bg-success' : item.status === 'overdue' ? 'bg-destructive' : 'bg-warning'}`} />
          </Card>
        ))}
      </div>
    </div>
  );
}
