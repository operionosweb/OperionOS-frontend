import React, { useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { AlertTriangle, Info, AlertCircle, CheckCircle2 } from 'lucide-react';
import { generateRiskForecast } from '@/lib/investorModeHelpers.js';

const OperationalRiskForecast = ({ fleetList = [] }) => {
  const risks = useMemo(() => generateRiskForecast(fleetList), [fleetList]);

  if (!fleetList.length) return null;

  const getRiskStyles = (level) => {
    switch (level) {
      case 'HIGH':
        return {
          card: 'bg-red-50/50 border-red-100 dark:bg-red-950/10 dark:border-red-900/30 hover:border-red-200',
          badge: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400',
          icon: <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-500" />
        };
      case 'MEDIUM':
        return {
          card: 'bg-amber-50/50 border-amber-100 dark:bg-amber-950/10 dark:border-amber-900/30 hover:border-amber-200',
          badge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-400',
          icon: <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-500" />
        };
      case 'LOW':
      default:
        return {
          card: 'bg-slate-50/50 border-slate-200 dark:bg-slate-900/20 dark:border-slate-800 hover:border-slate-300',
          badge: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-400',
          icon: <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-500" />
        };
    }
  };

  return (
    <Card className="border-border shadow-sm bg-card">
      <CardHeader className="pb-4 border-b border-border/50 bg-muted/10">
        <CardTitle className="text-sm font-bold flex items-center gap-2 uppercase tracking-wider text-muted-foreground">
          <AlertTriangle className="w-4 h-4 text-primary" /> Operational Risk Forecast
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {risks.map((risk) => {
            const styles = getRiskStyles(risk.level);
            return (
              <div 
                key={risk.id} 
                className={`p-4 rounded-xl border transition-all duration-200 flex flex-col gap-3 ${styles.card}`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-semibold text-foreground">{risk.name}</h4>
                    <p className="text-xs text-muted-foreground capitalize">{risk.type}</p>
                  </div>
                  <Badge variant="outline" className={`font-semibold border-transparent ${styles.badge}`}>
                    {risk.level}
                  </Badge>
                </div>
                
                <div className="mt-auto space-y-2 pt-2 border-t border-black/5 dark:border-white/5">
                  <div className="flex items-start gap-2">
                    <Info className="w-3.5 h-3.5 mt-0.5 text-muted-foreground shrink-0" />
                    <p className="text-sm text-muted-foreground leading-snug">{risk.reason}</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="shrink-0 mt-0.5">{styles.icon}</div>
                    <p className="text-sm font-medium text-foreground leading-snug">{risk.action}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default OperationalRiskForecast;