import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Input } from '@/components/ui/input.jsx';

export const AssignCrewModal = ({ isOpen, onClose, crew, onConfirm }) => {
  const [vessel, setVessel] = useState('');
  const vessels = ['MV Neptune', 'MSC Poseidon', 'CMA CGM Sealand', 'Evergreen Explorer', 'Maersk Voyager'];

  const handleConfirm = () => {
    if (vessel) {
      onConfirm(crew.id, vessel);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Assign Crew Member</DialogTitle>
          <DialogDescription>
            Assign {crew?.name} to a new vessel. Current status: {crew?.status}.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="vessel">Select Vessel</Label>
            <Select value={vessel} onValueChange={setVessel}>
              <SelectTrigger>
                <SelectValue placeholder="Select a vessel" />
              </SelectTrigger>
              <SelectContent>
                {vessels.map(v => (
                  <SelectItem key={v} value={v}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleConfirm} disabled={!vessel}>Confirm Assignment</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const ConfirmActionModal = ({ isOpen, onClose, title, description, onConfirm, isDestructive = false }) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button variant={isDestructive ? "destructive" : "default"} onClick={() => { onConfirm(); onClose(); }}>
            Confirm
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};