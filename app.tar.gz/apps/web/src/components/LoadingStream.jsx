import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Loader2 } from 'lucide-react';

const LoadingStream = ({ items, isActive }) => {
  const [completedIndex, setCompletedIndex] = useState(-1);

  useEffect(() => {
    if (!isActive) {
      setCompletedIndex(-1);
      return;
    }

    const interval = setInterval(() => {
      setCompletedIndex(prev => {
        if (prev < items.length - 1) return prev + 1;
        clearInterval(interval);
        return prev;
      });
    }, 800);

    return () => clearInterval(interval);
  }, [isActive, items.length]);

  return (
    <div className="space-y-3">
      {items.map((item, index) => {
        const isCompleted = index <= completedIndex;
        const isCurrent = index === completedIndex + 1 && isActive;
        const isPending = index > completedIndex + 1 || !isActive;

        return (
          <motion.div
            key={item}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: isPending ? 0.3 : 1, x: 0 }}
            className="flex items-center gap-3"
          >
            {isCompleted ? (
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              </motion.div>
            ) : isCurrent ? (
              <Loader2 className="h-5 w-5 text-primary animate-spin" />
            ) : (
              <div className="h-5 w-5 rounded-full border-2 border-gray-600" />
            )}
            <span className={`text-sm ${isCompleted ? 'text-gray-200' : isCurrent ? 'text-primary font-medium' : 'text-gray-500'}`}>
              {item}
            </span>
          </motion.div>
        );
      })}
    </div>
  );
};

export default LoadingStream;