import React from 'react';
import { motion } from 'framer-motion';
import { MapPin } from 'lucide-react';

const MapVisualization = () => {
  return (
    <div className="relative w-full h-full min-h-[400px] bg-secondary rounded-3xl overflow-hidden border border-border shadow-xl flex flex-col">
      {/* Desktop Header */}
      <div className="absolute top-6 left-6 z-10 hidden md:block">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[hsl(var(--tertiary))]/20 border border-[hsl(var(--tertiary))]/30 text-[hsl(var(--tertiary))] text-xs font-bold tracking-wider mb-4">
          <span className="w-2 h-2 rounded-full bg-[hsl(var(--tertiary))] animate-pulse"></span>
          SYSTEM STATUS: OPERATIONAL
        </div>
      </div>

      {/* Mobile Header */}
      <div className="absolute top-4 left-4 z-10 md:hidden">
        <div className="inline-flex items-center gap-2 px-2 py-1 rounded-full bg-[hsl(var(--tertiary))]/20 border border-[hsl(var(--tertiary))]/30 text-[hsl(var(--tertiary))] text-[10px] font-bold tracking-wider mb-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[hsl(var(--tertiary))] animate-pulse"></span>
          LIVE FLEET VIEW
        </div>
        <div className="text-white text-sm font-bold">FLIGHT AA294 ON TRACK</div>
      </div>

      {/* Map SVG Background */}
      <div className="absolute inset-0 opacity-50 flex items-center justify-center pointer-events-none">
        <svg viewBox="0 0 800 600" className="w-full h-full text-primary" fill="currentColor">
          {/* Nodes */}
          <circle cx="200" cy="250" r="4" />
          <circle cx="350" cy="180" r="5" className="text-[hsl(var(--tertiary))]" />
          <circle cx="500" cy="300" r="6" className="text-white" />
          <circle cx="650" cy="220" r="4" />
          <circle cx="400" cy="450" r="3" />
          
          {/* Paths */}
          <path d="M200,250 Q275,150 350,180" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" opacity="0.6" />
          <path d="M350,180 Q425,200 500,300" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" opacity="0.6" />
          <path d="M500,300 Q575,200 650,220" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" opacity="0.6" />
          <path d="M200,250 Q300,400 400,450" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="4 4" opacity="0.4" />
          <path d="M400,450 Q450,350 500,300" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="4 4" opacity="0.4" />
          
          {/* Glowing active path */}
          <motion.path 
            d="M200,250 Q275,150 350,180 Q425,200 500,300" 
            fill="none" 
            stroke="hsl(var(--tertiary))" 
            strokeWidth="3"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
        </svg>
      </div>

      {/* Metrics Overlay */}
      <div className="absolute bottom-6 left-6 flex flex-col md:flex-row gap-4 z-10">
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-3 md:p-4">
          <div className="text-[10px] md:text-xs font-bold text-white/60 uppercase tracking-wider mb-1">Airborne</div>
          <div className="text-2xl md:text-3xl font-extrabold text-white" style={{ fontVariantNumeric: 'tabular-nums' }}>482 <span className="text-sm font-normal text-white/60 md:hidden">Units</span></div>
        </div>
        <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-3 md:p-4">
          <div className="text-[10px] md:text-xs font-bold text-white/60 uppercase tracking-wider mb-1">Delayed</div>
          <div className="text-2xl md:text-3xl font-extrabold text-destructive" style={{ fontVariantNumeric: 'tabular-nums' }}>12 <span className="text-sm font-normal text-white/60 md:hidden">Units</span></div>
        </div>
      </div>
    </div>
  );
};

export default MapVisualization;