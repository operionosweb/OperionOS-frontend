
import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import { CheckCircle2, ArrowRight, Target } from 'lucide-react';

export default function AIRecommendationList({ recommendations = [] }) {
  if (!recommendations.length) {
    return (
      <div className="p-8 text-center border border-dashed border-border rounded-xl bg-muted/30">
        <Target className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-50" />
        <p className="text-sm font-medium text-foreground">No active recommendations</p>
        <p className="text-xs text-muted-foreground mt-1">The AI engine is monitoring your data streams.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {recommendations.map((rec) => (
        <Card key={rec.id} className="p-4 border-border bg-card shadow-sm">
          <div className="flex items-start justify-between mb-2">
            <h4 className="text-sm font-bold text-foreground">{rec.title}</h4>
            <Badge variant="outline" className={rec.effortLevel === 'High' ? 'border-destructive/30 text-destructive' : 'border-primary/30 text-primary'}>
              {rec.effortLevel} Effort
            </Badge>
          </div>
          
          <p className="text-xs text-muted-foreground mb-4">{rec.description}</p>
          
          <div className="space-y-3 mb-4">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5 block">Suggested Strategies</span>
              <ul className="space-y-1.5">
                {rec.strategies.map((strategy, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-foreground">
                    <CheckCircle2 className="w-3.5 h-3.5 text-success shrink-0 mt-0.5" />
                    <span>{strategy}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <Button size="sm" className="w-full text-xs h-8 gap-1.5">
            Execute Strategy <ArrowRight className="w-3 h-3" />
          </Button>
        </Card>
      ))}
    </div>
  );
}
