import React from 'react';
import { Card } from '@/components/ui/card.jsx';

const DisruptionControlCard = ({ icon: Icon, title, description }) => {
  return (
    <Card className="p-6 border-none shadow-md bg-card flex flex-col gap-4">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
          <Icon className="w-6 h-6 text-destructive" />
        </div>
        <h3 className="text-xl font-bold text-foreground">{title}</h3>
      </div>
      <p className="text-muted-foreground">{description}</p>
    </Card>
  );
};

export default DisruptionControlCard;