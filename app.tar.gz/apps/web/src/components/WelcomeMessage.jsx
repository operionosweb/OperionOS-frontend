
import React, { useState, useEffect } from 'react';
import { X, Sparkles } from 'lucide-react';

export default function WelcomeMessage({ onDismiss }) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Only check session storage on client side mount
    const hasBeenShown = sessionStorage.getItem('aiWelcomeShown');
    if (!hasBeenShown) {
      setIsVisible(true);
    }
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    sessionStorage.setItem('aiWelcomeShown', 'true');
    if (onDismiss) onDismiss();
  };

  if (!isVisible) return null;

  return (
    <div className="mx-4 mt-4 mb-2 p-4 bg-primary/5 border border-primary/10 rounded-xl relative shadow-sm">
      <button 
        onClick={handleDismiss}
        className="absolute top-2 right-2 p-1 text-muted-foreground hover:text-foreground rounded-full hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
        aria-label="Dismiss welcome message"
      >
        <X className="w-4 h-4" />
      </button>
      
      <div className="flex gap-3">
        <div className="mt-0.5 flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          <Sparkles className="w-4 h-4" />
        </div>
        <div className="text-sm">
          <p className="font-semibold text-foreground mb-1">Hi there.</p>
          <p className="text-muted-foreground leading-relaxed">
            I'm Operion's AI assistant. Ask me anything about our platform, logistics, or disruption management.
          </p>
        </div>
      </div>
    </div>
  );
}
