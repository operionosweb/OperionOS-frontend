import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card.jsx';
import { BarChart3, Info } from 'lucide-react';
import { calculateValuation } from '@/lib/investorPresentationHelpers.js';

const formatCurrency = (val) => {
  if (val >= 1000000) {
    return `€${(val / 1000000).toFixed(1)}M`;
  }
  return new Intl.NumberFormat('en-IE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(val);
};

const ValuationSimulator = ({ operationsData, fleetData }) => {
  const valuation = calculateValuation(operationsData, fleetData);

  const scenarios = [
    { label: 'Conservative', value: valuation.conservativeValuation, color: 'bg-slate-200 dark:bg-slate-800', text: 'text-slate-700 dark:text-slate-300' },
    { label: 'Mid-Point', value: valuation.midPointValuation, color: 'bg-primary/80', text: 'text-primary-foreground' },
    { label: 'Optimistic', value: valuation.optimisticValuation, color: 'bg-emerald-500', text: 'text-emerald-950' }
  ];

  const maxVal = valuation.optimisticValuation;

  return (
    <Card className="border-border/50 shadow-sm bg-card">
      <CardHeader className="pb-4 border-b border-border/50">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-bold flex items-center gap-2 text-foreground">
            <BarChart3 className="w-5 h-5 text-primary" /> Enterprise Valuation Scenarios
          </CardTitle>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/50 px-2.5 py-1 rounded-full">
            <Info className="w-3.5 h-3.5" /> Simulation only, not financial advice
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Chart Section */}
          <div className="lg:col-span-2 space-y-6">
            <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Projected Enterprise Value</h4>
            <div className="space-y-5">
              {scenarios.map((scenario, idx) => {
                const widthPct = (scenario.value / maxVal) * 100;
                return (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between text-sm font-medium">
                      <span className="text-foreground">{scenario.label}</span>
                      <span className="tabular-nums font-bold">{formatCurrency(scenario.value)}</span>
                    </div>
                    <div className="h-8 w-full bg-muted rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${scenario.color} transition-all duration-1000 ease-out flex items-center px-4`}
                        style={{ width: `${widthPct}%` }}
                      >
                        {widthPct > 20 && (
                          <span className={`text-xs font-bold ${scenario.text}`}>
                            {formatCurrency(scenario.value)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Breakdown Section */}
          <div className="lg:col-span-1 bg-muted/30 rounded-2xl p-6 border border-border/50">
            <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">Value Creation Breakdown</h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-border/50">
                <span className="text-sm text-foreground">Operational Efficiency</span>
                <span className="text-sm font-bold tabular-nums">{formatCurrency(valuation.valueCreationBreakdown.operationalEfficiency)}</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-border/50">
                <span className="text-sm text-foreground">Revenue Uplift</span>
                <span className="text-sm font-bold tabular-nums">{formatCurrency(valuation.valueCreationBreakdown.revenueUplift)}</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-border/50">
                <span className="text-sm text-foreground">Valuation Premium</span>
                <span className="text-sm font-bold tabular-nums text-primary">{formatCurrency(valuation.valueCreationBreakdown.valuationPremium)}</span>
              </div>
              <div className="pt-2">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Breakdown based on mid-point scenario. Premium derived from software-defined operational leverage and predictive capabilities.
                </p>
              </div>
            </div>
          </div>

        </div>
      </CardContent>
    </Card>
  );
};

export default ValuationSimulator;