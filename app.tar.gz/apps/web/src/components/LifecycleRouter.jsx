
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLifecycleStage } from '@/hooks/useLifecycleStage.js';
import { LIFECYCLE_STAGES } from '@/constants/lifecycle.js';
import OnboardingFlow from '@/components/onboarding/OnboardingFlow.jsx';
import ControlPanelPage from '@/pages/ControlPanelPage.jsx';

export default function LifecycleRouter() {
  const { stage, refreshStage } = useLifecycleStage();
  const navigate = useNavigate();

  const handleOnboardingComplete = () => {
    refreshStage();
    navigate('/control-panel', { replace: true });
  };

  // Super Admin always bypasses onboarding
  if (stage === LIFECYCLE_STAGES.ADMIN_MODE) {
    return <ControlPanelPage />;
  }

  if (stage === LIFECYCLE_STAGES.NEW_USER || stage === LIFECYCLE_STAGES.ONBOARDING) {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  if (stage === LIFECYCLE_STAGES.ACTIVE_USER) {
    return <ControlPanelPage />;
  }

  // Fallback
  return <ControlPanelPage />;
}
