
import React, { useEffect, useRef } from 'react';
import { BellOff } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area.jsx';
import AlertCard from '@/components/AlertCard.jsx';
import AlertStats from '@/components/AlertStats.jsx';
import { useAlert } from '@/contexts/AlertContext.jsx';

export default function AlertFeedPanel() {
  const { alerts, alertStats, acknowledgeAlert, dismissAlert } = useAlert();
  const scrollRef = useRef(null);

  // Auto-scroll to top when new alerts arrive
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [alerts.length]);

  return (
    <div className="flex flex-col h-full bg-background border-l border-border">
      <div className="p-4 border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold tracking-tight text-foreground">System Alerts</h2>
        </div>
        <AlertStats alertStats={alertStats} />
      </div>

      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-3">
          {alerts.length > 0 ? (
            alerts.map(alert => (
              <AlertCard 
                key={alert.id} 
                alert={alert} 
                onAcknowledge={acknowledgeAlert}
                onDismiss={dismissAlert}
              />
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center opacity-60">
              <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                <BellOff className="w-6 h-6 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-foreground">No active alerts</p>
              <p className="text-xs text-muted-foreground mt-1">Your system is running smoothly.</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
