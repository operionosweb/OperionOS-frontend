import React from 'react';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Plane, Users, Activity, ShieldAlert, Gauge } from 'lucide-react';
import { generateExecutiveSummary } from '@/lib/investorPresentationHelpers.js';

const ExecutiveOperationsView = ({ operationsData, fleetData, crewData }) => {
  const summary = generateExecutiveSummary(operationsData, fleetData, crewData);

  const getRiskColor = (level) => {
    if (level === 'LOW') return 'text-emerald-600 bg-emerald-500/10 border-emerald-500/20';
    if (level === 'MEDIUM') return 'text-amber-600 bg-amber-500/10 border-amber-500/20';
    return 'text-red-600 bg-red-500/10 border-red-500/20';
  };

  const kpis = [
    { label: 'Total Fleet Size', value: summary.totalFleetSize, icon: Plane },
    { label: 'Active Crew', value: summary.activeCrewCount, icon: Users },
    { label: 'Health Score', value: `${summary.operationalHealthScore}/100`, icon: Activity },
    { 
      label: 'Risk Level', 
      value: summary.riskLevel, 
      icon: ShieldAlert,
      customClass: getRiskColor(summary.riskLevel)
    },
    { label: 'Utilization', value: `${summary.utilizationStatus}%`, icon: Gauge }
  ];

  return (
    <Card className="border-border/50 shadow-sm bg-card overflow-hidden">
      <CardContent className="p-0">
        <div className="flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-border/50">
          {kpis.map((kpi, idx) => {
            const Icon = kpi.icon;
            return (
              <div key={idx} className="flex-1 p-4 sm:p-6 flex items-center gap-4 hover:bg-muted/30 transition-colors">
                <div className="p-2.5 bg-muted rounded-full shrink-0">
                  <Icon className="w-5 h-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">
                    {kpi.label}
                  </p>
                  {kpi.customClass ? (
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-bold border ${kpi.customClass}`}>
                      {kpi.value}
                    </span>
                  ) : (
                    <p className="text-xl font-bold text-foreground tabular-nums">
                      {kpi.value}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default ExecutiveOperationsView;