import React from 'react';
import { Card } from '@/components/ui/card.jsx';
import { BarChart, Bar, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { name: 'A', val: 40 },
  { name: 'B', val: 70 },
  { name: 'C', val: 55 },
  { name: 'D', val: 90 },
  { name: 'E', val: 65 },
];

const IntelligenceCard = ({ icon: Icon, title, description }) => {
  return (
    <Card className="p-6 border-none shadow-md bg-card flex flex-col md:flex-row gap-6 items-start md:items-center">
      <div className="flex-1">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-xl bg-[hsl(var(--tertiary))]/10 flex items-center justify-center">
            <Icon className="w-6 h-6 text-[hsl(var(--tertiary))]" />
          </div>
          <h3 className="text-xl font-bold text-foreground">{title}</h3>
        </div>
        <p className="text-muted-foreground">{description}</p>
      </div>
      <div className="w-full md:w-48 h-24 flex-shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <Bar dataKey="val" radius={[4, 4, 0, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={index === 3 ? 'hsl(var(--tertiary))' : 'hsl(var(--primary))'} opacity={index === 3 ? 1 : 0.5} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};

export default IntelligenceCard;