
import React from 'react';
import { TrendingUp, TrendingDown as TrendDown, Minus, BrainCircuit, Activity, ShieldAlert, DollarSign, Target } from 'lucide-react';
import { Card } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Progress } from '@/components/ui/progress.jsx';

const ContractForecasting = ({ forecast }) => {
  if (!forecast) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-muted/20 rounded-xl border border-dashed border-border h-full">
        <Target className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
        <h3 className="text-lg font-medium text-foreground">Select a Contract</h3>
        <p className="text-muted-foreground text-sm mt-1">
          Choose a contract from the list to view its AI-driven forecast.
        </p>
      </div>
    );
  }

  const getTrendIcon = (trend, value) => {
    if (trend === 'up') return <span className="flex items-center text-emerald-500"><TrendingUp className="w-3 h-3 mr-1" /> +{value}%</span>;
    if (trend === 'down') return <span className="flex items-center text-destructive"><TrendDown className="w-3 h-3 mr-1" /> -{value}%</span>;
    return <span className="flex items-center text-muted-foreground"><Minus className="w-3 h-3 mr-1" /> Stable</span>;
  };

  const formatCurrency = (val) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Renewal Probability */}
        <Card className="p-5 flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Activity className="w-4 h-4" />
              <span className="text-sm font-medium">Renewal Probability</span>
            </div>
            <div className="text-xs font-semibold bg-muted px-2 py-0.5 rounded-full">
              {getTrendIcon(forecast.trend, forecast.trend_value)}
            </div>
          </div>
          <div>
            <div className="text-3xl font-bold text-foreground tabular-nums mb-2">
              {forecast.renewal_probability}%
            </div>
            <Progress 
              value={forecast.renewal_probability} 
              className="h-2" 
              indicatorClassName={forecast.renewal_probability > 70 ? 'bg-emerald-500' : forecast.renewal_probability > 40 ? 'bg-orange-500' : 'bg-destructive'} 
            />
          </div>
        </Card>

        {/* Risk of Non-Renewal */}
        <Card className="p-5 flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <ShieldAlert className="w-4 h-4" />
              <span className="text-sm font-medium">Risk of Non-Renewal</span>
            </div>
          </div>
          <div>
            <div className="text-3xl font-bold text-foreground tabular-nums mb-2">
              {forecast.risk_of_non_renewal}%
            </div>
            <Progress 
              value={forecast.risk_of_non_renewal} 
              className="h-2 bg-muted" 
              indicatorClassName={forecast.risk_of_non_renewal > 50 ? 'bg-destructive' : 'bg-orange-500'} 
            />
          </div>
        </Card>

        {/* Expected Financial Impact */}
        <Card className="p-5 flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-2 text-muted-foreground">
              <DollarSign className="w-4 h-4" />
              <span className="text-sm font-medium">Expected Impact</span>
            </div>
          </div>
          <div>
            <div className={`text-2xl font-bold tabular-nums mb-1 ${forecast.expected_financial_impact < 0 ? 'text-destructive' : 'text-emerald-500'}`}>
              {forecast.expected_financial_impact > 0 ? '+' : ''}{formatCurrency(forecast.expected_financial_impact)}
            </div>
            <p className="text-xs text-muted-foreground">Projected 12m exposure</p>
          </div>
        </Card>

        {/* Operational Dependency */}
        <Card className="p-5 flex flex-col justify-between bg-primary/5 border-primary/20">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-2 text-primary">
              <Target className="w-4 h-4" />
              <span className="text-sm font-medium">Operational Dependency</span>
            </div>
          </div>
          <div className="flex items-end gap-2">
            <div className="text-4xl font-black text-primary tabular-nums leading-none">
              {forecast.operational_dependency_score}
            </div>
            <span className="text-sm text-primary/70 mb-1 font-medium">/ 100</span>
          </div>
        </Card>

      </div>

      {/* AI Recommendation Panel */}
      <Card className="p-6 border-l-4 border-l-primary bg-gradient-to-r from-primary/5 to-transparent">
        <div className="flex items-center gap-2 mb-3">
          <BrainCircuit className="w-5 h-5 text-primary" />
          <h3 className="font-semibold text-foreground">AI Forecasting Recommendation</h3>
          <Badge variant="outline" className="ml-auto bg-background text-xs font-mono">
            Confidence: {forecast.confidence_level}%
          </Badge>
        </div>
        <p className="text-foreground leading-relaxed">
          {forecast.ai_recommendation}
        </p>
        <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">Generated by Operion Predictive Engine</span>
          <button className="text-sm font-medium text-primary hover:underline">
            View Full Analysis Report &rarr;
          </button>
        </div>
      </Card>
    </div>
  );
};

export default ContractForecasting;
