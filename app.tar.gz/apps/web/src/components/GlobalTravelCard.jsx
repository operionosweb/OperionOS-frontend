import React from 'react';
import { Card } from '@/components/ui/card.jsx';

const GlobalTravelCard = ({ icon: Icon, title, description }) => {
  return (
    <Card className="p-6 border-none shadow-md bg-card flex flex-col md:flex-row gap-6 items-start md:items-center overflow-hidden relative">
      <div className="flex-1 z-10">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <h3 className="text-xl font-bold text-foreground">{title}</h3>
        </div>
        <p className="text-muted-foreground">{description}</p>
      </div>
      <div className="w-full md:w-64 h-32 bg-secondary rounded-xl relative overflow-hidden flex-shrink-0">
        <div className="absolute inset-0 opacity-50 flex items-center justify-center">
           <svg viewBox="0 0 200 100" className="w-full h-full text-primary" fill="currentColor">
            <circle cx="50" cy="50" r="2" />
            <circle cx="100" cy="30" r="3" className="text-[hsl(var(--tertiary))]" />
            <circle cx="150" cy="60" r="2" />
            <path d="M50,50 Q75,20 100,30 T150,60" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="2 2" />
          </svg>
        </div>
      </div>
    </Card>
  );
};

export default GlobalTravelCard;